"""Sync and optimize 1,000 bird sticker icons from big-year-birding into data/mini_stickers."""

from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path

from PIL import Image

REPO_ROOT = Path(__file__).resolve().parents[1]
BYB_ROOT = Path(r"C:\Users\cuteh\.gemini\antigravity\scratch\big-year-birding")
SRC_STICKERS = BYB_ROOT / "stickers"
BIRDS_1000_JSON = BYB_ROOT / "birds_1000.json"

MINI_DIR = REPO_ROOT / "data" / "mini_stickers"
ALIASES_JSON = REPO_ROOT / "data" / "sticker_aliases.json"


def _convert_one(src_path: Path) -> int:
    dst_path = MINI_DIR / f"{src_path.stem}.webp"
    with Image.open(src_path) as im:
        rgba = im.convert("RGBA")
        # Auto-crop transparent padding so the bird fills the small 24x24 tree icon nicely!
        bbox = rgba.getbbox()
        if bbox:
            rgba = rgba.crop(bbox)
        # Fit into a square 56x56 RGBA canvas centered
        canvas = Image.new("RGBA", (56, 56), (0, 0, 0, 0))
        rgba.thumbnail((54, 54), Image.Resampling.LANCZOS)
        ox = (56 - rgba.width) // 2
        oy = (56 - rgba.height) // 2
        canvas.paste(rgba, (ox, oy), rgba)
        canvas.save(dst_path, format="WEBP", quality=82, method=4)
    return dst_path.stat().st_size


def main() -> None:
    MINI_DIR.mkdir(parents=True, exist_ok=True)
    webp_files = sorted(SRC_STICKERS.glob("*.webp"))
    if not webp_files:
        raise FileNotFoundError(f"No .webp stickers found in {SRC_STICKERS}")

    # Inspect first image mode
    with Image.open(webp_files[0]) as sample:
        print(f"Sample sticker: {webp_files[0].name}, size={sample.size}, mode={sample.mode}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        sizes = list(pool.map(_convert_one, webp_files))

    total_mb = sum(sizes) / (1024 * 1024)
    print(f"Converted {len(webp_files)} mini stickers -> {MINI_DIR} ({total_mb:.2f} MB)")

    # Build Chinese & Scientific name alias lookup -> sticker stem
    by_cn: dict[str, str] = {}
    by_sci: dict[str, str] = {}

    for f in webp_files:
        stem = f.stem
        by_sci[stem.replace("_", " ").lower()] = stem

    if BIRDS_1000_JSON.exists():
        b1000 = json.loads(BIRDS_1000_JSON.read_text(encoding="utf-8"))
        for item in b1000:
            sp_id = str(item.get("species_id") or "").strip()
            if not sp_id:
                continue
            for cn_key in ("name", "ioc_zh"):
                cn_val = str(item.get(cn_key) or "").strip()
                if cn_val:
                    by_cn[cn_val] = sp_id
            sci_val = str(item.get("scientific_name") or "").strip().lower()
            if sci_val:
                by_sci[sci_val] = sp_id

    ALIASES_JSON.write_text(
        json.dumps({"by_cn": by_cn, "by_sci": by_sci}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Wrote {ALIASES_JSON} (by_cn={len(by_cn)}, by_sci={len(by_sci)})")


if __name__ == "__main__":
    main()

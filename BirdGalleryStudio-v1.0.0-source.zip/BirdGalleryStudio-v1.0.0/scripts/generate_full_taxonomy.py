"""Generate the complete enriched taxonomy_cn.csv (~11,000 global species, ~1,500 China species, Chinese orders/families, and Pinyin)."""

from __future__ import annotations

import concurrent.futures
import csv
import json
import re
import urllib.request
from pathlib import Path

from pypinyin import Style, lazy_pinyin

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_CSV = REPO_ROOT / "build" / "raw_species.csv"
CHINA_KEYS_JSON = REPO_ROOT / "build" / "china_gbif_keys.json"
OUT_CSV = REPO_ROOT / "data" / "taxonomy_cn.csv"

# Complete authoritative Simplified Chinese names for all 45 Avian Orders
ORDER_CN_MAP: dict[str, str] = {
    "Struthioniformes": "鸵鸟目",
    "Casuariiformes": "鹤鸵目",
    "Apterygiformes": "无翼鸟目",
    "Rheiformes": "美洲鸵目",
    "Tinamiformes": "䳍形目",
    "Anseriformes": "雁形目",
    "Galliformes": "鸡形目",
    "Phoenicopteriformes": "红鹳目",
    "Podicipediformes": "䴙䴘目",
    "Musophagiformes": "蕉鹃目",
    "Otidiformes": "鸨形目",
    "Cuculiformes": "鹃形目",
    "Mesitornithiformes": "拟鹑目",
    "Pterocliformes": "沙鸡目",
    "Columbiformes": "鸽形目",
    "Opisthocomiformes": "麝雉目",
    "Gruiformes": "鹤形目",
    "Charadriiformes": "鸻形目",
    "Eurypygiformes": "日鳽目",
    "Phaethontiformes": "鹲形目",
    "Gaviiformes": "潜鸟目",
    "Sphenisciformes": "企鹅目",
    "Procellariiformes": "鹱形目",
    "Ciconiiformes": "鹳形目",
    "Suliformes": "鲣鸟目",
    "Pelecaniformes": "鹈形目",
    "Caprimulgiformes": "夜鹰目",
    "Steatornithiformes": "油夜鹰目",
    "Nyctibiiformes": "林鸱目",
    "Podargiformes": "蛙口夜鹰目",
    "Aegotheliformes": "裸鼻夜鹰目",
    "Apodiformes": "雨燕目",
    "Strigiformes": "鸮形目",
    "Cathartiformes": "美洲鹫目",
    "Accipitriformes": "鹰形目",
    "Coliiformes": "鼠鸟目",
    "Leptosomiformes": "鹃鴗目",
    "Trogoniformes": "咬鹃目",
    "Bucerotiformes": "犀鸟目",
    "Coraciiformes": "佛法僧目",
    "Piciformes": "䴕形目",
    "Cariamiformes": "叫鹤目",
    "Falconiformes": "隼形目",
    "Psittaciformes": "鹦形目",
    "Passeriformes": "雀形目",
}

# Complete authoritative Simplified Chinese names for all 249 Avian Families (IOC / AviList)
FAMILY_CN_MAP: dict[str, str] = {
    "Struthionidae": "鸵鸟科",
    "Casuariidae": "鹤鸵科",
    "Apterygidae": "无翼鸟科",
    "Rheidae": "美洲鸵科",
    "Tinamidae": "䳍科",
    "Anhimidae": "叫鸭科",
    "Anseranatidae": "鹊雁科",
    "Anatidae": "鸭科",
    "Megapodiidae": "冢雉科",
    "Cracidae": "凤冠雉科",
    "Numididae": "珠鸡科",
    "Odontophoridae": "齿鹑科",
    "Phasianidae": "雉科",
    "Phoenicopteridae": "红鹳科",
    "Podicipedidae": "䴙䴘科",
    "Musophagidae": "蕉鹃科",
    "Otididae": "鸨科",
    "Cuculidae": "杜鹃科",
    "Mesitornithidae": "拟鹑科",
    "Pteroclidae": "沙鸡科",
    "Columbidae": "鸠鸽科",
    "Opisthocomidae": "麝雉科",
    "Psophiidae": "喇叭鸟科",
    "Aramidae": "秧鹤科",
    "Gruidae": "鹤科",
    "Heliornithidae": "日鷉科",
    "Sarothruridae": "侏秧鸡科",
    "Rallidae": "秧鸡科",
    "Pluvianellidae": "麦哲伦鸻科",
    "Chionidae": "鞘嘴鸥科",
    "Burhinidae": "石鸻科",
    "Pluvianidae": "埃及鸻科",
    "Recurvirostridae": "反嘴鹬科",
    "Ibidorhynchidae": "鹮嘴鹬科",
    "Haematopodidae": "蛎鹬科",
    "Charadriidae": "鸻科",
    "Pedionomidae": "领鹑科",
    "Thinocoridae": "籽鹬科",
    "Rostratulidae": "彩鹬科",
    "Jacanidae": "水雉科",
    "Scolopacidae": "鹬科",
    "Turnicidae": "三趾鹑科",
    "Dromadidae": "蟹鸻科",
    "Glareolidae": "燕鸻科",
    "Stercorariidae": "贼鸥科",
    "Alcidae": "海雀科",
    "Laridae": "鸥科",
    "Eurypygidae": "日鳽科",
    "Rhynochetidae": "鹭鹤科",
    "Phaethontidae": "鹲科",
    "Gaviidae": "潜鸟科",
    "Spheniscidae": "企鹅科",
    "Diomedeidae": "信天翁科",
    "Oceanitidae": "南极海燕科",
    "Hydrobatidae": "海燕科",
    "Procellariidae": "鹱科",
    "Ciconiidae": "鹳科",
    "Fregatidae": "军舰鸟科",
    "Sulidae": "鲣鸟科",
    "Anhingidae": "蛇鹈科",
    "Phalacrocoracidae": "鸬鹚科",
    "Threskiornithidae": "鹮科",
    "Balaenicipitidae": "鲸头鹳科",
    "Scopidae": "锤头鹳科",
    "Pelecanidae": "鹈鹕科",
    "Ardeidae": "鹭科",
    "Caprimulgidae": "夜鹰科",
    "Steatornithidae": "油夜鹰科",
    "Nyctibiidae": "林鸱科",
    "Podargidae": "蛙口夜鹰科",
    "Aegothelidae": "裸鼻夜鹰科",
    "Hemiprocnidae": "凤头雨燕科",
    "Apodidae": "雨燕科",
    "Trochilidae": "蜂鸟科",
    "Tytonidae": "草鸮科",
    "Strigidae": "鸱鸮科",
    "Cathartidae": "美洲鹫科",
    "Sagittariidae": "蛇鹫科",
    "Pandionidae": "鹗科",
    "Accipitridae": "鹰科",
    "Coliidae": "鼠鸟科",
    "Leptosomidae": "鹃鴗科",
    "Trogonidae": "咬鹃科",
    "Upupidae": "戴胜科",
    "Phoeniculidae": "林戴胜科",
    "Bucerotidae": "犀鸟科",
    "Brachypteraciidae": "地三宝鸟科",
    "Coraciidae": "佛法僧科",
    "Meropidae": "蜂虎科",
    "Todidae": "短尾鴗科",
    "Momotidae": "翠鴗科",
    "Alcedinidae": "翠鸟科",
    "Galbulidae": "鹟䴕科",
    "Bucconidae": "蓬头䴕科",
    "Megalaimidae": "拟啄木鸟科",
    "Lybiidae": "非洲拟啄木鸟科",
    "Capitonidae": "须䴕科",
    "Semnornithidae": "巨嘴拟啄木鸟科",
    "Ramphastidae": "巨嘴鸟科",
    "Indicatoridae": "响蜜䴕科",
    "Picidae": "啄木鸟科",
    "Cariamidae": "叫鹤科",
    "Falconidae": "隼科",
    "Strigopidae": "鸮鹦鹉科",
    "Cacatuidae": "凤头鹦鹉科",
    "Psittacidae": "鹦鹉科",
    "Psittaculidae": "长尾鹦鹉科",
    "Acanthisittidae": "刺鹩科",
    "Philepittidae": "裸眉鸫科",
    "Eurylaimidae": "阔嘴鸟科",
    "Calyptomenidae": "绿阔嘴鸟科",
    "Sapayoidae": "阔嘴霸鹟科",
    "Pittidae": "八色鸫科",
    "Pipridae": "娇鹟科",
    "Cotingidae": "伞鸟科",
    "Tityridae": "蒂泰霸鹟科",
    "Oxyruncidae": "尖喙霸鹟科",
    "Onychorhynchidae": "皇霸鹟科",
    "Tyrannidae": "霸鹟科",
    "Melanopareiidae": "月胸窜鸟科",
    "Conopophagidae": "食蚊鸟科",
    "Thamnophilidae": "蚁鸟科",
    "Grallariidae": "蚁八色鸫科",
    "Rhinocryptidae": "窜鸟科",
    "Formicariidae": "蚁鸫科",
    "Furnariidae": "灶鸟科",
    "Menuridae": "琴鸟科",
    "Atrichornithidae": "薮鸟科",
    "Climacteridae": "澳䴓科",
    "Ptilonorhynchidae": "园丁鸟科",
    "Maluridae": "细尾鹩莺科",
    "Dasyornithidae": "刺莺科",
    "Pardalotidae": "斑食蜜鸟科",
    "Acanthizidae": "荆莺科",
    "Meliphagidae": "吸蜜鸟科",
    "Orthonychidae": "刺尾鸫科",
    "Pomatostomidae": "澳鹛科",
    "Cinclosomatidae": "鹑鸫科",
    "Campephagidae": "山椒鸟科",
    "Mohouidae": "白头刺莺科",
    "Machaerirhynchidae": "船嘴鹟科",
    "Artamidae": "燕鵙科",
    "Rhagologidae": "斑啸鹟科",
    "Pityriasidae": "秃头鵙科",
    "Aegithinidae": "雀鹎科",
    "Malaconotidae": "丛鵙科",
    "Platysteiridae": "眼瘤鹟科",
    "Vangidae": "钩嘴鵙科",
    "Neosittidae": "澳鳾科",
    "Psophodidae": "鞭鸫科",
    "Eulacestomatidae": "肉垂犁嘴鸟科",
    "Oreoicidae": "钟鹟科",
    "Falcunculidae": "冠鵙雀科",
    "Paramythiidae": "冠啄果鸟科",
    "Vireonidae": "绿鹃科",
    "Oriolidae": "黄鹂科",
    "Pachycephalidae": "啸鹟科",
    "Rhipiduridae": "扇尾鹟科",
    "Dicruridae": "卷尾科",
    "Monarchidae": "王鹟科",
    "Corcoracidae": "澳鸦科",
    "Ifritidae": "蓝顶鹛鸫科",
    "Paradisaeidae": "极乐鸟科",
    "Melampittidae": "黑脚风鸟科",
    "Platylophidae": "冠鸦科",
    "Laniidae": "伯劳科",
    "Corvidae": "鸦科",
    "Cnemophilidae": "丝尾鸟科",
    "Melanocharitidae": "啄果鸟科",
    "Notiomystidae": "缝叶吸蜜鸟科",
    "Callaeidae": "垂耳鸦科",
    "Eupetidae": "长颈鸫科",
    "Chaetopidae": "岩跳鸫科",
    "Picathartidae": "秃颈鸦科",
    "Petroicidae": "鸲鹟科",
    "Hyliotidae": "林莺鹟科",
    "Stenostiridae": "仙鹟科",
    "Remizidae": "攀雀科",
    "Paridae": "山雀科",
    "Panuridae": "文须雀科",
    "Alaudidae": "百灵科",
    "Nicatoridae": "斗鹎科",
    "Macrosphenidae": "非洲长嘴莺科",
    "Cisticolidae": "扇尾莺科",
    "Acrocephalidae": "苇莺科",
    "Donacobiidae": "黑顶鹪莺科",
    "Bernieridae": "马岛莺科",
    "Locustellidae": "蝗莺科",
    "Pnoepygidae": "鳞胸鹪鹛科",
    "Hirundinidae": "燕科",
    "Hyliidae": "绿莺科",
    "Aegithalidae": "长尾山雀科",
    "Erythrocercidae": "红鹟科",
    "Cettiidae": "树莺科",
    "Phylloscopidae": "柳莺科",
    "Pycnonotidae": "鹎科",
    "Sylviidae": "莺鹛科",
    "Paradoxornithidae": "鸦雀科",
    "Zosteropidae": "绣眼鸟科",
    "Timaliidae": "鹛科",
    "Pellorneidae": "幽鹛科",
    "Leiothrichidae": "噪鹛科",
    "Dulidae": "棕榈䳭科",
    "Bombycillidae": "太平鸟科",
    "Ptiliogonatidae": "丝鹟科",
    "Hylocitreidae": "林啸鹟科",
    "Hypocoliidae": "连雀科",
    "Regulidae": "戴菊科",
    "Tichodromidae": "旋壁雀科",
    "Sittidae": "䴓科",
    "Salpornithidae": "斑旋木雀科",
    "Certhiidae": "旋木雀科",
    "Polioptilidae": "蚋莺科",
    "Troglodytidae": "鹪鹩科",
    "Elachuridae": "丽星鹩鹛科",
    "Buphagidae": "牛椋鸟科",
    "Mimidae": "嘲鸫科",
    "Sturnidae": "椋鸟科",
    "Cinclidae": "河乌科",
    "Turdidae": "鸫科",
    "Muscicapidae": "鹟科",
    "Promeropidae": "长尾食蜜鸟科",
    "Modulatricidae": "斑喉䳭科",
    "Dicaeidae": "啄花鸟科",
    "Nectariniidae": "太阳鸟科",
    "Chloropseidae": "叶鹎科",
    "Irenidae": "和平鸟科",
    "Peucedramidae": "橄榄林莺科",
    "Urocynchramidae": "朱鹀科",
    "Ploceidae": "织雀科",
    "Viduidae": "维达雀科",
    "Estrildidae": "梅花雀科",
    "Prunellidae": "岩鹨科",
    "Passeridae": "雀科",
    "Motacillidae": "鹡鸰科",
    "Fringillidae": "燕雀科",
    "Rhodinocichlidae": "鸫唐纳雀科",
    "Calcariidae": "铁爪鹀科",
    "Emberizidae": "鹀科",
    "Passerellidae": "雀鹀科",
    "Calyptophilidae": "䳭唐纳雀科",
    "Zeledoniidae": "鹪森莺科",
    "Phaenicophilidae": "棕榈唐纳雀科",
    "Teretistridae": "古巴森莺科",
    "Icteridae": "拟鹂科",
    "Parulidae": "森莺科",
    "Cardinalidae": "美洲雀科",
    "Mitrospingidae": "绿唐纳雀科",
    "Thraupidae": "唐纳雀科",
}

# Explicit rare CJK Extension A ornithological character readings so pypinyin never misses them
RARE_BIRD_CHAR_SYLLABLES: dict[str, str] = {
    "䴙": "pi",
    "䴘": "ti",
    "䴕": "lie",
    "䴓": "shi",
    "䳭": "ji",
    "䳍": "gong",
    "鸻": "heng",
    "鹀": "wu",
    "鹨": "liu",
    "鹎": "bei",
    "鳽": "yan",
    "鸺": "xiu",
    "鹠": "liu",
    "鸮": "xiao",
    "鵟": "kuang",
    "鹞": "yao",
    "鹫": "jiu",
    "鹬": "yu",
    "鹱": "hu",
    "鹲": "meng",
    "鲣": "jian",
    "鸬": "lu",
    "鹚": "ci",
    "鹮": "huan",
    "鸨": "bao",
    "鹑": "chun",
    "雉": "zhi",
    "鹇": "xian",
    "鸠": "jiu",
    "鴗": "li",
    "鵙": "ju",
    "鹩": "liao",
    "鹛": "mei",
    "鸲": "qu",
    "鸫": "dong",
    "鹟": "weng",
    "鹡": "ji",
    "鸰": "ling",
    "椋": "liang",
    "鳾": "shi",
    "鷉": "ti",
    "塚": "zhong",
}

CHINA_GEO_KEYWORDS = (
    "中华", "中国", "华南", "华北", "华东", "华西", "台湾", "海南",
    "四川", "峨眉", "宝兴", "藏", "喜山", "秦岭", "贺兰山", "白马", "神州", "震旦",
)


def compute_bird_pinyin(name_cn: str) -> tuple[str, str]:
    """Compute accurate (pinyin_initials, pinyin_full) for a Chinese bird name."""
    if not name_cn:
        return "", ""

    # Normalize ornithological polyphones ('长尾/长嘴/长脚/黑长尾雉' -> 'chang')
    syllables: list[str] = []
    cleaned = re.sub(r"[^\u3400-\u9fff]", "", name_cn)
    for ch in cleaned:
        if ch in RARE_BIRD_CHAR_SYLLABLES:
            syllables.append(RARE_BIRD_CHAR_SYLLABLES[ch])
        elif ch == "长":
            syllables.append("chang")
        elif ch == "重":
            syllables.append("chong")
        elif ch == "奇":
            syllables.append("qi")
        elif ch == "雀":
            syllables.append("que")
        else:
            py = lazy_pinyin(ch, style=Style.NORMAL, errors="ignore")
            if py and py[0]:
                # Normalize ü/v to v so keyboard 'lv' matches '绿'
                s = py[0].lower().replace("ü", "v")
                syllables.append(s)

    initials = "".join(s[0] for s in syllables if s)
    full_py = "".join(syllables)
    return initials, full_py


def resolve_unmatched_gbif_names(unmatched_keys: list[str]) -> set[str]:
    """Resolve canonical scientific names from GBIF species API for split/synonym China taxa."""
    names: set[str] = set()

    def _fetch_one(key: str) -> list[str]:
        found: list[str] = []
        for attempt in range(3):
            try:
                url = f"https://api.gbif.org/v1/species/{key}"
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=8) as r:
                    d = json.loads(r.read().decode())
                    for field in ("canonicalName", "species"):
                        v = str(d.get(field) or "").strip()
                        if v:
                            found.append(v.lower())
                break
            except Exception:
                continue
        return found

    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        for res in pool.map(_fetch_one, unmatched_keys):
            names.update(res)
    return names


def main() -> None:
    rows = list(csv.DictReader(RAW_CSV.open("r", encoding="utf-8")))
    china_keys = set(json.loads(CHINA_KEYS_JSON.read_text(encoding="utf-8")))

    # Preserve species from existing starter CSV as definitely in_china
    existing_china_sci: set[str] = set()
    if OUT_CSV.exists():
        for r in csv.DictReader(OUT_CSV.open("r", encoding="utf-8-sig")):
            sci = (r.get("scientific_name") or "").strip().lower()
            if sci:
                existing_china_sci.add(sci)

    matched_gbif_keys = {r["gbif"].strip() for r in rows if r["gbif"].strip() in china_keys}
    unmatched_keys = sorted(china_keys - matched_gbif_keys)
    print(f"Resolving {len(unmatched_keys)} synonym/split GBIF keys...")
    extra_china_sci = resolve_unmatched_gbif_names(unmatched_keys)
    print(f"Resolved {len(extra_china_sci)} extra scientific names from GBIF.")

    out_rows: list[dict[str, str]] = []
    china_count = 0

    for r in rows:
        sci = r["scientific_name"].strip()
        if not sci:
            continue
        cn = r["name_zh_hans"].strip() or r["name_zh_hant"].strip() or r["name_en"].strip()
        en = r["name_en"].strip()
        ord_en = r["order"].strip()
        fam_en = r["family"].strip()
        ord_cn = ORDER_CN_MAP.get(ord_en, ord_en)
        fam_cn = FAMILY_CN_MAP.get(fam_en, fam_en)

        initials, full_py = compute_bird_pinyin(cn)

        sci_low = sci.lower()
        prev_ioc = r.get("previous_ioc_ids", "").replace("_", " ").lower()
        is_cn = (
            r["gbif"].strip() in china_keys
            or sci_low in existing_china_sci
            or sci_low in extra_china_sci
            or any(s in prev_ioc for s in extra_china_sci if " " in s)
            or any(kw in cn for kw in CHINA_GEO_KEYWORDS)
        )
        if is_cn:
            china_count += 1

        out_rows.append(
            {
                "scientific_name": sci,
                "common_name_cn": cn,
                "common_name_en": en,
                "order_name": ord_en,
                "order_cn": ord_cn,
                "family_name": fam_en,
                "family_cn": fam_cn,
                "pinyin_initials": initials,
                "pinyin_full": full_py,
                "in_china": "1" if is_cn else "0",
            }
        )

    fieldnames = [
        "scientific_name",
        "common_name_cn",
        "common_name_en",
        "order_name",
        "order_cn",
        "family_name",
        "family_cn",
        "pinyin_initials",
        "pinyin_full",
        "in_china",
    ]
    with OUT_CSV.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(out_rows)

    size_kb = OUT_CSV.stat().st_size / 1024
    print(f"Done! Wrote {len(out_rows)} total species ({china_count} China species) to {OUT_CSV} ({size_kb:.1f} KB)")


if __name__ == "__main__":
    main()

"""Package clean GitHub Release archives (Windows x64 portable .zip + clean source .zip)."""

from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELEASES_DIR = ROOT / "releases"
VERSION = "v1.0.0"

EXCLUDE_DIRS = {
    ".git",
    ".venv",
    ".pytest_cache",
    "__pycache__",
    "build",
    "dist",
    "releases",
    ".bird_gallery_cache",
}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".pyd", ".db", ".db-shm", ".db-wal", ".spec"}


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def build_release_archives() -> tuple[Path, Path]:
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    exe_path = ROOT / "dist" / "BirdGalleryStudio.exe"
    readme_path = ROOT / "README.md"
    if not exe_path.exists():
        raise FileNotFoundError(f"Missing executable: {exe_path}")

    win_zip = RELEASES_DIR / f"BirdGalleryStudio-{VERSION}-win64.zip"
    src_zip = RELEASES_DIR / f"BirdGalleryStudio-{VERSION}-source.zip"

    print(f"[zip] Creating portable Windows package: {win_zip} ...")
    with zipfile.ZipFile(win_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.write(exe_path, arcname="BirdGalleryStudio/BirdGalleryStudio.exe")
        if readme_path.exists():
            zf.write(readme_path, arcname="BirdGalleryStudio/README.md")

    sha_hex = _sha256_file(win_zip)
    sha_file = RELEASES_DIR / f"{win_zip.name}.sha256"
    sha_file.write_text(f"{sha_hex}  {win_zip.name}\n", encoding="utf-8")

    print(f"[zip] Creating clean source archive: {src_zip} ...")
    with zipfile.ZipFile(src_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for item in sorted(ROOT.rglob("*")):
            if item.is_dir():
                continue
            rel = item.relative_to(ROOT)
            if any(part in EXCLUDE_DIRS for part in rel.parts):
                continue
            if item.suffix.lower() in EXCLUDE_SUFFIXES:
                continue
            zf.write(item, arcname=f"BirdGalleryStudio-{VERSION}/{rel.as_posix()}")

    win_mb = win_zip.stat().st_size / (1024 * 1024)
    src_mb = src_zip.stat().st_size / (1024 * 1024)
    print(f"[done] {win_zip.name}: {win_mb:.1f} MB (SHA256: {sha_hex})")
    print(f"[done] {src_zip.name}: {src_mb:.2f} MB")
    return win_zip, src_zip


if __name__ == "__main__":
    build_release_archives()

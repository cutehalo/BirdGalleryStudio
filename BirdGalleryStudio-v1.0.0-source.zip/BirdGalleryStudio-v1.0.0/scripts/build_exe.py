"""Cross-platform build script to package BirdGalleryStudio (.exe on Windows, .app on macOS) via PyInstaller."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw

REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = REPO_ROOT / "data"
ICON_ICO_PATH = DATA_DIR / "app_icon.ico"
ICON_ICNS_PATH = DATA_DIR / "app_icon.icns"
ENTRY_SCRIPT = REPO_ROOT / "src" / "bird_gallery" / "gui" / "app.py"
DIST_DIR = REPO_ROOT / "dist"
BUILD_DIR = REPO_ROOT / "build"


def _render_icon_image(size: int = 512) -> Image.Image:
    """Render a high-res emerald & obsidian studio bird icon."""
    scale = size / 256.0
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    def _s(v: float) -> int:
        return int(round(v * scale))

    draw.rounded_rectangle(
        (_s(12), _s(12), _s(244), _s(244)),
        radius=_s(52),
        fill=(26, 36, 48, 255),
        outline=(58, 122, 254, 255),
        width=max(2, _s(6)),
    )
    draw.ellipse(
        (_s(52), _s(48), _s(204), _s(200)),
        fill=(24, 68, 62, 255),
        outline=(76, 195, 148, 255),
        width=max(2, _s(5)),
    )

    wing_main = [(_s(66), _s(148)), (_s(118), _s(78)), (_s(186), _s(92)), (_s(144), _s(142))]
    body_tail = [(_s(62), _s(166)), (_s(132), _s(126)), (_s(196), _s(146)), (_s(122), _s(174))]
    beak_head = [(_s(146), _s(108)), (_s(182), _s(98)), (_s(212), _s(108)), (_s(176), _s(124))]
    draw.polygon(wing_main, fill=(110, 231, 183, 255))
    draw.polygon(body_tail, fill=(56, 189, 248, 255))
    draw.polygon(beak_head, fill=(250, 204, 21, 255))
    return img


def generate_app_icons() -> Path:
    """Generate `.ico` (Windows) and `.icns` (macOS) application icons."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    img512 = _render_icon_image(512)
    img256 = img512.resize((256, 256), Image.Resampling.LANCZOS)
    img256.save(
        ICON_ICO_PATH,
        format="ICO",
        sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)],
    )
    print(f"[icon] Generated {ICON_ICO_PATH}")

    if sys.platform == "darwin":
        try:
            img512.save(ICON_ICNS_PATH, format="ICNS")
            print(f"[icon] Generated {ICON_ICNS_PATH}")
            return ICON_ICNS_PATH
        except Exception as exc:
            print(f"[warn] ICNS generation fallback to ICO: {exc}")
    return ICON_ICO_PATH


EXCLUDED_MODULES = [
    # Unused heavy PySide6 modules (keep QtWebEngineWidgets + its Qml/Quick/WebChannel/Positioning/PrintSupport deps!)
    "PySide6.QtWebEngineQuick",
    "PySide6.QtQuick3D",
    "PySide6.Qt3DCore",
    "PySide6.Qt3DRender",
    "PySide6.Qt3DInput",
    "PySide6.Qt3DExtras",
    "PySide6.Qt3DLogic",
    "PySide6.Qt3DAnimation",
    "PySide6.QtPdf",
    "PySide6.QtPdfWidgets",
    "PySide6.QtMultimedia",
    "PySide6.QtMultimediaWidgets",
    "PySide6.QtCharts",
    "PySide6.QtDataVisualization",
    "PySide6.QtGraphs",
    "PySide6.QtDesigner",
    "PySide6.QtUiTools",
    "PySide6.QtSql",
    "PySide6.QtTest",
    "PySide6.QtBluetooth",
    "PySide6.QtNfc",
    "PySide6.QtSensors",
    "PySide6.QtSerialPort",
    "PySide6.QtWebSockets",
    # Unused heavy CV/AI/CLI/test modules for pure desktop studio
    "cv2",
    "torch",
    "torchvision",
    "ultralytics",
    "bioclip",
    "pytest",
    "typer",
    "rich",
    "tkinter",
]


def build() -> None:
    is_macos = sys.platform == "darwin"
    icon_file = generate_app_icons()

    taxonomy_csv = DATA_DIR / "taxonomy_cn.csv"
    if not taxonomy_csv.exists():
        raise FileNotFoundError(f"Missing taxonomy file: {taxonomy_csv}")

    sep = os.pathsep
    cmd: list[str] = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--clean",
        "--onedir" if is_macos else "--onefile",
        "--windowed",
        "--name",
        "BirdGalleryStudio",
        "--icon",
        str(icon_file),
        "--paths",
        str(REPO_ROOT / "src"),
        "--add-data",
        f"{taxonomy_csv}{sep}data",
        "--add-data",
        f"{ICON_ICO_PATH}{sep}data",
        "--add-data",
        f"{DATA_DIR / 'sticker_aliases.json'}{sep}data",
        "--add-data",
        f"{DATA_DIR / 'ebird_species_codes.json'}{sep}data",
        "--add-data",
        f"{DATA_DIR / 'mini_stickers'}{sep}data/mini_stickers",
        "--collect-binaries",
        "rawpy",
        "--hidden-import",
        "pypinyin",
        "--hidden-import",
        "PySide6.QtWebEngineWidgets",
        "--hidden-import",
        "PySide6.QtWebEngineCore",
        "--hidden-import",
        "PySide6.QtWebChannel",
        "--hidden-import",
        "PySide6.QtPrintSupport",
        "--distpath",
        str(DIST_DIR),
        "--workpath",
        str(BUILD_DIR),
        "--specpath",
        str(BUILD_DIR),
    ]

    if is_macos:
        if ICON_ICNS_PATH.exists():
            cmd.extend(["--add-data", f"{ICON_ICNS_PATH}{sep}data"])
        cmd.extend(["--osx-bundle-identifier", "com.birdgallerystudio.app"])

    for mod in EXCLUDED_MODULES:
        cmd.extend(["--exclude-module", mod])

    cmd.append(str(ENTRY_SCRIPT))

    if is_macos:
        # Clean previous macOS bundle folders before building
        for old_dir in (DIST_DIR / "BirdGalleryStudio.app", DIST_DIR / "BirdGalleryStudio"):
            if old_dir.exists():
                shutil.rmtree(old_dir, ignore_errors=True)

    print(f"[build] Running PyInstaller ({'macOS .app bundle' if is_macos else 'Windows .exe'})...")
    subprocess.run(cmd, cwd=str(REPO_ROOT), check=True)

    if is_macos:
        app_bundle = DIST_DIR / "BirdGalleryStudio.app"
        if not app_bundle.exists():
            raise FileNotFoundError(f"Expected macOS bundle was not created: {app_bundle}")
        # Ad-hoc codesign so macOS Gatekeeper / Apple Silicon allows local execution cleanly
        subprocess.run(["codesign", "--force", "--deep", "--sign", "-", str(app_bundle)], check=False)
        total_bytes = sum(f.stat().st_size for f in app_bundle.rglob("*") if f.is_file() and not f.is_symlink())
        print(f"[done] Built {app_bundle} ({total_bytes / (1024 * 1024):.1f} MB)")
    else:
        exe_path = DIST_DIR / "BirdGalleryStudio.exe"
        size_mb = exe_path.stat().st_size / (1024 * 1024)
        print(f"[done] Built {exe_path} ({size_mb:.1f} MB)")

        old_cn_exe = DIST_DIR / "鸟羽集.exe"
        if old_cn_exe.exists():
            try:
                old_cn_exe.unlink()
                print(f"[clean] Removed redundant {old_cn_exe}")
            except OSError as exc:
                print(f"[warn] Could not remove {old_cn_exe}: {exc}")


if __name__ == "__main__":
    build()

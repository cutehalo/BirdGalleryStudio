"""End-to-end tests for pipeline scanning, DB querying, manual review, culling, and archive export."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

from bird_gallery import (
    ArchiveExporter,
    BirdGalleryPipeline,
    EngineConfig,
    FilterQuery,
    GalleryDatabase,
    RawDetection,
    ReviewService,
    ReviewStatus,
    SpeciesPrediction,
)


def _create_photo(path: Path, *, blurry: bool = False) -> None:
    rng = np.random.default_rng(7)
    y, x = np.mgrid[0:320, 0:420]
    pattern = (((x // 5) + (y // 5)) % 2) * 190 + rng.integers(0, 40, size=(320, 420))
    arr = np.stack([pattern, pattern, pattern], axis=-1).clip(0, 255).astype(np.uint8)
    img = Image.fromarray(arr, mode="RGB")
    if blurry:
        img = img.filter(ImageFilter.GaussianBlur(radius=8))
    img.save(path, format="JPEG", quality=92)


class _MockDetector:
    """Returns deterministic bird detections based on image pixel variance / call counter."""

    def __init__(self, plan: dict[int, list[RawDetection]]) -> None:
        self.plan = plan
        self.calls = 0

    def detect(self, image: Image.Image) -> list[RawDetection]:
        res = self.plan.get(self.calls, [])
        self.calls += 1
        return res


class _MockClassifier:
    def __init__(self, responses: list[list[SpeciesPrediction]]) -> None:
        self.responses = responses
        self.calls = 0

    def classify(self, crop: Image.Image, top_k: int = 5) -> list[SpeciesPrediction]:
        res = self.responses[self.calls % len(self.responses)]
        self.calls += 1
        return res[:top_k]


def test_full_workflow_scan_review_cull_and_export(tmp_path: Path) -> None:
    photos_dir = tmp_path / "photos"
    photos_dir.mkdir()

    p1 = photos_dir / "01_kingfisher_sharp.jpg"
    p2 = photos_dir / "02_bulbul_blurry.jpg"
    p3 = photos_dir / "03_empty_sky.jpg"
    _create_photo(p1, blurry=False)
    _create_photo(p2, blurry=True)
    _create_photo(p3, blurry=False)

    detector = _MockDetector(
        {
            0: [RawDetection(bbox=(60, 40, 260, 240), confidence=0.93)],
            1: [RawDetection(bbox=(50, 50, 250, 250), confidence=0.81)],
            2: [],
        }
    )
    classifier = _MockClassifier(
        [
            [
                SpeciesPrediction(rank=1, scientific_name="Alcedo atthis", score=0.91),
                SpeciesPrediction(rank=2, scientific_name="Halcyon smyrnensis", score=0.05),
            ],
            [
                SpeciesPrediction(rank=1, scientific_name="Pycnonotus sinensis", score=0.42),
            ],
        ]
    )

    cfg = EngineConfig(
        db_path=tmp_path / "gallery.db",
        thumbnail_dir=tmp_path / "thumbs",
        device="cpu",
        sharpness_blur_threshold=25.0,
    )
    pipeline = BirdGalleryPipeline(cfg, detector=detector, classifier=classifier)

    # 1. Initial scan
    summary = pipeline.scan_directory(photos_dir)
    assert summary.total_discovered == 3
    assert summary.processed == 3
    assert summary.with_birds == 2
    assert summary.no_birds == 1
    assert summary.flagged_blurry == 1
    assert summary.failed == 0

    # 2. Incremental rescan skips unchanged files
    summary2 = pipeline.scan_directory(photos_dir)
    assert summary2.skipped_existing == 3
    assert summary2.processed == 0

    # 3. Query & Review
    db = GalleryDatabase(cfg.db_path)
    review = ReviewService(db)

    birds = review.search(FilterQuery(has_bird=True, sort_by="confidence_desc"))
    assert len(birds) == 2
    assert birds[0].effective_common_name_cn == "普通翠鸟"
    assert birds[0].primary_family_cn == "翠鸟科"
    assert birds[0].is_blurry is False
    assert birds[1].effective_common_name_cn == "白头鹎"
    assert birds[1].is_blurry is True

    # Low-confidence queue surfaces p2
    low_conf = review.get_low_confidence_queue(max_confidence=0.6)
    assert len(low_conf) == 1
    assert low_conf[0].file_name == "02_bulbul_blurry.jpg"

    # Confirm p1 with 5 stars, manually correct p2 to 红耳鹎
    assert birds[0].photo_id is not None and birds[1].photo_id is not None
    assert review.confirm(birds[0].photo_id, rating=5, notes="完美合焦")
    ok, cn_name, sci_name = review.correct_species(birds[1].photo_id, "红耳鹎", rating=3)
    assert ok is True
    assert cn_name == "红耳鹎"
    assert sci_name == "Pycnonotus jocosus"

    # Batch cull empty sky (dry-run then apply)
    cull_preview = review.batch_cull(reject_no_bird=True, dry_run=True)
    assert len(cull_preview) == 1
    assert cull_preview[0].file_name == "03_empty_sky.jpg"

    cull_applied = review.batch_cull(reject_no_bird=True, dry_run=False)
    assert len(cull_applied) == 1

    # Verify stats
    stats = db.get_stats()
    assert stats["total_photos"] == 3
    assert stats["with_birds"] == 2
    assert stats["rejected_photos"] == 1
    assert stats["reviewed_ok"] == 2

    # 4. Archive export (dry-run + actual copy with taxonomy hierarchy template)
    exporter = ArchiveExporter(db)
    export_dir = tmp_path / "archive"
    manifest_path = tmp_path / "manifest.json"

    dry_report = exporter.export(
        export_dir,
        FilterQuery(has_bird=True, only_reviewed=True, include_blurry=True),
        mode="copy",
        folder_template="{order_cn}/{family_cn}/{species_cn}",
        dry_run=True,
    )
    assert dry_report.exported == 2
    assert not export_dir.exists()

    real_report = exporter.export(
        export_dir,
        FilterQuery(has_bird=True, only_reviewed=True, include_blurry=True),
        mode="copy",
        folder_template="{order_cn}/{family_cn}/{species_cn}",
        dry_run=False,
        manifest_path=manifest_path,
    )
    assert real_report.exported == 2
    assert real_report.failed == 0
    assert (export_dir / "佛法僧目" / "翠鸟科" / "普通翠鸟" / "01_kingfisher_sharp.jpg").exists()
    assert (export_dir / "雀形目" / "鹎科" / "红耳鹎" / "02_bulbul_blurry.jpg").exists()
    assert manifest_path.exists()
    manifest_data = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest_data["exported"] == 2

    # 5. Export with move updates DB file_path
    move_dir = tmp_path / "moved_archive"
    move_report = exporter.export(
        move_dir,
        FilterQuery(species="普通翠鸟", has_bird=True),
        mode="move",
        folder_template="{species_cn}",
        dry_run=False,
    )
    assert move_report.exported == 1
    moved_photo = db.get_photo(birds[0].photo_id)
    assert moved_photo is not None
    assert Path(moved_photo.file_path).parent.name == "普通翠鸟"
    assert Path(moved_photo.file_path).exists()
    assert not p1.exists()

"""Automated tests for 10-step Undo (`UndoManager`, composite species+location rollback, and 10-step cap)."""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PIL import Image
from PySide6.QtWidgets import QApplication

from bird_gallery.gui.checklist_dialog import ChecklistManagerDialog
from bird_gallery.gui.main_window import MainWindow
from bird_gallery.models import FilterQuery


def test_undo_composite_actions_culling_albums_and_10_step_cap(tmp_path: Path) -> None:
    app = QApplication.instance() or QApplication([])

    photos_dir = tmp_path / "undo_birds"
    photos_dir.mkdir()
    for idx in range(2):
        arr = np.full((180, 240, 3), (50 + idx * 40, 120, 190), dtype=np.uint8)
        Image.fromarray(arr, mode="RGB").save(photos_dir / f"SHOT_{idx + 1}.jpg")

    win = MainWindow(db_path=tmp_path / "undo_gui.db", thumbnail_dir=tmp_path / "thumbs")
    win.show()
    win.catalog.import_folder(photos_dir)
    win.refresh_all()

    assert not win.btn_undo.isEnabled()
    assert win.undo_manager.count == 0

    shot1_id = win._get_selected_photos()[0].photo_id
    assert shot1_id is not None

    # Set date to 2026-11-26 (Step 1)
    win.inspector.edit_date.setText("2026-11-26")
    win.inspector._apply_date()
    assert win.undo_manager.count == 1
    assert win.btn_undo.isEnabled()
    assert "1" in win.btn_undo.text()
    # Selection MUST stay on shot1_id even after date sort order changes!
    assert win._get_selected_photos()[0].photo_id == shot1_id

    # Import a checklist on 2026-11-26 with location '广东省深圳市深圳湾公园'
    dlg = ChecklistManagerDialog(win, win.checklist_service, initial_date="2026-11-26")
    dlg.checklists_changed.connect(win._on_albums_changed)
    dlg.edit_paste_text.setPlainText(
        "观测时间：2026-11-26 08:00\n"
        "观测地点：广东省深圳市深圳湾公园\n"
        "黑脸琵鹭 12、反嘴鹬 30"
    )
    dlg._save_pasted_checklist()
    dlg.close()
    app.processEvents()

    # Step 2: Assign '黑脸琵鹭' -> ALSO auto-fills report location ('广东省深圳市深圳湾公园')!
    win.inspector.edit_species.setText("黑脸琵鹭")
    win.inspector._apply_species()
    app.processEvents()
    assert win.undo_manager.count == 2
    p_after_sp = win.db.get_photo(shot1_id)
    assert p_after_sp is not None
    assert p_after_sp.all_species_cn == ["黑脸琵鹭"]
    assert "深圳湾公园" in p_after_sp.location_name

    # Step 3: Append co-occurring species '大白鹭'
    win.inspector.edit_species.setText("大白鹭")
    win.inspector._on_plus_add_species()
    app.processEvents()
    assert win.undo_manager.count == 3
    p_step3 = win.db.get_photo(shot1_id)
    assert p_step3 is not None and p_step3.all_species_cn == ["黑脸琵鹭", "大白鹭"]

    # Step 4: Create a new album & assign photo
    win.inspector.edit_new_album.setText("年度精选集")
    win.inspector._create_and_assign_album()
    app.processEvents()
    assert win.undo_manager.count == 4
    assert len(win.catalog.list_albums()) == 1

    # Step 5: Reject ('淘汰 X') the selected photo -> vanishes from active grid!
    win.inspector._apply_pick_flag(-1)
    app.processEvents()
    assert win.undo_manager.count == 5
    assert len(win.db.query_photos(FilterQuery())) == 1  # Only SHOT_2 remains in active view

    # Undo Step 5 (Reject) -> SHOT_1 immediately returns to active grid AND is re-selected!
    assert win.trigger_undo() is True
    app.processEvents()
    assert len(win.db.query_photos(FilterQuery())) == 2
    assert win._get_selected_photos()[0].photo_id == shot1_id
    assert win.undo_manager.count == 4

    # Undo Step 4 (Create & assign album) -> newly created album is cleanly removed!
    assert win.trigger_undo() is True
    app.processEvents()
    assert len(win.catalog.list_albums()) == 0
    assert win.undo_manager.count == 3

    # Undo Step 3 (Append '大白鹭') -> back to ['黑脸琵鹭']
    assert win.trigger_undo() is True
    app.processEvents()
    p_u3 = win.db.get_photo(shot1_id)
    assert p_u3 is not None and p_u3.all_species_cn == ["黑脸琵鹭"]

    # Undo Step 2 (Assign '黑脸琵鹭' + auto-filled location) -> BOTH species AND location revert!
    assert win.trigger_undo() is True
    app.processEvents()
    p_reverted = win.db.get_photo(shot1_id)
    assert p_reverted is not None
    assert p_reverted.all_species_cn == []
    assert p_reverted.location_name == ""
    assert p_reverted.location_province == ""
    assert win.catalog.get_field_guide(status_filter="lit").lit_count == 0

    # Undo Step 1 (Date) -> stack is now empty (0)
    assert win.trigger_undo() is True
    assert win.undo_manager.count == 0
    assert not win.btn_undo.isEnabled()
    assert win.trigger_undo() is False

    # Now test strict 10-step cap: perform 12 distinct operations -> only the latest 10 can be undone!
    target_id = win._get_selected_photos()[0].photo_id
    assert target_id is not None
    for i in range(1, 13):
        win.inspector.edit_notes.setPlainText(f"备注版本_{i}")
        win.inspector._apply_notes()
    app.processEvents()

    assert win.undo_manager.count == 10
    assert win.btn_undo.text() == "↶ 撤销 (10)"
    p_12 = win.db.get_photo(target_id)
    assert p_12 is not None and p_12.notes == "备注版本_12"

    # Undo all 10 retained steps:
    # Step 12 -> 11 -> 10 -> 9 -> 8 -> 7 -> 6 -> 5 -> 4 -> 3 -> 2!
    undone_steps = 0
    while win.trigger_undo():
        undone_steps += 1
    app.processEvents()

    assert undone_steps == 10
    assert win.undo_manager.count == 0
    assert not win.btn_undo.isEnabled()
    p_after_10_undos = win.db.get_photo(target_id)
    assert p_after_10_undos is not None and p_after_10_undos.notes == "备注版本_2"

    win.close()
    app.processEvents()

"""Headless smoke & non-blocking stress tests for the PySide6 desktop MainWindow."""

from __future__ import annotations

import os
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PIL import Image
from PySide6.QtWidgets import QApplication

from bird_gallery.gui.main_window import MainWindow
from bird_gallery.gui.stickers import StickerIconProvider
from bird_gallery.models import FilterQuery


def test_sticker_icon_provider_and_tree_fallback(tmp_path: Path) -> None:
    app = QApplication.instance() or QApplication([])
    provider = StickerIconProvider()

    # Species present in big-year-birding/stickers -> returns non-null QIcon
    kingfisher_icon = provider.get_species_icon("普通翠鸟", "Alcedo atthis")
    assert kingfisher_icon is not None and not kingfisher_icon.isNull()

    # Synonym mapped via birds_1000.json ('红原鸡' / '原鸡' -> Gallus_gallus.webp)
    junglefowl_icon = provider.get_species_icon("红原鸡", "Gallus gallus")
    assert junglefowl_icon is not None and not junglefowl_icon.isNull()

    # Non-China species without sticker -> returns None so tree falls back to '🐦'
    ostrich_icon = provider.get_species_icon("非洲鸵鸟", "Struthio camelus")
    assert ostrich_icon is None
    _ = app


def test_gui_main_window_workflow(tmp_path: Path) -> None:
    app = QApplication.instance() or QApplication([])

    photos_dir = tmp_path / "sample_birds"
    photos_dir.mkdir()
    for idx in range(2):
        arr = np.full((200, 260, 3), (60 + idx * 40, 130, 190), dtype=np.uint8)
        Image.fromarray(arr, mode="RGB").save(photos_dir / f"IMG_{idx + 1}.jpg")

    db_path = tmp_path / "gui_test.db"
    thumb_dir = tmp_path / "thumbs"

    win = MainWindow(db_path=db_path, thumbnail_dir=thumb_dir)
    assert win.windowTitle() == "鸟羽集"
    win.catalog.import_folder(photos_dir, default_location="深圳湾公园")
    win.refresh_all()

    assert win.grid_list.count() == 2

    # Assign species via Inspector on selected photo
    win.inspector.edit_species.setText("黑脸琵鹭")
    win.inspector._apply_species()
    app.processEvents()

    # Switch to Field Guide mode and verify 1 species is lit
    win._switch_center_mode(2)
    app.processEvents()
    overview = win.catalog.get_field_guide(status_filter="lit")
    assert overview.lit_count == 1
    assert overview.cards[0].common_name_cn == "黑脸琵鹭"

    # Jump from Field Guide to species photos
    win._jump_to_species_photos("黑脸琵鹭")
    app.processEvents()
    assert win.center_stack.currentIndex() == 0
    assert win.grid_list.count() == 1

    # Switch to Loupe preview mode
    win._switch_center_mode(1)
    app.processEvents()
    assert win.center_stack.currentIndex() == 1

    win.close()
    app.processEvents()


def test_inspector_works_on_unimported_disk_photos(tmp_path: Path) -> None:
    """Verify every Right Sidebar feature works directly when browsing un-imported disk folders."""
    app = QApplication.instance() or QApplication([])

    raw_folder = tmp_path / "unimported_sd_card"
    raw_folder.mkdir()
    arr = np.full((300, 400, 3), (30, 140, 210), dtype=np.uint8)
    Image.fromarray(arr, mode="RGB").save(raw_folder / "KINGFISHER_01.jpg")

    win = MainWindow(db_path=tmp_path / "disk_auto.db", thumbnail_dir=tmp_path / "thumbs")
    win._on_disk_folder_preview(str(raw_folder))

    deadline = time.perf_counter() + 5.0
    while time.perf_counter() < deadline:
        app.processEvents()
        if win.grid_list.count() == 1:
            break
        time.sleep(0.02)

    assert win.grid_list.count() == 1
    # Even before DB import, all Inspector controls MUST be enabled!
    assert win.inspector.edit_species.isEnabled()
    assert win.inspector.btn_plus_species.isEnabled()
    assert win.inspector.edit_location.isEnabled()
    assert win.inspector.edit_date.isEnabled()
    assert win.inspector.edit_notes.isEnabled()
    assert win.inspector._star_buttons[5].isEnabled()

    # Apply rating, pick, species, location, date, custom album, and notes!
    win.inspector._apply_rating(5)
    win.inspector._apply_pick_flag(1)
    win.inspector.edit_species.setText("普通翠鸟")
    win.inspector._apply_species()
    win.inspector.edit_location.setText("北京·玉渊潭")
    win.inspector._apply_location()
    win.inspector.edit_date.setText("2026-10-08")
    win.inspector._apply_date()
    win.inspector.edit_new_album.setText("飞版精选")
    win.inspector._create_and_assign_album()
    win.inspector.edit_notes.setPlainText("悬停入水瞬间")
    win.inspector._apply_notes()
    app.processEvents()

    # Verify auto-indexed record in SQLite has all attributes & album membership
    rows = win.db.query_photos(FilterQuery())
    assert len(rows) == 1
    rec = win.db.get_photo(rows[0].photo_id or -1)
    assert rec is not None
    assert rec.rating == 5
    assert rec.pick_flag == 1
    assert rec.effective_common_name_cn == "普通翠鸟"
    assert rec.location_name == "北京·玉渊潭"
    assert rec.taken_date == "2026-10-08"
    assert rec.notes == "悬停入水瞬间"
    assert len(rec.album_ids) == 1

    # Verify Field Guide is lit
    guide = win.catalog.get_field_guide(status_filter="lit")
    assert guide.lit_count == 1
    assert guide.cards[0].common_name_cn == "普通翠鸟"

    win.close()
    deadline_close = time.perf_counter() + 3.0
    while win._worker_tracker._active and time.perf_counter() < deadline_close:
        app.processEvents()
        time.sleep(0.02)


def test_rapid_disk_folder_switching_never_blocks_or_crashes(tmp_path: Path) -> None:
    app = QApplication.instance() or QApplication([])

    folders: list[Path] = []
    for f_idx in range(3):
        sub = tmp_path / f"folder_{f_idx}"
        sub.mkdir()
        for img_idx in range(12):
            arr = np.full((1200, 1600, 3), ((f_idx * 50 + img_idx * 10) % 255, 110, 160), dtype=np.uint8)
            Image.fromarray(arr, mode="RGB").save(sub / f"RAW_SHOT_{img_idx:03d}.jpg", quality=85)
        folders.append(sub)

    win = MainWindow(db_path=tmp_path / "stress.db", thumbnail_dir=tmp_path / "thumbs")

    t0 = time.perf_counter()
    for folder in folders:
        win._on_disk_folder_preview(str(folder))
    elapsed_ui_ms = (time.perf_counter() - t0) * 1000.0
    assert elapsed_ui_ms < 150.0, f"UI thread blocked for {elapsed_ui_ms:.1f}ms!"

    deadline = time.perf_counter() + 8.0
    while time.perf_counter() < deadline:
        app.processEvents()
        if win.grid_list.count() == 12 and len(win._qimage_cache) >= 12:
            break
        time.sleep(0.03)

    assert win.grid_list.count() == 12
    assert len(win._qimage_cache) >= 12

    win.close()
    deadline_close = time.perf_counter() + 3.0
    while win._worker_tracker._active and time.perf_counter() < deadline_close:
        app.processEvents()
        time.sleep(0.02)


def test_location_manager_dialog_and_inspector_ebird_favorites(tmp_path: Path) -> None:
    """Verify LocationManagerDialog CRUD, eBird hotspot linking, Inspector chips, and Navigator ⭐ display."""
    from bird_gallery.ebird import EBirdLocationService
    from bird_gallery.gui.location_dialog import LocationManagerDialog

    app = QApplication.instance() or QApplication([])

    photos_dir = tmp_path / "spot_birds"
    photos_dir.mkdir()
    arr = np.full((180, 240, 3), (80, 150, 200), dtype=np.uint8)
    Image.fromarray(arr, mode="RGB").save(photos_dir / "SPOONBILL_01.jpg")

    win = MainWindow(db_path=tmp_path / "ebird_gui.db", thumbnail_dir=tmp_path / "thumbs")
    assert win.windowTitle() == "鸟羽集"

    # Seed a cached eBird hotspot and create a linked Favorite Location via LocationManagerDialog
    hotspot = EBirdLocationService._parse_hotspot_dict(
        {
            "locId": "L2586431",
            "locName": "Shenzhen Bay Park (深圳湾公园)",
            "countryCode": "CN",
            "subnational1Code": "CN-44",
            "lat": 22.5212,
            "lng": 113.9921,
            "numSpeciesAllTime": 270,
        }
    )
    assert hotspot is not None
    win.db.upsert_ebird_hotspots([hotspot])

    win.catalog.import_folder(photos_dir)
    win.refresh_all()
    assert win.grid_list.count() == 1

    dlg = LocationManagerDialog(
        win,
        win.ebird_service,
        active_photo_gps=None,
        has_selected_photos=True,
    )
    dlg.apply_location_requested.connect(win.inspector.apply_external_location)

    # Search cached hotspot in right pane via Pinyin initials 'szw'
    dlg.edit_hotspot_search.setText("szw")
    dlg._run_hotspot_search()
    assert dlg.hotspot_table.rowCount() == 1

    # Select row 0 and save it directly as a Favorite Birding Spot
    dlg.hotspot_table.selectRow(0)
    dlg._add_selected_hotspot_as_favorite()
    favs = win.ebird_service.list_favorites()
    assert len(favs) == 1
    assert favs[0].ebird_loc_id == "L2586431"
    assert "深圳湾公园" in favs[0].name

    # Apply selected favorite from dialog to active photo in MainWindow
    dlg.fav_table.selectRow(0)
    dlg._apply_selected_favorite_to_photos()
    app.processEvents()

    photos = win.db.query_photos(FilterQuery())
    assert len(photos) == 1
    assert photos[0].location_name == favs[0].name
    assert photos[0].location_province == "广东"
    assert photos[0].location_city == "深圳市"
    assert photos[0].ebird_loc_id == "L2586431"
    assert photos[0].exif.gps_lat == 22.5212
    assert "L2586431" in win.inspector.btn_open_ebird_spot.text()

    # Test MapPickerDialog coordinate projection & point fine-tuning (override_gps=True)
    from bird_gallery.gui.map_picker import MapPickerDialog

    map_dlg = MapPickerDialog(
        win,
        win.ebird_service,
        initial_lat=22.5212,
        initial_lng=113.9921,
        initial_province="广东",
        initial_city="深圳市",
        initial_spot_name="深圳湾公园北湾鹭港",
        initial_ebird_id="L2586431",
        photo_count=1,
    )
    map_dlg.resize(800, 600)
    # Test screen <-> WGS-84 round-trip on both GCJ-02 layer (0) and WGS-84 layer (2)
    for layer_idx in (0, 2):
        map_dlg.map_widget.set_layer_index(layer_idx)
        pt = map_dlg.map_widget.wgs_to_screen(22.5235, 113.9960)
        lat_rt, lng_rt = map_dlg.map_widget.screen_to_wgs(pt.x(), pt.y())
        assert abs(lat_rt - 22.5235) < 1e-4
        assert abs(lng_rt - 113.9960) < 1e-4

    # Simulate user adjusting pin on map to fine-tuned coordinates in Nanshan/Shenzhen Bay
    map_dlg.map_widget.set_pin(22.519876, 113.988765, pan_to=True, emit_signal=True)
    map_dlg.chk_save_fav.setChecked(True)
    map_dlg._confirm_selection()
    picked = map_dlg.picked_result()
    assert picked is not None
    assert picked.province == "广东"
    assert picked.city == "深圳市"

    win.inspector.apply_external_location(
        picked.spot_name,
        picked.ebird_loc_id or "",
        picked.lat,
        picked.lng,
        picked.province,
        picked.city,
        override_gps=True,
    )
    app.processEvents()

    updated_photo = win.db.query_photos(FilterQuery(location_province="广东", location_city="深圳市"))[0]
    assert abs((updated_photo.exif.gps_lat or 0.0) - 22.519876) < 1e-6
    assert abs((updated_photo.exif.gps_lon or 0.0) - 113.988765) < 1e-6

    dlg.close()
    win.close()
    app.processEvents()

"""Unit tests for the expanded 11,000+ species TaxonomyMapper and Pinyin-initials fuzzy search."""

from pathlib import Path

from bird_gallery.taxonomy import TaxonomyMapper


def test_builtin_taxonomy_loads_global_and_china_checklists() -> None:
    mapper = TaxonomyMapper()
    assert len(mapper) >= 10_000
    assert mapper.china_species_count >= 1_350

    kingfisher = mapper.lookup("Alcedo atthis")
    assert kingfisher is not None
    assert kingfisher.common_name_cn == "普通翠鸟"
    assert kingfisher.family_cn == "翠鸟科"
    assert kingfisher.pinyin_initials == "ptcn"
    assert kingfisher.in_china is True

    # Case-insensitive and underscore-normalized lookup
    assert mapper.lookup("alcedo_atthis") == kingfisher

    # Reverse lookup by Chinese name
    by_cn = mapper.lookup_by_cn("白头鹎")
    assert by_cn is not None
    assert by_cn.scientific_name == "Pycnonotus sinensis"

    # Keyword search across family and CN names
    herons = mapper.search("鹭科", limit=50)
    assert any(e.common_name_cn == "苍鹭" for e in herons)


def test_pinyin_initials_and_fuzzy_subsequence_search() -> None:
    mapper = TaxonomyMapper()

    # Exact initials match ranks #1 (including rare ornithological chars like 鹎, 䴙䴘, 琵鹭)
    assert mapper.search("ptcn", limit=5)[0].common_name_cn == "普通翠鸟"
    assert mapper.search("btb", limit=5)[0].common_name_cn == "白头鹎"
    assert mapper.search("hlpl", limit=5)[0].common_name_cn == "黑脸琵鹭"
    assert mapper.search("xpt", limit=5)[0].common_name_cn == "小䴙䴘"
    # Ornithological polyphone '长' -> 'chang' ('c')
    assert any(e.common_name_cn == "银喉长尾山雀" for e in mapper.search("yhcwsq", limit=5))

    # Full pinyin + lu/lv equivalence ('红翅绿鸠')
    lujiu = mapper.search("hongchilujiu", limit=5)
    assert any(e.common_name_cn == "红翅绿鸠" for e in lujiu)

    # Fuzzy subsequence on initials ('hlq' -> '红嘴蓝鹊 [hzlq]')
    fuzzy_res = mapper.search("hlq", limit=15)
    assert any(e.common_name_cn == "红嘴蓝鹊" for e in fuzzy_res)


def test_custom_csv_computes_pinyin_automatically(tmp_path: Path) -> None:
    custom_csv = tmp_path / "custom_birds.csv"
    custom_csv.write_text(
        "scientific_name,common_name_cn,common_name_en,order_cn,family_cn\n"
        "Cyanistes testbirdus,测试蓝山雀,Test Blue Tit,雀形目,山雀科\n",
        encoding="utf-8",
    )
    mapper = TaxonomyMapper(custom_csv)
    entry = mapper.lookup("Cyanistes testbirdus")
    assert entry is not None
    assert entry.common_name_cn == "测试蓝山雀"
    assert entry.pinyin_initials == "cslyq" or entry.pinyin_initials == "cslsq"
    assert mapper.search("cslsq", limit=3)[0].common_name_cn == "测试蓝山雀"

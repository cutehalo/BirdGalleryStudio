"""Unit tests for pure catalog import, Bird Field Guide life list, date/location trees, and multi-albums."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image

from bird_gallery import CatalogService, EngineConfig, FilterQuery, GalleryDatabase, TaxonomyMapper


def _save_sample_jpg(path: Path, color: tuple[int, int, int] = (40, 140, 200)) -> None:
    arr = np.full((240, 320, 3), color, dtype=np.uint8)
    Image.fromarray(arr, mode="RGB").save(path, format="JPEG", quality=88)


def test_catalog_import_field_guide_and_multi_dimensional_albums(tmp_path: Path) -> None:
    shoot_dir = tmp_path / "2026_Autumn_Shoot"
    shoot_dir.mkdir()
    img1 = shoot_dir / "DSC_0001.jpg"
    img2 = shoot_dir / "DSC_0002.jpg"
    img3 = shoot_dir / "DSC_0003.jpg"
    _save_sample_jpg(img1, (30, 120, 220))
    _save_sample_jpg(img2, (50, 180, 90))
    _save_sample_jpg(img3, (180, 120, 50))

    db_path = tmp_path / "catalog.db"
    cfg = EngineConfig(db_path=db_path, thumbnail_dir=tmp_path / "thumbs")
    db = GalleryDatabase(db_path)
    catalog = CatalogService(db, TaxonomyMapper(), cfg)

    # 1. Import folder without any AI dependencies, tagging initial location
    summary = catalog.import_folder(shoot_dir, default_location="北京·奥森公园")
    assert summary.total_discovered == 3
    assert summary.processed == 3
    assert summary.failed == 0

    all_photos = db.query_photos(FilterQuery(sort_by="name_asc"))
    assert len(all_photos) == 3
    p1, p2, p3 = all_photos
    assert p1.photo_id is not None and p2.photo_id is not None and p3.photo_id is not None
    assert Path(p1.thumbnail_path or "").exists()

    # 2. Assign species from Field Guide & check Life List ('点亮图鉴')
    entry1 = catalog.assign_species([p1.photo_id, p2.photo_id], "普通翠鸟")
    assert entry1.scientific_name == "Alcedo atthis"
    assert entry1.family_cn == "翠鸟科"

    entry2 = catalog.assign_species([p3.photo_id], "红嘴蓝鹊")
    assert entry2.order_cn == "雀形目"

    guide_all = catalog.get_field_guide(status_filter="all")
    assert guide_all.lit_count == 2
    assert guide_all.total_bird_photos == 3
    assert guide_all.total_checklist_count >= 150

    guide_lit = catalog.get_field_guide(status_filter="lit")
    assert [c.common_name_cn for c in guide_lit.cards] == ["普通翠鸟", "红嘴蓝鹊"]
    assert guide_lit.cards[0].photo_count == 2
    assert guide_lit.cards[0].cover_thumbnail_path is not None

    # Species hierarchy tree (Order -> Family -> Species)
    sp_tree = catalog.get_photographed_species_tree()
    assert len(sp_tree) == 2

    # 3. Date & Location attributes
    db.batch_update_attributes([p1.photo_id, p2.photo_id], manual_date="2026-10-05")
    db.batch_update_attributes([p3.photo_id], manual_date="2026-11-12", location_name="江西·鄱阳湖")

    date_tree, undated = catalog.get_date_hierarchy()
    assert undated == 0
    assert date_tree[0][0] == "2026"
    assert date_tree[0][1] == 3

    oct_photos = db.query_photos(FilterQuery(date_prefix="2026-10"))
    assert len(oct_photos) == 2

    locs = dict((k, cnt) for k, _label, cnt in catalog.get_location_albums())
    assert locs["北京·奥森公园"] == 2
    assert locs["江西·鄱阳湖"] == 1

    # 4. Multi-album membership: SAME photo p1 belongs to TWO custom albums simultaneously!
    alb_best = db.create_album("年度精选")
    alb_action = db.create_album("飞版合集")

    db.add_photos_to_album(alb_best.album_id, [p1.photo_id, p3.photo_id])
    db.add_photos_to_album(alb_action.album_id, [p1.photo_id])

    p1_reloaded = db.get_photo(p1.photo_id)
    assert p1_reloaded is not None
    assert set(p1_reloaded.album_ids) == {alb_best.album_id, alb_action.album_id}

    best_photos = db.query_photos(FilterQuery(album_id=alb_best.album_id))
    action_photos = db.query_photos(FilterQuery(album_id=alb_action.album_id))
    assert len(best_photos) == 2
    assert len(action_photos) == 1
    assert action_photos[0].photo_id == p1.photo_id

    # Verify partial checkbox state helper for multi-selection [p1, p2]
    membership = db.get_album_membership_counts([p1.photo_id, p2.photo_id])
    assert membership[alb_best.album_id] == 1  # 1 of 2 selected -> PartiallyChecked

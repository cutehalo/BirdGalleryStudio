"""Unit & GUI tests for Personal Birding Checklists (BirdReport.cn paste, XLSX/CSV, eBird S-ID) & Same-Date Priority."""

from __future__ import annotations

import io
import json
import os
import zipfile
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PIL import Image
from PySide6.QtWidgets import QApplication

from bird_gallery.checklists import PersonalChecklistService
from bird_gallery.db import GalleryDatabase
from bird_gallery.gui.checklist_dialog import ChecklistManagerDialog
from bird_gallery.gui.main_window import MainWindow
from bird_gallery.models import FilterQuery


def _write_minimal_xlsx(path: Path, rows: list[list[str]]) -> None:
    """Create a valid minimal OpenXML .xlsx workbook using stdlib zipfile."""
    import re

    strings: list[str] = []
    str_idx: dict[str, int] = {}
    sheet_rows_xml: list[str] = []

    for r_i, row in enumerate(rows, start=1):
        cells_xml: list[str] = []
        for c_i, val in enumerate(row):
            col_letter = chr(ord("A") + c_i)
            ref = f"{col_letter}{r_i}"
            if re.fullmatch(r"\d+(?:\.\d+)?", val):
                cells_xml.append(f'<c r="{ref}"><v>{val}</v></c>')
            else:
                if val not in str_idx:
                    str_idx[val] = len(strings)
                    strings.append(val)
                cells_xml.append(f'<c r="{ref}" t="s"><v>{str_idx[val]}</v></c>')
        sheet_rows_xml.append(f'<row r="{r_i}">{"".join(cells_xml)}</row>')

    ss_items = "".join(f"<si><t>{s}</t></si>" for s in strings)
    ss_xml = f'<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">{ss_items}</sst>'
    ws_xml = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{"".join(sheet_rows_xml)}</sheetData></worksheet>'

    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("xl/sharedStrings.xml", ss_xml)
        zf.writestr("xl/worksheets/sheet1.xml", ws_xml)


def test_birdreport_personal_export_xlsx_and_csv_split_by_report_id_date_only(tmp_path: Path) -> None:
    """Verify BirdReport '定点记+随手记报告记录导出.xlsx/.csv' splits by 报告编号 and keeps ONLY start date."""
    db = GalleryDatabase(tmp_path / "br_export.db")
    svc = PersonalChecklistService(db)

    export_rows = [
        [
            "报告编号", "观测开始时间", "观测结束时间", "中文名", "拉丁名",
            "省", "州/市", "区/县", "观测点名称", "IUCN", "国内保护等级", "CITES", "鸟种数量",
        ],
        # Report 1: Excel numeric serial date 45765.5125 -> 2025-04-18, plus mainland BirdReport synonyms
        ["2025041800634", "45765.5125", "2025-04-18 14:00:00", "黄眉柳莺", "Phylloscopus inornatus", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "3"],
        ["2025041800634", "45765.5125", "2025-04-18 14:00:00", "白额燕尾", "Enicurus leschenaulti", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "1"],
        ["2025041800634", "45765.5125", "2025-04-18 14:00:00", "绿鹭", "Butorides striata", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "2"],
        ["2025041800634", "45765.5125", "2025-04-18 14:00:00", "黄斑苇鳽", "Ixobrychus sinensis", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "1"],
        ["2025041800634", "45765.5125", "2025-04-18 14:00:00", "东亚石䳭", "Saxicola stejnegeri", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "2"],
        # Report 2 & 3: Two separate reports on the same date (2025-04-26)
        ["2025042600727", "2025-04-26 07:30:00", "2025-04-26 10:00:00", "普通翠鸟", "Alcedo atthis", "福建省", "厦门市", "湖里区", "虎头山公园", "LC", "三有", "", "2"],
        ["2025042601332", "2025-04-26 12:00:00", "2025-04-26 15:00:00", "黑脸琵鹭", "Platalea minor", "福建省", "厦门市", "思明区", "东山水库", "EN", "一级", "", "12"],
        # Report 4: Backfilled historical observation (serial 20250701..., actual start date 2020-08-20)
        ["2025070100861", "2020-08-20 09:50:00", "2020-08-20 11:00:00", "黑尾蜡嘴雀", "Eophona migratoria", "青海省", "海西蒙古族藏族自治州", "乌兰县", "茶卡盐湖", "LC", "三有", "", "5"],
    ]

    xlsx_path = tmp_path / "定点记+随手记报告记录导出.xlsx"
    _write_minimal_xlsx(xlsx_path, export_rows)

    cl_cnt, sp_cnt = svc.import_checklist_file(
        xlsx_path,
        default_date="2026-09-10",
        default_location="错误备用鸟点",
    )
    assert cl_cnt == 4
    assert sp_cnt == 8

    all_cls = {c.external_id: c for c in db.list_checklists(include_items=True)}
    assert set(all_cls.keys()) == {"2025041800634", "2025042600727", "2025042601332", "2025070100861"}

    # Every BirdReport record MUST store ONLY start date (YYYY-MM-DD) and NO time!
    for cl in all_cls.values():
        assert cl.obs_time == ""
        assert cl.obs_date != "2026-09-10"
        assert cl.location_name != "错误备用鸟点"

    r1 = all_cls["2025041800634"]
    assert r1.obs_date == "2025-04-18"
    assert r1.province == "福建" and r1.city == "厦门市" and r1.location_name == "虎头山公园"
    r1_map = {it.common_name_cn: it.count_num for it in r1.items}
    assert r1_map == {
        "黄眉柳莺": 3,
        "白冠燕尾": 1,
        "绿鹭": 2,
        "黄苇鳽": 1,
        "东亚石䳭": 2,
    }

    # Same-date reports split cleanly by 报告编号
    apr26_cls, _ = db.get_checklist_species_for_date("2025-04-26")
    assert len(apr26_cls) == 2
    assert {c.location_name for c in apr26_cls} == {"虎头山公园", "东山水库"}

    # Historical report uses 观测开始时间 date (2020-08-20), NOT 报告编号 prefix (2025-07-01)
    r4 = all_cls["2025070100861"]
    assert r4.obs_date == "2020-08-20"
    assert r4.province == "青海" and r4.city == "海西蒙古族藏族自治州" and r4.location_name == "茶卡盐湖"
    assert r4.items[0].count_num == 5

    # Also verify CSV tabular paste in ChecklistManagerDialog updates/imports cleanly
    csv_text = "\n".join(",".join(r) for r in export_rows[:3])
    assert svc.is_tabular_checklist_text(csv_text)
    p_cnt, p_sp = svc.import_tabular_text(csv_text)
    assert p_cnt == 1 and p_sp == 2


def test_birdreport_paste_longest_match_and_synonyms(tmp_path: Path) -> None:
    db = GalleryDatabase(tmp_path / "br.db")
    svc = PersonalChecklistService(db)

    pasted_report = """
    中国观鸟记录中心 - 观鸟报告详情
    观测时间：2026年11月24日 07:45
    观测地点：广东省深圳市深圳湾公园
    记录人：测试鸟友  天气：晴
    序号\t鸟种\t学名\t数量
    1\t大白鹭\tArdea alba\t5
    2\t中白鹭\tArdea intermedia\t3
    3\t白鹭\tEgretta garzetta\t18
    4. 黑脸琵鹭 12、反嘴鹬 45、白胸翡翠 1、小鸊鷉 6
    """
    draft = svc.parse_birdreport_text(pasted_report)
    assert draft.obs_date == "2026-11-24"
    assert draft.obs_time == "07:45"
    assert draft.location_name == "广东省深圳市深圳湾公园"
    assert draft.province == "广东"
    assert draft.city == "深圳市"

    by_cn = {it.common_name_cn: it.count_num for it in draft.items}
    # Verify longest-match kept 大白鹭, 中白鹭, 白鹭 completely separate!
    assert by_cn["大白鹭"] == 5
    assert by_cn["中白鹭"] == 3
    assert by_cn["白鹭"] == 18
    assert by_cn["黑脸琵鹭"] == 12
    assert by_cn["反嘴鹬"] == 45
    assert by_cn["白胸翡翠"] == 1
    # Verify Traditional/variant '小鸊鷉' normalized to canonical '小䴙䴘'
    assert by_cn["小䴙䴘"] == 6

    saved = svc.save_parsed_draft(draft)
    assert saved.species_count == 7


def test_checklist_dialog_batch_delete_filter_select_all_and_clear_all(tmp_path: Path) -> None:
    """Verify single-click checkbox toggle, keyword filter + select all batch delete, and clear all."""
    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import QMouseEvent

    app = QApplication.instance() or QApplication([])
    db = GalleryDatabase(tmp_path / "batch_del.db")
    svc = PersonalChecklistService(db)

    for rid, dt, loc, sp in [
        ("2025041800001", "2025-04-18", "厦门虎头山公园", "白头鹎 5"),
        ("2025041900002", "2025-04-19", "厦门东山水库", "普通翠鸟 2"),
        ("2025050100003", "2025-05-01", "厦门园博苑", "黑脸琵鹭 8"),
        ("2026112500004", "2026-11-25", "新乡和谐公园", "灰喜鹊 6"),
        ("2026112600005", "2026-11-26", "新乡人民公园", "黑尾蜡嘴雀 4"),
    ]:
        draft = svc.parse_birdreport_text(f"观测时间：{dt}\n观测地点：{loc}\n{sp}")
        db.upsert_checklist(draft.obs_date, draft.items, external_id=rid, location_name=loc)

    assert db.count_checklists() == 5

    dlg = ChecklistManagerDialog(None, svc)
    dlg.show()
    app.processEvents()

    # Initially row 0 is selected; single-clicking checkbox col 0 on row 2 adds row 2 without clearing row 0!
    assert dlg._selected_checklist_rows() == [0]
    rect_r2_c0 = dlg.cl_table.visualRect(dlg.cl_table.model().index(2, 0))
    ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonPress,
        QPointF(rect_r2_c0.center()),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    dlg.cl_table.mousePressEvent(ev)
    app.processEvents()
    assert dlg._selected_checklist_rows() == [0, 2]
    assert "批量删除 (2 篇)" in dlg.btn_del_cl.text()

    # Batch delete those 2 selected rows
    deleted_cnt = dlg._delete_selected_checklists(confirm=False)
    assert deleted_cnt == 2
    assert db.count_checklists() == 3

    # Filter by keyword ('厦门' matches remaining 2025-04-18 & 2025-04-19), select all filtered, and batch delete!
    dlg.edit_filter_date.setText("厦门")
    app.processEvents()
    assert dlg.cl_table.rowCount() == 2
    dlg.select_all_checklists()
    app.processEvents()
    assert len(dlg.selected_checklists()) == 2
    assert dlg._delete_selected_checklists(confirm=False) == 2

    dlg.edit_filter_date.clear()
    app.processEvents()
    assert db.count_checklists() == 1
    assert dlg.cl_table.rowCount() == 1

    # Clear all remaining checklists
    assert dlg._clear_all_checklists(confirm=False) == 1
    assert db.count_checklists() == 0
    assert dlg.cl_table.rowCount() == 0
    assert not dlg.btn_del_cl.isEnabled()
    assert not dlg.btn_clear_all_cl.isEnabled()

    dlg.close()
    app.processEvents()


def test_xlsx_template_and_myebirddata_csv_import_and_ebird_sync(tmp_path: Path) -> None:
    db = GalleryDatabase(tmp_path / "files.db")
    svc = PersonalChecklistService(db)

    # 1. BirdReport upload template (.xlsx without date column -> uses default_date)
    xlsx_file = tmp_path / "birdreport_template.xlsx"
    _write_minimal_xlsx(
        xlsx_file,
        [
            ["鸟种", "数量", "鸟种备注"],
            ["普通翠鸟", "2", "捕鱼"],
            ["红嘴蓝鹊", "4", ""],
        ],
    )
    cl_cnt, sp_cnt = svc.import_checklist_file(
        xlsx_file,
        default_date="2026-10-18",
        default_location="北京·圆明园遗址公园",
    )
    assert cl_cnt == 1 and sp_cnt == 2

    # 2. Official eBird MyEBirdData.csv export
    ebird_csv = tmp_path / "MyEBirdData.csv"
    ebird_csv.write_text(
        "Submission ID,Common Name,Scientific Name,Taxonomic Order,Count,State/Province,County,Location ID,Location,Latitude,Longitude,Date,Time\n"
        "S19000111,Black-faced Spoonbill,Platalea minor,4120,15,CN-44,,L2586431,Shenzhen Bay Park (深圳湾公园),22.5212,113.9921,2026-11-20,08:15 AM\n"
        "S19000111,Common Kingfisher,Alcedo atthis,5210,X,CN-44,,L2586431,Shenzhen Bay Park (深圳湾公园),22.5212,113.9921,2026-11-20,08:15 AM\n",
        encoding="utf-8",
    )
    cl_cnt2, sp_cnt2 = svc.import_checklist_file(ebird_csv)
    assert cl_cnt2 == 1 and sp_cnt2 == 2
    cls_nov20, items_nov20 = db.get_checklist_species_for_date("2026-11-20")
    assert len(cls_nov20) == 1
    assert cls_nov20[0].province == "广东" and cls_nov20[0].city == "深圳市"
    assert {i.common_name_cn for i in items_nov20} == {"黑脸琵鹭", "普通翠鸟"}

    # 3. eBird Checklist S-ID API sync
    svc.ebird_svc.set_api_key("dummy-token")
    mock_cl_json = {
        "subId": "S89703713",
        "locId": "L2586431",
        "obsDt": "2026-11-22 09:20",
        "subnational1Code": "CN-44",
        "obs": [
            {"speciesCode": "comkin1", "howManyStr": "3"},
            {"speciesCode": "blfspo1", "howManyStr": "9"},
            {"speciesCode": "newsplit1", "howManyStr": "2"},
        ],
    }
    mock_loc_json = {
        "locId": "L2586431",
        "locName": "Shenzhen Bay Park (深圳湾公园)",
        "countryCode": "CN",
        "subnational1Code": "CN-44",
        "lat": 22.5212,
        "lng": 113.9921,
    }
    mock_tax_json = [
        {"speciesCode": "newsplit1", "comName": "反嘴鹬", "sciName": "Recurvirostra avosetta"}
    ]

    class _FakeResp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.close()

    def _fake_urlopen(req, timeout=25):
        url = req.full_url
        if "/product/checklist/view/" in url:
            return _FakeResp(json.dumps(mock_cl_json).encode("utf-8"))
        if "/ref/taxonomy/ebird" in url:
            return _FakeResp(json.dumps(mock_tax_json).encode("utf-8"))
        return _FakeResp(json.dumps(mock_loc_json).encode("utf-8"))

    with patch("urllib.request.urlopen", side_effect=_fake_urlopen):
        synced = svc.sync_ebird_checklists("https://ebird.org/checklist/S89703713")

    assert len(synced) == 1
    assert synced[0].obs_date == "2026-11-22"
    assert {i.common_name_cn for i in synced[0].items} == {"普通翠鸟", "黑脸琵鹭", "反嘴鹬"}


def test_gui_inspector_prioritizes_same_date_checklist_species(tmp_path: Path) -> None:
    from PySide6.QtCore import Qt

    from bird_gallery.gui.species_picker_dialog import ChecklistSpeciesPickerDialog

    app = QApplication.instance() or QApplication([])

    photos_dir = tmp_path / "trip_20261124"
    photos_dir.mkdir()
    arr = np.full((180, 240, 3), (40, 120, 200), dtype=np.uint8)
    Image.fromarray(arr, mode="RGB").save(photos_dir / "BIRD_01.jpg")

    win = MainWindow(db_path=tmp_path / "cl_gui.db", thumbnail_dir=tmp_path / "thumbs")
    win.show()
    win.catalog.import_folder(photos_dir)
    win.refresh_all()

    # Set photo date to 2026-11-24
    win.inspector.edit_date.setText("2026-11-24")
    win.inspector._apply_date()
    app.processEvents()

    # Before importing any checklist for 2026-11-24, report area must be hidden!
    assert not win.inspector.cl_report_area.isVisible()
    # Verify edit_species and '+' button are merged into a single horizontal row (count == 2)
    assert win.inspector.sp_input_row.count() == 2

    # Rule 1: Even if a report exists for ANOTHER date (2026-11-20), 2026-11-24 must NOT display it!
    other_draft = win.checklist_service.parse_birdreport_text(
        "观测时间：2026-11-20 09:00\n观测地点：北京圆明园\n普通翠鸟 2"
    )
    win.checklist_service.save_parsed_draft(other_draft)
    win._on_albums_changed()
    app.processEvents()
    assert not win.inspector.cl_report_area.isVisible()

    # Paste first personal checklist for 2026-11-24 via ChecklistManagerDialog
    dlg = ChecklistManagerDialog(win, win.checklist_service, initial_date="2026-11-24")
    dlg.checklists_changed.connect(win._on_albums_changed)
    dlg.edit_paste_text.setPlainText(
        "观测时间：2026-11-24 08:00\n"
        "观测地点：广东省深圳市深圳湾公园\n"
        "黑脸琵鹭 12、反嘴鹬 30、白胸翡翠 2"
    )
    dlg._save_pasted_checklist()
    # Add a SECOND checklist on the same date (2026-11-24 afternoon at 福田红树林) to verify multi-report buttons!
    dlg.edit_paste_text.setPlainText(
        "观测时间：2026-11-24 15:30\n"
        "观测地点：广东省深圳市福田红树林\n"
        "黑脸琵鹭 6、苍鹭 4"
    )
    dlg._save_pasted_checklist()
    dlg.close()
    app.processEvents()

    # 1. Inspector must show 2 compact report buttons for 2026-11-24 (each showing ONLY date, location, species count)!
    assert len(win.inspector._active_date_checklists) == 2
    assert len(win.inspector._active_date_items) == 4
    assert win.inspector.cl_report_area.isVisible()
    assert win.inspector.cl_report_buttons_layout.count() == 2
    btn_texts = [
        win.inspector.cl_report_buttons_layout.itemAt(i).widget().text()
        for i in range(2)
    ]
    assert any("2026-11-24" in t and "深圳湾" in t and "3种" in t for t in btn_texts)
    assert any("2026-11-24" in t and "福田红树林" in t and "2种" in t for t in btn_texts)

    # 2. Typing 'fc' in edit_species must pin '📋 [当日记录·2] 白胸翡翠' at the VERY TOP of autocomplete
    #    AND completer popup MUST have dark high-contrast background (not white)!
    win.inspector._on_species_text_edited("fc")
    comp_list = win.inspector._species_completer_model.stringList()
    assert len(comp_list) >= 1
    assert comp_list[0].startswith("📋 [当日记录·2] 白胸翡翠")
    popup_bg = win.inspector._species_completer.popup().palette().base().color().lightness()
    assert popup_bg < 55, f"Completer popup background must be dark, got lightness={popup_bg}"

    # 3. Pressing Enter on shorthand 'fc' assigns '白胸翡翠' AND auto-completes report location onto photo!
    win.inspector.edit_species.setText("fc")
    win.inspector._apply_species()
    app.processEvents()

    rec = win.db.query_photos(FilterQuery())[0]
    assert rec.all_species_cn == ["白胸翡翠"]
    assert win.inspector._recent_species == ["白胸翡翠"]
    assert "深圳湾公园" in rec.location_name
    assert rec.location_province == "广东"
    assert rec.location_city == "深圳市"

    # 4. Verify '+' multi-species addition, full multi-tag badge (no '+1'), & ONLY 1 recent species!
    win.inspector.edit_species.setText("大白鹭")
    win.inspector._on_plus_add_species()
    app.processEvents()

    # Recent species MUST strictly keep only the 1 most recently chosen species!
    assert len(win.inspector._recent_species) == 1
    assert win.inspector._recent_species == ["大白鹭"]

    rec_multi = win.db.query_photos(FilterQuery())[0]
    assert rec_multi.all_species_cn == ["白胸翡翠", "大白鹭"]
    assert "+" not in rec_multi.display_species_badge
    assert rec_multi.display_species_badge == "白胸翡翠 · 大白鹭"

    # Both co-occurring species must be queryable individually AND lit in the Field Guide!
    assert len(win.db.query_photos(FilterQuery(exact_species_cn="白胸翡翠"))) == 1
    assert len(win.db.query_photos(FilterQuery(exact_species_cn="大白鹭"))) == 1
    assert win.catalog.get_field_guide(status_filter="lit").lit_count == 2

    # 5. Verify clicking a specific report button opens ChecklistSpeciesPickerDialog on THAT report, sorted A-Z!
    same_cls = win.inspector._active_date_checklists
    szw_cl = next(c for c in same_cls if "深圳湾" in c.location_name)
    picker = ChecklistSpeciesPickerDialog(
        win,
        win.catalog,
        same_cls,
        preferred_date="2026-11-24",
        initial_checklist_id=szw_cl.checklist_id,
        existing_photo_species=rec_multi.all_species_cn,
    )
    assert picker.list_widget.count() == 3
    ordered_names = [
        picker.list_widget.item(i).data(Qt.ItemDataRole.UserRole)
        for i in range(picker.list_widget.count())
    ]
    # bxfc (白胸翡翠) -> fzy (反嘴鹬) -> hlpl (黑脸琵鹭)
    assert ordered_names == ["白胸翡翠", "反嘴鹬", "黑脸琵鹭"]
    # '白胸翡翠' was already on the photo -> pre-checked! Check '黑脸琵鹭' and '反嘴鹬' too:
    for i in range(picker.list_widget.count()):
        picker.list_widget.item(i).setCheckState(Qt.CheckState.Checked)
    assert picker.selected_species() == ["白胸翡翠", "反嘴鹬", "黑脸琵鹭"]

    # Append via inspector multi-species sync ('add' mode keeps '大白鹭' + adds '反嘴鹬', '黑脸琵鹭',
    # AND explicit_from_report=True syncs the report's location even if photo had another location)
    win.db.batch_update_attributes([rec_multi.photo_id], location_name="", location_province="", location_city="")
    win.inspector._append_species_list(
        picker.selected_species(),
        source_checklist=picker.matched_checklist(),
        explicit_from_report=True,
    )
    picker.close()
    app.processEvents()

    rec_after_popup = win.db.query_photos(FilterQuery())[0]
    assert rec_after_popup.all_species_cn == ["白胸翡翠", "大白鹭", "反嘴鹬", "黑脸琵鹭"]
    assert "深圳湾公园" in rec_after_popup.location_name
    assert rec_after_popup.location_province == "广东"
    assert rec_after_popup.location_city == "深圳市"
    assert win.catalog.get_field_guide(status_filter="lit").lit_count == 4
    assert len(win.inspector._recent_species) == 1

    # Removing 1 species tag ('大白鹭') leaves the remaining 3 intact
    win.inspector._remove_single_species("大白鹭")
    app.processEvents()
    rec_after_rm = win.db.query_photos(FilterQuery())[0]
    assert rec_after_rm.all_species_cn == ["白胸翡翠", "反嘴鹬", "黑脸琵鹭"]

    # 6. Clicking '📍套用地点' copies checklist location + (广东, 深圳市) to the photo!
    win.inspector._apply_checklist_location_to_photos()
    app.processEvents()
    rec2 = win.db.query_photos(FilterQuery())[0]
    assert "深圳湾公园" in rec2.location_name
    assert rec2.location_province == "广东"
    assert rec2.location_city == "深圳市"

    win.close()
    app.processEvents()


def test_birdreport_id_and_url_parsing_and_cdp_websocket_sync(tmp_path: Path) -> None:
    import base64
    import hashlib
    import socket
    import struct
    import threading
    import urllib.parse

    from bird_gallery.birdreport_sync import (
        MiniCDPWebSocket,
        RawBirdReportData,
        RawBirdReportSpecies,
        parse_birdreport_inputs,
    )

    sample_url = (
        "https://www.birdreport.cn/home/record/page.html?"
        "param=eyJyZXBvcnRJZCI6IjU3NjZlYTY1LWU2NDItNGZhNC04OTIzLWFhNWE1ZDJmODc2NyIsInRzIjoxNzk1NjE1MTQ2MjIzfQ=="
        "&sign=d41d8cd98f00b204e9800998ecf8427e"
    )
    targets = parse_birdreport_inputs(f"2026112501740  {sample_url}")
    assert len(targets) == 2
    assert targets[0].kind == "url"
    assert targets[0].start_url == sample_url
    assert targets[1].kind == "serial_id"
    assert targets[1].value == "2026112501740"
    parsed_qs = urllib.parse.parse_qs(urllib.parse.urlparse(targets[1].start_url).query)
    decoded_search = json.loads(base64.b64decode(parsed_qs["search"][0]).decode("utf-8"))
    assert decoded_search == {"serial_id": "2026112501740"}

    # Verify MiniCDPWebSocket RFC-6455 framing (including >125-byte 16-bit payload & Ping/Pong)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]

    def _ws_encode_server_frame(opcode: int, payload: bytes) -> bytes:
        hdr = bytearray([0x80 | opcode])
        if len(payload) < 126:
            hdr.append(len(payload))
        else:
            hdr.append(126)
            hdr.extend(struct.pack(">H", len(payload)))
        return bytes(hdr) + payload

    def _mock_cdp_server() -> None:
        conn, _ = srv.accept()
        with conn:
            req = b""
            while b"\r\n\r\n" not in req:
                req += conn.recv(1024)
            key = ""
            for line in req.decode("ascii", errors="ignore").splitlines():
                if line.lower().startswith("sec-websocket-key:"):
                    key = line.split(":", 1)[1].strip()
            accept = base64.b64encode(
                hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()
            ).decode("ascii")
            conn.sendall(
                (
                    "HTTP/1.1 101 Switching Protocols\r\n"
                    "Upgrade: websocket\r\n"
                    "Connection: Upgrade\r\n"
                    f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
                ).encode("ascii")
            )
            # Read client masked frame
            b0, b1 = conn.recv(2)
            assert b0 == 0x81 and (b1 & 0x80)
            ln = b1 & 0x7F
            if ln == 126:
                (ln,) = struct.unpack(">H", conn.recv(2))
            mkey = conn.recv(4)
            enc = conn.recv(ln)
            msg = json.loads(bytes(b ^ mkey[i % 4] for i, b in enumerate(enc)).decode("utf-8"))

            # Send Ping + unrequested CDP event + >200-byte result frame
            conn.sendall(_ws_encode_server_frame(0x9, b"ping"))
            conn.sendall(_ws_encode_server_frame(0x1, json.dumps({"method": "Page.loadEventFired"}).encode("utf-8")))
            big_reply = json.dumps(
                {
                    "id": msg["id"],
                    "result": {
                        "result": {
                            "value": json.dumps(
                                {
                                    "stage": "done",
                                    "serial_id": "2026112501740",
                                    "items": [{"taxon_name": "黑脸琵鹭", "latin_name": "Platalea minor", "count_str": "16"}],
                                },
                                ensure_ascii=False,
                            )
                        }
                    },
                },
                ensure_ascii=False,
            ).encode("utf-8")
            assert len(big_reply) >= 126
            conn.sendall(_ws_encode_server_frame(0x1, big_reply))
            # Drain client's Pong frame before closing socket so Windows TCP does not send RST (WinError 10054)
            try:
                conn.settimeout(0.5)
                conn.recv(128)
            except OSError:
                pass

    t = threading.Thread(target=_mock_cdp_server, daemon=True)
    t.start()
    client = MiniCDPWebSocket(f"ws://127.0.0.1:{port}/devtools/page/test1")
    res = client.call("Runtime.evaluate", {"expression": "1+1"})
    client.close()
    srv.close()
    t.join(timeout=2.0)

    inner = json.loads(res["result"]["value"])  # type: ignore[index]
    assert inner["serial_id"] == "2026112501740"

    # Verify PersonalChecklistService.sync_birdreport_by_id_or_url saves normalized checklist & matches photo date
    db = GalleryDatabase(tmp_path / "br_id_sync.db")
    svc = PersonalChecklistService(db)
    fake_report = RawBirdReportData(
        serial_id="2026112501740",
        start_time="2026-11-25 08:30:00",
        end_time="2026-11-25 11:20:00",
        address="广东省深圳市南山区深圳湾公园",
        note="早潮观鸟",
        species=[
            RawBirdReportSpecies("黑脸琵鹭", "Platalea minor", "16"),
            RawBirdReportSpecies("小鸊鷉", "Tachybaptus ruficollis", "8"),
        ],
    )
    with patch("bird_gallery.checklists.fetch_birdreport_targets_via_browser", return_value=[fake_report]):
        saved_list = svc.sync_birdreport_by_id_or_url("2026112501740")

    assert len(saved_list) == 1
    cl = saved_list[0]
    assert cl.external_id == "2026112501740"
    assert cl.obs_date == "2026-11-25"
    assert cl.province == "广东" and cl.city == "深圳市"
    assert {i.common_name_cn for i in cl.items} == {"黑脸琵鹭", "小䴙䴘"}


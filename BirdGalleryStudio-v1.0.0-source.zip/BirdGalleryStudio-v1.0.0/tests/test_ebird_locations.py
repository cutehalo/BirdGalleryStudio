"""Unit tests for Favorite Birding Locations, eBird Hotspot syncing/search, and DB schema migration."""

from __future__ import annotations

import io
import json
import sqlite3
from pathlib import Path
from unittest.mock import patch

from bird_gallery.db import GalleryDatabase
from bird_gallery.ebird import (
    EBirdLocationService,
    extract_ebird_loc_id,
    haversine_km,
    suggest_short_spot_name,
)
from bird_gallery.models import ExifMetadata, PhotoRecord


def test_legacy_db_migrates_ebird_loc_id_and_new_tables(tmp_path: Path) -> None:
    """Ensure existing user databases without ebird_loc_id migrate cleanly without losing photos."""
    db_file = tmp_path / "legacy_user.db"
    conn = sqlite3.connect(db_file)
    conn.execute(
        """
        CREATE TABLE photos (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path               TEXT NOT NULL UNIQUE,
            folder_path             TEXT NOT NULL DEFAULT '',
            file_name               TEXT NOT NULL,
            file_ext                TEXT NOT NULL,
            file_size               INTEGER NOT NULL,
            file_mtime              REAL NOT NULL,
            file_hash               TEXT,
            is_raw                  INTEGER NOT NULL DEFAULT 0,
            width                   INTEGER NOT NULL DEFAULT 0,
            height                  INTEGER NOT NULL DEFAULT 0,
            thumbnail_path          TEXT,
            taken_at                TEXT,
            taken_date              TEXT,
            manual_date             TEXT,
            camera_make             TEXT,
            camera_model            TEXT,
            lens_model              TEXT,
            focal_length_mm         REAL,
            aperture                REAL,
            shutter_speed           TEXT,
            iso                     INTEGER,
            gps_lat                 REAL,
            gps_lon                 REAL,
            location_name           TEXT NOT NULL DEFAULT '',
            has_bird                INTEGER NOT NULL DEFAULT 0,
            bird_count              INTEGER NOT NULL DEFAULT 0,
            is_blurry               INTEGER NOT NULL DEFAULT 0,
            best_sharpness          REAL NOT NULL DEFAULT 0.0,
            primary_scientific_name TEXT NOT NULL DEFAULT '',
            primary_common_name_cn  TEXT NOT NULL DEFAULT '',
            primary_common_name_en  TEXT NOT NULL DEFAULT '',
            primary_order_cn        TEXT NOT NULL DEFAULT '',
            primary_family_cn       TEXT NOT NULL DEFAULT '',
            primary_confidence      REAL NOT NULL DEFAULT 0.0,
            review_status           TEXT NOT NULL DEFAULT 'unreviewed',
            manual_scientific_name  TEXT,
            manual_common_name_cn   TEXT,
            rating                  INTEGER NOT NULL DEFAULT 0,
            pick_flag               INTEGER NOT NULL DEFAULT 0,
            is_rejected             INTEGER NOT NULL DEFAULT 0,
            notes                   TEXT NOT NULL DEFAULT '',
            scanned_at              TEXT NOT NULL DEFAULT '2026-01-01T00:00:00Z',
            updated_at              TEXT NOT NULL DEFAULT '2026-01-01T00:00:00Z'
        );
        """
    )
    conn.execute(
        """
        INSERT INTO photos (file_path, file_name, file_ext, file_size, file_mtime, location_name, rating)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        ("D:/Birds/IMG_0001.JPG", "IMG_0001.JPG", ".jpg", 1024, 1700000000.0, "深圳湾公园", 5),
    )
    conn.commit()
    conn.close()

    # Opening with GalleryDatabase must auto-migrate ebird_loc_id & create favorite_locations/ebird_hotspots
    db = GalleryDatabase(db_file)
    rec = db.get_photo(1)
    assert rec is not None
    assert rec.location_name == "深圳湾公园"
    assert rec.rating == 5
    assert rec.ebird_loc_id is None

    db.batch_update_attributes([1], ebird_loc_id="L2586431", fallback_lat=22.5212, fallback_lon=113.9921)
    updated = db.get_photo(1)
    assert updated is not None
    assert updated.ebird_loc_id == "L2586431"
    assert updated.exif.gps_lat == 22.5212
    assert updated.exif.gps_lon == 113.9921


def test_ebird_helpers_and_cached_pinyin_search(tmp_path: Path) -> None:
    assert extract_ebird_loc_id("L2586431") == "L2586431"
    assert extract_ebird_loc_id("https://ebird.org/hotspot/L1092384?yr=all") == "L1092384"
    assert extract_ebird_loc_id("⭐ 北京·圆明园 [L1092384]") == "L1092384"
    assert extract_ebird_loc_id("普通公园名称") is None

    assert suggest_short_spot_name("Beijing--Yuanmingyuan Park (圆明园遗址公园)", "CN-11") == "北京·圆明园遗址公园"
    assert suggest_short_spot_name("マイアミ浜 (Miami Beach)", "JP-25") == "マイアミ浜 (Miami Beach)"

    db = GalleryDatabase(tmp_path / "spots.db")
    svc = EBirdLocationService(db)
    svc.set_api_key("test-ebird-token-123")

    mock_payload = [
        {
            "locId": "L100001",
            "locName": "Beijing--Yuanmingyuan Park (圆明园遗址公园)",
            "countryCode": "CN",
            "subnational1Code": "CN-11",
            "lat": 40.0081,
            "lng": 116.2982,
            "numSpeciesAllTime": 298,
            "latestObsDt": "2026-11-20",
        },
        {
            "locId": "L100002",
            "locName": "Beijing--Olympic Forest Park (奥林匹克森林公园)",
            "countryCode": "CN",
            "subnational1Code": "CN-11",
            "lat": 40.0155,
            "lng": 116.3924,
            "numSpeciesAllTime": 315,
            "latestObsDt": "2026-11-22",
        },
        {
            "locId": "L200001",
            "locName": "Shenzhen Bay Park (深圳湾公园)",
            "countryCode": "CN",
            "subnational1Code": "CN-44",
            "lat": 22.5212,
            "lng": 113.9921,
            "numSpeciesAllTime": 265,
            "latestObsDt": "2026-11-23",
        },
    ]

    class _FakeResp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.close()

    with patch(
        "urllib.request.urlopen",
        side_effect=lambda req, timeout=25: _FakeResp(json.dumps(mock_payload).encode("utf-8")),
    ):
        total, codes = svc.sync_regions("CN")

    assert total == 3
    assert codes == ["CN(3)"]
    assert db.count_ebird_hotspots() == 3

    # 1. Pinyin initials search ('ymy' -> 圆明园遗址公园)
    res_py = svc.search_cached_hotspots("ymy")
    assert len(res_py) >= 1
    assert res_py[0].loc_id == "L100001"

    # 2. Pinyin initials search ('szwgy' -> 深圳湾公园)
    res_sz = svc.search_cached_hotspots("szwgy")
    assert len(res_sz) == 1
    assert res_sz[0].loc_id == "L200001"

    # 3. Direct L-code search
    res_lid = svc.search_cached_hotspots("L100002")
    assert len(res_lid) == 1
    assert "奥林匹克森林公园" in res_lid[0].loc_name

    # 4. GPS Haversine nearby search around Haidian Beijing (offline cache)
    nearby = svc.find_nearby_hotspots(40.0090, 116.3000, dist_km=15.0, try_online=False)
    assert [h.loc_id for h in nearby] == ["L100001", "L100002"]
    assert nearby[0].distance_km is not None and nearby[0].distance_km < 1.0
    assert haversine_km(40.0081, 116.2982, 22.5212, 113.9921) > 1900.0


def test_favorite_location_linking_and_photo_assignment(tmp_path: Path) -> None:
    db = GalleryDatabase(tmp_path / "fav_link.db")
    svc = EBirdLocationService(db)

    hotspot = EBirdLocationService._parse_hotspot_dict(
        {
            "locId": "L888999",
            "locName": "Mai Po Nature Reserve (米埔自然保护区)",
            "countryCode": "HK",
            "subnational1Code": "HK",
            "lat": 22.4892,
            "lng": 114.0398,
            "numSpeciesAllTime": 380,
        }
    )
    assert hotspot is not None
    db.upsert_ebird_hotspots([hotspot])

    fav = svc.save_favorite_from_hotspot(hotspot, alias_name="香港·米埔保护区", notes="通行证预约")
    assert fav.name == "香港·米埔保护区"
    assert fav.ebird_loc_id == "L888999"
    assert fav.lat == 22.4892

    # Photo 1 has no EXIF GPS -> should inherit favorite spot's GPS + ebird_loc_id
    pid1 = db.upsert_photo(
        PhotoRecord(
            file_path="D:/Shot1.jpg",
            file_name="Shot1.jpg",
            file_ext=".jpg",
            file_size=100,
            file_mtime=1700000000.0,
            is_raw=False,
        )
    )
    # Photo 2 already has EXIF GPS -> should keep its own exact camera GPS while attaching ebird_loc_id
    pid2 = db.upsert_photo(
        PhotoRecord(
            file_path="D:/Shot2.jpg",
            file_name="Shot2.jpg",
            file_ext=".jpg",
            file_size=100,
            file_mtime=1700000000.0,
            is_raw=False,
            exif=ExifMetadata(gps_lat=22.4950, gps_lon=114.0410),
        )
    )

    resolved_name, resolved_lid = svc.apply_location_to_photos(
        [pid1, pid2],
        "⭐ 香港·米埔保护区 [L888999]",
    )
    assert resolved_name == "香港·米埔保护区"
    assert resolved_lid == "L888999"

    p1 = db.get_photo(pid1)
    p2 = db.get_photo(pid2)
    assert p1 is not None and p2 is not None
    assert p1.location_name == "香港·米埔保护区"
    assert p1.ebird_loc_id == "L888999"
    assert p1.exif.gps_lat == 22.4892 and p1.exif.gps_lon == 114.0398

    assert p2.location_name == "香港·米埔保护区"
    assert p2.ebird_loc_id == "L888999"
    assert p2.exif.gps_lat == 22.4950 and p2.exif.gps_lon == 114.0410

    # Use count must increment so top favorites rise to the top
    fav_after = db.get_favorite_location_by_name("香港·米埔保护区")
    assert fav_after is not None and fav_after.use_count == 1
    assert fav_after.province == "香港"
    assert fav_after.city == "元朗区"


def test_province_city_hierarchy_and_gcj02_precision(tmp_path: Path) -> None:
    from bird_gallery.china_regions import (
        gcj02_to_wgs84,
        infer_province_city,
        list_cities,
        list_provinces,
        search_cities,
        wgs84_to_gcj02,
    )
    from bird_gallery.models import FilterQuery

    assert len(list_provinces()) == 34
    gd_cities = [c.city for c in list_cities("广东省")]
    assert "深圳市" in gd_cities and "湛江市" in gd_cities

    # Pinyin search on prefecture cities
    yc = search_cities("yc")
    assert any(c.city == "盐城市" and c.province == "江苏" for c in yc)

    # Offline GPS -> (province, prefecture/district) reverse lookup
    assert infer_province_city(22.5212, 113.9921) == ("广东", "深圳市")
    assert infer_province_city(40.0081, 116.2982) == ("北京", "海淀区")
    assert infer_province_city(24.4320, 98.5850) == ("云南", "德宏傣族景颇族自治州")

    # WGS-84 <-> GCJ-02 round-trip precision (< 0.1 meter)
    orig_lat, orig_lng = 31.230416, 121.473701
    gcj_lat, gcj_lng = wgs84_to_gcj02(orig_lat, orig_lng)
    assert abs(gcj_lat - orig_lat) > 0.001  # Shifted in Shanghai
    back_lat, back_lng = gcj02_to_wgs84(gcj_lat, gcj_lng)
    assert abs(back_lat - orig_lat) < 1e-6
    assert abs(back_lng - orig_lng) < 1e-6

    # Verify DB 3-level location hierarchy & province/city filtering + GPS override adjustment
    db = GalleryDatabase(tmp_path / "city_tree.db")
    svc = EBirdLocationService(db)
    pid = db.upsert_photo(
        PhotoRecord(
            file_path="D:/Yancheng_Spoonbill.jpg",
            file_name="Yancheng_Spoonbill.jpg",
            file_ext=".jpg",
            file_size=200,
            file_mtime=1700000000.0,
            is_raw=False,
            exif=ExifMetadata(gps_lat=32.0000, gps_lon=120.0000),  # Rough initial GPS
        )
    )
    # Fine-tune coordinates via override_gps=True to Tiaozini (Yancheng, Jiangsu)
    svc.apply_location_to_photos(
        [pid],
        "条子泥湿地",
        province="江苏",
        city="盐城市",
        fallback_lat=32.7685,
        fallback_lon=120.9652,
        override_gps=True,
    )
    rec = db.get_photo(pid)
    assert rec is not None
    assert rec.location_province == "江苏"
    assert rec.location_city == "盐城市"
    assert abs((rec.exif.gps_lat or 0.0) - 32.7685) < 1e-6
    assert abs((rec.exif.gps_lon or 0.0) - 120.9652) < 1e-6

    assert len(db.query_photos(FilterQuery(location_province="江苏"))) == 1
    assert len(db.query_photos(FilterQuery(location_province="江苏", location_city="盐城市"))) == 1
    assert len(db.query_photos(FilterQuery(location_province="广东"))) == 0

    tree, unloc = db.get_location_hierarchy()
    assert unloc == 0
    assert tree[0][0] == "江苏"
    assert tree[0][2][0][0] == "盐城市"
    assert tree[0][2][0][2][0][0] == "条子泥湿地"


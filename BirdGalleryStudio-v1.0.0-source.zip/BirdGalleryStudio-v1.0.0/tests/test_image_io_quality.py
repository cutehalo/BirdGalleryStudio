"""Unit tests for image discovery, thumbnailing, and sharpness scoring."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

from bird_gallery.image_io import discover_photos, is_raw_file, save_thumbnail
from bird_gallery.quality import compute_sharpness_metrics


def _make_textured_image(size: tuple[int, int] = (400, 400)) -> Image.Image:
    rng = np.random.default_rng(42)
    h, w = size[1], size[0]
    y, x = np.mgrid[0:h, 0:w]
    pattern = (((x // 6) + (y // 6)) % 2) * 180 + rng.integers(0, 60, size=(h, w))
    arr = np.stack([pattern, pattern * 0.9, pattern * 0.8], axis=-1).clip(0, 255).astype(np.uint8)
    return Image.fromarray(arr, mode="RGB")


def test_sharpness_distinguishes_sharp_and_blurry_crops() -> None:
    sharp = _make_textured_image()
    blurry = sharp.filter(ImageFilter.GaussianBlur(radius=6))

    sharp_score, sharp_lap = compute_sharpness_metrics(sharp)
    blur_score, blur_lap = compute_sharpness_metrics(blurry)

    assert 0.0 <= blur_score < sharp_score <= 100.0
    assert sharp_score - blur_score > 25.0
    assert sharp_lap > blur_lap * 10


def test_discover_photos_handles_images_and_raw_extensions(tmp_path: Path) -> None:
    (tmp_path / "a.jpg").write_bytes(b"fake")
    (tmp_path / "b.CR3").write_bytes(b"fake")
    (tmp_path / "c.NEF").write_bytes(b"fake")
    (tmp_path / "notes.txt").write_text("ignore", encoding="utf-8")
    sub = tmp_path / "nested"
    sub.mkdir()
    (sub / "d.webp").write_bytes(b"fake")

    all_files = discover_photos(tmp_path, recursive=True, include_raw=True)
    assert [p.name for p in all_files] == ["a.jpg", "b.CR3", "c.NEF", "d.webp"]
    assert is_raw_file(tmp_path / "b.CR3")
    assert not is_raw_file(tmp_path / "a.jpg")

    no_raw = discover_photos(tmp_path, recursive=True, include_raw=False)
    assert [p.name for p in no_raw] == ["a.jpg", "d.webp"]

    non_recursive = discover_photos(tmp_path, recursive=False, include_raw=True)
    assert [p.name for p in non_recursive] == ["a.jpg", "b.CR3", "c.NEF"]


def test_save_thumbnail_resizes_image(tmp_path: Path) -> None:
    img = _make_textured_image((1200, 800))
    src = tmp_path / "bird.jpg"
    img.save(src)

    thumb_path = save_thumbnail(img, src, tmp_path / "thumbs", max_size=256)
    assert thumb_path.exists()
    with Image.open(thumb_path) as thumb:
        assert max(thumb.size) <= 256

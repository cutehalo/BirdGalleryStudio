"""Archive exporter: organize filtered bird photos into structured Chinese species folders."""

from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path
from typing import Literal

from bird_gallery.db import GalleryDatabase
from bird_gallery.models import ExportItem, ExportReport, FilterQuery, PhotoRecord
from bird_gallery.taxonomy import TaxonomyMapper

ExportMode = Literal["copy", "move", "hardlink", "symlink"]

_INVALID_FS_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_folder_segment(value: str, fallback: str = "未分类") -> str:
    cleaned = _INVALID_FS_CHARS.sub("_", value.strip()).strip(". ")
    return cleaned or fallback


def _resolve_unique_target(target_path: Path, source_path: Path) -> tuple[Path, bool]:
    """Resolve filename conflicts safely. Returns (resolved_path, already_same_file)."""
    if not target_path.exists():
        return target_path, False

    try:
        if target_path.resolve() == source_path.resolve():
            return target_path, True
    except OSError:
        pass

    stem = target_path.stem
    suffix = target_path.suffix
    parent = target_path.parent
    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate, False
        counter += 1


class ArchiveExporter:
    """Export queried photos into bird-species directory hierarchies."""

    def __init__(
        self,
        db: GalleryDatabase,
        taxonomy: TaxonomyMapper | None = None,
    ) -> None:
        self.db = db
        self.taxonomy = taxonomy or TaxonomyMapper()

    def build_relative_folder(self, photo: PhotoRecord, template: str) -> Path:
        """Render a directory template such as '{species_cn}' or '{order_cn}/{family_cn}/{species_cn}'."""
        species_cn = photo.effective_common_name_cn
        sci_name = photo.effective_scientific_name or "Unknown"

        order_cn = photo.primary_order_cn
        family_cn = photo.primary_family_cn
        if (not order_cn or not family_cn) and sci_name != "Unknown":
            entry = self.taxonomy.lookup(sci_name)
            if entry is not None:
                order_cn = order_cn or entry.order_cn
                family_cn = family_cn or entry.family_cn

        date_str = "未知日期"
        if photo.exif.taken_at and len(photo.exif.taken_at) >= 10:
            date_str = photo.exif.taken_at[:10]

        values = {
            "species_cn": sanitize_folder_segment(species_cn, "未知鸟种"),
            "scientific_name": sanitize_folder_segment(sci_name, "Unknown"),
            "order_cn": sanitize_folder_segment(order_cn, "未知目"),
            "family_cn": sanitize_folder_segment(family_cn, "未知科"),
            "date": sanitize_folder_segment(date_str, "未知日期"),
            "rating": f"{photo.rating}星",
        }

        rendered = template.format(**values)
        segments = [sanitize_folder_segment(seg) for seg in Path(rendered).parts if seg not in ("", ".", "..")]
        return Path(*segments) if segments else Path(values["species_cn"])

    def export(
        self,
        output_dir: str | Path,
        query: FilterQuery,
        *,
        mode: ExportMode = "copy",
        folder_template: str = "{species_cn}",
        dry_run: bool = False,
        manifest_path: str | Path | None = None,
    ) -> ExportReport:
        """Export photos matching `query` into `output_dir` according to `folder_template`."""
        out_root = Path(output_dir).expanduser().resolve()
        photos = self.db.query_photos(query, include_detections=False)

        report = ExportReport(
            mode=mode,
            output_dir=out_root,
            dry_run=dry_run,
            total_matched=len(photos),
        )

        # Track reserved paths during dry-run so collision numbering stays accurate
        reserved_targets: set[Path] = set()

        for photo in photos:
            src = Path(photo.file_path)
            rel_dir = self.build_relative_folder(photo, folder_template)
            desired_target = out_root / rel_dir / src.name

            if not src.exists():
                report.failed += 1
                report.items.append(
                    ExportItem(
                        photo_id=photo.photo_id or -1,
                        source_path=src,
                        target_path=desired_target,
                        species_cn=photo.effective_common_name_cn,
                        scientific_name=photo.effective_scientific_name,
                        status="missing_source",
                        error="Source file does not exist",
                    )
                )
                continue

            target_path, same_file = _resolve_unique_target(desired_target, src)
            while target_path in reserved_targets:
                target_path = target_path.with_name(f"{target_path.stem}_dup{target_path.suffix}")

            if same_file:
                report.skipped += 1
                report.items.append(
                    ExportItem(
                        photo_id=photo.photo_id or -1,
                        source_path=src,
                        target_path=target_path,
                        species_cn=photo.effective_common_name_cn,
                        scientific_name=photo.effective_scientific_name,
                        status="skipped_exists",
                    )
                )
                continue

            reserved_targets.add(target_path)

            if dry_run:
                report.exported += 1
                report.items.append(
                    ExportItem(
                        photo_id=photo.photo_id or -1,
                        source_path=src,
                        target_path=target_path,
                        species_cn=photo.effective_common_name_cn,
                        scientific_name=photo.effective_scientific_name,
                        status="planned",
                    )
                )
                continue

            try:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                if mode == "copy":
                    shutil.copy2(src, target_path)
                elif mode == "move":
                    shutil.move(str(src), str(target_path))
                    # Update DB path after moving so gallery stays consistent
                    if photo.photo_id is not None:
                        with self.db.connect() as conn:
                            conn.execute(
                                "UPDATE photos SET file_path = ?, folder_path = ?, file_name = ? WHERE id = ?",
                                (str(target_path), str(target_path.parent), target_path.name, photo.photo_id),
                            )
                elif mode == "hardlink":
                    os.link(src, target_path)
                elif mode == "symlink":
                    os.symlink(src, target_path)
                else:
                    raise ValueError(f"Unsupported export mode: {mode}")

                report.exported += 1
                report.items.append(
                    ExportItem(
                        photo_id=photo.photo_id or -1,
                        source_path=src,
                        target_path=target_path,
                        species_cn=photo.effective_common_name_cn,
                        scientific_name=photo.effective_scientific_name,
                        status="exported",
                    )
                )
            except Exception as exc:
                report.failed += 1
                report.items.append(
                    ExportItem(
                        photo_id=photo.photo_id or -1,
                        source_path=src,
                        target_path=target_path,
                        species_cn=photo.effective_common_name_cn,
                        scientific_name=photo.effective_scientific_name,
                        status="error",
                        error=str(exc),
                    )
                )

        if manifest_path is not None:
            self._write_manifest(report, Path(manifest_path))

        return report

    @staticmethod
    def _write_manifest(report: ExportReport, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "mode": report.mode,
            "output_dir": str(report.output_dir),
            "dry_run": report.dry_run,
            "total_matched": report.total_matched,
            "exported": report.exported,
            "skipped": report.skipped,
            "failed": report.failed,
            "items": [
                {
                    "photo_id": item.photo_id,
                    "source_path": str(item.source_path),
                    "target_path": str(item.target_path),
                    "species_cn": item.species_cn,
                    "scientific_name": item.scientific_name,
                    "status": item.status,
                    "error": item.error,
                }
                for item in report.items
            ],
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

"""Pure catalog management, folder import (no AI required), Bird Field Guide, and multi-album service."""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from bird_gallery.config import EngineConfig
from bird_gallery.db import GalleryDatabase
from bird_gallery.image_io import (
    compute_sha1,
    derive_taken_date,
    discover_photos,
    extract_exif,
    is_raw_file,
    load_image_for_inference,
    save_thumbnail,
)
from bird_gallery.models import (
    Album,
    FieldGuideSpeciesCard,
    FilterQuery,
    PhotoRecord,
    ScanSummary,
)
from bird_gallery.taxonomy import TaxonEntry, TaxonomyMapper

ImportProgressCallback = Callable[[int, int, Path, PhotoRecord | None, str | None], None]


@dataclass(slots=True)
class FieldGuideOverview:
    """Complete Bird Field Guide state including personal Life List metrics."""

    cards: list[FieldGuideSpeciesCard]
    lit_count: int
    total_checklist_count: int
    total_bird_photos: int
    matched_count: int = 0
    orders: list[str] = field(default_factory=list)
    families_by_order: dict[str, list[str]] = field(default_factory=dict)


class CatalogService:
    """UI-ready facade for Lightroom-style library browsing, Bird Field Guide, and virtual albums."""

    def __init__(
        self,
        db: GalleryDatabase,
        taxonomy: TaxonomyMapper | None = None,
        config: EngineConfig | None = None,
    ) -> None:
        self.db = db
        self.taxonomy = taxonomy or TaxonomyMapper()
        self.config = config or EngineConfig(db_path=db.db_path)

    # ---------------- Fast Folder Import (No AI / PyTorch Needed) ----------------

    def import_folder(
        self,
        source: str | Path,
        *,
        default_location: str = "",
        default_album_id: int | None = None,
        force_reimport: bool = False,
        on_progress: ImportProgressCallback | None = None,
        should_cancel: Callable[[], bool] | None = None,
    ) -> ScanSummary:
        """Import a folder or single file into the catalog, generating fast thumbnails and reading EXIF/GPS."""
        started = time.perf_counter()
        source_path = Path(source).expanduser().resolve()
        if source_path.is_dir():
            self.db.add_watched_folder(source_path)

        files = discover_photos(
            source_path,
            recursive=self.config.recursive,
            include_raw=self.config.include_raw,
        )
        summary = ScanSummary(total_discovered=len(files))

        imported_ids: list[int] = []

        for idx, file_path in enumerate(files, start=1):
            if should_cancel and should_cancel():
                break

            try:
                stat = file_path.stat()
                if not force_reimport and self.db.is_file_unchanged(
                    str(file_path), stat.st_size, stat.st_mtime
                ):
                    summary.skipped_existing += 1
                    if on_progress:
                        on_progress(idx, summary.total_discovered, file_path, None, "skipped")
                    continue

                record = self.import_single_file(file_path, default_location=default_location)
                if record.photo_id is not None:
                    imported_ids.append(record.photo_id)

                summary.processed += 1
                if record.has_bird:
                    summary.with_birds += 1
                else:
                    summary.no_birds += 1

                if on_progress:
                    on_progress(idx, summary.total_discovered, file_path, record, None)
            except Exception as exc:
                summary.failed += 1
                summary.errors.append((str(file_path), str(exc)))
                if on_progress:
                    on_progress(idx, summary.total_discovered, file_path, None, str(exc))

        if default_album_id is not None and imported_ids:
            self.db.add_photos_to_album(default_album_id, imported_ids)

        summary.elapsed_seconds = round(time.perf_counter() - started, 2)
        return summary

    def import_single_file(
        self,
        path: str | Path,
        *,
        default_location: str = "",
    ) -> PhotoRecord:
        """Read image/RAW dimensions, EXIF+GPS, generate thumbnail, and upsert into SQLite."""
        file_path = Path(path).expanduser().resolve()
        stat = file_path.stat()

        image = load_image_for_inference(file_path)
        width, height = image.size
        exif = extract_exif(file_path)
        taken_date = derive_taken_date(exif.taken_at, stat.st_mtime)

        thumb_path_str: str | None = None
        if self.config.generate_thumbnails:
            thumb_path = save_thumbnail(
                image,
                file_path,
                self.config.thumbnail_dir,
                max_size=self.config.thumbnail_max_size,
            )
            thumb_path_str = str(thumb_path)

        file_hash = compute_sha1(file_path) if self.config.compute_file_hash else None

        loc_name = default_location.strip()
        ebird_lid: str | None = None
        loc_prov = ""
        loc_city = ""
        if loc_name:
            fav = self.db.get_favorite_location_by_name(loc_name)
            if fav is not None:
                ebird_lid = fav.ebird_loc_id
                loc_prov = fav.province
                loc_city = fav.city
                if exif.gps_lat is None and fav.lat is not None and fav.lng is not None:
                    exif.gps_lat = fav.lat
                    exif.gps_lon = fav.lng
        if not loc_prov:
            from bird_gallery.china_regions import infer_province_city

            loc_prov, inf_c = infer_province_city(exif.gps_lat, exif.gps_lon, text_hint=loc_name)
            loc_city = loc_city or inf_c

        record = PhotoRecord(
            file_path=str(file_path),
            folder_path=str(file_path.parent),
            file_name=file_path.name,
            file_ext=file_path.suffix.lower(),
            file_size=stat.st_size,
            file_mtime=stat.st_mtime,
            is_raw=is_raw_file(file_path),
            width=width,
            height=height,
            file_hash=file_hash,
            thumbnail_path=thumb_path_str,
            exif=exif,
            taken_date=taken_date,
            location_name=loc_name,
            location_province=loc_prov,
            location_city=loc_city,
            ebird_loc_id=ebird_lid,
        )
        self.db.upsert_photo(record)
        return record

    def ensure_indexed(self, photos: list[PhotoRecord]) -> list[int]:
        """Fast on-demand indexing (~2ms/photo, header-only EXIF) for un-imported disk browser photos."""
        ids: list[int] = []
        watched_added: set[str] = set()

        for photo in photos:
            if photo.photo_id is not None:
                ids.append(photo.photo_id)
                continue

            file_path = Path(photo.file_path)
            if not file_path.exists():
                continue

            stat = file_path.stat()
            photo.file_size = stat.st_size
            photo.file_mtime = stat.st_mtime
            photo.folder_path = photo.folder_path or str(file_path.parent)

            # Read lightweight EXIF/GPS headers without decoding full pixel buffer
            if photo.exif.taken_at is None and photo.exif.camera_model is None:
                photo.exif = extract_exif(file_path)
            if not photo.taken_date:
                photo.taken_date = derive_taken_date(photo.exif.taken_at, stat.st_mtime)

            # Read image dimensions from header quickly for standard images
            if (photo.width == 0 or photo.height == 0) and not photo.is_raw:
                try:
                    from PIL import Image

                    with Image.open(file_path) as im:
                        photo.width, photo.height = im.size
                except Exception:
                    pass

            pid = self.db.upsert_photo(photo)
            ids.append(pid)
            if photo.folder_path and photo.folder_path not in watched_added:
                self.db.add_watched_folder(photo.folder_path)
                watched_added.add(photo.folder_path)

        return ids

    # ---------------- Bird Species Assignment & Field Guide ----------------

    def resolve_taxon(self, species_input: str) -> TaxonEntry:
        """Resolve Chinese name, Pinyin initials (e.g. 'ptcn'), formatted completion, or Latin name."""
        import re

        raw = species_input.strip()
        if raw.startswith("📋"):
            raw = re.sub(r"^📋\s*(?:\[[^\]]*\]\s*)?", "", raw).strip()
        if raw.startswith("🌏"):
            raw = raw.lstrip("🌏").strip()

        # Parse formatted completion strings like:
        # "普通翠鸟  [ptcn] · 翠鸟科 (Alcedo atthis)" or "普通翠鸟 (Alcedo atthis)"
        for sep in ("  [", " [", " ("):
            if sep in raw:
                cn_part = raw.split(sep, 1)[0].strip()
                entry = self.taxonomy.lookup_by_cn(cn_part)
                if entry is not None:
                    return entry

        entry = self.taxonomy.lookup_by_cn(raw) or self.taxonomy.lookup(raw)
        if entry is not None:
            return entry

        # Support direct Enter after typing Pinyin initials / full Pinyin (e.g. 'ptcn', 'btb', 'cuiniao')
        matches = self.taxonomy.search(raw, limit=1, prefer_china=True)
        if matches:
            return matches[0]

        # Custom species outside built-in checklist
        if re.fullmatch(r"[A-Za-z\s\-]+", raw):
            return TaxonEntry(scientific_name=raw, common_name_cn=raw, order_cn="其他目", family_cn="其他科")
        return TaxonEntry(scientific_name="", common_name_cn=raw, order_cn="其他目", family_cn="其他科")

    def assign_species(self, photo_ids: list[int], species_input: str) -> TaxonEntry:
        """Set (replace) 1 or multiple photos to a single bird species from the Field Guide."""
        entry = self.resolve_taxon(species_input)
        self.db.batch_assign_species(
            photo_ids,
            common_name_cn=entry.common_name_cn,
            scientific_name=entry.scientific_name,
            common_name_en=entry.common_name_en,
            order_cn=entry.order_cn or "未分类目",
            family_cn=entry.family_cn or "未分类科",
        )
        return entry

    def add_species(self, photo_ids: list[int], species_inputs: list[str]) -> list[TaxonEntry]:
        """Append 1 or multiple co-occurring bird species onto `photo_ids` without overwriting existing species."""
        entries = [self.resolve_taxon(s) for s in species_inputs if s.strip()]
        tuples = [
            (
                e.common_name_cn,
                e.scientific_name,
                e.common_name_en,
                e.order_cn or "未分类目",
                e.family_cn or "未分类科",
            )
            for e in entries
        ]
        if tuples:
            self.db.batch_add_species(photo_ids, tuples)
        return entries

    def set_species_list(self, photo_ids: list[int], species_inputs: list[str]) -> list[TaxonEntry]:
        """Set the exact multi-species list on `photo_ids`."""
        entries = [self.resolve_taxon(s) for s in species_inputs if s.strip()]
        tuples = [
            (
                e.common_name_cn,
                e.scientific_name,
                e.common_name_en,
                e.order_cn or "未分类目",
                e.family_cn or "未分类科",
            )
            for e in entries
        ]
        self.db.batch_set_species_list(photo_ids, tuples)
        return entries

    def remove_species(self, photo_ids: list[int], species_cn: str) -> int:
        """Remove one species tag from `photo_ids` while keeping any other species tags."""
        return self.db.batch_remove_species(photo_ids, species_cn)

    def clear_species(self, photo_ids: list[int]) -> int:
        return self.db.batch_assign_species(photo_ids, common_name_cn="", scientific_name="")

    def get_field_guide(
        self,
        *,
        scope: str = "china",  # "china" (~1,411 species) | "world" (~11,011 species)
        status_filter: str = "all",  # "all" | "lit" | "unlit"
        order_cn: str | None = None,
        family_cn: str | None = None,
        keyword: str = "",
        max_cards: int = 360,
    ) -> FieldGuideOverview:
        """Build the Bird Field Guide cards and Life List ('点亮图鉴') summary with Pinyin search."""
        import re

        photographed = self.db.get_photographed_species_summary()
        lit_by_cn: dict[str, dict[str, object]] = {
            str(item["species_cn"]): item for item in photographed
        }

        china_only = scope == "china"
        seen_cn: set[str] = set()
        all_cards: list[tuple[TaxonEntry | None, FieldGuideSpeciesCard]] = []
        orders_set: list[str] = []
        families_map: dict[str, list[str]] = defaultdict(list)

        for taxon in self.taxonomy.all_entries(china_only=False):
            if not taxon.common_name_cn or taxon.common_name_cn in seen_cn:
                continue
            is_photographed = taxon.common_name_cn in lit_by_cn
            # In China scope, include all China birds PLUS any foreign birds the user already photographed
            if china_only and not taxon.in_china and not is_photographed:
                continue

            seen_cn.add(taxon.common_name_cn)
            ord_name = taxon.order_cn or "其他目"
            fam_name = taxon.family_cn or "其他科"
            if ord_name not in orders_set:
                orders_set.append(ord_name)
            if fam_name not in families_map[ord_name]:
                families_map[ord_name].append(fam_name)

            lit_info = lit_by_cn.pop(taxon.common_name_cn, None)
            if lit_info is not None:
                card = FieldGuideSpeciesCard(
                    scientific_name=taxon.scientific_name,
                    common_name_cn=taxon.common_name_cn,
                    common_name_en=taxon.common_name_en,
                    order_cn=ord_name,
                    family_cn=fam_name,
                    is_lit=True,
                    photo_count=int(lit_info["photo_count"]),  # type: ignore[arg-type]
                    cover_photo_id=int(lit_info["cover_photo_id"]),  # type: ignore[arg-type]
                    cover_thumbnail_path=str(lit_info["cover_thumbnail_path"] or "") or None,
                    cover_file_path=str(lit_info["cover_file_path"] or "") or None,
                    first_seen_date=str(lit_info["first_seen_date"] or "") or None,
                )
            else:
                card = FieldGuideSpeciesCard(
                    scientific_name=taxon.scientific_name,
                    common_name_cn=taxon.common_name_cn,
                    common_name_en=taxon.common_name_en,
                    order_cn=ord_name,
                    family_cn=fam_name,
                    is_lit=False,
                )
            all_cards.append((taxon, card))

        # Include any user-added custom bird species not in built-in CSV
        for custom_cn, lit_info in lit_by_cn.items():
            ord_name = str(lit_info.get("order_cn") or "自定义鸟种")
            fam_name = str(lit_info.get("family_cn") or "未分类科")
            if ord_name not in orders_set:
                orders_set.append(ord_name)
            if fam_name not in families_map[ord_name]:
                families_map[ord_name].append(fam_name)

            all_cards.append(
                (
                    None,
                    FieldGuideSpeciesCard(
                        scientific_name=str(lit_info.get("scientific_name") or ""),
                        common_name_cn=custom_cn,
                        common_name_en=str(lit_info.get("common_name_en") or ""),
                        order_cn=ord_name,
                        family_cn=fam_name,
                        is_lit=True,
                        photo_count=int(lit_info["photo_count"]),  # type: ignore[arg-type]
                        cover_photo_id=int(lit_info["cover_photo_id"]),  # type: ignore[arg-type]
                        cover_thumbnail_path=str(lit_info["cover_thumbnail_path"] or "") or None,
                        cover_file_path=str(lit_info["cover_file_path"] or "") or None,
                        first_seen_date=str(lit_info["first_seen_date"] or "") or None,
                    ),
                )
            )

        lit_count = sum(1 for _t, c in all_cards if c.is_lit)
        total_bird_photos = sum(c.photo_count for _t, c in all_cards)

        raw_kw = keyword.strip().lower()
        alpha_kw = re.sub(r"[\s\-_']", "", raw_kw)
        py_alt = alpha_kw.replace("lu", "lv") if "lu" in alpha_kw else ""

        scored_cards: list[tuple[int, FieldGuideSpeciesCard]] = []
        for taxon, card in all_cards:
            if status_filter == "lit" and not card.is_lit:
                continue
            if status_filter == "unlit" and card.is_lit:
                continue
            if order_cn and card.order_cn != order_cn:
                continue
            if family_cn and card.family_cn != family_cn:
                continue
            if raw_kw:
                if taxon is not None:
                    tier = self.taxonomy.score_entry(taxon, raw_kw, alpha_kw, py_alt)
                    if tier is None:
                        continue
                else:
                    hay = f"{card.common_name_cn} {card.scientific_name}".lower()
                    if raw_kw not in hay:
                        continue
                    tier = 3
                scored_cards.append((tier, card))
            else:
                scored_cards.append((0, card))

        if raw_kw:
            scored_cards.sort(key=lambda x: (x[0], not x[1].is_lit, -x[1].photo_count, len(x[1].common_name_cn)))
        else:
            scored_cards.sort(key=lambda x: (not x[1].is_lit, -x[1].photo_count, x[1].order_cn, x[1].family_cn, x[1].common_name_cn))

        matched_total = len(scored_cards)
        limited_cards = [c for _tier, c in scored_cards[:max_cards]]

        return FieldGuideOverview(
            cards=limited_cards,
            lit_count=lit_count,
            total_checklist_count=len(all_cards),
            total_bird_photos=total_bird_photos,
            matched_count=matched_total,
            orders=orders_set,
            families_by_order=dict(families_map),
        )

    # ---------------- Navigation Trees (Species / Date / Location / Folders / Albums) ----------------

    def get_photographed_species_tree(self) -> list[tuple[str, int, list[tuple[str, int, list[tuple[str, int]]]]]]:
        """Return hierarchical [(order_cn, count, [(family_cn, count, [(species_cn, count)])])] for photographed birds."""
        summary = self.db.get_photographed_species_summary()
        tree: dict[str, dict[str, list[tuple[str, int]]]] = defaultdict(lambda: defaultdict(list))

        for item in summary:
            sp_cn = str(item["species_cn"])
            cnt = int(item["photo_count"])  # type: ignore[arg-type]
            taxon = self.taxonomy.lookup_by_cn(sp_cn) or self.taxonomy.lookup(str(item.get("scientific_name") or ""))
            ord_cn = str(item.get("order_cn") or (taxon.order_cn if taxon else "") or "其他目")
            fam_cn = str(item.get("family_cn") or (taxon.family_cn if taxon else "") or "其他科")
            tree[ord_cn][fam_cn].append((sp_cn, cnt))

        result: list[tuple[str, int, list[tuple[str, int, list[tuple[str, int]]]]]] = []
        for ord_cn, fam_dict in tree.items():
            fam_list: list[tuple[str, int, list[tuple[str, int]]]] = []
            ord_total = 0
            for fam_cn, sp_list in fam_dict.items():
                sp_sorted = sorted(sp_list, key=lambda x: (-x[1], x[0]))
                fam_total = sum(x[1] for x in sp_sorted)
                ord_total += fam_total
                fam_list.append((fam_cn, fam_total, sp_sorted))
            fam_list.sort(key=lambda x: (-x[1], x[0]))
            result.append((ord_cn, ord_total, fam_list))

        result.sort(key=lambda x: (-x[1], x[0]))
        return result

    def get_date_hierarchy(self) -> tuple[list[tuple[str, int, list[tuple[str, int, list[tuple[str, int]]]]]], int]:
        """Return ([(year, count, [(year_month, count, [(yyyy_mm_dd, count)])])], undated_count)."""
        raw_counts = self.db.get_date_counts()
        years: dict[str, dict[str, list[tuple[str, int]]]] = defaultdict(lambda: defaultdict(list))
        undated = 0

        for date_str, cnt in raw_counts:
            if not date_str or len(date_str) < 10:
                undated += cnt
                continue
            yr = date_str[:4]
            ym = date_str[:7]
            years[yr][ym].append((date_str[:10], cnt))

        hierarchy: list[tuple[str, int, list[tuple[str, int, list[tuple[str, int]]]]]] = []
        for yr in sorted(years.keys(), reverse=True):
            ym_list: list[tuple[str, int, list[tuple[str, int]]]] = []
            yr_total = 0
            for ym in sorted(years[yr].keys(), reverse=True):
                days = sorted(years[yr][ym], key=lambda x: x[0], reverse=True)
                ym_total = sum(x[1] for x in days)
                yr_total += ym_total
                ym_list.append((ym, ym_total, days))
            hierarchy.append((yr, yr_total, ym_list))

        return hierarchy, undated

    def get_location_albums(self) -> list[tuple[str, str, int]]:
        """Return [(location_key, display_label, photo_count)] for location album navigation."""
        raw = self.db.get_location_counts()
        out: list[tuple[str, str, int]] = []
        for key, cnt in raw:
            if key == "__unlocated__":
                out.append((key, "未设置地点", cnt))
            else:
                out.append((key, key, cnt))
        return out

    def get_location_hierarchy(
        self,
    ) -> tuple[list[tuple[str, int, list[tuple[str, int, list[tuple[str, str, int, str | None, bool]]]]]], int]:
        """Return hierarchical `(provinces_tree, unlocated_count)` grouped by Province -> Prefecture/City -> Spot.

        Each spot tuple is `(loc_key, display_label, photo_count, ebird_loc_id, is_favorite)`.
        """
        return self.db.get_location_hierarchy()

    def list_albums(self) -> list[Album]:
        return self.db.list_albums()

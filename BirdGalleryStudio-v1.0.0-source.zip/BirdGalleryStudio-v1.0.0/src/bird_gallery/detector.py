"""YOLO-based bird object detector and padded cropping."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from PIL import Image

# COCO dataset class index for "bird"
COCO_BIRD_CLASS_ID = 14


@dataclass(slots=True)
class RawDetection:
    """Bounding box and confidence returned by a bird detector."""

    bbox: tuple[int, int, int, int]  # (x1, y1, x2, y2)
    confidence: float


class BirdDetector(Protocol):
    """Pluggable bird detection interface."""

    def detect(self, image: Image.Image) -> list[RawDetection]:
        ...


def crop_with_padding(
    image: Image.Image,
    bbox: tuple[int, int, int, int],
    padding: float = 0.15,
) -> Image.Image:
    """Crop a detected bird region with contextual padding clamped to image bounds."""
    width, height = image.size
    x1, y1, x2, y2 = bbox
    box_w = max(1, x2 - x1)
    box_h = max(1, y2 - y1)

    pad_x = int(box_w * padding)
    pad_y = int(box_h * padding)

    cx1 = max(0, x1 - pad_x)
    cy1 = max(0, y1 - pad_y)
    cx2 = min(width, x2 + pad_x)
    cy2 = min(height, y2 + pad_y)

    if cx2 <= cx1 or cy2 <= cy1:
        return image
    return image.crop((cx1, cy1, cx2, cy2))


class YoloBirdDetector:
    """Ultralytics YOLO bird detector (defaults to yolo11s.pt on GPU)."""

    def __init__(
        self,
        model_name: str = "yolo11s.pt",
        *,
        device: str = "cuda",
        conf: float = 0.25,
        iou: float = 0.45,
        min_crop_size: int = 32,
        max_birds: int = 8,
    ) -> None:
        self.model_name = model_name
        self.device = device
        self.conf = conf
        self.iou = iou
        self.min_crop_size = min_crop_size
        self.max_birds = max_birds
        self._model = None

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        try:
            from ultralytics import YOLO
        except ImportError as exc:
            raise RuntimeError(
                "YOLO detection requires `ultralytics`. Install AI extras with: uv sync --extra ai"
            ) from exc

        self._model = YOLO(self.model_name)

    def detect(self, image: Image.Image) -> list[RawDetection]:
        self._ensure_loaded()
        assert self._model is not None

        results = self._model.predict(
            source=image,
            classes=[COCO_BIRD_CLASS_ID],
            conf=self.conf,
            iou=self.iou,
            device=self.device,
            verbose=False,
        )

        detections: list[RawDetection] = []
        if not results:
            return detections

        boxes = results[0].boxes
        if boxes is None or len(boxes) == 0:
            return detections

        xyxy_list = boxes.xyxy.cpu().tolist()
        conf_list = boxes.conf.cpu().tolist()

        for coords, score in zip(xyxy_list, conf_list):
            x1, y1, x2, y2 = (int(round(v)) for v in coords)
            if (x2 - x1) < self.min_crop_size or (y2 - y1) < self.min_crop_size:
                continue
            detections.append(RawDetection(bbox=(x1, y1, x2, y2), confidence=float(score)))

        # Prioritize high-confidence, prominent birds
        detections.sort(
            key=lambda d: (d.confidence, (d.bbox[2] - d.bbox[0]) * (d.bbox[3] - d.bbox[1])),
            reverse=True,
        )
        return detections[: self.max_birds]

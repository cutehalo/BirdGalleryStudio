"""End-to-end local GPU bird scanning, culling, and classification pipeline."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Callable

from bird_gallery.classifier import BioClipClassifier, SpeciesClassifier
from bird_gallery.config import EngineConfig
from bird_gallery.db import GalleryDatabase
from bird_gallery.detector import BirdDetector, YoloBirdDetector, crop_with_padding
from bird_gallery.image_io import (
    compute_sha1,
    discover_photos,
    extract_exif,
    is_raw_file,
    load_image_for_inference,
    save_thumbnail,
)
from bird_gallery.models import BirdDetection, PhotoRecord, ScanSummary
from bird_gallery.quality import compute_sharpness_metrics
from bird_gallery.taxonomy import TaxonomyMapper

ProgressCallback = Callable[[int, int, Path, PhotoRecord | None, str | None], None]


class BirdGalleryPipeline:
    """Orchestrates photo discovery, RAW preview decoding, bird detection, sharpness, classification, and indexing."""

    def __init__(
        self,
        config: EngineConfig | None = None,
        *,
        db: GalleryDatabase | None = None,
        taxonomy: TaxonomyMapper | None = None,
        detector: BirdDetector | None = None,
        classifier: SpeciesClassifier | None = None,
    ) -> None:
        self.config = config or EngineConfig()
        self.db = db or GalleryDatabase(self.config.db_path)
        self.taxonomy = taxonomy or TaxonomyMapper(self.config.taxonomy_csv)

        resolved_device = self.config.resolve_device()
        self.device = resolved_device

        self.detector: BirdDetector = detector or YoloBirdDetector(
            model_name=self.config.yolo_model,
            device=resolved_device,
            conf=self.config.detect_conf,
            iou=self.config.detect_iou,
            min_crop_size=self.config.min_crop_size,
            max_birds=self.config.max_birds_per_photo,
        )
        self.classifier: SpeciesClassifier = classifier or BioClipClassifier(
            device=resolved_device,
            model_str=self.config.bioclip_model,
            filter_aves_only=self.config.filter_aves_only,
            restrict_to_taxonomy=self.config.restrict_to_taxonomy_csv,
            taxonomy=self.taxonomy,
        )

    def process_file(self, path: str | Path) -> PhotoRecord:
        """Run full detection, sharpness evaluation, species classification, and DB indexing on one file."""
        file_path = Path(path).expanduser().resolve()
        stat = file_path.stat()

        image = load_image_for_inference(file_path)
        width, height = image.size
        exif = extract_exif(file_path)

        thumb_path_str: str | None = None
        if self.config.generate_thumbnails:
            thumb_path = save_thumbnail(
                image,
                file_path,
                self.config.thumbnail_dir,
                max_size=self.config.thumbnail_max_size,
            )
            thumb_path_str = str(thumb_path)

        file_hash = compute_sha1(file_path) if self.config.compute_file_hash else None

        raw_detections = self.detector.detect(image)
        detections: list[BirdDetection] = []

        for raw_det in raw_detections:
            crop = crop_with_padding(image, raw_det.bbox, padding=self.config.crop_padding)
            sharpness_score, raw_lap_var = compute_sharpness_metrics(crop)
            predictions = self.classifier.classify(crop, top_k=self.config.top_k)

            # Enrich predictions with taxonomy mapper if custom classifier did not populate CN names
            for pred in predictions:
                if not pred.common_name_cn and pred.scientific_name:
                    entry = self.taxonomy.lookup(pred.scientific_name)
                    if entry is not None:
                        pred.common_name_cn = entry.common_name_cn
                        pred.common_name_en = pred.common_name_en or entry.common_name_en
                        pred.order_cn = pred.order_cn or entry.order_cn
                        pred.family_cn = pred.family_cn or entry.family_cn

            detections.append(
                BirdDetection(
                    bbox=raw_det.bbox,
                    detect_conf=round(raw_det.confidence, 4),
                    sharpness_score=sharpness_score,
                    raw_laplacian_var=raw_lap_var,
                    predictions=predictions,
                )
            )

        has_bird = len(detections) > 0
        best_sharpness = max((d.sharpness_score for d in detections), default=0.0)
        is_blurry = has_bird and (best_sharpness < self.config.sharpness_blur_threshold)

        primary_sci = ""
        primary_cn = ""
        primary_en = ""
        primary_order_cn = ""
        primary_family_cn = ""
        primary_conf = 0.0

        if detections:
            # Select primary bird by combining detection confidence and species confidence
            best_det = max(
                detections,
                key=lambda d: (
                    (d.top_prediction.score if d.top_prediction else 0.0) * 0.7
                    + d.detect_conf * 0.3,
                    d.sharpness_score,
                ),
            )
            top_pred = best_det.top_prediction
            if top_pred is not None:
                primary_sci = top_pred.scientific_name
                primary_cn = top_pred.common_name_cn
                primary_en = top_pred.common_name_en
                primary_order_cn = top_pred.order_cn
                primary_family_cn = top_pred.family_cn
                primary_conf = top_pred.score

        record = PhotoRecord(
            file_path=str(file_path),
            file_name=file_path.name,
            file_ext=file_path.suffix.lower(),
            file_size=stat.st_size,
            file_mtime=stat.st_mtime,
            is_raw=is_raw_file(file_path),
            width=width,
            height=height,
            file_hash=file_hash,
            thumbnail_path=thumb_path_str,
            exif=exif,
            has_bird=has_bird,
            bird_count=len(detections),
            is_blurry=is_blurry,
            best_sharpness=best_sharpness,
            primary_scientific_name=primary_sci,
            primary_common_name_cn=primary_cn,
            primary_common_name_en=primary_en,
            primary_order_cn=primary_order_cn,
            primary_family_cn=primary_family_cn,
            primary_confidence=primary_conf,
            detections=detections,
        )
        self.db.upsert_photo(record)
        return record

    def scan_directory(
        self,
        source: str | Path,
        *,
        on_progress: ProgressCallback | None = None,
    ) -> ScanSummary:
        """Scan a file or folder recursively, skipping unchanged photos if configured."""
        started = time.perf_counter()
        files = discover_photos(
            source,
            recursive=self.config.recursive,
            include_raw=self.config.include_raw,
        )
        summary = ScanSummary(total_discovered=len(files))

        for idx, file_path in enumerate(files, start=1):
            try:
                stat = file_path.stat()
                if self.config.skip_existing and self.db.is_file_unchanged(
                    str(file_path), stat.st_size, stat.st_mtime
                ):
                    summary.skipped_existing += 1
                    if on_progress:
                        on_progress(idx, summary.total_discovered, file_path, None, "skipped")
                    continue

                record = self.process_file(file_path)
                summary.processed += 1
                if record.has_bird:
                    summary.with_birds += 1
                else:
                    summary.no_birds += 1
                if record.is_blurry:
                    summary.flagged_blurry += 1

                if on_progress:
                    on_progress(idx, summary.total_discovered, file_path, record, None)
            except Exception as exc:
                summary.failed += 1
                summary.errors.append((str(file_path), str(exc)))
                if on_progress:
                    on_progress(idx, summary.total_discovered, file_path, None, str(exc))

        summary.elapsed_seconds = round(time.perf_counter() - started, 2)
        return summary

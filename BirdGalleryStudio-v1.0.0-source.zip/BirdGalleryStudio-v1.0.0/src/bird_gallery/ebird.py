"""eBird Hotspot API v2 client, local Pinyin/GPS search, and Favorite Birding Locations service."""

from __future__ import annotations

import json
import math
import os
import re
import urllib.error
import urllib.parse
import urllib.request

from bird_gallery.china_regions import (
    format_province_city,
    infer_province_city,
    normalize_province_name,
)
from bird_gallery.db import GalleryDatabase
from bird_gallery.models import EBirdHotspot, FavoriteLocation
from bird_gallery.taxonomy import compute_pinyin_fields

EBIRD_API_BASE = "https://api.ebird.org/v2"
SETTING_EBIRD_API_KEY = "ebird_api_key"
SETTING_EBIRD_REGIONS = "ebird_sync_regions"

# Human-readable Chinese province/region labels for eBird subnational1Code
REGION_CODE_LABELS: dict[str, str] = {
    "CN": "中国大陆",
    "HK": "中国香港",
    "MO": "中国澳门",
    "TW": "中国台湾",
    "CN-11": "北京",
    "CN-12": "天津",
    "CN-13": "河北",
    "CN-14": "山西",
    "CN-15": "内蒙古",
    "CN-21": "辽宁",
    "CN-22": "吉林",
    "CN-23": "黑龙江",
    "CN-31": "上海",
    "CN-32": "江苏",
    "CN-33": "浙江",
    "CN-34": "安徽",
    "CN-35": "福建",
    "CN-36": "江西",
    "CN-37": "山东",
    "CN-41": "河南",
    "CN-42": "湖北",
    "CN-43": "湖南",
    "CN-44": "广东",
    "CN-45": "广西",
    "CN-46": "海南",
    "CN-50": "重庆",
    "CN-51": "四川",
    "CN-52": "贵州",
    "CN-53": "云南",
    "CN-54": "西藏",
    "CN-61": "陕西",
    "CN-62": "甘肃",
    "CN-63": "青海",
    "CN-64": "宁夏",
    "CN-65": "新疆",
}

_LOC_ID_PATTERN = re.compile(r"\b(L\d{4,12})\b", re.IGNORECASE)


def format_region_label(country_code: str, subnational1_code: str) -> str:
    if subnational1_code in REGION_CODE_LABELS:
        return REGION_CODE_LABELS[subnational1_code]
    if country_code in REGION_CODE_LABELS:
        return REGION_CODE_LABELS[country_code]
    return subnational1_code or country_code


def extract_ebird_loc_id(text: str) -> str | None:
    """Extract an eBird Hotspot ID like 'L2586431' from raw text or an eBird URL."""
    m = _LOC_ID_PATTERN.search(text.strip())
    return m.group(1).upper() if m else None


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two decimal degree coordinates in kilometers."""
    r = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    return 2.0 * r * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))


def suggest_short_spot_name(ebird_loc_name: str, subnational1_code: str = "") -> str:
    """Derive a concise Chinese-friendly alias from a bilingual eBird hotspot name.

    For example:
    'Beijing--Olympic Forest Park (奥林匹克森林公园)' -> '北京·奥林匹克森林公园'
    """
    raw = ebird_loc_name.strip()
    m_cn = re.search(r"[（(]([^()（）]*[\u4e00-\u9fff]+[^()（）]*)[)）]", raw)
    core = m_cn.group(1).strip() if m_cn else raw
    prov = REGION_CODE_LABELS.get(subnational1_code, "")
    if prov and not core.startswith(prov):
        return f"{prov}·{core}"
    return core


class EBirdLocationService:
    """Manages Favorite Birding Locations and official eBird Hotspot syncing/searching."""

    def __init__(self, db: GalleryDatabase) -> None:
        self.db = db

    # ---------------- Settings ----------------

    def get_api_key(self) -> str:
        saved = self.db.get_setting(SETTING_EBIRD_API_KEY, "").strip()
        if saved:
            return saved
        return os.environ.get("EBIRD_API_KEY", "").strip()

    def set_api_key(self, api_key: str) -> None:
        self.db.set_setting(SETTING_EBIRD_API_KEY, api_key.strip())

    def get_sync_regions(self) -> str:
        return self.db.get_setting(SETTING_EBIRD_REGIONS, "CN,HK,TW,MO")

    def set_sync_regions(self, regions: str) -> None:
        self.db.set_setting(SETTING_EBIRD_REGIONS, regions.strip() or "CN")

    # ---------------- Official eBird API v2 Requests ----------------

    def _ebird_get_json(self, path: str, params: dict[str, str] | None = None) -> object:
        api_key = self.get_api_key()
        if not api_key:
            raise RuntimeError("尚未设置 eBird API Key，请先在上方填入免费的 eBird API Key。")

        query = f"?{urllib.parse.urlencode(params)}" if params else ""
        url = f"{EBIRD_API_BASE}{path}{query}"
        req = urllib.request.Request(
            url,
            headers={
                "X-eBirdApiToken": api_key,
                "User-Agent": "NiaoYuJi/1.0",
                "Accept": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                raise RuntimeError("eBird API Key 无效或无权限（HTTP 403），请检查 Key 是否正确。") from exc
            if exc.code == 404:
                raise RuntimeError(f"未找到对应的地区或鸟点编号（{path}）。") from exc
            raise RuntimeError(f"请求 eBird 接口失败：HTTP {exc.code}") from exc
        except Exception as exc:
            raise RuntimeError(f"连接 eBird 网络失败：{exc}") from exc

    @staticmethod
    def _parse_hotspot_dict(item: dict[str, object]) -> EBirdHotspot | None:
        loc_id = str(item.get("locId") or "").strip()
        loc_name = str(item.get("locName") or item.get("name") or "").strip()
        if not loc_id or not loc_name:
            return None
        ini, full_py = compute_pinyin_fields(loc_name)
        lat_raw = item.get("lat") if item.get("lat") is not None else item.get("latitude")
        lng_raw = item.get("lng") if item.get("lng") is not None else item.get("longitude")
        lat_val = float(lat_raw) if lat_raw is not None else None  # type: ignore[arg-type]
        lng_val = float(lng_raw) if lng_raw is not None else None  # type: ignore[arg-type]
        num_sp_raw = item.get("numSpeciesAllTime") or 0
        country_code = str(item.get("countryCode") or "")
        sub1 = str(item.get("subnational1Code") or "")
        sub2 = str(item.get("subnational2Code") or "")
        _prov, city_cn = infer_province_city(
            lat_val,
            lng_val,
            subnational1_code=sub1 or country_code,
            text_hint=loc_name,
        )

        return EBirdHotspot(
            loc_id=loc_id,
            loc_name=loc_name,
            country_code=country_code,
            subnational1_code=sub1,
            subnational2_code=sub2,
            city_name=city_cn,
            lat=lat_val,
            lng=lng_val,
            num_species=int(num_sp_raw),  # type: ignore[arg-type]
            latest_obs_dt=str(item.get("latestObsDt") or ""),
            pinyin_initials=ini,
            pinyin_full=full_py,
        )

    def sync_regions(self, regions_csv: str) -> tuple[int, list[str]]:
        """Download and cache all eBird hotspots for one or more region codes (e.g. 'CN,HK,TW' or 'CN-11')."""
        codes = [c.strip().upper() for c in re.split(r"[,;，；\s]+", regions_csv) if c.strip()]
        if not codes:
            raise ValueError("请输入至少一个地区代码（如 CN、CN-11、HK、TW）")

        total_synced = 0
        synced_codes: list[str] = []
        for code in codes:
            data = self._ebird_get_json(f"/ref/hotspot/{code}", {"fmt": "json"})
            if isinstance(data, list):
                parsed = [h for item in data if isinstance(item, dict) and (h := self._parse_hotspot_dict(item))]
                total_synced += self.db.upsert_ebird_hotspots(parsed)
                synced_codes.append(f"{code}({len(parsed)})")
        self.set_sync_regions(",".join(codes))
        return total_synced, synced_codes

    def fetch_hotspot_by_id_or_url(self, text: str) -> EBirdHotspot | None:
        """Resolve a single eBird hotspot by L-code or URL (checks local cache first, then API)."""
        loc_id = extract_ebird_loc_id(text)
        if not loc_id:
            return None
        cached = self.db.get_ebird_hotspot(loc_id)
        if cached is not None:
            return cached
        if not self.get_api_key():
            return None
        data = self._ebird_get_json(f"/ref/hotspot/info/{loc_id}")
        if isinstance(data, dict):
            hotspot = self._parse_hotspot_dict(data)
            if hotspot is not None:
                self.db.upsert_ebird_hotspots([hotspot])
                return hotspot
        return None

    def find_nearby_hotspots(
        self,
        lat: float,
        lng: float,
        *,
        dist_km: float = 20.0,
        try_online: bool = True,
        limit: int = 30,
    ) -> list[EBirdHotspot]:
        """Find eBird hotspots near decimal coordinates (online `/ref/hotspot/geo` + local cache)."""
        if try_online and self.get_api_key():
            try:
                data = self._ebird_get_json(
                    "/ref/hotspot/geo",
                    {
                        "lat": f"{lat:.5f}",
                        "lng": f"{lng:.5f}",
                        "dist": str(max(1, min(50, int(round(dist_km))))),
                        "fmt": "json",
                    },
                )
                if isinstance(data, list):
                    parsed = [h for item in data if isinstance(item, dict) and (h := self._parse_hotspot_dict(item))]
                    self.db.upsert_ebird_hotspots(parsed)
            except Exception:
                # Gracefully fall back to offline cached hotspots if offline
                pass

        candidates: list[EBirdHotspot] = []
        for h in self.db.load_all_ebird_hotspots():
            if h.lat is None or h.lng is None:
                continue
            d = haversine_km(lat, lng, h.lat, h.lng)
            if d <= dist_km:
                h.distance_km = round(d, 2)
                candidates.append(h)

        candidates.sort(key=lambda x: (x.distance_km if x.distance_km is not None else 9999.0, -x.num_species))
        return candidates[:limit]

    # ---------------- Local Fast Search (Name + Pinyin Initials + L-Code) ----------------

    def search_cached_hotspots(
        self,
        keyword: str,
        *,
        region_filter: str = "",
        limit: int = 60,
    ) -> list[EBirdHotspot]:
        """Search locally cached eBird hotspots by Chinese/English name, Pinyin initials, province, or L-code."""
        all_items = self.db.load_all_ebird_hotspots(region_filter)
        raw_kw = keyword.strip()
        if not raw_kw:
            return all_items[:limit]

        # Direct L-code or URL paste
        loc_id = extract_ebird_loc_id(raw_kw)
        if loc_id:
            exact = [h for h in all_items if h.loc_id.upper() == loc_id]
            if exact:
                return exact
            fetched = self.fetch_hotspot_by_id_or_url(loc_id)
            return [fetched] if fetched else []

        kw_low = raw_kw.lower()
        alpha_kw = re.sub(r"[\s\-_·']", "", kw_low)

        scored: list[tuple[int, int, EBirdHotspot]] = []
        for h in all_items:
            name_low = h.loc_name.lower()
            reg_cn = format_region_label(h.country_code, h.subnational1_code).lower()
            city_low = (h.city_name or "").lower()

            tier: int | None = None
            if kw_low == name_low or (alpha_kw and h.pinyin_initials == alpha_kw):
                tier = 0
            elif name_low.startswith(kw_low) or (alpha_kw and h.pinyin_initials.startswith(alpha_kw)):
                tier = 1
            elif kw_low in name_low or (alpha_kw and len(alpha_kw) >= 2 and alpha_kw in h.pinyin_initials):
                tier = 2
            elif (alpha_kw and len(alpha_kw) >= 2 and alpha_kw in h.pinyin_full) or (city_low and kw_low in city_low):
                tier = 3
            elif kw_low in reg_cn or kw_low == h.subnational1_code.lower():
                tier = 4

            if tier is not None:
                scored.append((tier, -h.num_species, h))

        scored.sort(key=lambda x: (x[0], x[1], x[2].loc_name))
        return [x[2] for x in scored[:limit]]

    # ---------------- Favorite Locations & Unified Location Assignment ----------------

    def list_favorites(self) -> list[FavoriteLocation]:
        return self.db.list_favorite_locations()

    def save_favorite_from_hotspot(
        self,
        hotspot: EBirdHotspot,
        *,
        alias_name: str = "",
        notes: str = "",
    ) -> FavoriteLocation:
        display_name = alias_name.strip() or suggest_short_spot_name(hotspot.loc_name, hotspot.subnational1_code)
        prov, city = infer_province_city(
            hotspot.lat,
            hotspot.lng,
            subnational1_code=hotspot.subnational1_code or hotspot.country_code,
            text_hint=hotspot.loc_name,
        )
        city = hotspot.city_name or city
        region = format_province_city(prov, city) or format_region_label(hotspot.country_code, hotspot.subnational1_code)
        return self.db.upsert_favorite_location(
            display_name,
            province=prov,
            city=city,
            region=region,
            ebird_loc_id=hotspot.loc_id,
            ebird_loc_name=hotspot.loc_name,
            lat=hotspot.lat,
            lng=hotspot.lng,
            notes=notes,
        )

    def apply_location_to_photos(
        self,
        photo_ids: list[int],
        location_input: str,
        *,
        explicit_ebird_loc_id: str | None = None,
        province: str = "",
        city: str = "",
        fallback_lat: float | None = None,
        fallback_lon: float | None = None,
        override_gps: bool = False,
    ) -> tuple[str, str | None]:
        """Assign location (with province, city & optional GPS override) to photos.

        Returns (resolved_location_name, resolved_ebird_loc_id).
        """
        raw = location_input.strip()
        if not raw and not override_gps:
            self.db.batch_update_attributes(
                photo_ids,
                location_name="",
                location_province="",
                location_city="",
                ebird_loc_id="",
            )
            return "", None

        # Strip leading markers from autocomplete items like "⭐ 北京·圆明园 [L123456]" or "🧭 Yuanmingyuan [L123456]"
        for prefix in ("⭐", "🧭", "📍"):
            if raw.startswith(prefix):
                raw = raw.lstrip(prefix).strip()

        extracted_lid = explicit_ebird_loc_id or extract_ebird_loc_id(raw)
        # Clean trailing "[L123456 · ...]" suffix if selected from autocomplete dropdown
        clean_name = re.sub(r"\s*\[L\d+[^\]]*\]\s*$", "", raw).strip()

        prov_in = normalize_province_name(province) if province else ""
        city_in = city.strip()

        # 1. Check if matches a saved Favorite Location
        fav = self.db.get_favorite_location_by_name(clean_name) if clean_name else None
        if fav is not None:
            lid = extracted_lid or fav.ebird_loc_id
            lat = fallback_lat if fallback_lat is not None else fav.lat
            lon = fallback_lon if fallback_lon is not None else fav.lng
            inf_p, inf_c = infer_province_city(lat, lon, text_hint=fav.region or fav.name)
            eff_prov = prov_in or fav.province or inf_p
            eff_city = city_in or fav.city or inf_c
            self.db.batch_update_attributes(
                photo_ids,
                location_name=fav.name,
                location_province=eff_prov,
                location_city=eff_city,
                ebird_loc_id=lid,
                set_lat=lat if override_gps else None,
                set_lon=lon if override_gps else None,
                fallback_lat=None if override_gps else lat,
                fallback_lon=None if override_gps else lon,
            )
            self.db.increment_favorite_location_use(fav.name)
            return fav.name, lid

        # 2. Check if linked to a cached eBird Hotspot by L-code
        if extracted_lid:
            hotspot = self.db.get_ebird_hotspot(extracted_lid)
            if hotspot is not None:
                if not clean_name or clean_name.upper() == extracted_lid or clean_name.startswith("http"):
                    clean_name = suggest_short_spot_name(hotspot.loc_name, hotspot.subnational1_code)
                lat = fallback_lat if fallback_lat is not None else hotspot.lat
                lon = fallback_lon if fallback_lon is not None else hotspot.lng
                inf_p, inf_c = infer_province_city(
                    lat,
                    lon,
                    subnational1_code=hotspot.subnational1_code or hotspot.country_code,
                    text_hint=hotspot.loc_name,
                )
                eff_prov = prov_in or inf_p
                eff_city = city_in or hotspot.city_name or inf_c
                self.db.batch_update_attributes(
                    photo_ids,
                    location_name=clean_name,
                    location_province=eff_prov,
                    location_city=eff_city,
                    ebird_loc_id=hotspot.loc_id,
                    set_lat=lat if override_gps else None,
                    set_lon=lon if override_gps else None,
                    fallback_lat=None if override_gps else lat,
                    fallback_lon=None if override_gps else lon,
                )
                return clean_name, hotspot.loc_id

        # 3. Plain custom spot name or direct coordinate adjustment
        inf_p, inf_c = infer_province_city(fallback_lat, fallback_lon, text_hint=clean_name)
        eff_prov = prov_in or inf_p
        eff_city = city_in or inf_c
        self.db.batch_update_attributes(
            photo_ids,
            location_name=clean_name if clean_name else None,
            location_province=eff_prov if (eff_prov or clean_name) else None,
            location_city=eff_city if (eff_city or clean_name) else None,
            ebird_loc_id=extracted_lid,
            set_lat=fallback_lat if override_gps else None,
            set_lon=fallback_lon if override_gps else None,
            fallback_lat=None if override_gps else fallback_lat,
            fallback_lon=None if override_gps else fallback_lon,
        )
        return clean_name, extracted_lid

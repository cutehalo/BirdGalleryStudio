"""Manual review, filtering, rating, and batch culling service."""

from __future__ import annotations

from bird_gallery.db import GalleryDatabase
from bird_gallery.models import FilterQuery, PhotoRecord, ReviewStatus
from bird_gallery.taxonomy import TaxonomyMapper


class ReviewService:
    """High-level gallery query and manual review operations (UI-agnostic)."""

    def __init__(
        self,
        db: GalleryDatabase,
        taxonomy: TaxonomyMapper | None = None,
    ) -> None:
        self.db = db
        self.taxonomy = taxonomy or TaxonomyMapper()

    def search(self, query: FilterQuery, *, include_detections: bool = False) -> list[PhotoRecord]:
        return self.db.query_photos(query, include_detections=include_detections)

    def get_detail(self, photo_id: int) -> PhotoRecord | None:
        return self.db.get_photo(photo_id, include_detections=True)

    def confirm(self, photo_id: int, *, rating: int | None = None, notes: str | None = None) -> bool:
        """Confirm AI species identification as accurate."""
        return self.db.update_review(
            photo_id,
            review_status=ReviewStatus.CONFIRMED,
            is_rejected=False,
            rating=rating,
            notes=notes,
        )

    def correct_species(
        self,
        photo_id: int,
        species_input: str,
        *,
        rating: int | None = None,
        notes: str | None = None,
    ) -> tuple[bool, str, str]:
        """Manually correct a photo's bird species using either Chinese name or Latin scientific name.

        Automatically resolves the paired Chinese/Latin name via TaxonomyMapper when available.
        Returns (updated, resolved_cn_name, resolved_scientific_name).
        """
        raw = species_input.strip()
        if not raw:
            raise ValueError("species_input cannot be empty")

        entry = self.taxonomy.lookup_by_cn(raw) or self.taxonomy.lookup(raw)
        if entry is not None:
            cn_name = entry.common_name_cn
            sci_name = entry.scientific_name
        else:
            # Heuristic: ASCII text is likely Latin scientific name; non-ASCII is Chinese name
            if all(ord(ch) < 128 for ch in raw):
                sci_name = raw
                cn_name = raw
            else:
                cn_name = raw
                sci_name = ""

        updated = self.db.update_review(
            photo_id,
            manual_common_name_cn=cn_name,
            manual_scientific_name=sci_name,
            review_status=ReviewStatus.CORRECTED,
            is_rejected=False,
            rating=rating,
            notes=notes,
        )
        return updated, cn_name, sci_name

    def set_rating(self, photo_id: int, rating: int) -> bool:
        return self.db.update_review(photo_id, rating=rating)

    def reject(self, photo_id: int, *, notes: str | None = None) -> bool:
        return self.db.update_review(
            photo_id,
            is_rejected=True,
            review_status=ReviewStatus.REJECTED,
            notes=notes,
        )

    def restore(self, photo_id: int) -> bool:
        return self.db.update_review(
            photo_id,
            is_rejected=False,
            review_status=ReviewStatus.UNREVIEWED,
        )

    def get_low_confidence_queue(
        self,
        *,
        max_confidence: float = 0.65,
        min_confidence: float = 0.0,
        limit: int = 50,
    ) -> list[PhotoRecord]:
        """Fetch unreviewed bird photos within a confidence band for prioritized human verification."""
        query = FilterQuery(
            has_bird=True,
            min_confidence=min_confidence,
            max_confidence=max_confidence,
            review_status=ReviewStatus.UNREVIEWED,
            include_rejected=False,
            sort_by="confidence_asc",
            limit=limit,
        )
        return self.db.query_photos(query, include_detections=True)

    def batch_cull(
        self,
        *,
        reject_no_bird: bool = True,
        reject_blurry_below: float | None = None,
        dry_run: bool = True,
    ) -> list[PhotoRecord]:
        """Mark empty or excessively blurry unreviewed photos as rejected.

        Safe by default: `dry_run=True` returns matched records without modifying DB.
        """
        candidates: dict[int, PhotoRecord] = {}

        if reject_no_bird:
            no_bird_rows = self.db.query_photos(
                FilterQuery(
                    has_bird=False,
                    review_status=ReviewStatus.UNREVIEWED,
                    include_rejected=False,
                    limit=100_000,
                )
            )
            for row in no_bird_rows:
                if row.photo_id is not None:
                    candidates[row.photo_id] = row

        if reject_blurry_below is not None:
            blurry_rows = self.db.query_photos(
                FilterQuery(
                    has_bird=True,
                    max_sharpness=reject_blurry_below,
                    review_status=ReviewStatus.UNREVIEWED,
                    include_rejected=False,
                    include_blurry=True,
                    limit=100_000,
                )
            )
            for row in blurry_rows:
                if row.photo_id is not None:
                    candidates[row.photo_id] = row

        matched = list(candidates.values())
        if not dry_run:
            for row in matched:
                if row.photo_id is not None:
                    self.reject(row.photo_id)
        return matched

"""BioCLIP 2 species classifier with Aves filtering and Chinese taxonomy enrichment."""

from __future__ import annotations

from typing import Protocol

from PIL import Image

from bird_gallery.models import SpeciesPrediction
from bird_gallery.taxonomy import TaxonomyMapper


class SpeciesClassifier(Protocol):
    """Pluggable bird species classification interface."""

    def classify(self, crop: Image.Image, top_k: int = 5) -> list[SpeciesPrediction]:
        ...


class BioClipClassifier:
    """Wrapper around pybioclip's TreeOfLifeClassifier (BioCLIP 2) restricted to birds."""

    def __init__(
        self,
        *,
        device: str = "cuda",
        model_str: str | None = None,
        filter_aves_only: bool = True,
        restrict_to_taxonomy: bool = False,
        taxonomy: TaxonomyMapper | None = None,
    ) -> None:
        self.device = device
        self.model_str = model_str
        self.filter_aves_only = filter_aves_only
        self.restrict_to_taxonomy = restrict_to_taxonomy
        self.taxonomy = taxonomy or TaxonomyMapper()
        self._classifier = None
        self._rank_species = None

    def _ensure_loaded(self) -> None:
        if self._classifier is not None:
            return
        try:
            from bioclip import Rank, TreeOfLifeClassifier
        except ImportError as exc:
            raise RuntimeError(
                "Species classification requires `pybioclip`. Install AI extras with: uv sync --extra ai"
            ) from exc

        kwargs: dict[str, object] = {"device": self.device}
        if self.model_str:
            kwargs["model_str"] = self.model_str

        clf = TreeOfLifeClassifier(**kwargs)

        if self.restrict_to_taxonomy and len(self.taxonomy) > 0:
            allowed = {
                TaxonomyMapper.normalize_scientific(name)
                for name in self.taxonomy.all_scientific_names()
            }
            label_data = clf.get_label_data()
            species_col = (
                label_data["species"]
                .fillna("")
                .astype(str)
                .map(TaxonomyMapper.normalize_scientific)
            )
            mask = species_col.isin(allowed)
            if bool(mask.any()):
                clf.apply_filter(mask)
            elif self.filter_aves_only:
                clf.apply_filter(clf.create_taxa_filter(Rank.CLASS, ["Aves"]))
        elif self.filter_aves_only:
            aves_filter = clf.create_taxa_filter(Rank.CLASS, ["Aves"])
            clf.apply_filter(aves_filter)

        self._classifier = clf
        self._rank_species = Rank.SPECIES

    def classify(self, crop: Image.Image, top_k: int = 5) -> list[SpeciesPrediction]:
        self._ensure_loaded()
        assert self._classifier is not None

        raw_preds = self._classifier.predict(crop, rank=self._rank_species, k=top_k)
        # Sort defensively in descending score order
        raw_preds = sorted(raw_preds, key=lambda p: float(p.get("score", 0.0)), reverse=True)[:top_k]

        results: list[SpeciesPrediction] = []
        for idx, item in enumerate(raw_preds, start=1):
            sci = str(item.get("species") or "").strip()
            # Some TreeOfLife entries store genus + species separately
            genus = str(item.get("genus") or "").strip()
            if sci and " " not in sci and genus:
                sci = f"{genus} {sci}"

            entry = self.taxonomy.lookup(sci)
            common_en = str(item.get("common_name") or (entry.common_name_en if entry else "")).strip()
            common_cn = entry.common_name_cn if entry else ""
            order_name = str(item.get("order") or (entry.order_name if entry else "")).strip()
            family_name = str(item.get("family") or (entry.family_name if entry else "")).strip()

            results.append(
                SpeciesPrediction(
                    rank=idx,
                    scientific_name=sci,
                    score=round(float(item.get("score", 0.0)), 6),
                    common_name_en=common_en,
                    common_name_cn=common_cn,
                    order_name=order_name,
                    order_cn=entry.order_cn if entry else "",
                    family_name=family_name,
                    family_cn=entry.family_cn if entry else "",
                    genus_name=genus,
                )
            )
        return results

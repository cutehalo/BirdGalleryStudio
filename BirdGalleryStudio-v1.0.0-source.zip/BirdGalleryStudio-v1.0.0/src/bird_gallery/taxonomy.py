"""Bird taxonomy mapping (11,000+ global species & 1,400+ China species) with Pinyin-initials fuzzy search."""

from __future__ import annotations

import csv
import re
import sys
from dataclasses import dataclass
from pathlib import Path

_RARE_BIRD_SYLLABLES: dict[str, str] = {
    "䴙": "pi", "䴘": "ti", "䴕": "lie", "䴓": "shi", "䳭": "ji", "䳍": "gong",
    "鸻": "heng", "鹀": "wu", "鹨": "liu", "鹎": "bei", "鳽": "yan", "鸺": "xiu",
    "鹠": "liu", "鸮": "xiao", "鵟": "kuang", "鹞": "yao", "鹫": "jiu", "鹬": "yu",
    "鹱": "hu", "鹲": "meng", "鲣": "jian", "鸬": "lu", "鹚": "ci", "鹮": "huan",
    "鸨": "bao", "鹑": "chun", "雉": "zhi", "鹇": "xian", "鸠": "jiu", "鴗": "li",
    "鵙": "ju", "鹩": "liao", "鹛": "mei", "鸲": "qu", "鸫": "dong", "鹟": "weng",
    "鹡": "ji", "鸰": "ling", "椋": "liang", "鳾": "shi", "鷉": "ti", "塚": "zhong",
}

# Mainland China BirdReport (Zheng Guangmei 4th Ed.) <-> IOC/eBird synonym mappings
BIRDREPORT_SYNONYM_TO_SCI: dict[str, str] = {
    "黄斑苇鳽": "botaurus sinensis",
    "ixobrychus sinensis": "botaurus sinensis",
    "ixobrychus cinnamomeus": "botaurus cinnamomeus",
    "ixobrychus eurhythmus": "botaurus eurhythmus",
    "ixobrychus flavicollis": "botaurus flavicollis",
    "ixobrychus minutus": "botaurus minutus",
    "白额燕尾": "enicurus sinensis",
    "东亚石䳭": "saxicola stejnegeri",
    "小鸊鷉": "tachybaptus ruficollis",
    "凤头鸊鷉": "podiceps cristatus",
    "黑颈鸊鷉": "podiceps nigricollis",
    "角鸊鷉": "podiceps auritus",
    "赤颈鸊鷉": "podiceps grisegena",
}


def compute_pinyin_fields(name_cn: str) -> tuple[str, str]:
    """Compute (pinyin_initials, pinyin_full) at runtime when loading custom CSV entries."""
    if not name_cn:
        return "", ""
    cleaned = re.sub(r"[^\u3400-\u9fff]", "", name_cn)
    if not cleaned:
        return "", ""
    try:
        from pypinyin import Style, lazy_pinyin
    except ImportError:
        return "", ""

    syllables: list[str] = []
    for ch in cleaned:
        if ch in _RARE_BIRD_SYLLABLES:
            syllables.append(_RARE_BIRD_SYLLABLES[ch])
        elif ch == "长":
            syllables.append("chang")
        elif ch == "重":
            syllables.append("chong")
        elif ch == "奇":
            syllables.append("qi")
        elif ch == "雀":
            syllables.append("que")
        else:
            py = lazy_pinyin(ch, style=Style.NORMAL, errors="ignore")
            if py and py[0]:
                syllables.append(py[0].lower().replace("ü", "v"))

    return "".join(s[0] for s in syllables if s), "".join(syllables)


def _is_subsequence(needle: str, haystack: str) -> bool:
    """Return True if all characters of `needle` appear in order inside `haystack`."""
    if not needle or len(needle) > len(haystack):
        return False
    it = iter(haystack)
    return all(ch in it for ch in needle)


@dataclass(slots=True, frozen=True)
class TaxonEntry:
    scientific_name: str
    common_name_cn: str
    common_name_en: str = ""
    order_name: str = ""
    order_cn: str = ""
    family_name: str = ""
    family_cn: str = ""
    pinyin_initials: str = ""
    pinyin_full: str = ""
    in_china: bool = True


def _default_taxonomy_path() -> Path:
    if getattr(sys, "frozen", False):
        beside_exe = Path(sys.executable).resolve().parent / "data" / "taxonomy_cn.csv"
        if beside_exe.exists():
            return beside_exe
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        bundled = Path(meipass) / "data" / "taxonomy_cn.csv"
        if bundled.exists():
            return bundled
    return Path(__file__).resolve().parents[2] / "data" / "taxonomy_cn.csv"


class TaxonomyMapper:
    """Fast lookup & Pinyin-initials fuzzy search engine across 11,000+ bird species."""

    def __init__(self, csv_path: str | Path | None = None) -> None:
        self._by_scientific: dict[str, TaxonEntry] = {}
        self._by_cn: dict[str, TaxonEntry] = {}

        default_path = _default_taxonomy_path()
        if default_path.exists():
            self.load_csv(default_path)

        if csv_path is not None:
            self.load_csv(Path(csv_path))

    def __len__(self) -> int:
        return len(self._by_scientific)

    @property
    def china_species_count(self) -> int:
        return sum(1 for e in self._by_scientific.values() if e.in_china)

    @staticmethod
    def normalize_scientific(name: str) -> str:
        """Normalize a Latin name to lowercase 'genus species'."""
        parts = name.strip().replace("_", " ").split()
        if len(parts) >= 2:
            return f"{parts[0].lower()} {parts[1].lower()}"
        return " ".join(parts).lower()

    def load_csv(self, path: str | Path) -> int:
        """Load taxonomy entries from a UTF-8 CSV file."""
        csv_file = Path(path)
        if not csv_file.exists():
            raise FileNotFoundError(f"Taxonomy CSV not found: {csv_file}")

        loaded = 0
        with csv_file.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                sci = (
                    row.get("scientific_name")
                    or row.get("latin_name")
                    or row.get("species")
                    or ""
                ).strip()
                cn = (
                    row.get("common_name_cn")
                    or row.get("chinese_name")
                    or row.get("name_cn")
                    or row.get("cn_name")
                    or ""
                ).strip()
                if not sci:
                    continue

                initials = (row.get("pinyin_initials") or "").strip().lower()
                full_py = (row.get("pinyin_full") or "").strip().lower()
                if not initials and cn:
                    initials, full_py = compute_pinyin_fields(cn)

                in_china_raw = (row.get("in_china") or "").strip()
                # Custom CSVs without an `in_china` column default to True
                in_china = True if in_china_raw == "" else (in_china_raw in ("1", "true", "True", "yes"))

                entry = TaxonEntry(
                    scientific_name=sci,
                    common_name_cn=cn,
                    common_name_en=(row.get("common_name_en") or row.get("english_name") or "").strip(),
                    order_name=(row.get("order_name") or row.get("order") or "").strip(),
                    order_cn=(row.get("order_cn") or "").strip(),
                    family_name=(row.get("family_name") or row.get("family") or "").strip(),
                    family_cn=(row.get("family_cn") or "").strip(),
                    pinyin_initials=initials,
                    pinyin_full=full_py,
                    in_china=in_china,
                )
                key = self.normalize_scientific(sci)
                self._by_scientific[key] = entry
                if cn:
                    # Prefer China-occurring entry if two species share a Chinese name
                    existing_cn = self._by_cn.get(cn)
                    if existing_cn is None or (entry.in_china and not existing_cn.in_china):
                        self._by_cn[cn] = entry
                loaded += 1
        return loaded

    def lookup(self, scientific_name: str) -> TaxonEntry | None:
        if not scientific_name:
            return None
        norm = self.normalize_scientific(scientific_name)
        hit = self._by_scientific.get(norm)
        if hit is not None:
            return hit
        syn_sci = BIRDREPORT_SYNONYM_TO_SCI.get(norm)
        return self._by_scientific.get(syn_sci) if syn_sci else None

    def lookup_by_cn(self, common_name_cn: str) -> TaxonEntry | None:
        if not common_name_cn:
            return None
        s = common_name_cn.strip()
        hit = self._by_cn.get(s)
        if hit is not None:
            return hit
        syn_sci = BIRDREPORT_SYNONYM_TO_SCI.get(s)
        return self._by_scientific.get(syn_sci) if syn_sci else None

    def score_entry(self, entry: TaxonEntry, raw_kw: str, alpha_kw: str, py_alt: str) -> int | None:
        """Score an entry against a search keyword (lower score = higher rank; None = no match)."""
        cn = entry.common_name_cn
        ini = entry.pinyin_initials
        fpy = entry.pinyin_full

        # 0. Exact Chinese name or exact Pinyin initials (e.g., 'ptcn' -> '普通翠鸟')
        if cn == raw_kw or (alpha_kw and ini == alpha_kw):
            return 0

        # 1. Prefix match on Chinese name, Pinyin initials, or Full Pinyin
        if cn.startswith(raw_kw):
            return 1
        if alpha_kw and (ini.startswith(alpha_kw) or fpy.startswith(alpha_kw) or (py_alt and fpy.startswith(py_alt))):
            return 2

        # 2. Contiguous substring match on Chinese name or Pinyin initials
        if raw_kw in cn:
            return 3
        if alpha_kw and len(alpha_kw) >= 2 and alpha_kw in ini:
            return 4

        # 3. Tight fuzzy subsequence on Pinyin initials (e.g. 'hlq' -> 'hzlq' 红嘴蓝鹊)
        if (
            alpha_kw
            and 2 <= len(alpha_kw) <= 6
            and alpha_kw.isalpha()
            and ini.startswith(alpha_kw[0])
            and len(ini) - len(alpha_kw) <= 2
            and _is_subsequence(alpha_kw, ini)
        ):
            return 5

        # 4. Full Pinyin substring or Family/Order Chinese match
        if alpha_kw and len(alpha_kw) >= 2 and (alpha_kw in fpy or (py_alt and py_alt in fpy)):
            return 6
        if raw_kw in entry.family_cn or raw_kw in entry.order_cn:
            return 7

        # 5. Scientific or English name match
        sci_low = entry.scientific_name.lower()
        en_low = entry.common_name_en.lower()
        if raw_kw in sci_low or raw_kw in en_low:
            return 8

        # 6. General fuzzy subsequence on Pinyin initials
        if alpha_kw and 2 <= len(alpha_kw) <= 6 and alpha_kw.isalpha() and _is_subsequence(alpha_kw, ini):
            return 9

        return None

    def search(
        self,
        keyword: str,
        limit: int = 30,
        *,
        china_only: bool = False,
        prefer_china: bool = True,
    ) -> list[TaxonEntry]:
        """Ranked search by Chinese name, Pinyin initials (exact/prefix/substring/fuzzy), full Pinyin, Latin, or English."""
        raw_kw = keyword.strip().lower()
        if not raw_kw:
            items = [e for e in self._by_scientific.values() if (not china_only or e.in_china)]
            if prefer_china:
                items.sort(key=lambda e: (not e.in_china, e.common_name_cn))
            return items[:limit]

        alpha_kw = re.sub(r"[\s\-_']", "", raw_kw)
        py_alt = alpha_kw.replace("lu", "lv") if "lu" in alpha_kw else ""

        scored: list[tuple[int, bool, int, str, TaxonEntry]] = []
        for entry in self._by_scientific.values():
            if china_only and not entry.in_china:
                continue
            tier = self.score_entry(entry, raw_kw, alpha_kw, py_alt)
            if tier is not None:
                effective_score = tier if (not prefer_china or entry.in_china or tier == 0) else (tier + 3)
                china_tiebreak = (not entry.in_china) if prefer_china else False
                scored.append((effective_score, china_tiebreak, len(entry.common_name_cn), entry.common_name_cn, entry))

        scored.sort(key=lambda item: (item[0], item[1], item[2], item[3]))
        return [item[4] for item in scored[:limit]]

    def all_entries(self, *, china_only: bool = False) -> list[TaxonEntry]:
        if china_only:
            return [e for e in self._by_scientific.values() if e.in_china]
        return list(self._by_scientific.values())

    def all_scientific_names(self) -> list[str]:
        return [entry.scientific_name for entry in self._by_scientific.values()]

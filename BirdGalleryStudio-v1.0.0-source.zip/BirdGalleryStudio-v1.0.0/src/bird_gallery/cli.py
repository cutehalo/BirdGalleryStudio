"""Command-line interface for the local GPU bird recognition & gallery engine."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import BarColumn, MofNCompleteColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

from bird_gallery.config import EngineConfig
from bird_gallery.db import GalleryDatabase
from bird_gallery.exporter import ArchiveExporter, ExportMode
from bird_gallery.models import FilterQuery, ReviewStatus
from bird_gallery.pipeline import BirdGalleryPipeline
from bird_gallery.review import ReviewService
from bird_gallery.taxonomy import TaxonomyMapper

app = typer.Typer(
    name="bird-gallery",
    help="本地 GPU 鸟类识别、废片筛选、人工复核与分类归档引擎（YOLO + BioCLIP 2）",
    no_args_is_help=True,
)
console = Console()


@app.command()
def doctor() -> None:
    """检查本机 GPU、PyTorch CUDA、YOLO、BioCLIP 与 RAW 依赖环境。"""
    table = Table(title="Bird Gallery Engine 环境自检")
    table.add_column("组件", style="cyan")
    table.add_column("状态", style="bold")
    table.add_column("详情")

    def _check_pkg(label: str, mod_name: str) -> None:
        try:
            mod = __import__(mod_name)
            ver = getattr(mod, "__version__", "installed")
            table.add_row(label, "[green]OK[/green]", str(ver))
        except Exception as exc:
            table.add_row(label, "[red]MISSING[/red]", str(exc))

    _check_pkg("Pillow (图像)", "PIL")
    _check_pkg("OpenCV (清晰度)", "cv2")
    _check_pkg("rawpy (相机RAW)", "rawpy")
    _check_pkg("ExifRead (EXIF)", "exifread")
    _check_pkg("Ultralytics (YOLO)", "ultralytics")
    _check_pkg("pybioclip (BioCLIP 2)", "bioclip")

    try:
        import torch

        cuda_ok = torch.cuda.is_available()
        if cuda_ok:
            gpu_name = torch.cuda.get_device_name(0)
            cap = torch.cuda.get_device_capability(0)
            vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            # Quick tensor kernel smoke test on GPU (catches sm_61 incompatibility immediately!)
            x = torch.ones((4, 4), device="cuda")
            _ = float((x * 2).sum().item())
            table.add_row(
                "PyTorch CUDA",
                "[green]OK[/green]",
                f"torch {torch.__version__} | {gpu_name} (sm_{cap[0]}{cap[1]}, {vram_gb:.1f} GB)",
            )
        else:
            table.add_row(
                "PyTorch CUDA",
                "[yellow]CPU ONLY[/yellow]",
                f"torch {torch.__version__} (未检测到可用 CUDA GPU)",
            )
    except Exception as exc:
        table.add_row("PyTorch CUDA", "[red]ERROR[/red]", str(exc))

    tax = TaxonomyMapper()
    table.add_row(
        "内置中文鸟类名录",
        "[green]OK[/green]",
        f"全球 {len(tax)} 种 / 中国分布 {tax.china_species_count} 种（支持拼音首字母检索）",
    )
    console.print(table)


@app.command()
def scan(
    source: Path = typer.Argument(..., help="待扫描的照片文件夹或单张图片路径"),
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    device: str = typer.Option("auto", "--device", help="推理设备: auto | cuda | cpu"),
    yolo_model: str = typer.Option("yolo11s.pt", "--yolo-model", help="YOLO 模型名称或本地权重路径"),
    detect_conf: float = typer.Option(0.25, "--detect-conf", help="鸟类检测置信度阈值"),
    blur_threshold: float = typer.Option(18.0, "--blur-threshold", help="鸟体清晰度模糊判定阈值 (0-100)"),
    taxonomy_csv: Optional[Path] = typer.Option(None, "--taxonomy-csv", help="自定义中文鸟类名录 CSV 路径"),
    restrict_checklist: bool = typer.Option(
        False,
        "--restrict-checklist",
        help="仅在名录 CSV 的鸟种范围内识别（配合中国鸟类名录可提准）",
    ),
    include_raw: bool = typer.Option(True, "--include-raw/--no-raw", help="是否扫描相机 RAW 文件"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="是否递归扫描子目录"),
    rescan: bool = typer.Option(False, "--rescan", help="强制重新识别已入库且未修改的照片"),
    no_thumbs: bool = typer.Option(False, "--no-thumbs", help="跳过缩略图缓存生成"),
) -> None:
    """扫描目录，自动裁鸟、评估清晰度、识别鸟种并入库。"""
    cfg = EngineConfig(
        db_path=db,
        device=device,  # type: ignore[arg-type]
        yolo_model=yolo_model,
        detect_conf=detect_conf,
        sharpness_blur_threshold=blur_threshold,
        taxonomy_csv=taxonomy_csv,
        restrict_to_taxonomy_csv=restrict_checklist,
        include_raw=include_raw,
        recursive=recursive,
        skip_existing=not rescan,
        generate_thumbnails=not no_thumbs,
    )
    pipeline = BirdGalleryPipeline(cfg)
    console.print(f"[cyan]设备:[/cyan] {pipeline.device} | [cyan]数据库:[/cyan] {db.resolve()}")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task_id = progress.add_task("准备扫描...", total=None)

        def on_progress(idx: int, total: int, path: Path, record, err: str | None) -> None:
            progress.update(task_id, total=total, completed=idx)
            if err == "skipped":
                progress.update(task_id, description=f"[dim]跳过已入库: {path.name}[/dim]")
            elif err:
                progress.update(task_id, description=f"[red]失败: {path.name}[/red]")
            elif record is not None:
                if record.has_bird:
                    label = record.effective_common_name_cn
                    progress.update(
                        task_id,
                        description=f"[green]{label}[/green] ({record.primary_confidence:.2f}, 锐度{record.best_sharpness:.0f}) - {path.name}",
                    )
                else:
                    progress.update(task_id, description=f"[yellow]无鸟[/yellow] - {path.name}")

        summary = pipeline.scan_directory(source, on_progress=on_progress)

    table = Table(title="扫描完成汇总")
    table.add_column("指标", style="cyan")
    table.add_column("数量", justify="right", style="bold")
    table.add_row("发现文件总数", str(summary.total_discovered))
    table.add_row("跳过已入库", str(summary.skipped_existing))
    table.add_row("本次处理", str(summary.processed))
    table.add_row("检测到鸟类", f"[green]{summary.with_birds}[/green]")
    table.add_row("无鸟/空拍", f"[yellow]{summary.no_birds}[/yellow]")
    table.add_row("疑似模糊(低于阈值)", f"[magenta]{summary.flagged_blurry}[/magenta]")
    table.add_row("处理失败", f"[red]{summary.failed}[/red]")
    table.add_row("总耗时", f"{summary.elapsed_seconds:.2f} s")
    console.print(table)

    if summary.errors:
        console.print("[red]失败文件明细（前 10 条）：[/red]")
        for fp, msg in summary.errors[:10]:
            console.print(f"  - {fp}: {msg}")


@app.command()
def query(
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    species: Optional[str] = typer.Option(None, "--species", "-s", help="按鸟种中文名/学名/科/目搜索"),
    has_bird: Optional[bool] = typer.Option(None, "--has-bird/--no-bird", help="筛选有鸟或无鸟照片"),
    min_conf: Optional[float] = typer.Option(None, "--min-conf", help="最低识别置信度 (0~1)"),
    max_conf: Optional[float] = typer.Option(None, "--max-conf", help="最高识别置信度 (0~1)"),
    min_sharpness: Optional[float] = typer.Option(None, "--min-sharpness", help="最低鸟体清晰度 (0~100)"),
    min_rating: Optional[int] = typer.Option(None, "--min-rating", help="最低星标 (0~5)"),
    status: Optional[ReviewStatus] = typer.Option(None, "--status", help="复核状态: unreviewed/confirmed/corrected/rejected"),
    include_rejected: bool = typer.Option(False, "--include-rejected", help="包含已淘汰照片"),
    no_blurry: bool = typer.Option(False, "--no-blurry", help="排除模糊照片"),
    raw_only: Optional[bool] = typer.Option(None, "--raw-only/--no-raw-only", help="仅看 RAW 或非 RAW"),
    date_from: Optional[str] = typer.Option(None, "--date-from", help="起始拍摄日期 YYYY-MM-DD"),
    date_to: Optional[str] = typer.Option(None, "--date-to", help="结束拍摄日期 YYYY-MM-DD"),
    sort: str = typer.Option(
        "taken_at_desc",
        "--sort",
        help="排序: taken_at_desc | confidence_desc | confidence_asc | sharpness_desc | rating_desc | id_asc",
    ),
    limit: int = typer.Option(50, "--limit", "-n", help="最多返回条数"),
    as_json: bool = typer.Option(False, "--json", help="以 JSON 格式输出（方便外部程序调用）"),
) -> None:
    """多条件筛选图库照片（支持置信度区间、清晰度、星标、鸟种、复核状态等）。"""
    service = ReviewService(GalleryDatabase(db))
    q = FilterQuery(
        species=species,
        has_bird=has_bird,
        min_confidence=min_conf,
        max_confidence=max_conf,
        min_sharpness=min_sharpness,
        min_rating=min_rating,
        review_status=status,
        include_rejected=include_rejected,
        include_blurry=not no_blurry,
        is_raw=raw_only,
        date_from=date_from,
        date_to=date_to,
        sort_by=sort,
        limit=limit,
    )
    rows = service.search(q)

    if as_json:
        payload = [
            {
                "photo_id": r.photo_id,
                "file_path": r.file_path,
                "file_name": r.file_name,
                "is_raw": r.is_raw,
                "has_bird": r.has_bird,
                "bird_count": r.bird_count,
                "species_cn": r.effective_common_name_cn,
                "scientific_name": r.effective_scientific_name,
                "confidence": r.primary_confidence,
                "sharpness": r.best_sharpness,
                "is_blurry": r.is_blurry,
                "rating": r.rating,
                "review_status": r.review_status.value,
                "is_rejected": r.is_rejected,
                "taken_at": r.exif.taken_at,
            }
            for r in rows
        ]
        typer.echo(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    table = Table(title=f"筛选结果（共显示 {len(rows)} 条）")
    table.add_column("ID", justify="right", style="cyan")
    table.add_column("文件名")
    table.add_column("鸟种（中文）", style="green")
    table.add_column("置信度", justify="right")
    table.add_column("清晰度", justify="right")
    table.add_column("星标", justify="center")
    table.add_column("状态")
    table.add_column("拍摄时间")

    for r in rows:
        species_disp = r.effective_common_name_cn if r.has_bird else "[dim]无鸟[/dim]"
        if r.manual_common_name_cn:
            species_disp = f"{species_disp} *"
        stars = "★" * r.rating + "☆" * (5 - r.rating) if r.rating > 0 else "-"
        sharp = f"{r.best_sharpness:.1f}" + (" [red]糊[/red]" if r.is_blurry else "")
        table.add_row(
            str(r.photo_id),
            r.file_name + (" [dim]RAW[/dim]" if r.is_raw else ""),
            species_disp,
            f"{r.primary_confidence:.2%}" if r.has_bird else "-",
            sharp if r.has_bird else "-",
            stars,
            r.review_status.value,
            (r.exif.taken_at or "-")[:16],
        )
    console.print(table)


@app.command()
def show(
    photo_id: int = typer.Argument(..., help="照片 ID"),
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
) -> None:
    """查看单张照片的详细 EXIF、检测框和 Top-5 候选鸟种。"""
    service = ReviewService(GalleryDatabase(db))
    rec = service.get_detail(photo_id)
    if rec is None:
        console.print(f"[red]未找到 photo_id={photo_id}[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold cyan]#{rec.photo_id} {rec.file_name}[/bold cyan]")
    console.print(f"  路径: {rec.file_path}")
    console.print(f"  分辨率: {rec.width}x{rec.height} | RAW: {rec.is_raw} | 缩略图: {rec.thumbnail_path or '-'}")
    console.print(
        f"  当前鸟种: [green]{rec.effective_common_name_cn}[/green] ({rec.effective_scientific_name or '-'}) | "
        f"状态: {rec.review_status.value} | 星标: {rec.rating} | 淘汰: {rec.is_rejected}"
    )
    if rec.exif.camera_model or rec.exif.taken_at:
        console.print(
            f"  EXIF: {rec.exif.taken_at or '-'} | {rec.exif.camera_model or '-'} | "
            f"{rec.exif.lens_model or '-'} | {rec.exif.focal_length_mm or '-'}mm | "
            f"f/{rec.exif.aperture or '-'} | {rec.exif.shutter_speed or '-'}s | ISO {rec.exif.iso or '-'}"
        )
    if rec.notes:
        console.print(f"  备注: {rec.notes}")

    for idx, det in enumerate(rec.detections, start=1):
        table = Table(title=f"检测目标 #{idx} | bbox={det.bbox} | 检测分={det.detect_conf:.2f} | 锐度={det.sharpness_score:.1f}")
        table.add_column("Rank", justify="right")
        table.add_column("中文名", style="green")
        table.add_column("拉丁学名")
        table.add_column("科")
        table.add_column("置信度", justify="right")
        for pred in det.predictions:
            table.add_row(
                str(pred.rank),
                pred.common_name_cn or "-",
                pred.scientific_name,
                pred.family_cn or pred.family_name or "-",
                f"{pred.score:.2%}",
            )
        console.print(table)


@app.command()
def review(
    photo_id: int = typer.Argument(..., help="待复核的照片 ID"),
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    species: Optional[str] = typer.Option(None, "--species", "-s", help="人工修正鸟种（输入中文名或拉丁学名）"),
    confirm: bool = typer.Option(False, "--confirm", help="确认当前 AI 识别结果无误"),
    rating: Optional[int] = typer.Option(None, "--rating", "-r", min=0, max=5, help="设置星标 (0~5)"),
    reject: bool = typer.Option(False, "--reject", help="标记为淘汰废片"),
    restore: bool = typer.Option(False, "--restore", help="取消淘汰并恢复为未复核"),
    notes: Optional[str] = typer.Option(None, "--notes", help="添加备注"),
    taxonomy_csv: Optional[Path] = typer.Option(None, "--taxonomy-csv", help="自定义中文鸟类名录 CSV"),
) -> None:
    """人工复核单张照片：改鸟名、确认结果、打星标、标淘汰。"""
    service = ReviewService(GalleryDatabase(db), TaxonomyMapper(taxonomy_csv))

    if reject:
        ok = service.reject(photo_id, notes=notes)
        console.print("[yellow]已标记淘汰[/yellow]" if ok else "[red]未找到该照片[/red]")
        return
    if restore:
        ok = service.restore(photo_id)
        console.print("[green]已恢复该照片[/green]" if ok else "[red]未找到该照片[/red]")
        return
    if species:
        ok, cn_name, sci_name = service.correct_species(photo_id, species, rating=rating, notes=notes)
        if ok:
            console.print(f"[green]已修正鸟种 -> {cn_name} ({sci_name or '未匹配学名'})[/green]")
        else:
            console.print("[red]未找到该照片[/red]")
        return
    if confirm:
        ok = service.confirm(photo_id, rating=rating, notes=notes)
        console.print("[green]已确认识别结果[/green]" if ok else "[red]未找到该照片[/red]")
        return
    if rating is not None or notes is not None:
        ok = service.db.update_review(photo_id, rating=rating, notes=notes)
        console.print("[green]已更新评分/备注[/green]" if ok else "[red]未找到该照片[/red]")
        return

    console.print("[yellow]未指定任何修改参数，请使用 --species / --confirm / --rating / --reject / --restore[/yellow]")


@app.command()
def cull(
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    no_bird: bool = typer.Option(True, "--no-bird/--keep-no-bird", help="批量淘汰未检测到鸟的空拍照片"),
    max_sharpness: Optional[float] = typer.Option(None, "--max-sharpness", help="批量淘汰鸟体清晰度低于此值的照片 (0~100)"),
    apply: bool = typer.Option(False, "--apply", help="实际执行标记（默认仅预览，不修改数据库）"),
) -> None:
    """批量废片筛选：将无鸟空拍或过糊照片标记为淘汰（不删除原文件）。"""
    service = ReviewService(GalleryDatabase(db))
    matched = service.batch_cull(
        reject_no_bird=no_bird,
        reject_blurry_below=max_sharpness,
        dry_run=not apply,
    )
    prefix = "[green]已标记淘汰[/green]" if apply else "[yellow]预览模式（加 --apply 生效）[/yellow]"
    console.print(f"{prefix}：共命中 {len(matched)} 张照片。")
    for row in matched[:20]:
        console.print(
            f"  #{row.photo_id} {row.file_name} | has_bird={row.has_bird} | sharpness={row.best_sharpness:.1f}"
        )


@app.command()
def export(
    output_dir: Path = typer.Argument(..., help="归档导出目标根目录"),
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    mode: str = typer.Option("copy", "--mode", help="导出模式: copy | move | hardlink | symlink"),
    template: str = typer.Option(
        "{species_cn}",
        "--template",
        help="目录模板，可用变量: {species_cn} {scientific_name} {order_cn} {family_cn} {date} {rating}",
    ),
    species: Optional[str] = typer.Option(None, "--species", "-s", help="仅导出指定鸟种"),
    min_conf: Optional[float] = typer.Option(None, "--min-conf", help="最低置信度"),
    min_sharpness: Optional[float] = typer.Option(None, "--min-sharpness", help="最低清晰度"),
    min_rating: Optional[int] = typer.Option(None, "--min-rating", help="最低星标"),
    only_reviewed: bool = typer.Option(False, "--only-reviewed", help="仅导出已人工确认/修正的照片"),
    no_blurry: bool = typer.Option(True, "--no-blurry/--include-blurry", help="默认跳过模糊废片"),
    dry_run: bool = typer.Option(False, "--dry-run", help="仅预览导出计划，不实际复制/移动文件"),
    manifest: Optional[Path] = typer.Option(None, "--manifest", help="导出清单 JSON 输出路径"),
    taxonomy_csv: Optional[Path] = typer.Option(None, "--taxonomy-csv", help="自定义中文鸟类名录 CSV"),
) -> None:
    """按鸟种中文名目录结构自动归档导出照片。"""
    db_obj = GalleryDatabase(db)
    exporter = ArchiveExporter(db_obj, TaxonomyMapper(taxonomy_csv))

    q = FilterQuery(
        species=species,
        has_bird=True,
        min_confidence=min_conf,
        min_sharpness=min_sharpness,
        min_rating=min_rating,
        only_reviewed=only_reviewed,
        include_rejected=False,
        include_blurry=not no_blurry,
        limit=1_000_000,
    )

    report = exporter.export(
        output_dir,
        q,
        mode=mode,  # type: ignore[arg-type]
        folder_template=template,
        dry_run=dry_run,
        manifest_path=manifest,
    )

    tag = "[yellow]预览（DRY-RUN）[/yellow]" if dry_run else "[green]导出完成[/green]"
    console.print(
        f"{tag} | 模式={report.mode} | 命中={report.total_matched} | "
        f"成功={report.exported} | 跳过={report.skipped} | 失败={report.failed}"
    )
    for item in report.items[:20]:
        console.print(f"  [{item.status}] {item.species_cn} -> {item.target_path}")


@app.command()
def stats(
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
) -> None:
    """查看图库整体统计与鸟种数量排行。"""
    data = GalleryDatabase(db).get_stats()

    summary = Table(title="图库概览")
    summary.add_column("指标", style="cyan")
    summary.add_column("数值", justify="right", style="bold")
    summary.add_row("总照片数", str(data["total_photos"]))
    summary.add_row("有鸟照片", f"[green]{data['with_birds']}[/green]")
    summary.add_row("无鸟空拍", str(data["no_birds"]))
    summary.add_row("RAW 照片", str(data["raw_photos"]))
    summary.add_row("疑似模糊", str(data["blurry_photos"]))
    summary.add_row("已淘汰", str(data["rejected_photos"]))
    summary.add_row("待复核", str(data["unreviewed"]))
    summary.add_row("已确认/修正", str(data["reviewed_ok"]))
    summary.add_row("3星及以上精选", str(data["starred_3plus"]))
    console.print(summary)

    breakdown = data["species_breakdown"]
    if breakdown:
        sp_table = Table(title="鸟种统计排行 (Top 50)")
        sp_table.add_column("中文名", style="green")
        sp_table.add_column("拉丁学名")
        sp_table.add_column("张数", justify="right", style="bold")
        sp_table.add_column("平均置信度", justify="right")
        sp_table.add_column("最高清晰度", justify="right")
        for row in breakdown:  # type: ignore[union-attr]
            sp_table.add_row(
                str(row["species_cn"]),
                str(row["scientific_name"]),
                str(row["photo_count"]),
                f"{float(row['avg_conf']):.2%}",
                f"{float(row['max_sharpness']):.1f}",
            )
        console.print(sp_table)


@app.command()
def taxonomy(
    keyword: str = typer.Argument("", help="搜索中文名、拼音首字母(如 ptcn)、英文名、拉丁学名或科名"),
    taxonomy_csv: Optional[Path] = typer.Option(None, "--taxonomy-csv", help="附加自定义名录 CSV"),
    china_only: bool = typer.Option(False, "--china-only", help="仅搜索中国分布鸟种"),
    limit: int = typer.Option(30, "--limit", "-n", help="最多显示条数"),
) -> None:
    """检索内置或自定义中文鸟类名录（支持拼音首字母如 ptcn、btb）。"""
    mapper = TaxonomyMapper(taxonomy_csv)
    matches = mapper.search(keyword, limit=limit, china_only=china_only)
    table = Table(
        title=f"鸟类名录检索（全球 {len(mapper)} 种 / 中国 {mapper.china_species_count} 种，命中前 {len(matches)} 条）"
    )
    table.add_column("中文名", style="green")
    table.add_column("首字母", style="cyan")
    table.add_column("拉丁学名")
    table.add_column("目 / 科")
    table.add_column("中国分布", justify="center")
    for entry in matches:
        table.add_row(
            entry.common_name_cn,
            entry.pinyin_initials,
            entry.scientific_name,
            f"{entry.order_cn} / {entry.family_cn}",
            "✓" if entry.in_china else "-",
        )
    console.print(table)


@app.command("import")
def import_cmd(
    source: Path = typer.Argument(..., help="待导入图库的照片目录或文件（纯预览+EXIF/GPS提取，无需AI模型）"),
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    location: str = typer.Option("", "--location", "-l", help="可选：统一标记本次导入照片的观鸟点名称"),
    album: Optional[str] = typer.Option(None, "--album", "-a", help="可选：自动将本次导入照片加入指定自定义相册"),
    force: bool = typer.Option(False, "--force", help="强制重新提取已导入未修改的文件"),
) -> None:
    """快速导入本地文件夹照片（无需 PyTorch/AI，仅提取预览缩略图与 EXIF/日期/GPS）。"""
    from bird_gallery.catalog import CatalogService

    cfg = EngineConfig(db_path=db)
    db_obj = GalleryDatabase(db)
    catalog = CatalogService(db_obj, TaxonomyMapper(), cfg)

    album_id: int | None = None
    if album and album.strip():
        created = db_obj.create_album(album.strip())
        album_id = created.album_id

    summary = catalog.import_folder(
        source,
        default_location=location,
        default_album_id=album_id,
        force_reimport=force,
    )
    console.print(
        f"[green]导入完成[/green] | 发现={summary.total_discovered} | 新增处理={summary.processed} | "
        f"跳过未变={summary.skipped_existing} | 失败={summary.failed} | 耗时={summary.elapsed_seconds:.2f}s"
    )


@app.command()
def gui(
    db: Path = typer.Option(Path("bird_gallery.db"), "--db", help="SQLite 数据库文件路径"),
    thumb_dir: Path = typer.Option(Path(".bird_gallery_cache/thumbs"), "--thumb-dir", help="缩略图缓存目录"),
    taxonomy_csv: Optional[Path] = typer.Option(None, "--taxonomy-csv", help="自定义中文鸟类名录 CSV"),
) -> None:
    """启动原生桌面窗口应用（Lightroom 风格文件浏览 + 鸟种图鉴 + 日期/地点/多相册归类）。"""
    from bird_gallery.gui.app import launch_gui

    raise typer.Exit(code=launch_gui(db_path=db, thumbnail_dir=thumb_dir, taxonomy_csv=taxonomy_csv))


if __name__ == "__main__":
    app()

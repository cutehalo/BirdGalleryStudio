"""SQLite storage layer for bird photos, folders, dates, locations, custom albums, and reviews."""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from bird_gallery.china_regions import (
    format_province_city,
    infer_province_city,
    normalize_province_name,
)
from bird_gallery.image_io import derive_taken_date
from bird_gallery.models import (
    Album,
    BirdDetection,
    BirdingChecklist,
    ChecklistItem,
    EBirdHotspot,
    ExifMetadata,
    FavoriteLocation,
    FilterQuery,
    PhotoRecord,
    ReviewStatus,
    SpeciesPrediction,
    format_gps_bucket,
)

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS photos (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path               TEXT NOT NULL UNIQUE,
    folder_path             TEXT NOT NULL DEFAULT '',
    file_name               TEXT NOT NULL,
    file_ext                TEXT NOT NULL,
    file_size               INTEGER NOT NULL,
    file_mtime              REAL NOT NULL,
    file_hash               TEXT,
    is_raw                  INTEGER NOT NULL DEFAULT 0,
    width                   INTEGER NOT NULL DEFAULT 0,
    height                  INTEGER NOT NULL DEFAULT 0,
    thumbnail_path          TEXT,

    -- EXIF & Location/Date metadata
    taken_at                TEXT,
    taken_date              TEXT,
    manual_date             TEXT,
    camera_make             TEXT,
    camera_model            TEXT,
    lens_model              TEXT,
    focal_length_mm         REAL,
    aperture                REAL,
    shutter_speed           TEXT,
    iso                     INTEGER,
    gps_lat                 REAL,
    gps_lon                 REAL,
    location_name           TEXT NOT NULL DEFAULT '',
    location_province       TEXT NOT NULL DEFAULT '',
    location_city           TEXT NOT NULL DEFAULT '',
    ebird_loc_id            TEXT,

    -- Aggregated AI / Species fields
    has_bird                INTEGER NOT NULL DEFAULT 0,
    bird_count              INTEGER NOT NULL DEFAULT 0,
    is_blurry               INTEGER NOT NULL DEFAULT 0,
    best_sharpness          REAL NOT NULL DEFAULT 0.0,
    primary_scientific_name TEXT NOT NULL DEFAULT '',
    primary_common_name_cn  TEXT NOT NULL DEFAULT '',
    primary_common_name_en  TEXT NOT NULL DEFAULT '',
    primary_order_cn        TEXT NOT NULL DEFAULT '',
    primary_family_cn       TEXT NOT NULL DEFAULT '',
    primary_confidence      REAL NOT NULL DEFAULT 0.0,

    -- Manual review & culling
    review_status           TEXT NOT NULL DEFAULT 'unreviewed',
    manual_scientific_name  TEXT,
    manual_common_name_cn   TEXT,
    rating                  INTEGER NOT NULL DEFAULT 0,
    pick_flag               INTEGER NOT NULL DEFAULT 0,
    is_rejected             INTEGER NOT NULL DEFAULT 0,
    notes                   TEXT NOT NULL DEFAULT '',

    scanned_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS detections (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    photo_id          INTEGER NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
    x1                INTEGER NOT NULL,
    y1                INTEGER NOT NULL,
    x2                INTEGER NOT NULL,
    y2                INTEGER NOT NULL,
    detect_conf       REAL NOT NULL,
    sharpness_score   REAL NOT NULL DEFAULT 0.0,
    raw_laplacian_var REAL NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS species_predictions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    detection_id    INTEGER NOT NULL REFERENCES detections(id) ON DELETE CASCADE,
    rank            INTEGER NOT NULL,
    scientific_name TEXT NOT NULL,
    common_name_en  TEXT NOT NULL DEFAULT '',
    common_name_cn  TEXT NOT NULL DEFAULT '',
    order_name      TEXT NOT NULL DEFAULT '',
    order_cn        TEXT NOT NULL DEFAULT '',
    family_name     TEXT NOT NULL DEFAULT '',
    family_cn       TEXT NOT NULL DEFAULT '',
    genus_name      TEXT NOT NULL DEFAULT '',
    score           REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS albums (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS album_photos (
    album_id    INTEGER NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
    photo_id    INTEGER NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
    added_at    TEXT NOT NULL,
    PRIMARY KEY (album_id, photo_id)
);

CREATE TABLE IF NOT EXISTS watched_folders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    folder_path TEXT NOT NULL UNIQUE,
    added_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS favorite_locations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE,
    province        TEXT NOT NULL DEFAULT '',
    city            TEXT NOT NULL DEFAULT '',
    region          TEXT NOT NULL DEFAULT '',
    ebird_loc_id    TEXT,
    ebird_loc_name  TEXT NOT NULL DEFAULT '',
    lat             REAL,
    lng             REAL,
    notes           TEXT NOT NULL DEFAULT '',
    sort_order      INTEGER NOT NULL DEFAULT 0,
    use_count       INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ebird_hotspots (
    loc_id              TEXT PRIMARY KEY,
    loc_name            TEXT NOT NULL,
    country_code        TEXT NOT NULL DEFAULT '',
    subnational1_code   TEXT NOT NULL DEFAULT '',
    subnational2_code   TEXT NOT NULL DEFAULT '',
    city_name           TEXT NOT NULL DEFAULT '',
    lat                 REAL,
    lng                 REAL,
    num_species         INTEGER NOT NULL DEFAULT 0,
    latest_obs_dt       TEXT NOT NULL DEFAULT '',
    pinyin_initials     TEXT NOT NULL DEFAULT '',
    pinyin_full         TEXT NOT NULL DEFAULT '',
    synced_at           TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ebird_hotspots_region ON ebird_hotspots(country_code, subnational1_code);
CREATE INDEX IF NOT EXISTS idx_ebird_hotspots_city ON ebird_hotspots(city_name);
CREATE INDEX IF NOT EXISTS idx_ebird_hotspots_pinyin ON ebird_hotspots(pinyin_initials);

CREATE TABLE IF NOT EXISTS birding_checklists (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    obs_date        TEXT NOT NULL,
    obs_time        TEXT NOT NULL DEFAULT '',
    source          TEXT NOT NULL DEFAULT 'birdreport',
    external_id     TEXT NOT NULL DEFAULT '',
    location_name   TEXT NOT NULL DEFAULT '',
    province        TEXT NOT NULL DEFAULT '',
    city            TEXT NOT NULL DEFAULT '',
    ebird_loc_id    TEXT,
    lat             REAL,
    lng             REAL,
    species_count   INTEGER NOT NULL DEFAULT 0,
    notes           TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS birding_checklist_items (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    checklist_id    INTEGER NOT NULL REFERENCES birding_checklists(id) ON DELETE CASCADE,
    common_name_cn  TEXT NOT NULL,
    scientific_name TEXT NOT NULL DEFAULT '',
    count_num       INTEGER NOT NULL DEFAULT 1,
    count_str       TEXT NOT NULL DEFAULT '1',
    remarks         TEXT NOT NULL DEFAULT '',
    UNIQUE(checklist_id, common_name_cn)
);

CREATE INDEX IF NOT EXISTS idx_checklists_date ON birding_checklists(obs_date);
CREATE INDEX IF NOT EXISTS idx_checklist_items_cid ON birding_checklist_items(checklist_id);

CREATE TABLE IF NOT EXISTS photo_species (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    photo_id        INTEGER NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
    common_name_cn  TEXT NOT NULL,
    scientific_name TEXT NOT NULL DEFAULT '',
    common_name_en  TEXT NOT NULL DEFAULT '',
    order_cn        TEXT NOT NULL DEFAULT '',
    family_cn       TEXT NOT NULL DEFAULT '',
    added_at        TEXT NOT NULL,
    UNIQUE(photo_id, common_name_cn)
);

CREATE INDEX IF NOT EXISTS idx_photo_species_photo ON photo_species(photo_id, id);
CREATE INDEX IF NOT EXISTS idx_photo_species_cn ON photo_species(common_name_cn);
CREATE INDEX IF NOT EXISTS idx_photo_species_ord ON photo_species(order_cn);
CREATE INDEX IF NOT EXISTS idx_photo_species_fam ON photo_species(family_cn);

CREATE INDEX IF NOT EXISTS idx_photos_folder ON photos(folder_path);
CREATE INDEX IF NOT EXISTS idx_photos_has_bird ON photos(has_bird);
CREATE INDEX IF NOT EXISTS idx_photos_primary_sci ON photos(primary_scientific_name);
CREATE INDEX IF NOT EXISTS idx_photos_primary_cn ON photos(primary_common_name_cn);
CREATE INDEX IF NOT EXISTS idx_photos_manual_cn ON photos(manual_common_name_cn);
CREATE INDEX IF NOT EXISTS idx_photos_confidence ON photos(primary_confidence);
CREATE INDEX IF NOT EXISTS idx_photos_sharpness ON photos(best_sharpness);
CREATE INDEX IF NOT EXISTS idx_photos_review ON photos(review_status, is_rejected, rating);
CREATE INDEX IF NOT EXISTS idx_photos_taken_at ON photos(taken_at);
CREATE INDEX IF NOT EXISTS idx_photos_taken_date ON photos(taken_date);
CREATE INDEX IF NOT EXISTS idx_photos_location ON photos(location_name);
CREATE INDEX IF NOT EXISTS idx_photos_loc_admin ON photos(location_province, location_city);
CREATE INDEX IF NOT EXISTS idx_detections_photo_id ON detections(photo_id);
CREATE INDEX IF NOT EXISTS idx_predictions_det_id ON species_predictions(detection_id);
CREATE INDEX IF NOT EXISTS idx_album_photos_photo ON album_photos(photo_id);
"""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class GalleryDatabase:
    """Thread-safe-per-call SQLite wrapper for the bird photo gallery."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        if self.db_path.parent and str(self.db_path.parent) not in ("", "."):
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_schema()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_schema(self) -> None:
        with self.connect() as conn:
            # Safely migrate older tables before creating indexes
            def _ensure_cols(table: str, cols: list[tuple[str, str]]) -> bool:
                exists = conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                    (table,),
                ).fetchone()
                if exists is None:
                    return False
                existing_cols = {
                    row["name"]
                    for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
                }
                added = False
                for col_name, col_def in cols:
                    if col_name not in existing_cols:
                        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
                        added = True
                return added

            _ensure_cols(
                "photos",
                [
                    ("folder_path", "TEXT NOT NULL DEFAULT ''"),
                    ("taken_date", "TEXT"),
                    ("manual_date", "TEXT"),
                    ("gps_lat", "REAL"),
                    ("gps_lon", "REAL"),
                    ("location_name", "TEXT NOT NULL DEFAULT ''"),
                    ("location_province", "TEXT NOT NULL DEFAULT ''"),
                    ("location_city", "TEXT NOT NULL DEFAULT ''"),
                    ("ebird_loc_id", "TEXT"),
                    ("pick_flag", "INTEGER NOT NULL DEFAULT 0"),
                ],
            )
            _ensure_cols(
                "favorite_locations",
                [
                    ("province", "TEXT NOT NULL DEFAULT ''"),
                    ("city", "TEXT NOT NULL DEFAULT ''"),
                ],
            )
            _ensure_cols(
                "ebird_hotspots",
                [
                    ("subnational2_code", "TEXT NOT NULL DEFAULT ''"),
                    ("city_name", "TEXT NOT NULL DEFAULT ''"),
                ],
            )

            conn.executescript(SCHEMA_SQL)

            # Backfill missing province/city on existing rows so prefecture-level filtering works immediately
            fav_missing = conn.execute(
                "SELECT id, name, region, ebird_loc_name, lat, lng FROM favorite_locations WHERE province = ''"
            ).fetchall()
            for r in fav_missing:
                p, c = infer_province_city(
                    r["lat"],
                    r["lng"],
                    text_hint=f"{r['region'] or ''} {r['name'] or ''} {r['ebird_loc_name'] or ''}",
                )
                if p or c:
                    reg = format_province_city(p, c) or str(r["region"] or "")
                    conn.execute(
                        "UPDATE favorite_locations SET province = ?, city = ?, region = ? WHERE id = ?",
                        (p, c, reg, r["id"]),
                    )

            hs_missing = conn.execute(
                "SELECT loc_id, loc_name, country_code, subnational1_code, lat, lng "
                "FROM ebird_hotspots WHERE city_name = '' AND lat IS NOT NULL"
            ).fetchall()
            if hs_missing:
                hs_updates: list[tuple[str, str]] = []
                for r in hs_missing:
                    _p, c = infer_province_city(
                        r["lat"],
                        r["lng"],
                        subnational1_code=str(r["subnational1_code"] or r["country_code"] or ""),
                        text_hint=str(r["loc_name"] or ""),
                    )
                    if c:
                        hs_updates.append((c, str(r["loc_id"])))
                if hs_updates:
                    conn.executemany("UPDATE ebird_hotspots SET city_name = ? WHERE loc_id = ?", hs_updates)

            ph_missing = conn.execute(
                "SELECT id, location_name, gps_lat, gps_lon FROM photos "
                "WHERE location_province = '' AND (location_name != '' OR gps_lat IS NOT NULL)"
            ).fetchall()
            if ph_missing:
                ph_updates: list[tuple[str, str, int]] = []
                for r in ph_missing:
                    p, c = infer_province_city(r["gps_lat"], r["gps_lon"], text_hint=str(r["location_name"] or ""))
                    if p or c:
                        ph_updates.append((p, c, int(r["id"])))
                if ph_updates:
                    conn.executemany(
                        "UPDATE photos SET location_province = ?, location_city = ? WHERE id = ?",
                        ph_updates,
                    )

            # Seed multi-species table `photo_species` from any legacy single-species rows in `photos`
            conn.execute(
                """
                INSERT OR IGNORE INTO photo_species (
                    photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                )
                SELECT
                    id,
                    COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), NULLIF(manual_scientific_name, ''), primary_scientific_name),
                    COALESCE(NULLIF(manual_scientific_name, ''), primary_scientific_name),
                    primary_common_name_en,
                    primary_order_cn,
                    primary_family_cn,
                    updated_at
                FROM photos
                WHERE COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), NULLIF(manual_scientific_name, ''), NULLIF(primary_scientific_name, '')) IS NOT NULL
                """
            )

    def is_file_unchanged(self, file_path: str, file_size: int, file_mtime: float) -> bool:
        """Check if a file is already indexed with the same size and mtime."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT file_size, file_mtime FROM photos WHERE file_path = ?",
                (file_path,),
            ).fetchone()
            if row is None:
                return False
            return int(row["file_size"]) == file_size and abs(float(row["file_mtime"]) - file_mtime) < 1e-3

    def upsert_photo(self, photo: PhotoRecord) -> int:
        """Insert or update a photo record while preserving manual classifications, locations, and albums."""
        now = _utc_now()
        scanned_at = photo.scanned_at or now
        updated_at = now
        folder_path = photo.folder_path or str(Path(photo.file_path).parent)
        base_date = photo.manual_date or photo.taken_date or derive_taken_date(
            photo.exif.taken_at, photo.file_mtime
        )

        if not photo.location_province and (photo.location_name or photo.exif.gps_lat is not None):
            inf_p, inf_c = infer_province_city(
                photo.exif.gps_lat,
                photo.exif.gps_lon,
                text_hint=photo.location_name,
            )
            photo.location_province = inf_p
            photo.location_city = photo.location_city or inf_c

        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id, manual_date, location_name, location_province, location_city, ebird_loc_id, "
                "review_status, manual_scientific_name, "
                "manual_common_name_cn, rating, pick_flag, is_rejected, notes "
                "FROM photos WHERE file_path = ?",
                (photo.file_path,),
            ).fetchone()

            if existing is None:
                cur = conn.execute(
                    """
                    INSERT INTO photos (
                        file_path, folder_path, file_name, file_ext, file_size, file_mtime, file_hash,
                        is_raw, width, height, thumbnail_path,
                        taken_at, taken_date, manual_date,
                        camera_make, camera_model, lens_model,
                        focal_length_mm, aperture, shutter_speed, iso,
                        gps_lat, gps_lon, location_name, location_province, location_city, ebird_loc_id,
                        has_bird, bird_count, is_blurry, best_sharpness,
                        primary_scientific_name, primary_common_name_cn, primary_common_name_en,
                        primary_order_cn, primary_family_cn, primary_confidence,
                        review_status, manual_scientific_name, manual_common_name_cn,
                        rating, pick_flag, is_rejected, notes,
                        scanned_at, updated_at
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?
                    )
                    """,
                    (
                        photo.file_path,
                        folder_path,
                        photo.file_name,
                        photo.file_ext,
                        photo.file_size,
                        photo.file_mtime,
                        photo.file_hash,
                        int(photo.is_raw),
                        photo.width,
                        photo.height,
                        photo.thumbnail_path,
                        photo.exif.taken_at,
                        base_date,
                        photo.manual_date,
                        photo.exif.camera_make,
                        photo.exif.camera_model,
                        photo.exif.lens_model,
                        photo.exif.focal_length_mm,
                        photo.exif.aperture,
                        photo.exif.shutter_speed,
                        photo.exif.iso,
                        photo.exif.gps_lat,
                        photo.exif.gps_lon,
                        photo.location_name,
                        photo.location_province,
                        photo.location_city,
                        photo.ebird_loc_id,
                        int(photo.has_bird),
                        photo.bird_count,
                        int(photo.is_blurry),
                        photo.best_sharpness,
                        photo.primary_scientific_name,
                        photo.primary_common_name_cn,
                        photo.primary_common_name_en,
                        photo.primary_order_cn,
                        photo.primary_family_cn,
                        photo.primary_confidence,
                        photo.review_status.value,
                        photo.manual_scientific_name,
                        photo.manual_common_name_cn,
                        photo.rating,
                        photo.pick_flag,
                        int(photo.is_rejected),
                        photo.notes,
                        scanned_at,
                        updated_at,
                    ),
                )
                photo_id = int(cur.lastrowid)
            else:
                photo_id = int(existing["id"])
                effective_date = existing["manual_date"] or base_date
                effective_loc = existing["location_name"] or photo.location_name
                effective_prov = existing["location_province"] or photo.location_province
                effective_city = existing["location_city"] or photo.location_city
                effective_ebird = existing["ebird_loc_id"] or photo.ebird_loc_id
                # Preserve manual bird assignment & has_bird if user already tagged this photo
                keep_has_bird = int(photo.has_bird or bool(existing["manual_common_name_cn"]) or bool(existing["manual_scientific_name"]))

                conn.execute(
                    """
                    UPDATE photos SET
                        folder_path = ?, file_name = ?, file_ext = ?, file_size = ?, file_mtime = ?, file_hash = ?,
                        is_raw = ?, width = ?, height = ?, thumbnail_path = ?,
                        taken_at = ?, taken_date = ?,
                        camera_make = ?, camera_model = ?, lens_model = ?,
                        focal_length_mm = ?, aperture = ?, shutter_speed = ?, iso = ?,
                        gps_lat = COALESCE(?, gps_lat), gps_lon = COALESCE(?, gps_lon),
                        location_name = ?, location_province = ?, location_city = ?, ebird_loc_id = ?,
                        has_bird = ?, bird_count = ?, is_blurry = ?, best_sharpness = ?,
                        primary_scientific_name = CASE WHEN ? != '' THEN ? ELSE primary_scientific_name END,
                        primary_common_name_cn = CASE WHEN ? != '' THEN ? ELSE primary_common_name_cn END,
                        primary_common_name_en = CASE WHEN ? != '' THEN ? ELSE primary_common_name_en END,
                        primary_order_cn = CASE WHEN ? != '' THEN ? ELSE primary_order_cn END,
                        primary_family_cn = CASE WHEN ? != '' THEN ? ELSE primary_family_cn END,
                        primary_confidence = CASE WHEN ? > 0 THEN ? ELSE primary_confidence END,
                        scanned_at = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (
                        folder_path,
                        photo.file_name,
                        photo.file_ext,
                        photo.file_size,
                        photo.file_mtime,
                        photo.file_hash,
                        int(photo.is_raw),
                        photo.width,
                        photo.height,
                        photo.thumbnail_path,
                        photo.exif.taken_at,
                        effective_date,
                        photo.exif.camera_make,
                        photo.exif.camera_model,
                        photo.exif.lens_model,
                        photo.exif.focal_length_mm,
                        photo.exif.aperture,
                        photo.exif.shutter_speed,
                        photo.exif.iso,
                        photo.exif.gps_lat,
                        photo.exif.gps_lon,
                        effective_loc,
                        effective_prov,
                        effective_city,
                        effective_ebird,
                        keep_has_bird,
                        photo.bird_count,
                        int(photo.is_blurry),
                        photo.best_sharpness,
                        photo.primary_scientific_name,
                        photo.primary_scientific_name,
                        photo.primary_common_name_cn,
                        photo.primary_common_name_cn,
                        photo.primary_common_name_en,
                        photo.primary_common_name_en,
                        photo.primary_order_cn,
                        photo.primary_order_cn,
                        photo.primary_family_cn,
                        photo.primary_family_cn,
                        photo.primary_confidence,
                        photo.primary_confidence,
                        scanned_at,
                        updated_at,
                        photo_id,
                    ),
                )
                if photo.detections:
                    conn.execute("DELETE FROM detections WHERE photo_id = ?", (photo_id,))

            for det in photo.detections:
                x1, y1, x2, y2 = det.bbox
                det_cur = conn.execute(
                    """
                    INSERT INTO detections (photo_id, x1, y1, x2, y2, detect_conf, sharpness_score, raw_laplacian_var)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (photo_id, x1, y1, x2, y2, det.detect_conf, det.sharpness_score, det.raw_laplacian_var),
                )
                det_id = int(det_cur.lastrowid)
                det.detection_id = det_id
                if det.predictions:
                    conn.executemany(
                        """
                        INSERT INTO species_predictions (
                            detection_id, rank, scientific_name, common_name_en, common_name_cn,
                            order_name, order_cn, family_name, family_cn, genus_name, score
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        [
                            (
                                det_id,
                                pred.rank,
                                pred.scientific_name,
                                pred.common_name_en,
                                pred.common_name_cn,
                                pred.order_name,
                                pred.order_cn,
                                pred.family_name,
                                pred.family_cn,
                                pred.genus_name,
                                pred.score,
                            )
                            for pred in det.predictions
                        ],
                    )

        photo.photo_id = photo_id
        photo.folder_path = folder_path
        photo.taken_date = base_date
        if photo.has_assigned_species:
            sp_cn = (photo.manual_common_name_cn or photo.primary_common_name_cn or photo.effective_scientific_name or "").strip()
            if sp_cn:
                with self.connect() as conn:
                    has_ps = conn.execute("SELECT 1 FROM photo_species WHERE photo_id = ? LIMIT 1", (photo_id,)).fetchone()
                    if has_ps is None:
                        conn.execute(
                            """
                            INSERT OR IGNORE INTO photo_species (
                                photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                photo_id,
                                sp_cn,
                                photo.effective_scientific_name or "",
                                photo.primary_common_name_en or "",
                                photo.primary_order_cn or "",
                                photo.primary_family_cn or "",
                                updated_at,
                            ),
                        )
        return photo_id

    def get_photo(self, photo_id: int, include_detections: bool = True) -> PhotoRecord | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM photos WHERE id = ?", (photo_id,)).fetchone()
            if row is None:
                return None
            record = self._row_to_photo(row)
            if include_detections:
                record.detections = self._load_detections(conn, photo_id)
            record.species_list = [
                str(r["common_name_cn"])
                for r in conn.execute(
                    "SELECT common_name_cn FROM photo_species WHERE photo_id = ? ORDER BY id ASC",
                    (photo_id,),
                ).fetchall()
            ]
            record.album_ids = [
                int(r["album_id"])
                for r in conn.execute(
                    "SELECT album_id FROM album_photos WHERE photo_id = ? ORDER BY album_id ASC",
                    (photo_id,),
                ).fetchall()
            ]
            return record

    def query_photos(self, query: FilterQuery, include_detections: bool = False) -> list[PhotoRecord]:
        clauses: list[str] = []
        params: list[object] = []

        if query.keyword and query.keyword.strip():
            kw = f"%{query.keyword.strip()}%"
            clauses.append(
                "("
                "file_name LIKE ? OR "
                "location_name LIKE ? OR "
                "location_province LIKE ? OR "
                "location_city LIKE ? OR "
                "notes LIKE ? OR "
                "COALESCE(manual_common_name_cn, '') LIKE ? OR "
                "COALESCE(manual_scientific_name, '') LIKE ? OR "
                "primary_common_name_cn LIKE ? OR "
                "primary_scientific_name LIKE ? OR "
                "id IN (SELECT photo_id FROM photo_species WHERE common_name_cn LIKE ? OR scientific_name LIKE ?)"
                ")"
            )
            params.extend([kw] * 11)

        if query.species:
            like = f"%{query.species.strip()}%"
            clauses.append(
                "("
                "COALESCE(manual_common_name_cn, '') LIKE ? OR "
                "COALESCE(manual_scientific_name, '') LIKE ? OR "
                "primary_common_name_cn LIKE ? OR "
                "primary_common_name_en LIKE ? OR "
                "primary_scientific_name LIKE ? OR "
                "primary_family_cn LIKE ? OR "
                "primary_order_cn LIKE ? OR "
                "id IN (SELECT photo_id FROM photo_species WHERE "
                "common_name_cn LIKE ? OR scientific_name LIKE ? OR common_name_en LIKE ? OR family_cn LIKE ? OR order_cn LIKE ?)"
                ")"
            )
            params.extend([like] * 12)

        if query.exact_species_cn:
            clauses.append(
                "("
                "id IN (SELECT photo_id FROM photo_species WHERE common_name_cn = ?) OR "
                "COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), "
                "NULLIF(manual_scientific_name, ''), primary_scientific_name) = ?"
                ")"
            )
            params.extend([query.exact_species_cn, query.exact_species_cn])

        if query.exact_order_cn:
            clauses.append(
                "(primary_order_cn = ? OR id IN (SELECT photo_id FROM photo_species WHERE order_cn = ?))"
            )
            params.extend([query.exact_order_cn, query.exact_order_cn])

        if query.exact_family_cn:
            clauses.append(
                "(primary_family_cn = ? OR id IN (SELECT photo_id FROM photo_species WHERE family_cn = ?))"
            )
            params.extend([query.exact_family_cn, query.exact_family_cn])

        if query.unassigned_species_only:
            clauses.append(
                "COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), "
                "NULLIF(manual_scientific_name, ''), NULLIF(primary_scientific_name, '')) IS NULL"
            )

        if query.folder_path:
            norm_folder = str(Path(query.folder_path).resolve())
            if query.include_subfolders:
                sep = os.sep
                prefix = norm_folder if norm_folder.endswith(sep) else norm_folder + sep
                clauses.append("(folder_path = ? OR folder_path LIKE ?)")
                params.extend([norm_folder, prefix + "%"])
            else:
                clauses.append("folder_path = ?")
                params.append(norm_folder)

        if query.album_id is not None:
            clauses.append("id IN (SELECT photo_id FROM album_photos WHERE album_id = ?)")
            params.append(query.album_id)

        if query.date_prefix:
            clauses.append("taken_date LIKE ?")
            params.append(f"{query.date_prefix}%")
        elif query.undated_only:
            clauses.append("(taken_date IS NULL OR taken_date = '')")

        if query.location_key:
            if query.location_key == "__unlocated__":
                clauses.append("(location_name = '' AND gps_lat IS NULL)")
            elif query.location_key.startswith("GPS ("):
                # Filter unnamed GPS rows in Python post-filter for exact formatted bucket match
                clauses.append("(location_name = '' AND gps_lat IS NOT NULL AND gps_lon IS NOT NULL)")
            else:
                clauses.append("location_name = ?")
                params.append(query.location_key)

        if query.location_province:
            if query.location_province == "其他地区":
                clauses.append("(location_province = '' AND (location_name != '' OR gps_lat IS NOT NULL))")
            else:
                clauses.append("location_province = ?")
                params.append(query.location_province)

        if query.location_city:
            if query.location_city == "未分地市":
                clauses.append("location_city = ''")
            else:
                clauses.append("location_city = ?")
                params.append(query.location_city)

        if query.has_bird is not None:
            clauses.append("has_bird = ?")
            params.append(int(query.has_bird))

        if query.min_confidence is not None:
            clauses.append("primary_confidence >= ?")
            params.append(query.min_confidence)

        if query.max_confidence is not None:
            clauses.append("primary_confidence <= ?")
            params.append(query.max_confidence)

        if query.min_sharpness is not None:
            clauses.append("best_sharpness >= ?")
            params.append(query.min_sharpness)

        if query.max_sharpness is not None:
            clauses.append("best_sharpness <= ?")
            params.append(query.max_sharpness)

        if query.min_rating is not None:
            clauses.append("rating >= ?")
            params.append(query.min_rating)

        if query.max_rating is not None:
            clauses.append("rating <= ?")
            params.append(query.max_rating)

        if query.pick_only:
            clauses.append("pick_flag = 1")

        if query.review_status is not None:
            clauses.append("review_status = ?")
            params.append(query.review_status.value)
        elif query.only_reviewed:
            clauses.append("review_status IN ('confirmed', 'corrected')")

        if query.rejected_only:
            clauses.append("is_rejected = 1")
        elif not query.include_rejected:
            clauses.append("is_rejected = 0")

        if not query.include_blurry:
            clauses.append("is_blurry = 0")

        if query.is_raw is not None:
            clauses.append("is_raw = ?")
            params.append(int(query.is_raw))

        if query.date_from:
            clauses.append("COALESCE(taken_date, taken_at) >= ?")
            params.append(query.date_from)

        if query.date_to:
            clauses.append("COALESCE(taken_date, taken_at) <= ?")
            params.append(query.date_to + "T23:59:59" if len(query.date_to) == 10 else query.date_to)

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        sort_map = {
            "taken_at_desc": "COALESCE(taken_at, taken_date, scanned_at) DESC, file_name ASC",
            "taken_at_asc": "COALESCE(taken_at, taken_date, scanned_at) ASC, file_name ASC",
            "name_asc": "file_name ASC, id ASC",
            "confidence_desc": "primary_confidence DESC, best_sharpness DESC",
            "confidence_asc": "primary_confidence ASC, id ASC",
            "sharpness_desc": "best_sharpness DESC, primary_confidence DESC",
            "rating_desc": "rating DESC, pick_flag DESC, COALESCE(taken_at, scanned_at) DESC",
            "id_asc": "id ASC",
        }
        order_sql = sort_map.get(query.sort_by, sort_map["taken_at_desc"])

        sql = f"SELECT * FROM photos {where_sql} ORDER BY {order_sql} LIMIT ? OFFSET ?"
        params.extend([query.limit, query.offset])

        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
            records = [self._row_to_photo(r) for r in rows]
            if query.location_key and query.location_key.startswith("GPS ("):
                records = [r for r in records if r.display_location == query.location_key]
            if records:
                pids = [r.photo_id for r in records if r.photo_id is not None]
                if pids:
                    sp_map: dict[int, list[str]] = {}
                    # SQLite max host parameters is typically 999..32766; chunk by 800 for safety
                    for start in range(0, len(pids), 800):
                        chunk = pids[start : start + 800]
                        ph = ",".join("?" for _ in chunk)
                        for sr in conn.execute(
                            f"SELECT photo_id, common_name_cn FROM photo_species WHERE photo_id IN ({ph}) ORDER BY id ASC",
                            chunk,
                        ).fetchall():
                            sp_map.setdefault(int(sr["photo_id"]), []).append(str(sr["common_name_cn"]))
                    for rec in records:
                        if rec.photo_id is not None and rec.photo_id in sp_map:
                            rec.species_list = sp_map[rec.photo_id]
            if include_detections:
                for rec in records:
                    if rec.photo_id is not None:
                        rec.detections = self._load_detections(conn, rec.photo_id)
            return records

    def update_review(
        self,
        photo_id: int,
        *,
        manual_scientific_name: str | None = None,
        manual_common_name_cn: str | None = None,
        rating: int | None = None,
        pick_flag: int | None = None,
        is_rejected: bool | None = None,
        review_status: ReviewStatus | None = None,
        notes: str | None = None,
    ) -> bool:
        """Apply manual review fields to a single photo. Returns True if the photo existed."""
        updates: list[str] = []
        params: list[object] = []

        if manual_scientific_name is not None:
            updates.append("manual_scientific_name = ?")
            params.append(manual_scientific_name.strip() or None)
        if manual_common_name_cn is not None:
            updates.append("manual_common_name_cn = ?")
            params.append(manual_common_name_cn.strip() or None)
        if rating is not None:
            if not 0 <= rating <= 5:
                raise ValueError("rating must be between 0 and 5")
            updates.append("rating = ?")
            params.append(rating)
        if pick_flag is not None:
            updates.append("pick_flag = ?")
            params.append(pick_flag)
            updates.append("is_rejected = ?")
            params.append(1 if pick_flag < 0 else 0)
        elif is_rejected is not None:
            updates.append("is_rejected = ?")
            params.append(int(is_rejected))
            updates.append("pick_flag = ?")
            params.append(-1 if is_rejected else 0)
        if review_status is not None:
            updates.append("review_status = ?")
            params.append(review_status.value)
        if notes is not None:
            updates.append("notes = ?")
            params.append(notes)

        if not updates:
            return False

        updates.append("updated_at = ?")
        params.append(_utc_now())
        params.append(photo_id)

        with self.connect() as conn:
            cur = conn.execute(f"UPDATE photos SET {', '.join(updates)} WHERE id = ?", params)
            if (manual_common_name_cn is not None or manual_scientific_name is not None) and cur.rowcount > 0:
                cn_val = (manual_common_name_cn or manual_scientific_name or "").strip()
                conn.execute("DELETE FROM photo_species WHERE photo_id = ?", (photo_id,))
                if cn_val:
                    conn.execute(
                        "INSERT OR IGNORE INTO photo_species (photo_id, common_name_cn, scientific_name, added_at) VALUES (?, ?, ?, ?)",
                        (photo_id, cn_val, (manual_scientific_name or "").strip(), _utc_now()),
                    )
            return cur.rowcount > 0

    @staticmethod
    def _sync_primary_species_from_table(conn: sqlite3.Connection, photo_ids: list[int], now: str) -> None:
        """Mirror the first species in `photo_species` onto `photos` primary/manual columns (or clear if none)."""
        for pid in photo_ids:
            first = conn.execute(
                "SELECT * FROM photo_species WHERE photo_id = ? ORDER BY id ASC LIMIT 1",
                (pid,),
            ).fetchone()
            if first is None:
                conn.execute(
                    """
                    UPDATE photos SET
                        manual_common_name_cn = NULL,
                        manual_scientific_name = NULL,
                        primary_common_name_cn = '',
                        primary_scientific_name = '',
                        primary_common_name_en = '',
                        primary_order_cn = '',
                        primary_family_cn = '',
                        has_bird = 0,
                        review_status = 'unreviewed',
                        updated_at = ?
                    WHERE id = ?
                    """,
                    (now, pid),
                )
            else:
                conn.execute(
                    """
                    UPDATE photos SET
                        manual_common_name_cn = ?,
                        manual_scientific_name = ?,
                        primary_common_name_en = CASE WHEN ? != '' THEN ? ELSE primary_common_name_en END,
                        primary_order_cn = CASE WHEN ? != '' THEN ? ELSE primary_order_cn END,
                        primary_family_cn = CASE WHEN ? != '' THEN ? ELSE primary_family_cn END,
                        has_bird = 1,
                        review_status = 'corrected',
                        is_rejected = 0,
                        pick_flag = CASE WHEN pick_flag < 0 THEN 0 ELSE pick_flag END,
                        updated_at = ?
                    WHERE id = ?
                    """,
                    (
                        str(first["common_name_cn"]) or None,
                        str(first["scientific_name"]) or None,
                        str(first["common_name_en"]),
                        str(first["common_name_en"]),
                        str(first["order_cn"]),
                        str(first["order_cn"]),
                        str(first["family_cn"]),
                        str(first["family_cn"]),
                        now,
                        pid,
                    ),
                )

    def batch_assign_species(
        self,
        photo_ids: list[int],
        *,
        common_name_cn: str,
        scientific_name: str = "",
        common_name_en: str = "",
        order_cn: str = "",
        family_cn: str = "",
    ) -> int:
        """Set (replace) or clear a single bird species across multiple photos at once."""
        if not photo_ids:
            return 0
        placeholders = ",".join("?" for _ in photo_ids)
        now = _utc_now()
        cn = common_name_cn.strip()
        sci = scientific_name.strip()

        with self.connect() as conn:
            conn.execute(f"DELETE FROM photo_species WHERE photo_id IN ({placeholders})", photo_ids)
            if cn or sci:
                eff_cn = cn or sci
                conn.executemany(
                    """
                    INSERT OR IGNORE INTO photo_species (
                        photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    [(pid, eff_cn, sci, common_name_en.strip(), order_cn.strip(), family_cn.strip(), now) for pid in photo_ids],
                )
            self._sync_primary_species_from_table(conn, photo_ids, now)
            return len(photo_ids)

    def batch_add_species(
        self,
        photo_ids: list[int],
        species_tuples: list[tuple[str, str, str, str, str]],
    ) -> int:
        """Append 1 or more co-occurring species `(cn, sci, en, order_cn, family_cn)` to photos without removing existing ones."""
        if not photo_ids or not species_tuples:
            return 0
        now = _utc_now()
        rows_to_insert = [
            (pid, cn.strip(), sci.strip(), en.strip(), ord_c.strip(), fam_c.strip(), now)
            for pid in photo_ids
            for (cn, sci, en, ord_c, fam_c) in species_tuples
            if cn.strip()
        ]
        if not rows_to_insert:
            return 0
        with self.connect() as conn:
            conn.executemany(
                """
                INSERT OR IGNORE INTO photo_species (
                    photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                rows_to_insert,
            )
            self._sync_primary_species_from_table(conn, photo_ids, now)
        return len(photo_ids)

    def batch_set_species_list(
        self,
        photo_ids: list[int],
        species_tuples: list[tuple[str, str, str, str, str]],
    ) -> int:
        """Replace the multi-species list on `photo_ids` with `species_tuples` `(cn, sci, en, order_cn, family_cn)`."""
        if not photo_ids:
            return 0
        placeholders = ",".join("?" for _ in photo_ids)
        now = _utc_now()
        with self.connect() as conn:
            conn.execute(f"DELETE FROM photo_species WHERE photo_id IN ({placeholders})", photo_ids)
            rows_to_insert = [
                (pid, cn.strip(), sci.strip(), en.strip(), ord_c.strip(), fam_c.strip(), now)
                for pid in photo_ids
                for (cn, sci, en, ord_c, fam_c) in species_tuples
                if cn.strip()
            ]
            if rows_to_insert:
                conn.executemany(
                    """
                    INSERT OR IGNORE INTO photo_species (
                        photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    rows_to_insert,
                )
            self._sync_primary_species_from_table(conn, photo_ids, now)
        return len(photo_ids)

    def batch_remove_species(self, photo_ids: list[int], common_name_cn: str) -> int:
        """Remove a single species tag from `photo_ids`, keeping any other co-occurring species intact."""
        if not photo_ids or not common_name_cn.strip():
            return 0
        placeholders = ",".join("?" for _ in photo_ids)
        now = _utc_now()
        with self.connect() as conn:
            conn.execute(
                f"DELETE FROM photo_species WHERE common_name_cn = ? AND photo_id IN ({placeholders})",
                [common_name_cn.strip(), *photo_ids],
            )
            self._sync_primary_species_from_table(conn, photo_ids, now)
        return len(photo_ids)

    def batch_update_attributes(
        self,
        photo_ids: list[int],
        *,
        location_name: str | None = None,
        location_province: str | None = None,
        location_city: str | None = None,
        ebird_loc_id: str | None = None,
        set_lat: float | None = None,
        set_lon: float | None = None,
        fallback_lat: float | None = None,
        fallback_lon: float | None = None,
        manual_date: str | None = None,
        rating: int | None = None,
        pick_flag: int | None = None,
        notes: str | None = None,
    ) -> int:
        """Batch-update location (with province/city, eBird ID, exact or fallback GPS), date, rating, flag, or notes."""
        if not photo_ids:
            return 0
        updates: list[str] = []
        params: list[object] = []

        if location_name is not None:
            cleaned_loc = location_name.strip()
            updates.append("location_name = ?")
            params.append(cleaned_loc)
            if not cleaned_loc:
                if ebird_loc_id is None:
                    updates.append("ebird_loc_id = NULL")
                if location_province is None:
                    updates.append("location_province = ''")
                if location_city is None:
                    updates.append("location_city = ''")
        if location_province is not None:
            updates.append("location_province = ?")
            params.append(normalize_province_name(location_province))
        if location_city is not None:
            updates.append("location_city = ?")
            params.append(location_city.strip())
        if ebird_loc_id is not None:
            updates.append("ebird_loc_id = ?")
            params.append(ebird_loc_id.strip() or None)
        if set_lat is not None and set_lon is not None:
            updates.append("gps_lat = ?")
            params.append(set_lat)
            updates.append("gps_lon = ?")
            params.append(set_lon)
        elif fallback_lat is not None and fallback_lon is not None:
            updates.append("gps_lat = COALESCE(gps_lat, ?)")
            params.append(fallback_lat)
            updates.append("gps_lon = COALESCE(gps_lon, ?)")
            params.append(fallback_lon)
        if manual_date is not None:
            cleaned_date = manual_date.strip()
            updates.append("manual_date = ?")
            params.append(cleaned_date or None)
            if cleaned_date:
                updates.append("taken_date = ?")
                params.append(cleaned_date[:10])
        if rating is not None:
            if not 0 <= rating <= 5:
                raise ValueError("rating must be between 0 and 5")
            updates.append("rating = ?")
            params.append(rating)
        if pick_flag is not None:
            updates.append("pick_flag = ?")
            params.append(pick_flag)
            updates.append("is_rejected = ?")
            params.append(1 if pick_flag < 0 else 0)
            if pick_flag < 0:
                updates.append("review_status = 'rejected'")
        if notes is not None:
            updates.append("notes = ?")
            params.append(notes)

        if not updates:
            return 0

        updates.append("updated_at = ?")
        params.append(_utc_now())
        placeholders = ",".join("?" for _ in photo_ids)
        params.extend(photo_ids)

        with self.connect() as conn:
            cur = conn.execute(
                f"UPDATE photos SET {', '.join(updates)} WHERE id IN ({placeholders})",
                params,
            )
            return cur.rowcount

    # ---------------- Undo State Snapshot & Lossless Restore ----------------

    _SNAPSHOT_PHOTO_COLS = (
        "taken_date",
        "manual_date",
        "gps_lat",
        "gps_lon",
        "location_name",
        "location_province",
        "location_city",
        "ebird_loc_id",
        "has_bird",
        "primary_scientific_name",
        "primary_common_name_cn",
        "primary_common_name_en",
        "primary_order_cn",
        "primary_family_cn",
        "review_status",
        "manual_scientific_name",
        "manual_common_name_cn",
        "rating",
        "pick_flag",
        "is_rejected",
        "notes",
    )

    def capture_photos_snapshot(self, photo_ids: list[int]) -> dict[int, dict[str, object]]:
        """Capture complete mutable state (`photos` columns, `photo_species`, `album_photos`) for `photo_ids`."""
        clean_ids = [int(pid) for pid in dict.fromkeys(photo_ids) if pid is not None]
        if not clean_ids:
            return {}

        cols_sql = ", ".join(("id", *self._SNAPSHOT_PHOTO_COLS))
        snap: dict[int, dict[str, object]] = {}

        with self.connect() as conn:
            for start in range(0, len(clean_ids), 800):
                chunk = clean_ids[start : start + 800]
                ph = ",".join("?" for _ in chunk)

                for r in conn.execute(f"SELECT {cols_sql} FROM photos WHERE id IN ({ph})", chunk).fetchall():
                    pid = int(r["id"])
                    snap[pid] = {
                        "cols": {col: r[col] for col in self._SNAPSHOT_PHOTO_COLS},
                        "species": [],
                        "albums": [],
                    }

                for sr in conn.execute(
                    f"SELECT photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at "
                    f"FROM photo_species WHERE photo_id IN ({ph}) ORDER BY id ASC",
                    chunk,
                ).fetchall():
                    pid = int(sr["photo_id"])
                    if pid in snap:
                        snap[pid]["species"].append(  # type: ignore[attr-defined]
                            (
                                str(sr["common_name_cn"]),
                                str(sr["scientific_name"]),
                                str(sr["common_name_en"]),
                                str(sr["order_cn"]),
                                str(sr["family_cn"]),
                                str(sr["added_at"]),
                            )
                        )

                for ar in conn.execute(
                    f"SELECT photo_id, album_id, added_at FROM album_photos WHERE photo_id IN ({ph}) ORDER BY album_id ASC",
                    chunk,
                ).fetchall():
                    pid = int(ar["photo_id"])
                    if pid in snap:
                        snap[pid]["albums"].append((int(ar["album_id"]), str(ar["added_at"])))  # type: ignore[attr-defined]

        return snap

    def restore_photos_snapshot(
        self,
        snapshot: dict[int, dict[str, object]],
        *,
        delete_album_id: int | None = None,
    ) -> list[int]:
        """Atomically restore `photos`, `photo_species`, and `album_photos` from `capture_photos_snapshot`."""
        now = _utc_now()
        restored_ids: list[int] = []
        set_clause = ", ".join(f"{col} = ?" for col in self._SNAPSHOT_PHOTO_COLS) + ", updated_at = ?"

        with self.connect() as conn:
            if delete_album_id is not None:
                conn.execute("DELETE FROM albums WHERE id = ?", (int(delete_album_id),))

            valid_album_ids = {
                int(r["id"]) for r in conn.execute("SELECT id FROM albums").fetchall()
            }

            for pid, state in snapshot.items():
                cols_map: dict[str, object] = state["cols"]  # type: ignore[assignment]
                sp_rows: list[tuple[str, str, str, str, str, str]] = state["species"]  # type: ignore[assignment]
                alb_rows: list[tuple[int, str]] = state["albums"]  # type: ignore[assignment]

                params = [cols_map[col] for col in self._SNAPSHOT_PHOTO_COLS] + [now, int(pid)]
                cur = conn.execute(f"UPDATE photos SET {set_clause} WHERE id = ?", params)
                if cur.rowcount == 0:
                    continue
                restored_ids.append(int(pid))

                conn.execute("DELETE FROM photo_species WHERE photo_id = ?", (int(pid),))
                if sp_rows:
                    conn.executemany(
                        """
                        INSERT OR IGNORE INTO photo_species (
                            photo_id, common_name_cn, scientific_name, common_name_en, order_cn, family_cn, added_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        [(int(pid), *t) for t in sp_rows],
                    )

                conn.execute("DELETE FROM album_photos WHERE photo_id = ?", (int(pid),))
                kept_alb_rows = [(aid, int(pid), added) for (aid, added) in alb_rows if aid in valid_album_ids]
                if kept_alb_rows:
                    conn.executemany(
                        "INSERT OR IGNORE INTO album_photos (album_id, photo_id, added_at) VALUES (?, ?, ?)",
                        kept_alb_rows,
                    )

        return restored_ids

    # ---------------- Watched Folders & Aggregations ----------------

    def add_watched_folder(self, folder_path: str | Path) -> None:
        norm = str(Path(folder_path).resolve())
        with self.connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO watched_folders (folder_path, added_at) VALUES (?, ?)",
                (norm, _utc_now()),
            )

    def list_watched_folders(self) -> list[str]:
        with self.connect() as conn:
            rows = conn.execute("SELECT folder_path FROM watched_folders ORDER BY folder_path ASC").fetchall()
            return [str(r["folder_path"]) for r in rows]

    def get_folder_counts(self) -> list[tuple[str, int]]:
        """Return [(folder_path, photo_count)] for all non-rejected photos."""
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT folder_path, COUNT(*) AS cnt
                FROM photos
                WHERE is_rejected = 0 AND folder_path != ''
                GROUP BY folder_path
                ORDER BY folder_path ASC
                """
            ).fetchall()
            return [(str(r["folder_path"]), int(r["cnt"])) for r in rows]

    def get_date_counts(self) -> list[tuple[str, int]]:
        """Return [(YYYY-MM-DD, photo_count)] ordered newest first."""
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT COALESCE(taken_date, '') AS d, COUNT(*) AS cnt
                FROM photos
                WHERE is_rejected = 0
                GROUP BY d
                ORDER BY d DESC
                """
            ).fetchall()
            return [(str(r["d"]), int(r["cnt"])) for r in rows]

    def get_location_counts(self) -> list[tuple[str, int]]:
        """Return [(location_label, photo_count)] merging named spots and unnamed GPS buckets."""
        counts: dict[str, int] = {}
        unlocated = 0
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT location_name, gps_lat, gps_lon
                FROM photos
                WHERE is_rejected = 0
                """
            ).fetchall()
            for r in rows:
                loc = str(r["location_name"] or "").strip()
                if loc:
                    counts[loc] = counts.get(loc, 0) + 1
                elif r["gps_lat"] is not None and r["gps_lon"] is not None:
                    bucket = format_gps_bucket(float(r["gps_lat"]), float(r["gps_lon"]))
                    counts[bucket] = counts.get(bucket, 0) + 1
                else:
                    unlocated += 1

        sorted_items = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
        if unlocated > 0:
            sorted_items.append(("__unlocated__", unlocated))
        return sorted_items

    def get_location_hierarchy(
        self,
    ) -> tuple[list[tuple[str, int, list[tuple[str, int, list[tuple[str, str, int, str | None, bool]]]]]], int]:
        """Build Province -> Prefecture/City -> Spot hierarchy merging active photos and FavoriteLocations."""
        favs = self.list_favorite_locations()
        fav_by_name = {f.name: f for f in favs}

        # (prov, city) -> {loc_key: [disp_label, count, ebird_id]}
        spot_map: dict[tuple[str, str], dict[str, list[object]]] = {}
        shown_fav_names: set[str] = set()
        unlocated = 0

        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT location_name, location_province, location_city, ebird_loc_id, gps_lat, gps_lon
                FROM photos
                WHERE is_rejected = 0
                """
            ).fetchall()

        for r in rows:
            loc = str(r["location_name"] or "").strip()
            p_prov = str(r["location_province"] or "").strip()
            p_city = str(r["location_city"] or "").strip()
            p_lid = str(r["ebird_loc_id"]) if r["ebird_loc_id"] else None
            lat = float(r["gps_lat"]) if r["gps_lat"] is not None else None
            lon = float(r["gps_lon"]) if r["gps_lon"] is not None else None

            if loc:
                loc_key = loc
                disp = loc
                fav = fav_by_name.get(loc)
                if fav is not None:
                    shown_fav_names.add(fav.name)
                    p_prov = p_prov or fav.province
                    p_city = p_city or fav.city
                    p_lid = p_lid or fav.ebird_loc_id
                if not p_prov:
                    inf_p, inf_c = infer_province_city(lat, lon, text_hint=loc)
                    p_prov = inf_p
                    p_city = p_city or inf_c
            elif lat is not None and lon is not None:
                loc_key = format_gps_bucket(lat, lon)
                disp = loc_key
                if not p_prov:
                    inf_p, inf_c = infer_province_city(lat, lon)
                    p_prov = inf_p
                    p_city = p_city or inf_c
            else:
                unlocated += 1
                continue

            prov_key = p_prov or "其他地区"
            city_key = p_city or "未分地市"
            bucket = spot_map.setdefault((prov_key, city_key), {})
            if loc_key not in bucket:
                bucket[loc_key] = [disp, 1, p_lid, loc_key in fav_by_name]
            else:
                bucket[loc_key][1] = int(bucket[loc_key][1]) + 1  # type: ignore[arg-type]
                if not bucket[loc_key][2] and p_lid:
                    bucket[loc_key][2] = p_lid

        # Also include configured FavoriteLocations with 0 photos so they appear under their Province > City
        for fav in favs:
            if fav.name in shown_fav_names:
                continue
            inf_p, inf_c = infer_province_city(fav.lat, fav.lng, text_hint=f"{fav.region} {fav.name}")
            prov_key = fav.province or inf_p or "其他地区"
            city_key = fav.city or inf_c or "未分地市"
            bucket = spot_map.setdefault((prov_key, city_key), {})
            if fav.name not in bucket:
                bucket[fav.name] = [fav.name, 0, fav.ebird_loc_id, True]

        # Assemble nested Province -> City -> Spots
        prov_cities: dict[str, list[tuple[str, int, list[tuple[str, str, int, str | None, bool]]]]] = {}
        prov_totals: dict[str, int] = {}

        for (prov_key, city_key), spots_dict in spot_map.items():
            spot_tuples: list[tuple[str, str, int, str | None, bool]] = [
                (
                    k,
                    str(v[0]),
                    int(v[1]),  # type: ignore[arg-type]
                    str(v[2]) if v[2] else None,
                    bool(v[3]),
                )
                for k, v in spots_dict.items()
            ]
            spot_tuples.sort(key=lambda x: (not x[4], -x[2], x[1]))
            city_cnt = sum(x[2] for x in spot_tuples)
            prov_cities.setdefault(prov_key, []).append((city_key, city_cnt, spot_tuples))
            prov_totals[prov_key] = prov_totals.get(prov_key, 0) + city_cnt

        out_tree: list[tuple[str, int, list[tuple[str, int, list[tuple[str, str, int, str | None, bool]]]]]] = []
        for prov_key, c_list in prov_cities.items():
            c_list.sort(key=lambda x: (x[0] == "未分地市", -x[1], x[0]))
            out_tree.append((prov_key, prov_totals[prov_key], c_list))

        out_tree.sort(key=lambda x: (x[0] == "其他地区", -x[1], x[0]))
        return out_tree, unlocated

    def list_distinct_location_names(self) -> list[str]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT location_name FROM photos WHERE location_name != '' ORDER BY location_name ASC"
            ).fetchall()
            return [str(r["location_name"]) for r in rows]

    # ---------------- App Settings, Favorite Locations & eBird Hotspots ----------------

    def get_setting(self, key: str, default: str = "") -> str:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
            return str(row["value"]) if row is not None else default

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO app_settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )

    def upsert_favorite_location(
        self,
        name: str,
        *,
        fav_id: int | None = None,
        province: str = "",
        city: str = "",
        region: str = "",
        ebird_loc_id: str | None = None,
        ebird_loc_name: str = "",
        lat: float | None = None,
        lng: float | None = None,
        notes: str = "",
        sort_order: int = 0,
    ) -> FavoriteLocation:
        cleaned = name.strip()
        if not cleaned:
            raise ValueError("常用地点名称不能为空")
        now = _utc_now()
        loc_id_clean = (ebird_loc_id or "").strip() or None

        prov_clean = normalize_province_name(province) if province.strip() else ""
        city_clean = city.strip()
        if not prov_clean or not city_clean:
            inf_p, inf_c = infer_province_city(
                lat,
                lng,
                text_hint=f"{region} {cleaned} {ebird_loc_name}",
            )
            prov_clean = prov_clean or inf_p
            city_clean = city_clean or inf_c

        region_clean = region.strip() or format_province_city(prov_clean, city_clean)

        with self.connect() as conn:
            if fav_id is not None:
                conn.execute(
                    """
                    UPDATE favorite_locations SET
                        name = ?, province = ?, city = ?, region = ?, ebird_loc_id = ?, ebird_loc_name = ?,
                        lat = ?, lng = ?, notes = ?, sort_order = ?
                    WHERE id = ?
                    """,
                    (
                        cleaned,
                        prov_clean,
                        city_clean,
                        region_clean,
                        loc_id_clean,
                        ebird_loc_name.strip(),
                        lat,
                        lng,
                        notes.strip(),
                        sort_order,
                        fav_id,
                    ),
                )
                row = conn.execute("SELECT * FROM favorite_locations WHERE id = ?", (fav_id,)).fetchone()
            else:
                conn.execute(
                    """
                    INSERT INTO favorite_locations (
                        name, province, city, region, ebird_loc_id, ebird_loc_name, lat, lng, notes, sort_order, use_count, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                    ON CONFLICT(name) DO UPDATE SET
                        province = CASE WHEN excluded.province != '' THEN excluded.province ELSE favorite_locations.province END,
                        city = CASE WHEN excluded.city != '' THEN excluded.city ELSE favorite_locations.city END,
                        region = CASE WHEN excluded.region != '' THEN excluded.region ELSE favorite_locations.region END,
                        ebird_loc_id = COALESCE(excluded.ebird_loc_id, favorite_locations.ebird_loc_id),
                        ebird_loc_name = CASE WHEN excluded.ebird_loc_name != '' THEN excluded.ebird_loc_name ELSE favorite_locations.ebird_loc_name END,
                        lat = COALESCE(excluded.lat, favorite_locations.lat),
                        lng = COALESCE(excluded.lng, favorite_locations.lng),
                        notes = CASE WHEN excluded.notes != '' THEN excluded.notes ELSE favorite_locations.notes END
                    """,
                    (
                        cleaned,
                        prov_clean,
                        city_clean,
                        region_clean,
                        loc_id_clean,
                        ebird_loc_name.strip(),
                        lat,
                        lng,
                        notes.strip(),
                        sort_order,
                        now,
                    ),
                )
                row = conn.execute("SELECT * FROM favorite_locations WHERE name = ?", (cleaned,)).fetchone()

            assert row is not None
            return self._row_to_favorite_location(row)

    def delete_favorite_location(self, fav_id: int) -> bool:
        with self.connect() as conn:
            cur = conn.execute("DELETE FROM favorite_locations WHERE id = ?", (fav_id,))
            return cur.rowcount > 0

    def increment_favorite_location_use(self, name: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE favorite_locations SET use_count = use_count + 1 WHERE name = ?",
                (name.strip(),),
            )

    def get_favorite_location_by_name(self, name: str) -> FavoriteLocation | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM favorite_locations WHERE name = ?", (name.strip(),)).fetchone()
            return self._row_to_favorite_location(row) if row is not None else None

    def list_favorite_locations(self) -> list[FavoriteLocation]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM favorite_locations ORDER BY sort_order ASC, use_count DESC, id ASC"
            ).fetchall()
            return [self._row_to_favorite_location(r) for r in rows]

    @staticmethod
    def _row_to_favorite_location(row: sqlite3.Row) -> FavoriteLocation:
        keys = row.keys()
        return FavoriteLocation(
            fav_id=int(row["id"]),
            name=str(row["name"]),
            province=str(row["province"] or "") if "province" in keys else "",
            city=str(row["city"] or "") if "city" in keys else "",
            region=str(row["region"] or ""),
            ebird_loc_id=str(row["ebird_loc_id"]) if row["ebird_loc_id"] else None,
            ebird_loc_name=str(row["ebird_loc_name"] or ""),
            lat=float(row["lat"]) if row["lat"] is not None else None,
            lng=float(row["lng"]) if row["lng"] is not None else None,
            notes=str(row["notes"] or ""),
            sort_order=int(row["sort_order"] or 0),
            use_count=int(row["use_count"] or 0),
            created_at=str(row["created_at"] or ""),
        )

    def upsert_ebird_hotspots(self, hotspots: list[EBirdHotspot]) -> int:
        if not hotspots:
            return 0
        now = _utc_now()
        with self.connect() as conn:
            conn.executemany(
                """
                INSERT INTO ebird_hotspots (
                    loc_id, loc_name, country_code, subnational1_code, subnational2_code, city_name,
                    lat, lng, num_species, latest_obs_dt,
                    pinyin_initials, pinyin_full, synced_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(loc_id) DO UPDATE SET
                    loc_name = excluded.loc_name,
                    country_code = excluded.country_code,
                    subnational1_code = excluded.subnational1_code,
                    subnational2_code = CASE WHEN excluded.subnational2_code != '' THEN excluded.subnational2_code ELSE ebird_hotspots.subnational2_code END,
                    city_name = CASE WHEN excluded.city_name != '' THEN excluded.city_name ELSE ebird_hotspots.city_name END,
                    lat = excluded.lat,
                    lng = excluded.lng,
                    num_species = MAX(ebird_hotspots.num_species, excluded.num_species),
                    latest_obs_dt = CASE WHEN excluded.latest_obs_dt != '' THEN excluded.latest_obs_dt ELSE ebird_hotspots.latest_obs_dt END,
                    pinyin_initials = excluded.pinyin_initials,
                    pinyin_full = excluded.pinyin_full,
                    synced_at = excluded.synced_at
                """,
                [
                    (
                        h.loc_id,
                        h.loc_name,
                        h.country_code,
                        h.subnational1_code,
                        h.subnational2_code,
                        h.city_name,
                        h.lat,
                        h.lng,
                        h.num_species,
                        h.latest_obs_dt,
                        h.pinyin_initials,
                        h.pinyin_full,
                        now,
                    )
                    for h in hotspots
                ],
            )
        return len(hotspots)

    def count_ebird_hotspots(self) -> int:
        with self.connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS cnt FROM ebird_hotspots").fetchone()
            return int(row["cnt"] or 0) if row else 0

    def get_ebird_hotspot(self, loc_id: str) -> EBirdHotspot | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM ebird_hotspots WHERE loc_id = ?", (loc_id.strip(),)).fetchone()
            return self._row_to_ebird_hotspot(row) if row is not None else None

    def load_all_ebird_hotspots(self, region_prefix: str = "") -> list[EBirdHotspot]:
        with self.connect() as conn:
            if region_prefix.strip():
                rp = region_prefix.strip().upper()
                rows = conn.execute(
                    "SELECT * FROM ebird_hotspots WHERE country_code = ? OR subnational1_code LIKE ? ORDER BY num_species DESC",
                    (rp, f"{rp}%"),
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM ebird_hotspots ORDER BY num_species DESC").fetchall()
            return [self._row_to_ebird_hotspot(r) for r in rows]

    @staticmethod
    def _row_to_ebird_hotspot(row: sqlite3.Row) -> EBirdHotspot:
        keys = row.keys()
        return EBirdHotspot(
            loc_id=str(row["loc_id"]),
            loc_name=str(row["loc_name"]),
            country_code=str(row["country_code"] or ""),
            subnational1_code=str(row["subnational1_code"] or ""),
            subnational2_code=str(row["subnational2_code"] or "") if "subnational2_code" in keys else "",
            city_name=str(row["city_name"] or "") if "city_name" in keys else "",
            lat=float(row["lat"]) if row["lat"] is not None else None,
            lng=float(row["lng"]) if row["lng"] is not None else None,
            num_species=int(row["num_species"] or 0),
            latest_obs_dt=str(row["latest_obs_dt"] or ""),
            pinyin_initials=str(row["pinyin_initials"] or ""),
            pinyin_full=str(row["pinyin_full"] or ""),
        )

    # ---------------- Personal Birding Checklists (BirdReport.cn / eBird / CSV) ----------------

    def upsert_checklist(
        self,
        obs_date: str,
        items: list[ChecklistItem],
        *,
        checklist_id: int | None = None,
        obs_time: str = "",
        source: str = "birdreport",
        external_id: str = "",
        location_name: str = "",
        province: str = "",
        city: str = "",
        ebird_loc_id: str | None = None,
        lat: float | None = None,
        lng: float | None = None,
        notes: str = "",
        merge_same_date_loc: bool = True,
    ) -> BirdingChecklist:
        """Insert or update a personal birding checklist and its species items."""
        date_clean = obs_date.strip()[:10]
        if not date_clean:
            raise ValueError("观测日期不能为空 (格式 YYYY-MM-DD)")

        # Deduplicate items by Chinese species name while summing/preserving counts
        merged_items: dict[str, ChecklistItem] = {}
        for it in items:
            cn = it.common_name_cn.strip()
            if not cn:
                continue
            if cn not in merged_items:
                merged_items[cn] = ChecklistItem(
                    common_name_cn=cn,
                    scientific_name=it.scientific_name.strip(),
                    count_num=max(0, int(it.count_num)),
                    count_str=it.count_str.strip() or str(max(1, int(it.count_num))),
                    remarks=it.remarks.strip(),
                )
            else:
                prev = merged_items[cn]
                new_cnt = prev.count_num + max(0, int(it.count_num))
                prev.count_num = new_cnt
                prev.count_str = str(new_cnt) if new_cnt > 0 else prev.count_str
                if not prev.scientific_name and it.scientific_name:
                    prev.scientific_name = it.scientific_name.strip()
                if it.remarks and it.remarks not in prev.remarks:
                    prev.remarks = f"{prev.remarks}; {it.remarks}".strip("; ")

        dedup_list = list(merged_items.values())
        loc_clean = location_name.strip()
        prov_clean = normalize_province_name(province) if province.strip() else ""
        city_clean = city.strip()
        if not prov_clean or not city_clean:
            inf_p, inf_c = infer_province_city(lat, lng, text_hint=loc_clean)
            prov_clean = prov_clean or inf_p
            city_clean = city_clean or inf_c

        ext_clean = external_id.strip()
        lid_clean = (ebird_loc_id or "").strip() or None
        now = _utc_now()

        with self.connect() as conn:
            target_id = checklist_id
            if target_id is None and ext_clean:
                row_ext = conn.execute(
                    "SELECT id FROM birding_checklists WHERE source = ? AND external_id = ?",
                    (source.strip(), ext_clean),
                ).fetchone()
                if row_ext is not None:
                    target_id = int(row_ext["id"])

            if target_id is None and merge_same_date_loc and not ext_clean:
                row_dl = conn.execute(
                    "SELECT id FROM birding_checklists WHERE obs_date = ? AND location_name = ? AND source = ?",
                    (date_clean, loc_clean, source.strip()),
                ).fetchone()
                if row_dl is not None:
                    target_id = int(row_dl["id"])

            if target_id is not None:
                conn.execute(
                    """
                    UPDATE birding_checklists SET
                        obs_date = ?, obs_time = ?, source = ?, external_id = ?,
                        location_name = ?, province = ?, city = ?, ebird_loc_id = COALESCE(?, ebird_loc_id),
                        lat = COALESCE(?, lat), lng = COALESCE(?, lng),
                        species_count = ?, notes = CASE WHEN ? != '' THEN ? ELSE notes END
                    WHERE id = ?
                    """,
                    (
                        date_clean,
                        obs_time.strip(),
                        source.strip(),
                        ext_clean,
                        loc_clean,
                        prov_clean,
                        city_clean,
                        lid_clean,
                        lat,
                        lng,
                        len(dedup_list),
                        notes.strip(),
                        notes.strip(),
                        target_id,
                    ),
                )
                conn.execute("DELETE FROM birding_checklist_items WHERE checklist_id = ?", (target_id,))
            else:
                cur = conn.execute(
                    """
                    INSERT INTO birding_checklists (
                        obs_date, obs_time, source, external_id,
                        location_name, province, city, ebird_loc_id,
                        lat, lng, species_count, notes, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        date_clean,
                        obs_time.strip(),
                        source.strip(),
                        ext_clean,
                        loc_clean,
                        prov_clean,
                        city_clean,
                        lid_clean,
                        lat,
                        lng,
                        len(dedup_list),
                        notes.strip(),
                        now,
                    ),
                )
                target_id = int(cur.lastrowid)

            if dedup_list:
                conn.executemany(
                    """
                    INSERT INTO birding_checklist_items (
                        checklist_id, common_name_cn, scientific_name, count_num, count_str, remarks
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            target_id,
                            it.common_name_cn,
                            it.scientific_name,
                            it.count_num,
                            it.count_str,
                            it.remarks,
                        )
                        for it in dedup_list
                    ],
                )

            row_out = conn.execute("SELECT * FROM birding_checklists WHERE id = ?", (target_id,)).fetchone()
            assert row_out is not None
            cl = self._row_to_checklist(row_out)
            cl.items = dedup_list
            return cl

    def get_checklist(self, checklist_id: int) -> BirdingChecklist | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM birding_checklists WHERE id = ?", (checklist_id,)).fetchone()
            if row is None:
                return None
            cl = self._row_to_checklist(row)
            cl.items = self._load_checklist_items(conn, cl.checklist_id)
            return cl

    def list_checklists(
        self,
        *,
        obs_date: str = "",
        keyword: str = "",
        include_items: bool = False,
        limit: int = 500,
    ) -> list[BirdingChecklist]:
        with self.connect() as conn:
            if obs_date.strip():
                rows = conn.execute(
                    "SELECT * FROM birding_checklists WHERE obs_date = ? ORDER BY obs_time DESC, id DESC LIMIT ?",
                    (obs_date.strip()[:10], limit),
                ).fetchall()
            elif keyword.strip():
                kw = f"%{keyword.strip()}%"
                rows = conn.execute(
                    """
                    SELECT * FROM birding_checklists
                    WHERE obs_date LIKE ?
                       OR location_name LIKE ?
                       OR province LIKE ?
                       OR city LIKE ?
                       OR external_id LIKE ?
                    ORDER BY obs_date DESC, obs_time DESC, id DESC
                    LIMIT ?
                    """,
                    (kw, kw, kw, kw, kw, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM birding_checklists ORDER BY obs_date DESC, obs_time DESC, id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            out = [self._row_to_checklist(r) for r in rows]
            if include_items:
                for cl in out:
                    cl.items = self._load_checklist_items(conn, cl.checklist_id)
            return out

    def count_checklists(self) -> int:
        with self.connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS cnt FROM birding_checklists").fetchone()
            return int(row["cnt"] or 0) if row else 0

    def delete_checklist(self, checklist_id: int) -> bool:
        return self.delete_checklists([checklist_id]) > 0

    def delete_checklists(self, checklist_ids: list[int]) -> int:
        """Batch-delete multiple birding checklists (and cascade-delete their species items) in one transaction."""
        unique_ids = list(dict.fromkeys(int(cid) for cid in checklist_ids if cid is not None))
        if not unique_ids:
            return 0
        deleted = 0
        with self.connect() as conn:
            for start in range(0, len(unique_ids), 500):
                chunk = unique_ids[start : start + 500]
                placeholders = ",".join("?" for _ in chunk)
                conn.execute(
                    f"DELETE FROM birding_checklist_items WHERE checklist_id IN ({placeholders})",
                    chunk,
                )
                cur = conn.execute(
                    f"DELETE FROM birding_checklists WHERE id IN ({placeholders})",
                    chunk,
                )
                deleted += max(0, cur.rowcount)
        return deleted

    def clear_all_checklists(self) -> int:
        """Delete all saved personal birding checklists in one transaction."""
        with self.connect() as conn:
            conn.execute("DELETE FROM birding_checklist_items")
            cur = conn.execute("DELETE FROM birding_checklists")
            return max(0, cur.rowcount)

    def get_checklist_species_for_date(
        self,
        obs_date: str,
        *,
        preferred_location: str = "",
    ) -> tuple[list[BirdingChecklist], list[ChecklistItem]]:
        """Return `(checklists_on_date, deduplicated_priority_items)` for a photo's `YYYY-MM-DD` date."""
        d = obs_date.strip()[:10]
        if not d:
            return [], []
        checklists = self.list_checklists(obs_date=d, include_items=True)
        if not checklists:
            return [], []

        pref = preferred_location.strip().lower()
        if pref:
            checklists.sort(
                key=lambda c: (
                    0 if (c.location_name and (pref in c.location_name.lower() or c.location_name.lower() in pref)) else 1,
                    -c.species_count,
                )
            )

        merged: dict[str, ChecklistItem] = {}
        order_keys: list[str] = []
        for cl in checklists:
            for it in cl.items:
                if it.common_name_cn not in merged:
                    merged[it.common_name_cn] = ChecklistItem(
                        common_name_cn=it.common_name_cn,
                        scientific_name=it.scientific_name,
                        count_num=it.count_num,
                        count_str=it.count_str,
                        remarks=it.remarks,
                    )
                    order_keys.append(it.common_name_cn)
                else:
                    existing = merged[it.common_name_cn]
                    if it.count_num > 0:
                        existing.count_num += it.count_num
                        existing.count_str = str(existing.count_num)

        return checklists, [merged[k] for k in order_keys]

    @staticmethod
    def _load_checklist_items(conn: sqlite3.Connection, checklist_id: int) -> list[ChecklistItem]:
        rows = conn.execute(
            "SELECT * FROM birding_checklist_items WHERE checklist_id = ? ORDER BY count_num DESC, id ASC",
            (checklist_id,),
        ).fetchall()
        return [
            ChecklistItem(
                common_name_cn=str(r["common_name_cn"]),
                scientific_name=str(r["scientific_name"] or ""),
                count_num=int(r["count_num"] or 0),
                count_str=str(r["count_str"] or ""),
                remarks=str(r["remarks"] or ""),
            )
            for r in rows
        ]

    @staticmethod
    def _row_to_checklist(row: sqlite3.Row) -> BirdingChecklist:
        return BirdingChecklist(
            checklist_id=int(row["id"]),
            obs_date=str(row["obs_date"]),
            obs_time=str(row["obs_time"] or ""),
            source=str(row["source"] or "birdreport"),
            external_id=str(row["external_id"] or ""),
            location_name=str(row["location_name"] or ""),
            province=str(row["province"] or ""),
            city=str(row["city"] or ""),
            ebird_loc_id=str(row["ebird_loc_id"]) if row["ebird_loc_id"] else None,
            lat=float(row["lat"]) if row["lat"] is not None else None,
            lng=float(row["lng"]) if row["lng"] is not None else None,
            species_count=int(row["species_count"] or 0),
            notes=str(row["notes"] or ""),
            created_at=str(row["created_at"] or ""),
        )

    # ---------------- Custom Virtual Albums (Many-to-Many) ----------------

    def create_album(self, name: str, description: str = "") -> Album:
        cleaned = name.strip()
        if not cleaned:
            raise ValueError("Album name cannot be empty")
        now = _utc_now()
        with self.connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO albums (name, description, created_at) VALUES (?, ?, ?)",
                (cleaned, description.strip(), now),
            )
            row = conn.execute("SELECT * FROM albums WHERE name = ?", (cleaned,)).fetchone()
            assert row is not None
            cnt = conn.execute(
                "SELECT COUNT(*) AS c FROM album_photos ap JOIN photos p ON p.id = ap.photo_id "
                "WHERE ap.album_id = ? AND p.is_rejected = 0",
                (row["id"],),
            ).fetchone()
            return Album(
                album_id=int(row["id"]),
                name=str(row["name"]),
                description=str(row["description"]),
                photo_count=int(cnt["c"] or 0),
                created_at=str(row["created_at"]),
            )

    def rename_album(self, album_id: int, new_name: str) -> bool:
        cleaned = new_name.strip()
        if not cleaned:
            raise ValueError("Album name cannot be empty")
        with self.connect() as conn:
            cur = conn.execute("UPDATE albums SET name = ? WHERE id = ?", (cleaned, album_id))
            return cur.rowcount > 0

    def delete_album(self, album_id: int) -> bool:
        with self.connect() as conn:
            cur = conn.execute("DELETE FROM albums WHERE id = ?", (album_id,))
            return cur.rowcount > 0

    def list_albums(self) -> list[Album]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT
                    a.id, a.name, a.description, a.created_at,
                    COUNT(CASE WHEN p.id IS NOT NULL AND p.is_rejected = 0 THEN 1 END) AS photo_count
                FROM albums a
                LEFT JOIN album_photos ap ON ap.album_id = a.id
                LEFT JOIN photos p ON p.id = ap.photo_id
                GROUP BY a.id
                ORDER BY a.name ASC
                """
            ).fetchall()
            return [
                Album(
                    album_id=int(r["id"]),
                    name=str(r["name"]),
                    description=str(r["description"]),
                    photo_count=int(r["photo_count"] or 0),
                    created_at=str(r["created_at"]),
                )
                for r in rows
            ]

    def add_photos_to_album(self, album_id: int, photo_ids: list[int]) -> int:
        if not photo_ids:
            return 0
        now = _utc_now()
        with self.connect() as conn:
            cur = conn.executemany(
                "INSERT OR IGNORE INTO album_photos (album_id, photo_id, added_at) VALUES (?, ?, ?)",
                [(album_id, pid, now) for pid in photo_ids],
            )
            return cur.rowcount

    def remove_photos_from_album(self, album_id: int, photo_ids: list[int]) -> int:
        if not photo_ids:
            return 0
        placeholders = ",".join("?" for _ in photo_ids)
        with self.connect() as conn:
            cur = conn.execute(
                f"DELETE FROM album_photos WHERE album_id = ? AND photo_id IN ({placeholders})",
                [album_id, *photo_ids],
            )
            return cur.rowcount

    def get_album_membership_counts(self, photo_ids: list[int]) -> dict[int, int]:
        """For a selection of photos, return {album_id: count_of_selected_photos_in_album}."""
        if not photo_ids:
            return {}
        placeholders = ",".join("?" for _ in photo_ids)
        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT album_id, COUNT(*) AS cnt FROM album_photos WHERE photo_id IN ({placeholders}) GROUP BY album_id",
                photo_ids,
            ).fetchall()
            return {int(r["album_id"]): int(r["cnt"]) for r in rows}

    # ---------------- Stats & Species Breakdown ----------------

    def get_photographed_species_summary(self) -> list[dict[str, object]]:
        """Return every photographed bird species (including multi-species co-occurrences) with photo count & cover."""
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT
                    p.id AS id,
                    p.file_path AS file_path,
                    p.thumbnail_path AS thumbnail_path,
                    p.taken_date AS taken_date,
                    p.rating AS rating,
                    p.pick_flag AS pick_flag,
                    p.best_sharpness AS best_sharpness,
                    ps.common_name_cn AS species_cn,
                    ps.scientific_name AS scientific_name,
                    ps.common_name_en AS primary_common_name_en,
                    ps.order_cn AS primary_order_cn,
                    ps.family_cn AS primary_family_cn
                FROM photo_species ps
                JOIN photos p ON p.id = ps.photo_id
                WHERE p.is_rejected = 0 AND ps.common_name_cn != ''
                ORDER BY p.rating DESC, p.pick_flag DESC, p.best_sharpness DESC, p.id ASC
                """
            ).fetchall()

        grouped: dict[str, dict[str, object]] = {}
        for r in rows:
            sp_cn = str(r["species_cn"])
            if sp_cn not in grouped:
                grouped[sp_cn] = {
                    "species_cn": sp_cn,
                    "scientific_name": str(r["scientific_name"] or ""),
                    "common_name_en": str(r["primary_common_name_en"] or ""),
                    "order_cn": str(r["primary_order_cn"] or ""),
                    "family_cn": str(r["primary_family_cn"] or ""),
                    "photo_count": 1,
                    "cover_photo_id": int(r["id"]),
                    "cover_thumbnail_path": r["thumbnail_path"],
                    "cover_file_path": r["file_path"],
                    "first_seen_date": r["taken_date"],
                }
            else:
                entry = grouped[sp_cn]
                entry["photo_count"] = int(entry["photo_count"]) + 1  # type: ignore[arg-type]
                td = r["taken_date"]
                if td and (not entry["first_seen_date"] or str(td) < str(entry["first_seen_date"])):
                    entry["first_seen_date"] = td

        return list(grouped.values())

    def get_stats(self) -> dict[str, object]:
        """Return gallery-wide summary metrics and top species breakdown."""
        with self.connect() as conn:
            totals = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_photos,
                    SUM(CASE WHEN is_rejected = 0 THEN 1 ELSE 0 END) AS active_photos,
                    SUM(CASE WHEN has_bird = 1 AND is_rejected = 0 THEN 1 ELSE 0 END) AS with_birds,
                    SUM(CASE WHEN has_bird = 0 AND is_rejected = 0 THEN 1 ELSE 0 END) AS no_birds,
                    SUM(CASE WHEN is_rejected = 0 AND COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), NULLIF(manual_scientific_name, ''), NULLIF(primary_scientific_name, '')) IS NULL THEN 1 ELSE 0 END) AS unassigned_photos,
                    SUM(is_raw) AS raw_photos,
                    SUM(is_blurry) AS blurry_photos,
                    SUM(is_rejected) AS rejected_photos,
                    SUM(CASE WHEN pick_flag = 1 AND is_rejected = 0 THEN 1 ELSE 0 END) AS picked_photos,
                    SUM(CASE WHEN review_status = 'unreviewed' THEN 1 ELSE 0 END) AS unreviewed,
                    SUM(CASE WHEN review_status IN ('confirmed', 'corrected') THEN 1 ELSE 0 END) AS reviewed_ok,
                    SUM(CASE WHEN rating >= 3 AND is_rejected = 0 THEN 1 ELSE 0 END) AS starred_3plus
                FROM photos
                """
            ).fetchone()

            species_rows = conn.execute(
                """
                SELECT
                    COALESCE(NULLIF(manual_common_name_cn, ''), NULLIF(primary_common_name_cn, ''), NULLIF(manual_scientific_name, ''), NULLIF(primary_scientific_name, ''), '未知鸟种') AS species_cn,
                    COALESCE(NULLIF(manual_scientific_name, ''), primary_scientific_name) AS scientific_name,
                    COUNT(*) AS photo_count,
                    ROUND(AVG(primary_confidence), 4) AS avg_conf,
                    ROUND(MAX(best_sharpness), 2) AS max_sharpness
                FROM photos
                WHERE has_bird = 1 AND is_rejected = 0
                GROUP BY species_cn, scientific_name
                ORDER BY photo_count DESC, avg_conf DESC
                LIMIT 50
                """
            ).fetchall()

        return {
            "total_photos": int(totals["total_photos"] or 0),
            "active_photos": int(totals["active_photos"] or 0),
            "with_birds": int(totals["with_birds"] or 0),
            "no_birds": int(totals["no_birds"] or 0),
            "unassigned_photos": int(totals["unassigned_photos"] or 0),
            "raw_photos": int(totals["raw_photos"] or 0),
            "blurry_photos": int(totals["blurry_photos"] or 0),
            "rejected_photos": int(totals["rejected_photos"] or 0),
            "picked_photos": int(totals["picked_photos"] or 0),
            "unreviewed": int(totals["unreviewed"] or 0),
            "reviewed_ok": int(totals["reviewed_ok"] or 0),
            "starred_3plus": int(totals["starred_3plus"] or 0),
            "species_breakdown": [dict(r) for r in species_rows],
        }

    def _load_detections(self, conn: sqlite3.Connection, photo_id: int) -> list[BirdDetection]:
        det_rows = conn.execute(
            "SELECT * FROM detections WHERE photo_id = ? ORDER BY detect_conf DESC, id ASC",
            (photo_id,),
        ).fetchall()
        detections: list[BirdDetection] = []
        for d in det_rows:
            pred_rows = conn.execute(
                "SELECT * FROM species_predictions WHERE detection_id = ? ORDER BY rank ASC",
                (d["id"],),
            ).fetchall()
            preds = [
                SpeciesPrediction(
                    rank=int(p["rank"]),
                    scientific_name=p["scientific_name"],
                    common_name_en=p["common_name_en"],
                    common_name_cn=p["common_name_cn"],
                    order_name=p["order_name"],
                    order_cn=p["order_cn"],
                    family_name=p["family_name"],
                    family_cn=p["family_cn"],
                    genus_name=p["genus_name"],
                    score=float(p["score"]),
                )
                for p in pred_rows
            ]
            detections.append(
                BirdDetection(
                    detection_id=int(d["id"]),
                    bbox=(int(d["x1"]), int(d["y1"]), int(d["x2"]), int(d["y2"])),
                    detect_conf=float(d["detect_conf"]),
                    sharpness_score=float(d["sharpness_score"]),
                    raw_laplacian_var=float(d["raw_laplacian_var"]),
                    predictions=preds,
                )
            )
        return detections

    @staticmethod
    def _row_to_photo(row: sqlite3.Row) -> PhotoRecord:
        keys = row.keys()
        return PhotoRecord(
            photo_id=int(row["id"]),
            file_path=row["file_path"],
            folder_path=row["folder_path"] if "folder_path" in keys else str(Path(row["file_path"]).parent),
            file_name=row["file_name"],
            file_ext=row["file_ext"],
            file_size=int(row["file_size"]),
            file_mtime=float(row["file_mtime"]),
            file_hash=row["file_hash"],
            is_raw=bool(row["is_raw"]),
            width=int(row["width"]),
            height=int(row["height"]),
            thumbnail_path=row["thumbnail_path"],
            exif=ExifMetadata(
                taken_at=row["taken_at"],
                camera_make=row["camera_make"],
                camera_model=row["camera_model"],
                lens_model=row["lens_model"],
                focal_length_mm=row["focal_length_mm"],
                aperture=row["aperture"],
                shutter_speed=row["shutter_speed"],
                iso=row["iso"],
                gps_lat=row["gps_lat"] if "gps_lat" in keys else None,
                gps_lon=row["gps_lon"] if "gps_lon" in keys else None,
            ),
            taken_date=row["taken_date"] if "taken_date" in keys else None,
            manual_date=row["manual_date"] if "manual_date" in keys else None,
            location_name=row["location_name"] if "location_name" in keys else "",
            location_province=row["location_province"] if "location_province" in keys else "",
            location_city=row["location_city"] if "location_city" in keys else "",
            ebird_loc_id=row["ebird_loc_id"] if "ebird_loc_id" in keys else None,
            has_bird=bool(row["has_bird"]),
            bird_count=int(row["bird_count"]),
            is_blurry=bool(row["is_blurry"]),
            best_sharpness=float(row["best_sharpness"]),
            primary_scientific_name=row["primary_scientific_name"],
            primary_common_name_cn=row["primary_common_name_cn"],
            primary_common_name_en=row["primary_common_name_en"],
            primary_order_cn=row["primary_order_cn"],
            primary_family_cn=row["primary_family_cn"],
            primary_confidence=float(row["primary_confidence"]),
            review_status=ReviewStatus(row["review_status"]),
            manual_scientific_name=row["manual_scientific_name"],
            manual_common_name_cn=row["manual_common_name_cn"],
            rating=int(row["rating"]),
            pick_flag=int(row["pick_flag"]) if "pick_flag" in keys else (-1 if row["is_rejected"] else 0),
            is_rejected=bool(row["is_rejected"]),
            notes=row["notes"],
            scanned_at=row["scanned_at"],
            updated_at=row["updated_at"],
        )

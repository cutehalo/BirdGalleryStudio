"""Configuration models for the bird gallery engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

SUPPORTED_IMAGE_EXTENSIONS: tuple[str, ...] = (
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".bmp",
    ".tif",
    ".tiff",
)

SUPPORTED_RAW_EXTENSIONS: tuple[str, ...] = (
    ".cr2",
    ".cr3",
    ".nef",
    ".nrw",
    ".arw",
    ".srf",
    ".sr2",
    ".raf",
    ".orf",
    ".rw2",
    ".pef",
    ".dng",
    ".srw",
    ".3fr",
)

ALL_SUPPORTED_EXTENSIONS: frozenset[str] = frozenset(
    SUPPORTED_IMAGE_EXTENSIONS + SUPPORTED_RAW_EXTENSIONS
)


@dataclass(slots=True)
class EngineConfig:
    """Runtime configuration for scanning, detection, classification, and storage."""

    # Storage paths
    db_path: Path = field(default_factory=lambda: Path("bird_gallery.db"))
    thumbnail_dir: Path = field(default_factory=lambda: Path(".bird_gallery_cache/thumbs"))
    taxonomy_csv: Path | None = None

    # Device settings ("auto" selects CUDA if available, otherwise CPU)
    device: Literal["auto", "cuda", "cpu"] = "auto"

    # YOLO bird detector settings
    yolo_model: str = "yolo11s.pt"
    detect_conf: float = 0.25
    detect_iou: float = 0.45
    crop_padding: float = 0.15  # Expand bird bounding box by 15% on each side for context
    min_crop_size: int = 32  # Ignore tiny noisy detections smaller than 32px
    max_birds_per_photo: int = 8

    # BioCLIP 2 classifier settings
    bioclip_model: str | None = None  # None uses pybioclip default (BioCLIP 2)
    top_k: int = 5
    filter_aves_only: bool = True
    restrict_to_taxonomy_csv: bool = False  # Optionally restrict BioCLIP labels to loaded CSV list

    # Quality / culling settings
    sharpness_blur_threshold: float = 18.0  # 0-100 score below this is flagged as likely blurry
    generate_thumbnails: bool = True
    thumbnail_max_size: int = 512

    # Scanning behavior
    recursive: bool = True
    include_raw: bool = True
    skip_existing: bool = True
    compute_file_hash: bool = False  # Fast mtime+size check by default; SHA1 optional

    def resolve_device(self) -> str:
        """Resolve 'auto' to 'cuda' if a working CUDA device is available, else 'cpu'."""
        if self.device != "auto":
            return self.device
        try:
            import torch

            if torch.cuda.is_available():
                return "cuda"
        except Exception:
            pass
        return "cpu"

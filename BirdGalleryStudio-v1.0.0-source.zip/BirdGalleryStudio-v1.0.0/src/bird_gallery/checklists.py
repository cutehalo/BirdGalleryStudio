"""Personal Birding Checklist parser & sync service (BirdReport.cn text/XLSX/CSV + eBird MyEBirdData.csv & S-ID API)."""

from __future__ import annotations

import csv
import io
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from bird_gallery.birdreport_sync import (
    RawBirdReportData,
    fetch_birdreport_targets_via_browser,
    parse_birdreport_inputs,
)
from bird_gallery.china_regions import infer_province_city, normalize_province_name
from bird_gallery.db import GalleryDatabase
from bird_gallery.ebird import EBirdLocationService, suggest_short_spot_name
from bird_gallery.models import BirdingChecklist, ChecklistItem
from bird_gallery.taxonomy import BIRDREPORT_SYNONYM_TO_SCI, TaxonEntry, TaxonomyMapper

_EBIRD_SUB_ID_PATTERN = re.compile(r"\b(S\d{6,14})\b", re.IGNORECASE)
_DATE_YMD_PATTERN = re.compile(
    r"(?<!\d)((?:19|20)\d{2})\s*[-/.年]\s*(0?[1-9]|1[0-2])\s*[-/.月]\s*(0?[1-9]|[12]\d|3[01])\s*日?(?!\d)"
)
_TIME_HM_PATTERN = re.compile(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?(?!\d)")
_LOCATION_LINE_PATTERN = re.compile(
    r"(?:观测地点|观鸟地点|调查地点|记录地点|观鸟点|观测点|地点|位置)\s*[:：]\s*([^\r\n\t]+)"
)


def _default_ebird_codes_path() -> Path:
    if getattr(sys, "frozen", False):
        beside = Path(sys.executable).resolve().parent / "data" / "ebird_species_codes.json"
        if beside.exists():
            return beside
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        bundled = Path(meipass) / "data" / "ebird_species_codes.json"
        if bundled.exists():
            return bundled
    return Path(__file__).resolve().parents[2] / "data" / "ebird_species_codes.json"


def extract_ebird_sub_ids(text: str) -> list[str]:
    """Extract one or more eBird checklist submission IDs (e.g. 'S198273645') from text or URLs."""
    seen: set[str] = set()
    out: list[str] = []
    for m in _EBIRD_SUB_ID_PATTERN.finditer(text):
        sid = m.group(1).upper()
        if sid not in seen:
            seen.add(sid)
            out.append(sid)
    return out


def normalize_date_str(raw: str) -> str:
    """Normalize common date formats ('2026-11-24 12:18:00', '2026/11/5', Excel serials) to 'YYYY-MM-DD'."""
    s = raw.strip()
    if not s:
        return ""
    m = _DATE_YMD_PATTERN.search(s)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"

    # Excel 1900-epoch numeric serial date cells (e.g. '45765' or '45765.5125' -> 2025-04-18)
    if re.fullmatch(r"\d{5}(?:\.\d+)?", s):
        try:
            serial_val = float(s)
            if 20000.0 <= serial_val <= 65000.0:
                dt_xl = datetime(1899, 12, 30) + timedelta(days=int(serial_val))
                return dt_xl.strftime("%Y-%m-%d")
        except ValueError:
            pass

    # US / International formats found in MyEBirdData.csv
    head = s.split()[0].strip()
    for fmt in ("%m/%d/%Y", "%d/%m/%Y", "%Y%m%d", "%d-%b-%Y", "%d %b %Y"):
        try:
            dt = datetime.strptime(head if "%" not in fmt or " " not in fmt else s[:20].strip(), fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


def _read_xlsx_rows(xlsx_path: Path) -> list[list[str]]:
    """Zero-dependency pure-Python .xlsx worksheet reader using stdlib zipfile + ElementTree."""
    ns_main = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    shared_strings: list[str] = []

    with zipfile.ZipFile(xlsx_path, "r") as zf:
        names = set(zf.namelist())
        if "xl/sharedStrings.xml" in names:
            root_ss = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root_ss.findall(f"{ns_main}si"):
                parts = [t.text or "" for t in si.iter(f"{ns_main}t")]
                shared_strings.append("".join(parts))

        sheet_files = sorted(
            (n for n in names if n.startswith("xl/worksheets/sheet") and n.endswith(".xml")),
            key=lambda name: (len(name), name),
        )
        if not sheet_files:
            return []

        root_ws = ET.fromstring(zf.read(sheet_files[0]))
        rows_out: list[list[str]] = []

        def _col_letters_to_idx(cell_ref: str) -> int:
            idx = 0
            for ch in cell_ref:
                if ch.isalpha():
                    idx = idx * 26 + (ord(ch.upper()) - ord("A") + 1)
                else:
                    break
            return max(0, idx - 1)

        for row_el in root_ws.iter(f"{ns_main}row"):
            cells_dict: dict[int, str] = {}
            max_col = -1
            for c_el in row_el.findall(f"{ns_main}c"):
                ref = c_el.attrib.get("r", "")
                c_idx = _col_letters_to_idx(ref) if ref else (max_col + 1)
                max_col = max(max_col, c_idx)
                c_type = c_el.attrib.get("t", "")
                val_txt = ""
                if c_type == "inlineStr":
                    val_txt = "".join(t.text or "" for t in c_el.iter(f"{ns_main}t"))
                else:
                    v_el = c_el.find(f"{ns_main}v")
                    if v_el is not None and v_el.text is not None:
                        raw_v = v_el.text
                        if c_type == "s":
                            try:
                                s_idx = int(raw_v)
                                val_txt = shared_strings[s_idx] if 0 <= s_idx < len(shared_strings) else raw_v
                            except ValueError:
                                val_txt = raw_v
                        else:
                            val_txt = raw_v
                cells_dict[c_idx] = val_txt.strip()

            if max_col >= 0:
                row_vals = [cells_dict.get(i, "") for i in range(max_col + 1)]
                if any(row_vals):
                    rows_out.append(row_vals)
        return rows_out


@dataclass(slots=True)
class ParsedChecklistDraft:
    obs_date: str = ""
    obs_time: str = ""
    location_name: str = ""
    province: str = ""
    city: str = ""
    items: list[ChecklistItem] = field(default_factory=list)
    unmatched_tokens: list[str] = field(default_factory=list)


class PersonalChecklistService:
    """Parses, imports, and syncs personal birding checklists from BirdReport.cn, CSV/Excel, and eBird."""

    def __init__(
        self,
        db: GalleryDatabase,
        taxonomy: TaxonomyMapper | None = None,
        ebird_service: EBirdLocationService | None = None,
    ) -> None:
        self.db = db
        self.taxonomy = taxonomy or TaxonomyMapper()
        self.ebird_svc = ebird_service or EBirdLocationService(db)

        self._ebird_to_sci: dict[str, str] = {}
        self._alias_to_sci: dict[str, str] = {}
        self._en_to_entry: dict[str, TaxonEntry] = {}
        self._cn_name_by_first_char: dict[str, list[tuple[str, TaxonEntry]]] = defaultdict(list)

        self._load_code_maps_and_trie()

    # ---------------- 0. Direct BirdReport.cn Sync by Report ID or URL ----------------

    def save_raw_birdreport_data(self, raw: RawBirdReportData) -> BirdingChecklist:
        """Convert extracted `RawBirdReportData` into a normalized `BirdingChecklist` in SQLite."""
        obs_date = normalize_date_str(raw.start_time)
        if not obs_date and len(raw.serial_id) >= 8 and raw.serial_id[:8].isdigit():
            s8 = raw.serial_id[:8]
            obs_date = f"{s8[:4]}-{s8[4:6]}-{s8[6:8]}"
        if not obs_date:
            raise ValueError(f"报告 {raw.serial_id} 缺少有效观测日期")

        loc_name = raw.address.strip()
        prov, city = infer_province_city(text_hint=loc_name)

        # Inherit GPS/eBird ID if location matches a configured FavoriteLocation
        ebird_lid: str | None = None
        lat: float | None = None
        lng: float | None = None
        if loc_name:
            fav = self.db.get_favorite_location_by_name(loc_name)
            if fav is not None:
                ebird_lid = fav.ebird_loc_id
                lat, lng = fav.lat, fav.lng
                prov = prov or fav.province
                city = city or fav.city

        items: list[ChecklistItem] = []
        for sp in raw.species:
            has_cn = bool(re.search(r"[\u3400-\u9fff]", sp.taxon_name))
            if has_cn:
                taxon = self.resolve_species_any(sp.taxon_name) or self.resolve_species_any(sp.latin_name)
            else:
                taxon = self.resolve_species_any(sp.latin_name) or self.resolve_species_any(sp.taxon_name)
            cn_name = taxon.common_name_cn if taxon is not None else sp.taxon_name.strip()
            sci_name = taxon.scientific_name if taxon is not None else sp.latin_name.strip()
            c_str = sp.count_str.strip() or "1"
            c_num = int(c_str) if c_str.isdigit() else (0 if c_str.upper() == "X" else 1)
            items.append(
                ChecklistItem(
                    common_name_cn=cn_name,
                    scientific_name=sci_name,
                    count_num=c_num,
                    count_str=c_str,
                )
            )

        return self.db.upsert_checklist(
            obs_date,
            items,
            obs_time="",
            source="birdreport",
            external_id=raw.serial_id.strip(),
            location_name=loc_name,
            province=prov,
            city=city,
            ebird_loc_id=ebird_lid,
            lat=lat,
            lng=lng,
            notes=raw.note.strip(),
        )

    def sync_birdreport_by_id_or_url(
        self,
        raw_input: str,
        *,
        on_status: Callable[[str], None] | None = None,
    ) -> list[BirdingChecklist]:
        """Sync one or more BirdReport.cn reports given Report IDs (`2026112501740`) or `page.html` URLs."""
        targets = parse_birdreport_inputs(raw_input)
        if not targets:
            raise ValueError(
                "未识别到有效的观鸟记录中心报告编号（如 2026112501740）或报告链接（https://www.birdreport.cn/home/record/page.html?param=...）。"
            )
        raw_reports = fetch_birdreport_targets_via_browser(targets, on_status=on_status)
        saved: list[BirdingChecklist] = []
        for rep in raw_reports:
            saved.append(self.save_raw_birdreport_data(rep))
        return saved

    def _load_code_maps_and_trie(self) -> None:
        codes_path = _default_ebird_codes_path()
        if codes_path.exists():
            try:
                payload = json.loads(codes_path.read_text(encoding="utf-8"))
                self._ebird_to_sci = payload.get("ebird_to_sci", {})
                self._alias_to_sci = payload.get("alias_to_sci", {})
            except Exception:
                pass

        # Index English names and build longest-first Chinese name lookup by first char for fast text scanning
        seen_cn: set[str] = set()
        for entry in self.taxonomy._by_scientific.values():
            if entry.common_name_en:
                self._en_to_entry[entry.common_name_en.lower()] = entry
            cn = entry.common_name_cn.strip()
            if len(cn) >= 2 and cn not in seen_cn:
                seen_cn.add(cn)
                self._cn_name_by_first_char[cn[0]].append((cn, entry))

        for alias_cn, sci in {**self._alias_to_sci, **BIRDREPORT_SYNONYM_TO_SCI}.items():
            if len(alias_cn) >= 2 and re.search(r"[\u3400-\u9fff]", alias_cn) and alias_cn not in seen_cn:
                taxon = self.taxonomy.lookup(sci)
                if taxon is not None:
                    seen_cn.add(alias_cn)
                    self._cn_name_by_first_char[alias_cn[0]].append((alias_cn, taxon))

        # Sort longest bird names first per starting character (e.g. '大白鹭' before '白鹭' if same start, '黑脸琵鹭' before '黑脸噪鹛')
        for ch_list in self._cn_name_by_first_char.values():
            ch_list.sort(key=lambda pair: (-len(pair[0]), not pair[1].in_china))

    def resolve_species_any(self, name_or_code: str) -> TaxonEntry | None:
        """Resolve Chinese name (Simplified/Traditional/BirdReport alias), Latin name, English name, or eBird code."""
        s = name_or_code.strip()
        if not s:
            return None

        # Strip common noise suffixes like "sp." or "(未定种)" or parenthetical Latin
        s_clean = re.sub(r"\s*[（(][^()（）]*[)）]\s*$", "", s).strip() or s

        # 1. Direct Simplified Chinese or Scientific Name
        direct = self.taxonomy.lookup_by_cn(s_clean) or self.taxonomy.lookup(s_clean)
        if direct is not None:
            return direct

        # 2. Traditional Chinese / BirdReport synonym alias -> scientific name
        sci_alias = self._alias_to_sci.get(s_clean) or self._alias_to_sci.get(s)
        if sci_alias:
            found = self.taxonomy.lookup(sci_alias)
            if found is not None:
                return found

        # 3. eBird speciesCode (e.g. 'bktgod', 'comkin1', 'integr1')
        sci_eb = self._ebird_to_sci.get(s_clean.lower())
        if sci_eb:
            found = self.taxonomy.lookup(sci_eb)
            if found is not None:
                return found

        # 4. English common name (from MyEBirdData.csv)
        en_hit = self._en_to_entry.get(s_clean.lower()) or self._en_to_entry.get(s.lower())
        if en_hit is not None:
            return en_hit

        return None

    # ---------------- 1. BirdReport.cn / Free-Text Smart Parser ----------------

    def parse_birdreport_text(
        self,
        raw_text: str,
        *,
        default_date: str = "",
        default_location: str = "",
    ) -> ParsedChecklistDraft:
        """Parse pasted BirdReport.cn web/WeChat report text, copied table rows, or plain bird lists."""
        draft = ParsedChecklistDraft(
            obs_date=normalize_date_str(default_date),
            location_name=default_location.strip(),
        )
        text = raw_text.strip()
        if not text:
            return draft

        # 1. Extract date & time from header if present
        m_date = _DATE_YMD_PATTERN.search(text)
        if m_date:
            draft.obs_date = f"{int(m_date.group(1)):04d}-{int(m_date.group(2)):02d}-{int(m_date.group(3)):02d}"
        m_time = _TIME_HM_PATTERN.search(text)
        if m_time:
            draft.obs_time = f"{int(m_time.group(1)):02d}:{m_time.group(2)}"

        # 2. Extract location line if present
        m_loc = _LOCATION_LINE_PATTERN.search(text)
        if m_loc:
            loc_raw = m_loc.group(1).strip()
            # Trim trailing metadata on same line like "观测时间..."
            loc_raw = re.split(r"\s+(?:观测|记录|开始|调查|天气|鸟种)", loc_raw)[0].strip()
            if loc_raw:
                draft.location_name = loc_raw

        if draft.location_name:
            p, c = infer_province_city(text_hint=draft.location_name)
            draft.province, draft.city = p, c

        # 3. Longest-match scan across text lines for Chinese bird names + adjacent counts
        # Strip leading index numbers like "1." or "01、" or "[12]" at start of lines so they aren't misread as counts!
        cleaned_lines: list[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            # Remove leading serial index at line start: e.g. "1. 普通翠鸟 2" or "12\t普通翠鸟\t2"
            line = re.sub(r"^\s*(?:第?\d+\s*[.、)\]\t]\s*)", "", line)
            cleaned_lines.append(line)

        merged_counts: dict[str, ChecklistItem] = {}
        count_after_re = re.compile(r"^[\s\t:：×xX*（(\-—·]*(\d{1,5}|[xX])\s*(?:只|羽|ind)?[)）]?")

        for line in cleaned_lines:
            # Skip obvious metadata lines that are dates/locations unless they contain birds
            if line.startswith(("观测地点", "观鸟地点", "记录人", "观测者", "天气")):
                continue

            i = 0
            n = len(line)
            while i < n:
                ch = line[i]
                candidates = self._cn_name_by_first_char.get(ch)
                matched_taxon: TaxonEntry | None = None
                matched_len = 0

                if candidates:
                    for cand_name, taxon in candidates:
                        c_len = len(cand_name)
                        if i + c_len <= n and line[i : i + c_len] == cand_name:
                            matched_taxon = taxon
                            matched_len = c_len
                            break

                if matched_taxon is not None:
                    after_slice = line[i + matched_len : i + matched_len + 24]
                    # Also handle optional Latin name in between, e.g. "普通翠鸟\tAlcedo atthis\t2"
                    after_no_latin = re.sub(r"^[\s\t]+[A-Z][a-z]+\s+[a-z]+(?:\s+[a-z]+)?", "", after_slice)
                    m_cnt = count_after_re.match(after_no_latin)
                    cnt_num = 1
                    cnt_str = "1"
                    advance_extra = 0
                    if m_cnt:
                        raw_c = m_cnt.group(1)
                        if raw_c.upper() == "X":
                            cnt_num = 0
                            cnt_str = "X"
                        else:
                            val = int(raw_c)
                            # Guard against accidentally grabbing a 4-digit year like 2026
                            if not (2015 <= val <= 2035 and "年" in line[i + matched_len : i + matched_len + 10]):
                                cnt_num = val
                                cnt_str = str(val)
                        if after_no_latin is after_slice:
                            advance_extra = m_cnt.end()

                    cn_canon = matched_taxon.common_name_cn
                    if cn_canon not in merged_counts:
                        merged_counts[cn_canon] = ChecklistItem(
                            common_name_cn=cn_canon,
                            scientific_name=matched_taxon.scientific_name,
                            count_num=cnt_num,
                            count_str=cnt_str,
                        )
                    else:
                        prev = merged_counts[cn_canon]
                        if cnt_num > 0:
                            prev.count_num += cnt_num
                            prev.count_str = str(prev.count_num)
                    i += matched_len + advance_extra
                else:
                    i += 1

        draft.items = list(merged_counts.values())
        return draft

    def save_parsed_draft(
        self,
        draft: ParsedChecklistDraft,
        *,
        source: str = "birdreport",
        notes: str = "",
    ) -> BirdingChecklist:
        if not draft.obs_date:
            raise ValueError("请填写或选择该篇观鸟记录的日期（YYYY-MM-DD）")
        if not draft.items:
            raise ValueError("未在内容中识别到有效鸟种，请检查粘贴内容或手动添加鸟种")
        return self.db.upsert_checklist(
            draft.obs_date,
            draft.items,
            obs_time=draft.obs_time,
            source=source,
            location_name=draft.location_name,
            province=draft.province,
            city=draft.city,
            notes=notes,
        )

    # ---------------- 2. CSV / Excel (.xlsx / BirdReport Export / MyEBirdData.csv) ----------------

    @staticmethod
    def is_tabular_checklist_text(raw_text: str) -> bool:
        """Return True if pasted text looks like a multi-column CSV/TSV export with a header row."""
        lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
        if len(lines) < 2:
            return False
        first = lines[0].lstrip("\ufeff")
        if ("\t" not in first) and (first.count(",") < 2):
            return False
        low = first.lower()
        return any(
            k in low
            for k in ("报告编号", "观测开始时间", "观测点名称", "submission id", "checklist id")
        )

    def import_tabular_text(
        self,
        raw_text: str,
        *,
        default_date: str = "",
        default_location: str = "",
    ) -> tuple[int, int]:
        """Parse pasted CSV/TSV table text (such as BirdReport Excel/CSV copy-paste) into split checklists."""
        text = raw_text.lstrip("\ufeff")
        sample = text[:4096]
        delim = "\t" if sample.count("\t") > sample.count(",") else ","
        reader = csv.reader(io.StringIO(text), delimiter=delim)
        rows = [[c.strip() for c in r] for r in reader if any(c.strip() for c in r)]
        return self._import_parsed_rows(
            rows,
            default_date=default_date,
            default_location=default_location,
        )

    def import_checklist_file(
        self,
        file_path: str | Path,
        *,
        default_date: str = "",
        default_location: str = "",
    ) -> tuple[int, int]:
        """Import checklists from `.csv` or `.xlsx` (supports BirdReport exports/templates & `MyEBirdData.csv`).

        Splits rows into distinct checklists per `报告编号` (`Submission ID`), keeps ONLY the observation
        start date (`YYYY-MM-DD`, without time) for BirdReport records, and resolves taxonomy & locations.
        Returns `(imported_checklists_count, total_species_records_count)`.
        """
        path = Path(file_path)
        ext = path.suffix.lower()

        rows: list[list[str]] = []
        if ext == ".xlsx" or (path.exists() and zipfile.is_zipfile(path)):
            rows = _read_xlsx_rows(path)
        else:
            raw_bytes = path.read_bytes()
            text = ""
            for enc in ("utf-8-sig", "utf-8", "gb18030"):
                try:
                    text = raw_bytes.decode(enc)
                    break
                except UnicodeDecodeError:
                    continue
            if not text:
                text = raw_bytes.decode("utf-8", errors="ignore")
            sample = text[:4096]
            delim = "\t" if sample.count("\t") > sample.count(",") else ","
            reader = csv.reader(io.StringIO(text), delimiter=delim)
            rows = [[c.strip() for c in r] for r in reader if any(c.strip() for c in r)]

        return self._import_parsed_rows(
            rows,
            default_date=default_date,
            default_location=default_location,
            stem_hint=path.stem,
        )

    def _import_parsed_rows(
        self,
        rows: list[list[str]],
        *,
        default_date: str = "",
        default_location: str = "",
        stem_hint: str = "",
    ) -> tuple[int, int]:
        if not rows:
            raise ValueError("文件内容为空，未能读取到任何数据行。")

        # Locate header row within first 5 rows
        header_idx = 0
        col_map: dict[str, int] = {}
        for r_idx in range(min(5, len(rows))):
            low_cells = [c.strip().lstrip("\ufeff").lower() for c in rows[r_idx]]
            if any(
                k in cell
                for cell in low_cells
                for k in ("鸟种", "物种", "中文名", "common name", "scientific name", "species")
            ):
                header_idx = r_idx
                for c_i, cell in enumerate(low_cells):
                    if cell in ("观测结束时间", "结束时间", "end time", "end date"):
                        continue
                    if cell in ("submission id", "清单编号", "报告编号", "记录编号", "报告id", "checklist id"):
                        col_map.setdefault("sub_id", c_i)
                    elif cell in ("common name", "鸟种", "鸟种名称", "物种", "物种名称", "中文名", "中文名称", "种名"):
                        col_map.setdefault("species_cn", c_i)
                    elif cell in ("scientific name", "学名", "拉丁名", "拉丁学名"):
                        col_map.setdefault("species_sci", c_i)
                    elif cell in ("count", "数量", "鸟种数量", "只数", "个体数", "观测数量", "统计数量"):
                        col_map.setdefault("count", c_i)
                    elif cell in (
                        "date",
                        "日期",
                        "观测日期",
                        "观测开始时间",
                        "观测开始日期",
                        "记录日期",
                        "开始日期",
                        "观测时间",
                    ):
                        col_map.setdefault("date", c_i)
                    elif cell in ("time", "时间", "开始时间"):
                        col_map.setdefault("time", c_i)
                    elif cell in ("location", "地点", "观测地点", "观测点名称", "观鸟点", "观测点", "位置", "地址"):
                        col_map.setdefault("location", c_i)
                    elif cell in ("location id", "鸟点编号"):
                        col_map.setdefault("loc_id", c_i)
                    elif cell in ("state/province", "省份", "省"):
                        col_map.setdefault("province", c_i)
                    elif cell in ("county", "城市", "地市", "市", "州/市", "地州"):
                        col_map.setdefault("city", c_i)
                    elif cell in ("district", "区/县", "区县", "县", "区"):
                        col_map.setdefault("district", c_i)
                    elif cell in ("latitude", "纬度", "lat"):
                        col_map.setdefault("lat", c_i)
                    elif cell in ("longitude", "经度", "lng", "lon"):
                        col_map.setdefault("lng", c_i)
                    elif cell in ("observation details", "鸟种备注", "备注", "remarks"):
                        col_map.setdefault("remarks", c_i)
                break

        # If still no species column found (e.g. headerless 2-col table), assume col 0 = species, col 1 = count
        data_rows = rows[header_idx + 1 :] if col_map else rows
        if not col_map:
            col_map = {"species_cn": 0, "count": 1}

        has_date_col = "date" in col_map
        has_loc_col = "location" in col_map
        fallback_date = normalize_date_str(default_date) or normalize_date_str(stem_hint)
        is_ebird_export = "sub_id" in col_map and "loc_id" in col_map

        # Split observations strictly by `报告编号` (`sub_id`) when present, else by `(obs_date, location)`
        grouped: dict[tuple[str, str, str], dict[str, object]] = {}

        def _cell(r: list[str], key: str) -> str:
            idx = col_map.get(key)
            return r[idx].strip() if (idx is not None and idx < len(r)) else ""

        for r in data_rows:
            sp_cn_raw = _cell(r, "species_cn")
            sp_sci_raw = _cell(r, "species_sci")
            has_cn_chars = bool(re.search(r"[\u3400-\u9fff]", sp_cn_raw))
            if has_cn_chars:
                taxon = self.resolve_species_any(sp_cn_raw) or self.resolve_species_any(sp_sci_raw)
            else:
                taxon = self.resolve_species_any(sp_sci_raw) or self.resolve_species_any(sp_cn_raw)

            if taxon is None:
                if re.search(r"[\u3400-\u9fff]{2,}", sp_cn_raw):
                    cn_final = sp_cn_raw
                    sci_final = sp_sci_raw
                else:
                    continue
            else:
                # Never overwrite a valid Chinese bird name with a non-Chinese fallback label
                if has_cn_chars and not re.search(r"[\u3400-\u9fff]", taxon.common_name_cn):
                    cn_final = sp_cn_raw
                else:
                    cn_final = taxon.common_name_cn
                sci_final = taxon.scientific_name or sp_sci_raw

            sub_id = _cell(r, "sub_id")
            raw_date = _cell(r, "date")
            obs_d = normalize_date_str(raw_date)
            if not obs_d and len(sub_id) >= 8 and sub_id[:8].isdigit():
                obs_d = normalize_date_str(sub_id[:8])
            if not obs_d:
                obs_d = fallback_date
            if not obs_d:
                continue

            prov_raw = _cell(r, "province")
            city_raw = _cell(r, "city")
            dist_raw = _cell(r, "district")
            loc_cell = _cell(r, "location")
            if loc_cell:
                loc_raw = loc_cell
            elif has_loc_col and (dist_raw or city_raw):
                loc_raw = dist_raw or city_raw
            else:
                loc_raw = default_location.strip()

            loc_id = _cell(r, "loc_id")
            if is_ebird_export and loc_raw:
                loc_raw = suggest_short_spot_name(loc_raw, prov_raw)

            grp_key = ("id", sub_id, "") if sub_id else ("dl", obs_d, loc_raw)
            if grp_key not in grouped:
                lat_v: float | None = None
                lng_v: float | None = None
                try:
                    if _cell(r, "lat") and _cell(r, "lng"):
                        lat_v = float(_cell(r, "lat"))
                        lng_v = float(_cell(r, "lng"))
                except ValueError:
                    pass

                prov_norm = normalize_province_name(prov_raw) if prov_raw else ""
                inf_p, inf_c = infer_province_city(
                    lat_v,
                    lng_v,
                    subnational1_code=prov_raw,
                    text_hint=" ".join(x for x in (prov_raw, city_raw, dist_raw, loc_raw) if x),
                )
                prov_final = prov_norm or inf_p
                if prov_final in ("北京", "上海", "天津", "重庆") and dist_raw:
                    city_final = dist_raw
                elif re.search(r"[\u3400-\u9fff]", city_raw):
                    city_final = city_raw
                else:
                    city_final = inf_c or dist_raw

                is_ebird = is_ebird_export or sub_id.upper().startswith("S")
                # Keep ONLY observation start date (YYYY-MM-DD) without time for BirdReport imports!
                obs_t = _cell(r, "time")[:5] if is_ebird else ""

                grouped[grp_key] = {
                    "obs_date": obs_d,
                    "obs_time": obs_t,
                    "source": "ebird" if is_ebird else "birdreport",
                    "external_id": sub_id,
                    "location_name": loc_raw,
                    "province": prov_final,
                    "city": city_final,
                    "ebird_loc_id": loc_id or None,
                    "lat": lat_v,
                    "lng": lng_v,
                    "items": [],
                }

            cnt_raw = _cell(r, "count") or "1"
            cnt_num = (
                0
                if cnt_raw.upper() == "X"
                else (int(float(cnt_raw)) if re.match(r"^\d+(?:\.\d+)?$", cnt_raw) else 1)
            )
            grouped[grp_key]["items"].append(  # type: ignore[union-attr]
                ChecklistItem(
                    common_name_cn=cn_final,
                    scientific_name=sci_final,
                    count_num=cnt_num,
                    count_str="X" if cnt_raw.upper() == "X" else str(max(1, cnt_num)),
                    remarks=_cell(r, "remarks"),
                )
            )

        if not grouped:
            if not fallback_date and not has_date_col:
                raise ValueError("该表格中没有包含“日期 / 观测开始时间”列，请先在导入前选择观测日期。")
            raise ValueError("未能从该文件中解析出有效的观鸟记录行。")

        total_species_rows = 0
        for meta in grouped.values():
            items_list: list[ChecklistItem] = meta["items"]  # type: ignore[assignment]
            cl = self.db.upsert_checklist(
                str(meta["obs_date"]),
                items_list,
                obs_time=str(meta["obs_time"]),
                source=str(meta["source"]),
                external_id=str(meta["external_id"]),
                location_name=str(meta["location_name"]),
                province=str(meta["province"]),
                city=str(meta["city"]),
                ebird_loc_id=str(meta["ebird_loc_id"]) if meta["ebird_loc_id"] else None,
                lat=meta["lat"],  # type: ignore[arg-type]
                lng=meta["lng"],  # type: ignore[arg-type]
            )
            total_species_rows += cl.species_count

        return len(grouped), total_species_rows

    # ---------------- 3. Official eBird Checklist S-ID / URL Sync ----------------

    def sync_ebird_checklists(self, raw_sub_ids_or_urls: str) -> list[BirdingChecklist]:
        """Fetch one or more eBird checklists (`S12345678` or URL) via eBird API v2 and save locally."""
        sub_ids = extract_ebird_sub_ids(raw_sub_ids_or_urls)
        if not sub_ids:
            raise ValueError("未识别到有效的 eBird 清单编号（格式为 S 开头的数字，如 S198273645 或其网页链接）。")

        synced: list[BirdingChecklist] = []
        for sid in sub_ids:
            data = self.ebird_svc._ebird_get_json(f"/product/checklist/view/{sid}")
            if not isinstance(data, dict):
                continue

            obs_dt_raw = str(data.get("obsDt") or "")
            obs_date = normalize_date_str(obs_dt_raw)
            m_t = _TIME_HM_PATTERN.search(obs_dt_raw)
            obs_time = f"{int(m_t.group(1)):02d}:{m_t.group(2)}" if m_t else ""
            loc_id = str(data.get("locId") or "").strip() or None
            sub1 = str(data.get("subnational1Code") or "")

            loc_name = ""
            lat: float | None = None
            lng: float | None = None
            prov = ""
            city = ""

            if loc_id:
                hs = self.ebird_svc.fetch_hotspot_by_id_or_url(loc_id)
                if hs is not None:
                    loc_name = suggest_short_spot_name(hs.loc_name, hs.subnational1_code)
                    lat, lng = hs.lat, hs.lng
                    prov, city = infer_province_city(
                        lat, lng, subnational1_code=hs.subnational1_code or hs.country_code, text_hint=hs.loc_name
                    )
                    city = hs.city_name or city

            if not prov and sub1:
                prov = normalize_province_name(sub1)

            obs_list = data.get("obs") or []
            unresolved_codes: list[str] = []
            parsed_obs: list[tuple[str, int, str]] = []

            for ob in obs_list:
                if not isinstance(ob, dict):
                    continue
                sp_code = str(ob.get("speciesCode") or "").strip().lower()
                if not sp_code:
                    continue
                how_str = str(ob.get("howManyStr") or "1").strip()
                how_num = 0 if how_str.upper() == "X" else (int(how_str) if how_str.isdigit() else 1)
                parsed_obs.append((sp_code, how_num, how_str))
                if self.resolve_species_any(sp_code) is None:
                    unresolved_codes.append(sp_code)

            # Online taxonomy fallback for newly split eBird species codes
            online_code_map: dict[str, tuple[str, str]] = {}
            if unresolved_codes:
                try:
                    tax_data = self.ebird_svc._ebird_get_json(
                        "/ref/taxonomy/ebird",
                        {"fmt": "json", "locale": "zh_SIM", "species": ",".join(sorted(set(unresolved_codes)))},
                    )
                    if isinstance(tax_data, list):
                        for tr in tax_data:
                            if isinstance(tr, dict):
                                c = str(tr.get("speciesCode") or "").lower()
                                cn = str(tr.get("comName") or "")
                                sci = str(tr.get("sciName") or "")
                                if c and cn:
                                    online_code_map[c] = (cn, sci)
                except Exception:
                    pass

            items: list[ChecklistItem] = []
            for sp_code, how_num, how_str in parsed_obs:
                taxon = self.resolve_species_any(sp_code)
                if taxon is not None:
                    items.append(
                        ChecklistItem(
                            common_name_cn=taxon.common_name_cn,
                            scientific_name=taxon.scientific_name,
                            count_num=how_num,
                            count_str=how_str,
                        )
                    )
                elif sp_code in online_code_map:
                    cn_o, sci_o = online_code_map[sp_code]
                    items.append(
                        ChecklistItem(
                            common_name_cn=cn_o,
                            scientific_name=sci_o,
                            count_num=how_num,
                            count_str=how_str,
                        )
                    )

            if obs_date and items:
                cl = self.db.upsert_checklist(
                    obs_date,
                    items,
                    obs_time=obs_time,
                    source="ebird",
                    external_id=sid,
                    location_name=loc_name,
                    province=prov,
                    city=city,
                    ebird_loc_id=loc_id,
                    lat=lat,
                    lng=lng,
                )
                synced.append(cl)

        return synced

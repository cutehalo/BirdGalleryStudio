"""Bird crop sharpness / focus quality estimation for burst culling."""

from __future__ import annotations

import math

import cv2
import numpy as np
from PIL import Image


def compute_sharpness_metrics(image: Image.Image) -> tuple[float, float]:
    """Compute a normalized sharpness score (0..100) and raw Laplacian variance.

    Evaluating sharpness on the cropped bird region (rather than the whole frame)
    prevents blurred bokeh backgrounds from penalizing sharp tele-lens bird shots.

    To make scores comparable across different crop resolutions (e.g. a small distant
    bird vs. a full-frame portrait), the crop is resized to a standard reference width
    before computing Laplacian variance and Tenengrad (Sobel) gradient energy.
    """
    rgb = np.asarray(image.convert("RGB"))
    if rgb.size == 0 or rgb.shape[0] < 8 or rgb.shape[1] < 8:
        return 0.0, 0.0

    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    # Normalize long edge to 320px so focus metrics are scale-consistent across crops
    h, w = gray.shape
    long_edge = max(h, w)
    if long_edge > 320:
        scale = 320.0 / long_edge
        gray = cv2.resize(
            gray,
            (max(8, int(w * scale)), max(8, int(h * scale))),
            interpolation=cv2.INTER_AREA,
        )

    # Slight focus weighting toward the inner 70% of the bird crop (less background edge noise)
    ch, cw = gray.shape
    y0, y1 = int(ch * 0.12), max(int(ch * 0.88), int(ch * 0.12) + 4)
    x0, x1 = int(cw * 0.12), max(int(cw * 0.88), int(cw * 0.12) + 4)
    core = gray[y0:y1, x0:x1]

    # 1. Laplacian variance (sensitive to fine feather texture & crisp edges)
    lap_var = float(cv2.Laplacian(core, cv2.CV_64F).var())

    # 2. Tenengrad (mean squared Sobel gradient magnitude)
    gx = cv2.Sobel(core, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(core, cv2.CV_64F, 0, 1, ksize=3)
    tenengrad = float(np.mean(gx * gx + gy * gy))

    # Log-compress both signals into an intuitive 0..100 scale:
    # ~0-18: noticeably blurry / out of focus
    # ~20-45: acceptable / soft tele-lens shot
    # ~45-75: sharp feathers
    # ~75-100: tack-sharp close-up feather detail
    lap_score = min(100.0, max(0.0, (math.log1p(lap_var) / math.log1p(2500.0)) * 100.0))
    ten_score = min(100.0, max(0.0, (math.log1p(tenengrad) / math.log1p(45000.0)) * 100.0))

    combined = round(0.65 * lap_score + 0.35 * ten_score, 2)
    return combined, round(lap_var, 2)

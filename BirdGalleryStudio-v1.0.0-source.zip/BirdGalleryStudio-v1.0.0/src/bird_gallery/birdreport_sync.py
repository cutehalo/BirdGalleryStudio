"""Sync public birding checklists from China BirdReport (birdreport.cn) by Report ID or Report URL.

Uses the system's installed Chromium browser (Microsoft Edge / Google Chrome) in an isolated `--app`
window via localhost Chrome DevTools Protocol (CDP) so `birdreport.cn`'s own official frontend handles
rendering (and, if ever triggered by rate-limiting or serial search, lets the user complete any
official verification directly in the visible window without any automated bypass).
"""

from __future__ import annotations

import base64
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

BIRDREPORT_BASE = "https://www.birdreport.cn"

# Matches full or scheme-less BirdReport record page URLs
_REPORT_URL_RE = re.compile(
    r"(?:https?://)?(?:www\.)?birdreport\.cn/home/record/page\.html\?[^\s\"'<>]+",
    re.IGNORECASE,
)
# Matches BirdReport serial IDs like 2026112501740 (YYYYMMDD + sequence digits)
_SERIAL_ID_RE = re.compile(r"\b(20\d{6}\d{3,10})\b")
# Matches raw reportId UUIDs like 5766ea65-e642-4fa4-8923-aa5a5d2f8767
_UUID_RE = re.compile(
    r"\b([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\b"
)


@dataclass(slots=True, frozen=True)
class BirdReportTarget:
    kind: str  # 'url' | 'serial_id'
    value: str
    start_url: str


@dataclass(slots=True)
class RawBirdReportSpecies:
    taxon_name: str
    latin_name: str = ""
    count_str: str = "1"


@dataclass(slots=True)
class RawBirdReportData:
    serial_id: str
    start_time: str = ""
    end_time: str = ""
    address: str = ""
    note: str = ""
    species: list[RawBirdReportSpecies] = field(default_factory=list)


def build_serial_search_url(serial_id: str) -> str:
    payload = json.dumps({"serial_id": serial_id.strip()}, separators=(",", ":"))
    b64 = base64.b64encode(payload.encode("utf-8")).decode("ascii")
    return f"{BIRDREPORT_BASE}/home/search/report.html?search={urllib.parse.quote(b64)}"


def build_uuid_report_url(report_uuid: str) -> str:
    """Build standard BirdReport page.html URL from a reportId UUID."""
    import hashlib

    ts_ms = int(time.time() * 1000)
    payload = json.dumps({"reportId": report_uuid.strip(), "ts": ts_ms}, separators=(",", ":"))
    b64 = base64.b64encode(payload.encode("utf-8")).decode("ascii")
    # Note: birdreport.cn's page.html calls calcMD5(parseParam) on the parsed object, which hashes ""
    empty_md5 = hashlib.md5(b"").hexdigest()
    return f"{BIRDREPORT_BASE}/home/record/page.html?param={b64}&sign={empty_md5}"


def parse_birdreport_inputs(raw_input: str) -> list[BirdReportTarget]:
    """Parse one or more BirdReport URLs, Serial IDs (e.g. '2026112501740'), or UUIDs from text."""
    text = raw_input.strip()
    if not text:
        return []

    targets: list[BirdReportTarget] = []
    seen: set[str] = set()

    # 1. Extract explicit report URLs first
    def _consume_url(m: re.Match[str]) -> str:
        u = m.group(0).strip()
        if not u.lower().startswith("http"):
            u = "https://" + u
        if u not in seen:
            seen.add(u)
            targets.append(BirdReportTarget(kind="url", value=u, start_url=u))
        return " "

    remainder = _REPORT_URL_RE.sub(_consume_url, text)

    # 2. Extract UUIDs if user pasted a raw reportId UUID
    def _consume_uuid(m: re.Match[str]) -> str:
        uid = m.group(1).lower()
        if uid not in seen:
            seen.add(uid)
            u = build_uuid_report_url(uid)
            targets.append(BirdReportTarget(kind="url", value=uid, start_url=u))
        return " "

    remainder = _UUID_RE.sub(_consume_uuid, remainder)

    # 3. Extract Serial IDs like 2026112501740
    for m in _SERIAL_ID_RE.finditer(remainder):
        sid = m.group(1)
        if sid not in seen:
            seen.add(sid)
            targets.append(
                BirdReportTarget(
                    kind="serial_id",
                    value=sid,
                    start_url=build_serial_search_url(sid),
                )
            )

    return targets


def find_system_chromium_browser() -> Path | None:
    """Locate Microsoft Edge or Google Chrome on Windows, macOS, or Linux."""
    candidates: list[str] = []
    if os.name == "nt":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pfx86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local_app = os.environ.get("LOCALAPPDATA", "")
        candidates.extend(
            [
                os.path.join(pfx86, r"Microsoft\Edge\Application\msedge.exe"),
                os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe"),
                os.path.join(local_app, r"Microsoft\Edge\Application\msedge.exe"),
                os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
                os.path.join(pfx86, r"Google\Chrome\Application\chrome.exe"),
                os.path.join(local_app, r"Google\Chrome\Application\chrome.exe"),
            ]
        )
    elif sys.platform == "darwin":
        candidates.extend(
            [
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                "/Applications/Chromium.app/Contents/MacOS/Chromium",
                str(Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
                str(Path.home() / "Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
            ]
        )
    for name in ("msedge", "microsoft-edge", "google-chrome", "chromium", "chrome"):
        found = shutil.which(name)
        if found:
            candidates.append(found)

    for c in candidates:
        if c and os.path.isfile(c):
            return Path(c)
    return None


def _resolve_browser_profile_dir() -> Path:
    from bird_gallery.paths import resolve_app_data_dir

    cand = resolve_app_data_dir() / ".bird_gallery_cache" / "birdreport_browser"
    try:
        cand.mkdir(parents=True, exist_ok=True)
        return cand
    except OSError:
        local_base = Path.home() / ".bird_gallery_cache" / "birdreport_browser"
        local_base.mkdir(parents=True, exist_ok=True)
        return local_base


def _pick_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


class MiniCDPWebSocket:
    """Zero-dependency RFC-6455 localhost WebSocket client for Chrome DevTools Protocol."""

    def __init__(self, ws_url: str, timeout: float = 10.0) -> None:
        parsed = urllib.parse.urlparse(ws_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or 80
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"

        self._sock = socket.create_connection((host, port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        handshake = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self._sock.sendall(handshake.encode("ascii"))

        resp_buf = b""
        while b"\r\n\r\n" not in resp_buf:
            chunk = self._sock.recv(1024)
            if not chunk:
                raise ConnectionError("CDP WebSocket 握手中断")
            resp_buf += chunk
        header_part, leftover = resp_buf.split(b"\r\n\r\n", 1)
        if b" 101 " not in header_part.splitlines()[0]:
            raise ConnectionError(f"CDP WebSocket 握手失败: {header_part[:120]!r}")
        self._rx_buffer = bytearray(leftover)
        self._next_id = 1

    def close(self) -> None:
        try:
            self._send_frame(0x8, b"")
        except Exception:
            pass
        try:
            self._sock.close()
        except Exception:
            pass

    def _recv_exact(self, n: int) -> bytes:
        while len(self._rx_buffer) < n:
            chunk = self._sock.recv(max(4096, n - len(self._rx_buffer)))
            if not chunk:
                raise EOFError("浏览器窗口已关闭")
            self._rx_buffer.extend(chunk)
        out = bytes(self._rx_buffer[:n])
        del self._rx_buffer[:n]
        return out

    def _send_frame(self, opcode: int, payload: bytes) -> None:
        fin_op = 0x80 | (opcode & 0x0F)
        mask_key = os.urandom(4)
        length = len(payload)
        header = bytearray([fin_op])
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack(">H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack(">Q", length))
        header.extend(mask_key)
        masked = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        self._sock.sendall(bytes(header) + masked)

    def _recv_message_text(self) -> str:
        fragments: list[bytes] = []
        while True:
            b0, b1 = self._recv_exact(2)
            fin = bool(b0 & 0x80)
            opcode = b0 & 0x0F
            masked = bool(b1 & 0x80)
            length = b1 & 0x7F
            if length == 126:
                (length,) = struct.unpack(">H", self._recv_exact(2))
            elif length == 127:
                (length,) = struct.unpack(">Q", self._recv_exact(8))
            mask_key = self._recv_exact(4) if masked else b""
            data = self._recv_exact(length) if length > 0 else b""
            if masked:
                data = bytes(b ^ mask_key[i % 4] for i, b in enumerate(data))

            if opcode == 0x8:  # Close
                raise EOFError("浏览器页面连接已关闭")
            if opcode == 0x9:  # Ping -> Pong
                self._send_frame(0xA, data)
                continue
            if opcode == 0xA:  # Pong
                continue
            fragments.append(data)
            if fin:
                return b"".join(fragments).decode("utf-8", errors="replace")

    def call(self, method: str, params: dict[str, object] | None = None) -> dict[str, object]:
        req_id = self._next_id
        self._next_id += 1
        msg = json.dumps({"id": req_id, "method": method, "params": params or {}})
        self._send_frame(0x1, msg.encode("utf-8"))
        while True:
            raw = self._recv_message_text()
            obj = json.loads(raw)
            if obj.get("id") == req_id:
                if "error" in obj:
                    raise RuntimeError(f"CDP Error: {obj['error']}")
                return obj.get("result", {})  # type: ignore[return-value]


# Read-only DOM & state inspection script executed on birdreport.cn pages.
# NEVER clicks or bypasses any verification/CAPTCHA widget — if a verification dialog is visible,
# simply reports `stage: "waiting_verify"` so the user can complete it in the visible window.
_INSPECT_PAGE_JS_TPL = r"""
(function(expectedSerial) {
    var href = window.location.href || '';
    var path = window.location.pathname || '';

    // Check if official human verification modal is currently visible
    var verifyEl = document.querySelector('.tac-box, #tac-box, .layui-layer-page #code, .captcha-modal');
    var isVerifyVisible = !!(verifyEl && verifyEl.offsetParent !== null);

    // 1. On Search Report Page (/home/search/report.html)
    if (path.indexOf('/search/report.html') !== -1) {
        var links = document.querySelectorAll('a.safe-report-link');
        for (var i = 0; i < links.length; i++) {
            var a = links[i];
            var txt = (a.innerText || a.textContent || '').trim();
            var param = a.getAttribute('data-param') || '';
            var sign = a.getAttribute('data-sign') || '';
            if (param && sign && (!expectedSerial || txt === expectedSerial)) {
                window.location.href = '/home/record/page.html?param=' + param + '&sign=' + sign;
                return JSON.stringify({stage: 'jumping_to_report', serial_id: txt});
            }
        }
        if (isVerifyVisible) {
            return JSON.stringify({stage: 'waiting_verify'});
        }
        var emptyEl = document.querySelector('.layui-table-main .layui-none');
        if (emptyEl && (emptyEl.innerText || '').indexOf('无') !== -1) {
            return JSON.stringify({stage: 'not_found', msg: '未查询到报告编号 ' + expectedSerial + '（请确认编号正确且该报告为公开状态）'});
        }
        return JSON.stringify({stage: 'loading_search'});
    }

    // 2. On Report Detail Page (/home/record/page.html)
    if (path.indexOf('/record/page.html') !== -1) {
        var serialSpan = document.getElementById('serialid');
        var serialTxt = serialSpan ? (serialSpan.innerText || '').trim() : '';
        var timeBegin = (document.getElementById('timebegin')?.innerText || '').trim();
        var timeEnd = (document.getElementById('timeend')?.innerText || '').trim();
        var pointName = (document.getElementById('pointname')?.innerText || '').trim();
        var noteTxt = (document.getElementById('note')?.innerText || '').trim();
        var taxonCntTxt = (document.getElementById('taxoncount')?.innerText || '').trim();
        var expectedCnt = parseInt(taxonCntTxt, 10) || 0;

        // Prefer Layui's in-memory table data array (contains all rows up to limit: 1500)
        var items = [];
        if (window.layui && window.layui.table && window.layui.table.cache) {
            var cacheObj = window.layui.table.cache;
            var gridRows = cacheObj['grid'];
            if (!Array.isArray(gridRows)) {
                var cKeys = Object.keys(cacheObj);
                for (var ck = 0; ck < cKeys.length; ck++) {
                    if (Array.isArray(cacheObj[cKeys[ck]]) && cacheObj[cKeys[ck]].length > 0) {
                        gridRows = cacheObj[cKeys[ck]];
                        break;
                    }
                }
            }
            if (Array.isArray(gridRows) && gridRows.length > 0) {
                for (var j = 0; j < gridRows.length; j++) {
                    var r = gridRows[j];
                    if (r && r.taxon_name) {
                        items.push({
                            taxon_name: String(r.taxon_name || '').trim(),
                            latin_name: String(r.latinname || '').trim(),
                            count_str: String(r.taxon_count != null ? r.taxon_count : '1').trim()
                        });
                    }
                }
            }
        }

        // Fallback to rendered table DOM rows
        if (items.length === 0) {
            var trs = document.querySelectorAll('.taxon-grid .layui-table-body tbody tr');
            for (var k = 0; k < trs.length; k++) {
                var tr = trs[k];
                var cName = tr.querySelector('td[data-field="taxon_name"]')?.innerText?.trim() || '';
                var lName = tr.querySelector('td[data-field="latinname"]')?.innerText?.trim() || '';
                var cCnt = tr.querySelector('td[data-field="taxon_count"]')?.innerText?.trim() || '1';
                if (cName) {
                    items.push({taxon_name: cName, latin_name: lName, count_str: cCnt});
                }
            }
        }

        var noneEl = document.querySelector('.taxon-grid .layui-none');
        if (serialTxt.indexOf('观鸟报告') !== -1 && (items.length > 0 || (expectedCnt === 0 && noneEl))) {
            return JSON.stringify({
                stage: 'done',
                serial_id: serialTxt.replace('观鸟报告', '').trim(),
                start_time: timeBegin,
                end_time: timeEnd,
                address: pointName,
                note: noteTxt,
                items: items
            });
        }

        if (isVerifyVisible) {
            return JSON.stringify({stage: 'waiting_verify'});
        }
        return JSON.stringify({stage: 'loading_report'});
    }

    return JSON.stringify({stage: 'navigating', href: href});
})(%SERIAL_JSON%);
"""


def _wait_for_cdp_ws_url(port: int, proc: subprocess.Popen[bytes], timeout_sec: float = 10.0) -> str:
    deadline = time.monotonic() + timeout_sec
    last_err = ""
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError("浏览器进程已提前退出，请重试。")
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=1.5) as resp:
                targets = json.loads(resp.read().decode("utf-8"))
                for t in targets:
                    if isinstance(t, dict) and t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                        return str(t["webSocketDebuggerUrl"])
        except Exception as exc:
            last_err = str(exc)
        time.sleep(0.2)
    raise RuntimeError(f"连接本地浏览器调试通道超时：{last_err}")


def fetch_birdreport_targets_via_browser(
    targets: list[BirdReportTarget],
    *,
    on_status: Callable[[str], None] | None = None,
    timeout_per_target_sec: float = 120.0,
) -> list[RawBirdReportData]:
    """Fetch one or more BirdReport.cn reports by URL or Serial ID using an Edge/Chrome `--app` window."""
    if not targets:
        raise ValueError("请输入中国观鸟记录中心的报告编号（如 2026112501740）或报告网页链接。")

    browser_exe = find_system_chromium_browser()
    if browser_exe is None:
        raise RuntimeError("未检测到系统浏览器（Microsoft Edge 或 Chrome），无法打开观鸟记录中心页面。")

    port = _pick_free_port()
    profile_dir = _resolve_browser_profile_dir()

    cmd = [
        str(browser_exe),
        f"--app={targets[0].start_url}",
        "--window-size=980,700",
        f"--user-data-dir={profile_dir}",
        f"--remote-debugging-port={port}",
        "--remote-allow-origins=*",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-extensions",
    ]

    if on_status:
        on_status(f"🔄 正在启动观鸟记录中心同步窗口（{targets[0].value[:36]}）...")

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    ws: MiniCDPWebSocket | None = None
    results: list[RawBirdReportData] = []

    try:
        ws_url = _wait_for_cdp_ws_url(port, proc, timeout_sec=12.0)
        ws = MiniCDPWebSocket(ws_url, timeout=8.0)
        ws.call("Page.enable")
        ws.call("Runtime.enable")

        for idx, target in enumerate(targets):
            if idx > 0:
                if on_status:
                    on_status(f"🔄 正在读取第 {idx + 1}/{len(targets)} 篇报告（{target.value[:36]}）...")
                ws.call("Page.navigate", {"url": target.start_url})
                time.sleep(0.4)

            expected_serial = target.value if target.kind == "serial_id" else ""
            js_expr = _INSPECT_PAGE_JS_TPL.replace("%SERIAL_JSON%", json.dumps(expected_serial))

            deadline = time.monotonic() + timeout_per_target_sec
            notified_verify = False

            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError("观鸟记录中心窗口已被关闭，同步已中止。")

                eval_res = ws.call(
                    "Runtime.evaluate",
                    {"expression": js_expr, "returnByValue": True},
                )
                val_str = eval_res.get("result", {}).get("value")  # type: ignore[union-attr]
                if isinstance(val_str, str) and val_str:
                    state = json.loads(val_str)
                    stage = state.get("stage", "")

                    if stage == "waiting_verify":
                        if not notified_verify and on_status:
                            on_status(
                                "🛡 观鸟记录中心请求安全验证：请在弹出的窗口中完成滑块验证，加载出鸟种后将自动读取并关闭窗口..."
                            )
                            notified_verify = True
                    elif stage == "jumping_to_report":
                        if on_status:
                            on_status(f"✓ 已定位报告 {state.get('serial_id', '')}，正在读取全部鸟种明细...")
                        time.sleep(0.5)
                        continue
                    elif stage == "not_found":
                        raise RuntimeError(str(state.get("msg") or f"未找到报告 {target.value}"))
                    elif stage == "done":
                        raw_items = state.get("items") or []
                        sp_list = [
                            RawBirdReportSpecies(
                                taxon_name=str(it.get("taxon_name") or "").strip(),
                                latin_name=str(it.get("latin_name") or "").strip(),
                                count_str=str(it.get("count_str") or "1").strip(),
                            )
                            for it in raw_items
                            if isinstance(it, dict) and str(it.get("taxon_name") or "").strip()
                        ]
                        results.append(
                            RawBirdReportData(
                                serial_id=str(state.get("serial_id") or expected_serial),
                                start_time=str(state.get("start_time") or ""),
                                end_time=str(state.get("end_time") or ""),
                                address=str(state.get("address") or ""),
                                note=str(state.get("note") or ""),
                                species=sp_list,
                            )
                        )
                        break

                time.sleep(0.45)
            else:
                raise RuntimeError(f"等待报告 {target.value} 加载超时，请检查网络或确认该报告为公开状态。")

        try:
            ws.call("Browser.close")
        except Exception:
            pass
        return results
    except EOFError as exc:
        raise RuntimeError("观鸟记录中心窗口已关闭，同步已取消。") from exc
    finally:
        if ws is not None:
            ws.close()
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=2.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

"""Cross-platform application data & cache directory resolution (Windows portable / macOS Application Support / Linux)."""

from __future__ import annotations

import os
import sys
from pathlib import Path


def resolve_app_data_dir() -> Path:
    """Resolve writable directory for `bird_gallery.db` and `.bird_gallery_cache`.

    - Windows frozen `.exe`: next to `BirdGalleryStudio.exe` if writable (portable mode), else `%LOCALAPPDATA%/鸟羽集`.
    - macOS frozen `.app`: `~/Library/Application Support/BirdGalleryStudio` (never mutate inside signed `.app` bundle).
    - Linux frozen binary: `~/.local/share/BirdGalleryStudio`.
    - Source / dev mode: current working directory (with OS user-data fallback if read-only).
    """
    if getattr(sys, "frozen", False):
        if sys.platform == "darwin":
            mac_dir = Path.home() / "Library" / "Application Support" / "BirdGalleryStudio"
            mac_dir.mkdir(parents=True, exist_ok=True)
            return mac_dir

        if os.name == "nt":
            exe_dir = Path(sys.executable).resolve().parent
            probe = exe_dir / ".write_probe_tmp"
            try:
                probe.write_bytes(b"ok")
                probe.unlink(missing_ok=True)
                return exe_dir
            except OSError:
                local_base = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
                legacy_fallback = local_base / "BirdGalleryStudio"
                fallback = legacy_fallback if legacy_fallback.exists() else (local_base / "鸟羽集")
                fallback.mkdir(parents=True, exist_ok=True)
                return fallback

        xdg_base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
        linux_dir = xdg_base / "BirdGalleryStudio"
        linux_dir.mkdir(parents=True, exist_ok=True)
        return linux_dir

    cwd = Path.cwd()
    if sys.platform == "darwin" and str(cwd) == "/":
        mac_dir = Path.home() / "Library" / "Application Support" / "BirdGalleryStudio"
        mac_dir.mkdir(parents=True, exist_ok=True)
        return mac_dir
    return cwd

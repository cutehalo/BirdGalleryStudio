"""Image and camera RAW loading, EXIF + GPS extraction, and thumbnail/preview caching."""

from __future__ import annotations

import hashlib
import io
from datetime import datetime
from pathlib import Path
from typing import Iterator

from PIL import Image, ImageOps

from bird_gallery.config import (
    ALL_SUPPORTED_EXTENSIONS,
    SUPPORTED_IMAGE_EXTENSIONS,
    SUPPORTED_RAW_EXTENSIONS,
)
from bird_gallery.models import ExifMetadata


def is_raw_file(path: Path) -> bool:
    return path.suffix.lower() in SUPPORTED_RAW_EXTENSIONS


def is_supported_file(path: Path, include_raw: bool = True) -> bool:
    ext = path.suffix.lower()
    if include_raw:
        return ext in ALL_SUPPORTED_EXTENSIONS
    return ext in SUPPORTED_IMAGE_EXTENSIONS


def discover_photos(
    root: str | Path,
    *,
    recursive: bool = True,
    include_raw: bool = True,
) -> list[Path]:
    """Discover all supported image/RAW files under a directory or single file using fast os.scandir."""
    import os

    root_path = Path(root).expanduser().resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"Path does not exist: {root_path}")
    if root_path.is_file():
        return [root_path] if is_supported_file(root_path, include_raw=include_raw) else []

    allowed = ALL_SUPPORTED_EXTENSIONS if include_raw else frozenset(SUPPORTED_IMAGE_EXTENSIONS)
    files: list[Path] = []

    def _scan_dir(dir_str: str) -> None:
        try:
            with os.scandir(dir_str) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if recursive and not entry.name.startswith("."):
                                _scan_dir(entry.path)
                        elif entry.is_file(follow_symlinks=False):
                            ext = os.path.splitext(entry.name)[1].lower()
                            if ext in allowed:
                                files.append(Path(entry.path))
                    except OSError:
                        continue
        except OSError:
            return

    _scan_dir(str(root_path))
    files.sort()
    return files


def compute_sha1(path: Path, chunk_size: int = 1 << 20) -> str:
    hasher = hashlib.sha1()
    with path.open("rb") as fh:
        while chunk := fh.read(chunk_size):
            hasher.update(chunk)
    return hasher.hexdigest()


def load_image_for_inference(path: Path) -> Image.Image:
    """Load a standard image or camera RAW file as an EXIF-oriented RGB PIL Image.

    For camera RAW files (CR3/NEF/ARW/RAF/DNG...), extracts the embedded JPEG/bitmap
    preview via rawpy first for 10x+ faster throughput, falling back to half-size
    demosaicing only when no embedded thumbnail exists.
    """
    if is_raw_file(path):
        return _load_raw_preview(path)

    with Image.open(path) as img:
        oriented = ImageOps.exif_transpose(img)
        return oriented.convert("RGB")


def load_preview_image(path: Path, max_edge: int | None = 2560) -> Image.Image:
    """Load an EXIF-oriented RGB image for Lightroom-style single-photo Loupe preview."""
    img = load_image_for_inference(path)
    if max_edge is not None and max(img.size) > max_edge:
        copy_img = img.copy()
        copy_img.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
        return copy_img
    return img


def _load_raw_preview(path: Path) -> Image.Image:
    try:
        import rawpy
    except ImportError as exc:
        raise RuntimeError(
            "Loading camera RAW files requires `rawpy`. Install it with `uv sync`."
        ) from exc

    with rawpy.imread(str(path)) as raw:
        try:
            thumb = raw.extract_thumb()
            if thumb.format == rawpy.ThumbFormat.JPEG:
                with Image.open(io.BytesIO(thumb.data)) as img:
                    oriented = ImageOps.exif_transpose(img)
                    return oriented.convert("RGB")
            if thumb.format == rawpy.ThumbFormat.BITMAP:
                return Image.fromarray(thumb.data).convert("RGB")
        except (rawpy.LibRawNoThumbnailError, rawpy.LibRawUnsupportedThumbnailError):
            pass

        # Fallback: fast half-size demosaic with camera white balance
        rgb = raw.postprocess(half_size=True, use_camera_wb=True, no_auto_bright=True)
        return Image.fromarray(rgb).convert("RGB")


def _parse_ratio(value: object) -> float | None:
    if value is None:
        return None
    if hasattr(value, "num") and hasattr(value, "den"):
        den = float(value.den)
        return float(value.num) / den if den != 0 else None
    text = str(value).strip()
    if "/" in text:
        parts = text.split("/", 1)
        try:
            den = float(parts[1])
            return float(parts[0]) / den if den != 0 else None
        except ValueError:
            return None
    try:
        return float(text)
    except ValueError:
        return None


def _parse_gps_dms(values: object, ref: str) -> float | None:
    """Convert EXIF GPS [deg, min, sec] sequence and hemisphere ref to decimal degrees."""
    if not isinstance(values, (list, tuple)) or len(values) < 3:
        return None
    deg = _parse_ratio(values[0])
    minutes = _parse_ratio(values[1])
    seconds = _parse_ratio(values[2])
    if deg is None or minutes is None or seconds is None:
        return None
    decimal = deg + (minutes / 60.0) + (seconds / 3600.0)
    if ref.strip().upper() in ("S", "W"):
        decimal = -decimal
    return round(decimal, 6)


def _normalize_exif_datetime(raw_value: str | None) -> str | None:
    if not raw_value:
        return None
    cleaned = raw_value.strip()
    # EXIF format is typically "YYYY:MM:DD HH:MM:SS"
    if len(cleaned) >= 19 and cleaned[4] == ":" and cleaned[7] == ":":
        return f"{cleaned[0:4]}-{cleaned[5:7]}-{cleaned[8:10]}T{cleaned[11:19]}"
    if len(cleaned) >= 10 and cleaned[4] == ":" and cleaned[7] == ":":
        return f"{cleaned[0:4]}-{cleaned[5:7]}-{cleaned[8:10]}"
    return cleaned


def derive_taken_date(exif_taken_at: str | None, file_mtime: float) -> str:
    """Derive a YYYY-MM-DD date string from EXIF taken_at, falling back to file mtime."""
    if exif_taken_at and len(exif_taken_at) >= 10 and exif_taken_at[4] == "-" and exif_taken_at[7] == "-":
        return exif_taken_at[:10]
    return datetime.fromtimestamp(file_mtime).strftime("%Y-%m-%d")


def extract_exif(path: Path) -> ExifMetadata:
    """Extract camera/lens/exposure/GPS EXIF metadata for both standard images and RAW files."""
    meta = ExifMetadata()
    try:
        import exifread

        with path.open("rb") as fh:
            tags = exifread.process_file(fh, details=False)
        if tags:
            dt = tags.get("EXIF DateTimeOriginal") or tags.get("Image DateTime")
            meta.taken_at = _normalize_exif_datetime(str(dt)) if dt else None
            make = tags.get("Image Make")
            model = tags.get("Image Model")
            lens = tags.get("EXIF LensModel")
            meta.camera_make = str(make).strip() if make else None
            meta.camera_model = str(model).strip() if model else None
            meta.lens_model = str(lens).strip() if lens else None

            focal = tags.get("EXIF FocalLength")
            if focal and getattr(focal, "values", None):
                val = _parse_ratio(focal.values[0])
                meta.focal_length_mm = round(val, 1) if val is not None else None

            fnum = tags.get("EXIF FNumber")
            if fnum and getattr(fnum, "values", None):
                val = _parse_ratio(fnum.values[0])
                meta.aperture = round(val, 2) if val is not None else None

            exp = tags.get("EXIF ExposureTime")
            meta.shutter_speed = str(exp).strip() if exp else None

            iso = tags.get("EXIF ISOSpeedRatings")
            if iso:
                try:
                    meta.iso = int(str(iso).strip().split()[0])
                except ValueError:
                    pass

            lat_tag = tags.get("GPS GPSLatitude")
            lat_ref = str(tags.get("GPS GPSLatitudeRef") or "N")
            lon_tag = tags.get("GPS GPSLongitude")
            lon_ref = str(tags.get("GPS GPSLongitudeRef") or "E")
            if lat_tag and lon_tag and getattr(lat_tag, "values", None) and getattr(lon_tag, "values", None):
                lat = _parse_gps_dms(lat_tag.values, lat_ref)
                lon = _parse_gps_dms(lon_tag.values, lon_ref)
                if lat is not None and lon is not None:
                    meta.gps_lat = lat
                    meta.gps_lon = lon
    except Exception:
        pass

    return meta


def save_thumbnail(
    image: Image.Image,
    source_path: Path,
    thumbnail_dir: Path,
    max_size: int = 512,
) -> Path:
    """Generate and persist a compact JPEG thumbnail keyed by source path."""
    thumbnail_dir.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha1(str(source_path.resolve()).encode("utf-8")).hexdigest()[:16]
    thumb_path = thumbnail_dir / f"{key}.jpg"

    thumb = image.copy()
    thumb.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
    thumb.save(thumb_path, format="JPEG", quality=85, optimize=True)
    return thumb_path

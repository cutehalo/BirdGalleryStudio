"""PySide6 desktop GUI package for Bird Gallery."""

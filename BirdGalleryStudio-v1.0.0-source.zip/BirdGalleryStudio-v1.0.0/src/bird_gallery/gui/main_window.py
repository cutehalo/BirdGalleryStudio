"""Main Lightroom-style Desktop Window with 100% non-blocking async folder & thumbnail streaming."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction, QCloseEvent, QIcon, QImage, QKeySequence, QShortcut, QShowEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QButtonGroup,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSlider,
    QSplitter,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.catalog import CatalogService
from bird_gallery.checklists import PersonalChecklistService
from bird_gallery.config import EngineConfig
from bird_gallery.db import GalleryDatabase
from bird_gallery.ebird import EBirdLocationService
from bird_gallery.exporter import ArchiveExporter
from bird_gallery.gui.checklist_dialog import ChecklistManagerDialog
from bird_gallery.gui.field_guide_view import FieldGuideView
from bird_gallery.gui.inspector_panel import InspectorPanel
from bird_gallery.gui.location_dialog import LocationManagerDialog
from bird_gallery.gui.navigator_panel import FastFolderPickerDialog, NavigatorPanel
from bird_gallery.gui.preview_canvas import LoupePreviewWidget
from bird_gallery.gui.theme import (
    enable_windows_dark_titlebar,
    render_brand_logo_pixmap,
    render_photo_card_from_qimage,
)
from bird_gallery.gui.workers import (
    DiskFolderScanWorker,
    ImportFolderWorker,
    ThumbnailStreamWorker,
    WorkerTracker,
)
from bird_gallery.models import FilterQuery, PhotoRecord, ScanSummary
from bird_gallery.taxonomy import TaxonomyMapper
from bird_gallery.undo import MAX_UNDO_STEPS, UndoManager


class ImportFolderDialog(QDialog):
    """Optional metadata preset dialog when importing a folder of bird photos."""

    def __init__(self, parent: QWidget, folder: Path, catalog: CatalogService) -> None:
        super().__init__(parent)
        self.setWindowTitle("导入照片文件夹到图库")
        self.setMinimumWidth(440)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        lbl_folder = QLabel(str(folder))
        lbl_folder.setWordWrap(True)
        lbl_folder.setStyleSheet("color: #8ab4f8; font-weight: 600;")
        form.addRow("目标目录:", lbl_folder)

        self.combo_location = QComboBox()
        self.combo_location.setEditable(True)
        self.combo_location.addItem("", "")
        for fav in catalog.db.list_favorite_locations():
            admin_part = f" · {fav.admin_label}" if fav.admin_label else ""
            tag = f" [{fav.ebird_loc_id}]" if fav.ebird_loc_id else ""
            self.combo_location.addItem(f"⭐ {fav.name}{admin_part}{tag}", fav.name)
        if self.combo_location.lineEdit():
            self.combo_location.lineEdit().setPlaceholderText("可选：下拉选常用点，或手输本次观鸟点（如：北京·圆明园）")
        form.addRow("默认观鸟点:", self.combo_location)

        self.combo_album = QComboBox()
        self.combo_album.addItem("（不自动加入相册）", None)
        for alb in catalog.list_albums():
            self.combo_album.addItem(alb.name, alb.album_id)
        form.addRow("加入相册:", self.combo_album)

        layout.addLayout(form)

        note = QLabel("说明：原图保持在原磁盘位置不动，软件仅在后台提取预览缩略图与 EXIF/GPS 建立索引。")
        note.setWordWrap(True)
        note.setStyleSheet("color: #9da3ae; font-size: 12px; padding-top: 4px;")
        layout.addWidget(note)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("开始导入")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class MainWindow(QMainWindow):
    """Primary Lightroom-inspired Bird Gallery desktop application window."""

    def __init__(
        self,
        db_path: Path = Path("bird_gallery.db"),
        thumbnail_dir: Path = Path(".bird_gallery_cache/thumbs"),
        taxonomy_csv: Path | None = None,
    ) -> None:
        super().__init__()
        self.db_path = db_path.resolve()
        self.thumbnail_dir = thumbnail_dir.resolve()
        self.config = EngineConfig(
            db_path=self.db_path,
            thumbnail_dir=self.thumbnail_dir,
            taxonomy_csv=taxonomy_csv,
        )
        self.db = GalleryDatabase(self.db_path)
        self.taxonomy = TaxonomyMapper(taxonomy_csv)
        self.catalog = CatalogService(self.db, self.taxonomy, self.config)
        self.ebird_service = EBirdLocationService(self.db)
        self.checklist_service = PersonalChecklistService(self.db, self.taxonomy, self.ebird_service)
        self.undo_manager = UndoManager(self.db, max_steps=MAX_UNDO_STEPS)

        self._worker_tracker = WorkerTracker(self)
        self._active_scan_worker: DiskFolderScanWorker | None = None
        self._active_thumb_worker: ThumbnailStreamWorker | None = None
        self._import_worker: ImportFolderWorker | None = None
        self._view_request_id = 0

        self._base_query = FilterQuery()
        self._current_view_title = "全部照片"
        self._current_photos: list[PhotoRecord] = []
        self._disk_preview_mode = False
        self._disk_preview_folder: str = ""
        self._thumb_size = 176

        # In-memory caches (never block UI thread on disk reads)
        self._qimage_cache: dict[tuple[str, int], QImage] = {}  # (file_path, box_size) -> pre-scaled QImage
        self._placeholder_cache: dict[tuple[int, bool, tuple[str, ...], int, int], QIcon] = {}

        self._syncing_selection = False

        self.setWindowTitle("鸟羽集")
        self.resize(1500, 920)

        self._build_central_workspace()
        self._build_statusbar()
        self._register_shortcuts()

        self.refresh_all()

    def showEvent(self, event: QShowEvent) -> None:
        super().showEvent(event)
        enable_windows_dark_titlebar(self)

    # ---------------- UI Construction ----------------

    def _build_header_bar(self) -> QFrame:
        header = QFrame()
        header.setObjectName("TopHeaderBar")
        header.setFixedHeight(52)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(14, 7, 14, 7)
        h_layout.setSpacing(8)

        # Left Zone: Studio Brand + Primary Actions
        lbl_logo = QLabel()
        lbl_logo.setPixmap(render_brand_logo_pixmap(26))
        lbl_logo.setFixedSize(26, 26)
        h_layout.addWidget(lbl_logo)

        lbl_brand = QLabel("鸟羽集")
        lbl_brand.setStyleSheet("font-size: 15px; font-weight: 800; color: #F8FAFC; letter-spacing: 1px;")
        h_layout.addWidget(lbl_brand)

        div_left = QFrame()
        div_left.setFixedSize(1, 18)
        div_left.setStyleSheet("background-color: #232C3D;")
        h_layout.addWidget(div_left)

        self.btn_import = QPushButton("＋ 导入照片")
        self.btn_import.setObjectName("PrimaryButton")
        self.btn_import.clicked.connect(self._prompt_import_folder)
        h_layout.addWidget(self.btn_import)

        self.btn_locations = QPushButton("鸟点地图")
        self.btn_locations.setObjectName("SubtleActionBtn")
        self.btn_locations.setToolTip("管理常用观鸟点、关联 eBird 热点与交互式地图选点")
        self.btn_locations.clicked.connect(self._open_location_manager_dialog)
        h_layout.addWidget(self.btn_locations)

        self.btn_checklists = QPushButton("观鸟报告")
        self.btn_checklists.setObjectName("SubtleActionBtn")
        self.btn_checklists.setToolTip("输入中国观鸟记录中心报告ID/链接或导入表格，归类时自动联动报告鸟种")
        self.btn_checklists.clicked.connect(lambda: self._open_checklist_manager_dialog())
        h_layout.addWidget(self.btn_checklists)

        self.btn_export = QPushButton("归档导出")
        self.btn_export.setObjectName("SubtleActionBtn")
        self.btn_export.setToolTip("按「目 / 科 / 鸟种」目录结构自动导出已归类鸟片")
        self.btn_export.clicked.connect(self._prompt_export_archive)
        h_layout.addWidget(self.btn_export)

        self.btn_undo = QPushButton("↶ 撤销")
        self.btn_undo.setObjectName("SubtleActionBtn")
        self.btn_undo.setEnabled(False)
        self.btn_undo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_undo.clicked.connect(self.trigger_undo)
        h_layout.addWidget(self.btn_undo)
        self.undo_manager.add_listener(self._refresh_undo_button_ui)
        self._refresh_undo_button_ui()

        h_layout.addStretch(1)

        # Center Zone: Segmented Pill Mode Switcher
        mode_capsule = QFrame()
        mode_capsule.setObjectName("SegmentedCapsule")
        cap_layout = QHBoxLayout(mode_capsule)
        cap_layout.setContentsMargins(3, 3, 3, 3)
        cap_layout.setSpacing(2)

        self.btn_mode_grid = QPushButton("网格  G")
        self.btn_mode_loupe = QPushButton("精修  E")
        self.btn_mode_guide = QPushButton("图鉴  B")
        for b in (self.btn_mode_grid, self.btn_mode_loupe, self.btn_mode_guide):
            b.setObjectName("SegmentBtn")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            cap_layout.addWidget(b)
        self.btn_mode_grid.setChecked(True)
        h_layout.addWidget(mode_capsule)

        self.mode_group = QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.mode_group.addButton(self.btn_mode_grid, 0)
        self.mode_group.addButton(self.btn_mode_loupe, 1)
        self.mode_group.addButton(self.btn_mode_guide, 2)
        self.mode_group.idClicked.connect(self._switch_center_mode)

        h_layout.addStretch(1)

        # Right Zone: Spotlight Search + Filter & Zoom Controls
        self.search_box = QLineEdit()
        self.search_box.setObjectName("SpotlightSearch")
        self.search_box.setPlaceholderText("搜索鸟种 / 拼音 / 观鸟点 / 文件名...")
        self.search_box.setClearButtonEnabled(True)
        self.search_box.setMinimumWidth(200)
        self.search_box.setMaximumWidth(260)
        self.search_box.textChanged.connect(self._reload_grid)
        h_layout.addWidget(self.search_box)

        self.combo_min_rating = QComboBox()
        self.combo_min_rating.addItem("全部星级", None)
        for r in range(1, 6):
            self.combo_min_rating.addItem(f"{'★' * r}  {r}星+", r)
        self.combo_min_rating.currentIndexChanged.connect(self._reload_grid)
        h_layout.addWidget(self.combo_min_rating)

        self.combo_sort = QComboBox()
        self.combo_sort.addItem("最新拍摄", "taken_at_desc")
        self.combo_sort.addItem("最早拍摄", "taken_at_asc")
        self.combo_sort.addItem("文件名", "name_asc")
        self.combo_sort.addItem("高星优先", "rating_desc")
        self.combo_sort.currentIndexChanged.connect(self._reload_grid)
        h_layout.addWidget(self.combo_sort)

        lbl_zoom_hint = QLabel("尺寸")
        lbl_zoom_hint.setStyleSheet("color: #64748B; font-size: 11px; padding-left: 4px;")
        h_layout.addWidget(lbl_zoom_hint)

        self.slider_thumb = QSlider(Qt.Orientation.Horizontal)
        self.slider_thumb.setRange(120, 260)
        self.slider_thumb.setValue(self._thumb_size)
        self.slider_thumb.setFixedWidth(82)
        self.slider_thumb.setTracking(False)
        self.slider_thumb.valueChanged.connect(self._on_thumb_size_changed)
        h_layout.addWidget(self.slider_thumb)

        return header

    def _build_central_workspace(self) -> None:
        root_shell = QWidget()
        shell_layout = QVBoxLayout(root_shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        shell_layout.addWidget(self._build_header_bar())

        splitter = QSplitter(Qt.Orientation.Horizontal)
        shell_layout.addWidget(splitter, 1)
        self.setCentralWidget(root_shell)

        # 1. Left Navigator
        self.navigator = NavigatorPanel(self.catalog)
        self.navigator.setMinimumWidth(250)
        self.navigator.setMaximumWidth(350)
        self.navigator.filter_selected.connect(self._on_nav_filter_selected)
        self.navigator.open_field_guide_requested.connect(lambda: self._switch_center_mode(2))
        self.navigator.open_location_manager_requested.connect(self._open_location_manager_dialog)
        self.navigator.open_checklist_manager_requested.connect(lambda: self._open_checklist_manager_dialog())
        self.navigator.disk_folder_selected.connect(self._on_disk_folder_preview)
        self.navigator.import_disk_folder_requested.connect(self._start_import_folder_with_dialog)
        self.navigator.albums_changed.connect(self._on_albums_changed)
        splitter.addWidget(self.navigator)

        # 2. Center Workspace (Sub-Header + Stacked Views)
        center_wrapper = QWidget()
        center_layout = QVBoxLayout(center_wrapper)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        header_bar = QFrame()
        header_bar.setObjectName("CenterSubHeader")
        header_bar.setFixedHeight(38)
        header_layout = QHBoxLayout(header_bar)
        header_layout.setContentsMargins(16, 0, 16, 0)
        self.lbl_view_header = QLabel("全部照片")
        self.lbl_view_header.setStyleSheet("font-size: 13px; font-weight: 700; color: #F1F5F9; border: none;")
        self.lbl_view_count = QLabel("0 张")
        self.lbl_view_count.setStyleSheet(
            "color: #94A3B8; background-color: #151C2A; border: 1px solid #222C3F; "
            "border-radius: 9px; padding: 2px 10px; font-size: 11px; font-weight: 600;"
        )
        header_layout.addWidget(self.lbl_view_header)
        header_layout.addStretch(1)
        header_layout.addWidget(self.lbl_view_count)
        center_layout.addWidget(header_bar)

        self.center_stack = QStackedWidget()
        center_layout.addWidget(self.center_stack, 1)

        # Stack Page 0: Grid View
        self.grid_list = QListWidget()
        self.grid_list.setObjectName("PhotoGrid")
        self.grid_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.grid_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.grid_list.setMovement(QListWidget.Movement.Static)
        self.grid_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.grid_list.setWordWrap(True)
        self.grid_list.setUniformItemSizes(True)
        self._apply_grid_metrics()
        self.grid_list.itemSelectionChanged.connect(self._on_grid_selection_changed)
        self.grid_list.itemDoubleClicked.connect(lambda _item: self._switch_center_mode(1))
        self.grid_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid_list.customContextMenuRequested.connect(self._on_grid_context_menu)
        self.center_stack.addWidget(self.grid_list)

        # Stack Page 1: Loupe Single Preview + Bottom Filmstrip
        loupe_splitter = QSplitter(Qt.Orientation.Vertical)
        self.loupe_widget = LoupePreviewWidget()
        self.loupe_widget.back_to_grid_requested.connect(lambda: self._switch_center_mode(0))
        self.loupe_widget.prev_requested.connect(lambda: self._step_photo(-1))
        self.loupe_widget.next_requested.connect(lambda: self._step_photo(1))
        loupe_splitter.addWidget(self.loupe_widget)

        self.filmstrip = QListWidget()
        self.filmstrip.setObjectName("FilmstripGrid")
        self.filmstrip.setViewMode(QListWidget.ViewMode.IconMode)
        self.filmstrip.setFlow(QListWidget.Flow.LeftToRight)
        self.filmstrip.setWrapping(False)
        self.filmstrip.setMovement(QListWidget.Movement.Static)
        self.filmstrip.setUniformItemSizes(True)
        self.filmstrip.setIconSize(QSize(96, 96))
        self.filmstrip.setGridSize(QSize(112, 122))
        self.filmstrip.setFixedHeight(138)
        self.filmstrip.currentRowChanged.connect(self._on_filmstrip_row_changed)
        loupe_splitter.addWidget(self.filmstrip)
        loupe_splitter.setStretchFactor(0, 1)
        loupe_splitter.setStretchFactor(1, 0)
        self.center_stack.addWidget(loupe_splitter)

        # Stack Page 2: Bird Field Guide View
        self.field_guide_view = FieldGuideView(self.catalog)
        self.field_guide_view.species_selected.connect(self._jump_to_species_photos)
        self.field_guide_view.assign_selected_photos_to_species.connect(self._batch_assign_species_from_guide)
        self.center_stack.addWidget(self.field_guide_view)

        splitter.addWidget(center_wrapper)

        # 3. Right Inspector
        self.inspector = InspectorPanel(self.catalog, undo_manager=self.undo_manager)
        self.inspector.photos_modified.connect(self._on_photos_modified)
        self.inspector.albums_modified.connect(self._on_albums_changed)
        self.inspector.open_location_manager_requested.connect(self._open_location_manager_dialog)
        self.inspector.open_checklist_manager_requested.connect(self._open_checklist_manager_dialog)
        splitter.addWidget(self.inspector)

        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)
        splitter.setSizes([268, 872, 360])

    def _build_statusbar(self) -> None:
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.lbl_status = QLabel(
            "就绪  ·  快捷键:  Ctrl+Z 撤销(10步)  |  1–5 星级  |  0 清除  |  P 留片  |  X 淘汰  |  G 网格  |  E 精修  |  B 图鉴"
        )
        sb.addWidget(self.lbl_status, 1)

        self.import_progress = QProgressBar()
        self.import_progress.setFixedWidth(240)
        self.import_progress.setVisible(False)
        sb.addPermanentWidget(self.import_progress)

    def _register_shortcuts(self) -> None:
        sc_undo = QShortcut(QKeySequence.StandardKey.Undo, self)
        sc_undo.setContext(Qt.ShortcutContext.WindowShortcut)
        sc_undo.activated.connect(self._shortcut_undo)

        for rating_val in range(0, 6):
            sc = QShortcut(QKeySequence(str(rating_val)), self)
            sc.setContext(Qt.ShortcutContext.WindowShortcut)
            sc.activated.connect(lambda v=rating_val: self._shortcut_rate(v))

        for key, flag in (("P", 1), ("X", -1), ("U", 0)):
            sc = QShortcut(QKeySequence(key), self)
            sc.activated.connect(lambda f=flag: self._shortcut_flag(f))

        QShortcut(QKeySequence("G"), self).activated.connect(lambda: self._switch_center_mode(0))
        QShortcut(QKeySequence("E"), self).activated.connect(lambda: self._switch_center_mode(1))
        QShortcut(QKeySequence("B"), self).activated.connect(lambda: self._switch_center_mode(2))
        QShortcut(QKeySequence(Qt.Key.Key_Left), self).activated.connect(lambda: self._step_photo(-1))
        QShortcut(QKeySequence(Qt.Key.Key_Right), self).activated.connect(lambda: self._step_photo(1))

    def _refresh_undo_button_ui(self) -> None:
        cnt = self.undo_manager.count
        if cnt <= 0:
            self.btn_undo.setEnabled(False)
            self.btn_undo.setText("↶ 撤销")
            self.btn_undo.setToolTip(f"暂无可撤销操作（快捷键 Ctrl+Z，最多支持连续回溯 {MAX_UNDO_STEPS} 步）")
            return

        self.btn_undo.setEnabled(True)
        self.btn_undo.setText(f"↶ 撤销 ({cnt})")
        steps_lines = "\n".join(
            f"  {idx}. {desc}" for idx, desc in enumerate(self.undo_manager.history_descriptions(), start=1)
        )
        self.btn_undo.setToolTip(
            f"点击或按 Ctrl+Z 撤销上一步：{self.undo_manager.latest_description()}\n"
            f"当前可连续回溯 {cnt} / {MAX_UNDO_STEPS} 步：\n{steps_lines}"
        )

    def _shortcut_undo(self) -> None:
        fw = self.focusWidget()
        if isinstance(fw, QLineEdit) and fw.isUndoAvailable():
            fw.undo()
            return
        if isinstance(fw, QPlainTextEdit) and fw.document().isUndoAvailable():
            fw.undo()
            return
        self.trigger_undo()

    def trigger_undo(self) -> bool:
        """Undo the most recent catalog/photo operation (up to 10 steps)."""
        entry = self.undo_manager.undo()
        if entry is None:
            self.lbl_status.setText("当前没有可撤销的操作")
            return False

        rest = self.undo_manager.count
        msg = f"↶ 已撤销：{entry.description}（剩余可回溯 {rest}/{MAX_UNDO_STEPS} 步）"

        if entry.created_album_id is not None:
            self.inspector.refresh_completers()

        self._on_photos_modified(msg)

        # Re-select the restored photo(s) in the active grid if visible
        if entry.photo_ids and self._current_photos:
            target_set = set(entry.photo_ids)
            matched_rows = [
                idx
                for idx, p in enumerate(self._current_photos)
                if p.photo_id is not None and p.photo_id in target_set
            ]
            if matched_rows:
                self._syncing_selection = True
                self.grid_list.clearSelection()
                for r_idx in matched_rows:
                    it = self.grid_list.item(r_idx)
                    if it is not None:
                        it.setSelected(True)
                first_it = self.grid_list.item(matched_rows[0])
                if first_it is not None:
                    self.grid_list.scrollToItem(first_it)
                self.filmstrip.setCurrentRow(matched_rows[0])
                self._syncing_selection = False
                self._on_grid_selection_changed()

        if self.center_stack.currentIndex() == 2:
            self.field_guide_view.refresh()

        self.inspector._show_feedback(msg)
        return True

    def _focus_in_text_editor(self) -> bool:
        fw = self.focusWidget()
        return isinstance(fw, (QLineEdit, QComboBox)) or fw is self.inspector.edit_notes

    def _shortcut_rate(self, rating: int) -> None:
        if self._focus_in_text_editor():
            return
        self.inspector._apply_rating(rating)

    def _shortcut_flag(self, flag: int) -> None:
        if self._focus_in_text_editor():
            return
        self.inspector._apply_pick_flag(flag)

    def closeEvent(self, event: QCloseEvent) -> None:
        self._worker_tracker.cancel_all()
        super().closeEvent(event)

    # ---------------- Data Refresh & View Modes ----------------

    def refresh_all(self) -> None:
        self.navigator.refresh()
        self.inspector.refresh_completers()
        self._reload_grid()
        if self.center_stack.currentIndex() == 2:
            self.field_guide_view.refresh()

    def _switch_center_mode(self, mode_idx: int) -> None:
        self.center_stack.setCurrentIndex(mode_idx)
        self.btn_mode_grid.setChecked(mode_idx == 0)
        self.btn_mode_loupe.setChecked(mode_idx == 1)
        self.btn_mode_guide.setChecked(mode_idx == 2)

        if mode_idx == 1:
            self._refresh_loupe_from_selection()
        elif mode_idx == 2:
            self.lbl_view_header.setText("📖 鸟种图鉴（点亮模式）")
            self.field_guide_view.refresh()
        else:
            self.lbl_view_header.setText(self._current_view_title)

    def _on_nav_filter_selected(self, query: FilterQuery, title: str) -> None:
        self._disk_preview_mode = False
        self._base_query = query
        self._current_view_title = title
        if self.center_stack.currentIndex() == 2:
            self._switch_center_mode(0)
        self._reload_grid()

    def _jump_to_species_photos(self, species_cn: str) -> None:
        self._disk_preview_mode = False
        self._base_query = FilterQuery(exact_species_cn=species_cn)
        self._current_view_title = f"鸟种：{species_cn}"
        self._switch_center_mode(0)
        self._reload_grid()

    def _batch_assign_species_from_guide(self, species_cn: str) -> None:
        selected = self._get_selected_photos()
        ids = self.catalog.ensure_indexed(selected)
        if not ids:
            QMessageBox.information(self, "未选中照片", "请先在网格视图中选中需要归类的照片，再右键图鉴卡片归入。")
            return
        with self.undo_manager.record(ids, f"图鉴归类「{species_cn}」"):
            self.catalog.assign_species(ids, species_cn)
        self._on_photos_modified(f"✓ 已将 {len(ids)} 张照片归入鸟种「{species_cn}」！")
        if self.center_stack.currentIndex() == 2:
            self.field_guide_view.refresh()

    def _apply_grid_metrics(self) -> None:
        s = self._thumb_size
        self.grid_list.setIconSize(QSize(s, s))
        self.grid_list.setGridSize(QSize(s + 22, s + 44))

    def _on_thumb_size_changed(self, value: int) -> None:
        self._thumb_size = value
        self._placeholder_cache.clear()
        self._apply_grid_metrics()
        self._populate_grid_items(preserve_selection=True)

    def _cancel_active_view_workers(self) -> None:
        if self._active_scan_worker is not None:
            self._active_scan_worker.cancel()
            self._active_scan_worker = None
        if self._active_thumb_worker is not None:
            self._active_thumb_worker.cancel()
            self._active_thumb_worker = None

    def _reload_grid(self) -> None:
        if self._disk_preview_mode and self._disk_preview_folder:
            self._start_async_disk_scan(Path(self._disk_preview_folder))
            return

        effective_query = replace(self._base_query)
        kw = self.search_box.text().strip()
        if kw:
            effective_query.keyword = kw
        min_r = self.combo_min_rating.currentData()
        if min_r is not None:
            effective_query.min_rating = int(min_r)
        sort_key = self.combo_sort.currentData()
        if sort_key:
            effective_query.sort_by = str(sort_key)

        prev_selected_ids = {p.photo_id for p in self._get_selected_photos() if p.photo_id is not None}
        self._current_photos = self.db.query_photos(effective_query)
        self.lbl_view_header.setText(self._current_view_title)
        self.lbl_view_count.setText(f"共 {len(self._current_photos)} 张照片")
        self._populate_grid_items(preserve_selection=True, explicit_selected_ids=prev_selected_ids)

    def _make_card_icon(self, photo: PhotoRecord, qimg: QImage | None) -> QIcon:
        sp_list = photo.all_species_cn if photo.has_assigned_species else []
        sp_tuple = tuple(sp_list)
        if qimg is None:
            pkey = (self._thumb_size, photo.is_raw, sp_tuple, photo.rating, photo.pick_flag)
            cached = self._placeholder_cache.get(pkey)
            if cached is not None:
                return cached
            pix = render_photo_card_from_qimage(
                None,
                box_size=self._thumb_size,
                is_raw=photo.is_raw,
                species_list=sp_list,
                rating=photo.rating,
                pick_flag=photo.pick_flag,
                placeholder_text="加载预览…",
            )
            icon = QIcon(pix)
            self._placeholder_cache[pkey] = icon
            return icon

        pix = render_photo_card_from_qimage(
            qimg,
            box_size=self._thumb_size,
            is_raw=photo.is_raw,
            species_list=sp_list,
            rating=photo.rating,
            pick_flag=photo.pick_flag,
        )
        return QIcon(pix)

    def _populate_grid_items(
        self,
        *,
        preserve_selection: bool = False,
        explicit_selected_ids: set[int] | None = None,
    ) -> None:
        """Populate grid cards instantaneously using RAM cache or lightweight placeholders, then stream thumbnails."""
        self._view_request_id += 1
        req_id = self._view_request_id
        self._cancel_active_view_workers()

        prev_ids: set[int] = set()
        if explicit_selected_ids is not None:
            prev_ids = set(explicit_selected_ids)
        elif preserve_selection:
            prev_ids = {p.photo_id for p in self._get_selected_photos() if p.photo_id is not None}

        self._syncing_selection = True
        self.grid_list.setUpdatesEnabled(False)
        self.filmstrip.setUpdatesEnabled(False)
        self.grid_list.clear()
        self.filmstrip.clear()

        pending_thumb_tasks: list[tuple[int, str, str | None]] = []
        first_selected_row = -1
        avail_img_box = max(64, self._thumb_size - 8)

        for idx, photo in enumerate(self._current_photos):
            cached_qimg = self._qimage_cache.get((photo.file_path, avail_img_box))
            icon = self._make_card_icon(photo, cached_qimg)
            if cached_qimg is None:
                pending_thumb_tasks.append((idx, photo.file_path, photo.thumbnail_path))

            short_label = photo.file_name if len(photo.file_name) <= 20 else photo.file_name[:17] + "…"
            item = QListWidgetItem(icon, short_label)
            item.setData(Qt.ItemDataRole.UserRole, idx)
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
            loc_tip = f"\n地点: {photo.display_location}" if photo.display_location else ""
            sp_tip = photo.display_species_full
            item.setToolTip(
                f"{photo.file_name}\n鸟种: {sp_tip}\n日期: {photo.taken_date or '-'}{loc_tip}"
            )
            self.grid_list.addItem(item)

            film_item = QListWidgetItem(icon, short_label)
            film_item.setData(Qt.ItemDataRole.UserRole, idx)
            self.filmstrip.addItem(film_item)

            if photo.photo_id is not None and photo.photo_id in prev_ids:
                item.setSelected(True)
                if first_selected_row < 0:
                    first_selected_row = idx

        if first_selected_row < 0 and self._current_photos:
            self.grid_list.item(0).setSelected(True)
            first_selected_row = 0

        if first_selected_row >= 0:
            self.filmstrip.setCurrentRow(first_selected_row)

        self.grid_list.setUpdatesEnabled(True)
        self.filmstrip.setUpdatesEnabled(True)
        self._syncing_selection = False
        self._on_grid_selection_changed()

        if pending_thumb_tasks:
            worker = ThumbnailStreamWorker(
                req_id,
                pending_thumb_tasks,
                box_size=avail_img_box,
                disk_cache_dir=self.thumbnail_dir / "_disk_preview",
                batch_size=8,
            )
            worker.batch_ready.connect(self._on_thumb_batch_ready)
            self._active_thumb_worker = worker
            self._worker_tracker.start(worker)

    def _on_thumb_batch_ready(self, req_id: int, batch: list[tuple[int, str, QImage]]) -> None:
        if req_id != self._view_request_id:
            return
        avail_img_box = max(64, self._thumb_size - 8)
        # Bound RAM cache size to prevent excessive memory growth
        if len(self._qimage_cache) > 2500:
            self._qimage_cache.clear()

        for row_idx, resolved_thumb, qimg in batch:
            if not (0 <= row_idx < len(self._current_photos)):
                continue
            photo = self._current_photos[row_idx]
            if resolved_thumb and not photo.thumbnail_path:
                photo.thumbnail_path = resolved_thumb
            self._qimage_cache[(photo.file_path, avail_img_box)] = qimg
            icon = self._make_card_icon(photo, qimg)
            if row_idx < self.grid_list.count():
                self.grid_list.item(row_idx).setIcon(icon)
            if row_idx < self.filmstrip.count():
                self.filmstrip.item(row_idx).setIcon(icon)

    def _get_selected_photos(self) -> list[PhotoRecord]:
        selected_items = self.grid_list.selectedItems()
        out: list[PhotoRecord] = []
        for it in selected_items:
            idx = it.data(Qt.ItemDataRole.UserRole)
            if isinstance(idx, int) and 0 <= idx < len(self._current_photos):
                out.append(self._current_photos[idx])
        return out

    def _on_grid_selection_changed(self) -> None:
        if self._syncing_selection:
            return
        selected = self._get_selected_photos()
        self.inspector.set_selected_photos(selected)

        if selected:
            first = selected[0]
            try:
                row = self._current_photos.index(first)
                self._syncing_selection = True
                self.filmstrip.setCurrentRow(row)
                self._syncing_selection = False
            except ValueError:
                pass
            if self.center_stack.currentIndex() == 1:
                self._refresh_loupe_from_selection()

    def _on_filmstrip_row_changed(self, row: int) -> None:
        if self._syncing_selection or not (0 <= row < len(self._current_photos)):
            return
        self._syncing_selection = True
        self.grid_list.clearSelection()
        item = self.grid_list.item(row)
        if item is not None:
            item.setSelected(True)
            self.grid_list.scrollToItem(item)
        self._syncing_selection = False
        self.inspector.set_selected_photos([self._current_photos[row]])
        self.loupe_widget.display_photo_record(self._current_photos[row])

    def _refresh_loupe_from_selection(self) -> None:
        selected = self._get_selected_photos()
        if selected:
            self.loupe_widget.display_photo_record(selected[0])
        elif self._current_photos:
            self.loupe_widget.display_photo_record(self._current_photos[0])

    def _step_photo(self, delta: int) -> None:
        if self._focus_in_text_editor() or not self._current_photos:
            return
        row = self.filmstrip.currentRow()
        if row < 0:
            row = 0
        next_row = max(0, min(len(self._current_photos) - 1, row + delta))
        if next_row != row:
            self.filmstrip.setCurrentRow(next_row)

    def _on_photos_modified(self, status_msg: str = "") -> None:
        if status_msg:
            self.lbl_status.setText(status_msg)
        self.navigator.refresh()

        if self._disk_preview_mode:
            # Refresh edited records in-place without losing disk grid scroll or selection!
            avail_img_box = max(64, self._thumb_size - 8)
            for idx, rec in enumerate(self._current_photos):
                if rec.photo_id is not None:
                    fresh = self.db.get_photo(rec.photo_id, include_detections=False)
                    if fresh is not None:
                        if not fresh.thumbnail_path and rec.thumbnail_path:
                            fresh.thumbnail_path = rec.thumbnail_path
                        self._current_photos[idx] = fresh
                        qimg = self._qimage_cache.get((fresh.file_path, avail_img_box))
                        icon = self._make_card_icon(fresh, qimg)
                        if idx < self.grid_list.count():
                            self.grid_list.item(idx).setIcon(icon)
                        if idx < self.filmstrip.count():
                            self.filmstrip.item(idx).setIcon(icon)

            selected = self._get_selected_photos()
            self.inspector.set_selected_photos(selected)
            if self.center_stack.currentIndex() == 1 and selected:
                self.loupe_widget.display_photo_record(selected[0])
            return

        self._reload_grid()

    def _on_albums_changed(self) -> None:
        self.navigator.refresh()
        self.inspector.refresh_completers()
        self.inspector.set_selected_photos(self._get_selected_photos())

    def _open_location_manager_dialog(self) -> None:
        selected = self._get_selected_photos()
        active_gps: tuple[float, float] | None = None
        for p in selected:
            if p.exif.gps_lat is not None and p.exif.gps_lon is not None:
                active_gps = (p.exif.gps_lat, p.exif.gps_lon)
                break

        dlg = LocationManagerDialog(
            self,
            self.ebird_service,
            active_photo_gps=active_gps,
            has_selected_photos=len(selected) > 0,
        )
        dlg.favorites_changed.connect(self._on_albums_changed)
        dlg.apply_location_requested.connect(
            lambda name, lid, lat, lng, prov="", city="": self.inspector.apply_external_location(
                name, lid, lat, lng, prov, city
            )
        )
        dlg.exec()

    def _open_checklist_manager_dialog(self, initial_date: str = "", initial_loc: str = "") -> None:
        selected = self._get_selected_photos()
        if not initial_date and selected:
            initial_date = selected[0].taken_date or ""
        if not initial_loc and selected:
            initial_loc = selected[0].location_name or ""

        dlg = ChecklistManagerDialog(
            self,
            self.checklist_service,
            initial_date=initial_date,
            initial_location=initial_loc,
        )
        dlg.checklists_changed.connect(self._on_albums_changed)
        dlg.jump_to_date_requested.connect(self._jump_to_date_photos)
        dlg.exec()

    def _jump_to_date_photos(self, obs_date: str) -> None:
        self._disk_preview_mode = False
        self._base_query = FilterQuery(date_prefix=obs_date)
        self._current_view_title = f"观鸟记录日：{obs_date}"
        self._switch_center_mode(0)
        self._reload_grid()

    # ---------------- Live Disk Browser Preview Mode (100% Async) ----------------

    def _on_disk_folder_preview(self, folder_path: str) -> None:
        self._disk_preview_mode = True
        self._disk_preview_folder = folder_path
        if self.center_stack.currentIndex() == 2:
            self._switch_center_mode(0)
        self._start_async_disk_scan(Path(folder_path))

    def _start_async_disk_scan(self, folder: Path) -> None:
        self._view_request_id += 1
        req_id = self._view_request_id
        self._cancel_active_view_workers()

        self.grid_list.clear()
        self.filmstrip.clear()
        self._current_photos = []
        self.lbl_view_header.setText(f"🖴 正在快速扫描目录：{folder} ...")
        self.lbl_view_count.setText("读取中...")

        worker = DiskFolderScanWorker(req_id, folder, self.db_path, max_items=500)
        worker.folder_scanned.connect(self._on_disk_folder_scanned)
        worker.scan_failed.connect(self._on_disk_scan_failed)
        self._active_scan_worker = worker
        self._worker_tracker.start(worker)

    def _on_disk_folder_scanned(
        self,
        req_id: int,
        folder_path: str,
        records_obj: object,
        total_count: int,
    ) -> None:
        if req_id != self._view_request_id or not self._disk_preview_mode:
            return
        records: list[PhotoRecord] = records_obj  # type: ignore[assignment]
        self._current_photos = records
        self.lbl_view_header.setText(f"🖴 磁盘直览：{folder_path}（双击可放大看图，点击左侧导入可归档分类）")
        if total_count > len(records):
            self.lbl_view_count.setText(f"显示前 {len(records)} / 共 {total_count} 张")
        else:
            self.lbl_view_count.setText(f"共 {len(records)} 张")
        self._populate_grid_items(preserve_selection=False)

    def _on_disk_scan_failed(self, req_id: int, folder_path: str, err: str) -> None:
        if req_id != self._view_request_id:
            return
        self.lbl_view_header.setText(f"🖴 无法访问目录：{folder_path}")
        self.lbl_view_count.setText(err)

    # ---------------- Grid Context Menu ----------------

    def _on_grid_context_menu(self, pos) -> None:
        selected = self._get_selected_photos()
        if not selected:
            return

        menu = QMenu(self)
        if self.undo_manager.can_undo:
            act_undo = QAction(f"↶ 撤销：{self.undo_manager.latest_description()} (Ctrl+Z)", self)
            act_undo.triggered.connect(self.trigger_undo)
            menu.addAction(act_undo)
            menu.addSeparator()

        act_loupe = QAction("🔍 单图放大预览 (E)", self)
        act_loupe.triggered.connect(lambda: self._switch_center_mode(1))
        menu.addAction(act_loupe)

        menu.addSeparator()
        act_sp = QAction(f"🦜 批量设置鸟种 ({len(selected)} 张)...", self)
        act_loc = QAction(f"📍 批量设置观鸟点 ({len(selected)} 张)...", self)

        def _quick_sp() -> None:
            text, ok = QInputDialog.getText(self, "设置鸟种", "输入鸟种中文名或拉丁学名：")
            if ok and text.strip():
                ids = self.catalog.ensure_indexed(selected)
                if ids:
                    with self.undo_manager.record(ids, f"批量设置鸟种「{text.strip()}」"):
                        self.catalog.assign_species(ids, text.strip())
                    self._on_photos_modified(f"✓ 已设置鸟种：{text.strip()}")

        def _quick_loc() -> None:
            text, ok = QInputDialog.getText(self, "设置观鸟点", "输入拍摄地点/常用点名称或 eBird L编号：")
            if ok:
                ids = self.catalog.ensure_indexed(selected)
                if ids:
                    with self.undo_manager.record(ids, f"批量设置观鸟点「{text.strip() or '清空'}」"):
                        loc_name, lid = self.ebird_service.apply_location_to_photos(ids, text.strip())
                    tag = f" [eBird:{lid}]" if lid else ""
                    self._on_photos_modified(f"✓ 已设置观鸟点：{loc_name or '已清空'}{tag}")

        act_sp.triggered.connect(_quick_sp)
        act_loc.triggered.connect(_quick_loc)
        menu.addAction(act_sp)
        menu.addAction(act_loc)

        albums = self.catalog.list_albums()
        if albums:
            alb_menu = menu.addMenu("🗂 加入自定义相册")
            for alb in albums:
                act_a = QAction(alb.name, self)

                def _quick_add_alb(_checked: bool = False, aid: int = alb.album_id, aname: str = alb.name) -> None:
                    ids = self.catalog.ensure_indexed(selected)
                    if ids:
                        with self.undo_manager.record(ids, f"加入相册「{aname}」"):
                            self.db.add_photos_to_album(aid, ids)
                        self._on_photos_modified(f"✓ 已加入相册「{aname}」")

                act_a.triggered.connect(_quick_add_alb)
                alb_menu.addAction(act_a)

        menu.exec(self.grid_list.viewport().mapToGlobal(pos))

    # ---------------- Import & Export Dialogs ----------------

    def _prompt_import_folder(self) -> None:
        picker = FastFolderPickerDialog(self, "选择要导入图库的照片文件夹")
        if picker.exec() == QDialog.DialogCode.Accepted:
            folder = picker.selected_folder()
            if folder:
                self._start_import_folder_with_dialog(folder)

    def _start_import_folder_with_dialog(self, folder_str: str) -> None:
        if self._import_worker and self._import_worker.isRunning():
            QMessageBox.information(self, "正在导入", "当前已有导入任务正在后台运行，请稍候。")
            return

        folder = Path(folder_str)
        dlg = ImportFolderDialog(self, folder, self.catalog)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        raw_loc_data = dlg.combo_location.currentData()
        if isinstance(raw_loc_data, str) and raw_loc_data and dlg.combo_location.currentText().startswith("⭐"):
            default_loc = raw_loc_data
        else:
            default_loc = dlg.combo_location.currentText().strip()
        default_alb = dlg.combo_album.currentData()

        self.import_progress.setVisible(True)
        self.import_progress.setRange(0, 0)
        self.btn_import.setEnabled(False)

        worker = ImportFolderWorker(
            self.db_path,
            self.thumbnail_dir,
            folder,
            default_location=default_loc,
            default_album_id=default_alb,
        )
        worker.progress_changed.connect(self._on_import_progress)
        worker.import_finished.connect(self._on_import_finished)
        worker.import_failed.connect(self._on_import_failed)
        self._import_worker = worker
        self._worker_tracker.start(worker)

    def _on_import_progress(self, current: int, total: int, msg: str) -> None:
        self.import_progress.setRange(0, max(1, total))
        self.import_progress.setValue(current)
        self.lbl_status.setText(f"[{current}/{total}] {msg}")

    def _on_import_finished(self, summary_obj: object) -> None:
        self.import_progress.setVisible(False)
        self.btn_import.setEnabled(True)
        summary: ScanSummary = summary_obj  # type: ignore[assignment]
        self._disk_preview_mode = False
        self._base_query = FilterQuery()
        self._current_view_title = "全部照片"
        self.navigator.tabs.setCurrentIndex(0)
        self.refresh_all()
        self.lbl_status.setText(
            f"导入完成：共发现 {summary.total_discovered} 张，新增处理 {summary.processed} 张，"
            f"跳过未变 {summary.skipped_existing} 张（耗时 {summary.elapsed_seconds:.1f}s）"
        )

    def _on_import_failed(self, err: str) -> None:
        self.import_progress.setVisible(False)
        self.btn_import.setEnabled(True)
        QMessageBox.critical(self, "导入失败", err)

    def _prompt_export_archive(self) -> None:
        picker = FastFolderPickerDialog(self, "选择按鸟种导出归档的目标文件夹")
        if picker.exec() != QDialog.DialogCode.Accepted:
            return
        out_dir = picker.selected_folder()
        if not out_dir:
            return
        exporter = ArchiveExporter(self.db, self.taxonomy)
        report = exporter.export(
            out_dir,
            FilterQuery(has_bird=True, include_rejected=False, limit=1_000_000),
            mode="copy",
            folder_template="{order_cn}/{family_cn}/{species_cn}",
            dry_run=False,
        )
        QMessageBox.information(
            self,
            "按鸟种导出完成",
            f"已按「目 / 科 / 鸟种中文名」结构复制归档：\n"
            f"匹配鸟片：{report.total_matched} 张\n"
            f"成功导出：{report.exported} 张\n"
            f"目标位置：{report.output_dir}",
        )

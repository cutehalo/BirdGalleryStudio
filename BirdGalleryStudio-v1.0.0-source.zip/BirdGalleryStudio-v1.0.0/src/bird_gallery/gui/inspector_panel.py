"""Right-side Lightroom-style Inspector Panel for EXIF, Bird Species, Location, Date, and Multi-Albums.

Supports both already-imported catalog photos AND un-imported disk-browser photos via seamless
on-demand SQLite indexing (`catalog.ensure_indexed`).
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from PIL import Image
from PySide6.QtCore import QStringListModel, QTimer, QUrl, Qt, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QCompleter,
    QDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.catalog import CatalogService
from bird_gallery.china_regions import (
    infer_province_city,
    list_cities,
    list_provinces,
    normalize_province_name,
)
from bird_gallery.ebird import EBirdLocationService, suggest_short_spot_name
from bird_gallery.gui.map_picker import MapPickerDialog
from bird_gallery.gui.species_picker_dialog import (
    ChecklistSpeciesPickerDialog,
    QuickAddSpeciesDialog,
)
from bird_gallery.gui.theme import style_completer_popup
from bird_gallery.image_io import derive_taken_date, extract_exif
from bird_gallery.models import BirdingChecklist, ChecklistItem, PhotoRecord
from bird_gallery.undo import UndoManager


class InspectorPanel(QScrollArea):
    """Right sidebar supporting single-photo inspection and multi-photo batch classification."""

    photos_modified = Signal(str)  # Emits human-readable status message after modification
    albums_modified = Signal()  # Emitted when albums are created or membership changes
    open_location_manager_requested = Signal()  # Opens Favorite Spots & eBird Hotspot dialog
    open_checklist_manager_requested = Signal(str, str)  # (obs_date, location_name)

    def __init__(self, catalog: CatalogService, undo_manager: UndoManager | None = None) -> None:
        super().__init__()
        self.catalog = catalog
        self.undo_manager = undo_manager if undo_manager is not None else UndoManager(catalog.db)
        self.ebird_svc = EBirdLocationService(catalog.db)
        self._selected_photos: list[PhotoRecord] = []
        self._recent_species: list[str] = []
        self._current_ebird_loc_id: str | None = None
        self._active_date_str: str = ""
        self._active_date_checklists: list[BirdingChecklist] = []
        self._active_date_items: list[ChecklistItem] = []
        self._updating_checks = False
        self._syncing_loc_admin = False

        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setMinimumWidth(320)
        self.setMaximumWidth(400)

        container = QFrame()
        container.setObjectName("InspectorScrollRoot")
        self.setWidget(container)
        root = QVBoxLayout(container)
        root.setContentsMargins(10, 10, 14, 14)
        root.setSpacing(10)

        def _make_card(title: str, hint: str = "", right_widget: QWidget | None = None) -> tuple[QFrame, QVBoxLayout]:
            card = QFrame()
            card.setObjectName("InspectorCard")
            v = QVBoxLayout(card)
            v.setContentsMargins(12, 11, 12, 12)
            v.setSpacing(8)
            hdr = QHBoxLayout()
            hdr.setSpacing(6)
            lbl_t = QLabel(title)
            lbl_t.setObjectName("CardSectionTitle")
            hdr.addWidget(lbl_t)
            hdr.addStretch(1)
            if hint:
                lbl_h = QLabel(hint)
                lbl_h.setObjectName("CardSectionHint")
                hdr.addWidget(lbl_h)
            if right_widget is not None:
                hdr.addWidget(right_widget)
            v.addLayout(hdr)
            return card, v

        # Selection Hero Card + Toast Feedback
        hero_card = QFrame()
        hero_card.setObjectName("SelectionHeroCard")
        hero_v = QVBoxLayout(hero_card)
        hero_v.setContentsMargins(12, 10, 12, 10)
        hero_v.setSpacing(4)
        self.lbl_selection = QLabel("未选中照片")
        self.lbl_selection.setWordWrap(True)
        self.lbl_selection.setStyleSheet("font-size: 12px; font-weight: 700; color: #F8FAFC; background: transparent;")
        hero_v.addWidget(self.lbl_selection)
        root.addWidget(hero_card)

        self.lbl_feedback = QLabel("")
        self.lbl_feedback.setWordWrap(True)
        self.lbl_feedback.setVisible(False)
        self.lbl_feedback.setStyleSheet(
            "color: #6EE7B7; background-color: #102B23; border: 1px solid #10B981; "
            "padding: 6px 10px; border-radius: 8px; font-weight: 600; font-size: 12px;"
        )
        root.addWidget(self.lbl_feedback)

        self._feedback_timer = QTimer(self)
        self._feedback_timer.setSingleShot(True)
        self._feedback_timer.timeout.connect(lambda: self.lbl_feedback.setVisible(False))

        # ---- 1. Rating & Pick/Reject Studio Card ----
        card_rate, rate_layout = _make_card("选片与星级", "快捷键 0–5 · P · X")

        stars_row = QHBoxLayout()
        stars_row.setSpacing(4)
        self._star_buttons: list[QPushButton] = []
        for star_val in range(0, 6):
            label = "0" if star_val == 0 else f"{star_val}★"
            btn = QPushButton(label)
            btn.setObjectName("StarPill")
            btn.setCheckable(True)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setMinimumWidth(30)
            btn.clicked.connect(lambda _checked=False, v=star_val: self._apply_rating(v))
            stars_row.addWidget(btn, 1)
            self._star_buttons.append(btn)
        rate_layout.addLayout(stars_row)

        flag_row = QHBoxLayout()
        flag_row.setSpacing(5)
        self.btn_pick = QPushButton("留片 P")
        self.btn_pick.setObjectName("FlagPickBtn")
        self.btn_unflag = QPushButton("无标 U")
        self.btn_unflag.setObjectName("FlagNeutralBtn")
        self.btn_reject = QPushButton("淘汰 X")
        self.btn_reject.setObjectName("FlagRejectBtn")
        for fb in (self.btn_pick, self.btn_unflag, self.btn_reject):
            fb.setCheckable(True)
            fb.setMinimumWidth(56)
            fb.setStyleSheet("padding: 5px 6px; font-size: 12px;")
            fb.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_pick.clicked.connect(lambda: self._apply_pick_flag(1))
        self.btn_unflag.clicked.connect(lambda: self._apply_pick_flag(0))
        self.btn_reject.clicked.connect(lambda: self._apply_pick_flag(-1))
        flag_row.addWidget(self.btn_pick, 1)
        flag_row.addWidget(self.btn_unflag, 1)
        flag_row.addWidget(self.btn_reject, 1)
        rate_layout.addLayout(flag_row)
        root.addWidget(card_rate)

        # ---- 2. Bird Species Classification (Streamlined Single-Row Input + Multi-Species + Same-Date Reports) ----
        card_species, sp_layout = _make_card("鸟种图鉴归类")

        self.lbl_current_species = QLabel("当前鸟种：-")
        self.lbl_current_species.setWordWrap(True)
        self.lbl_current_species.setStyleSheet("color: #6EE7B7; font-size: 12px; font-weight: 600; background: transparent;")
        sp_layout.addWidget(self.lbl_current_species)

        self.current_species_tags_box = QWidget()
        self.current_species_tags_box.setStyleSheet("background: transparent;")
        self.current_species_tags_layout = QGridLayout(self.current_species_tags_box)
        self.current_species_tags_layout.setContentsMargins(0, 0, 0, 2)
        self.current_species_tags_layout.setSpacing(5)
        self.current_species_tags_box.setVisible(False)
        sp_layout.addWidget(self.current_species_tags_box)

        self.sp_input_row = QHBoxLayout()
        self.sp_input_row.setSpacing(5)

        self.edit_species = QLineEdit()
        self.edit_species.setPlaceholderText("输入鸟名 / 拼音(如 ptcn) / 学名，回车归类")
        self.edit_species.setClearButtonEnabled(True)
        self.edit_species.textEdited.connect(self._on_species_text_edited)
        self.edit_species.returnPressed.connect(self._apply_species)
        self._species_completer_model = QStringListModel(self)
        self._species_completer = QCompleter(self._species_completer_model, self)
        self._species_completer.setCompletionMode(QCompleter.CompletionMode.UnfilteredPopupCompletion)
        self._species_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._species_completer.setMaxVisibleItems(14)
        self._species_completer.activated.connect(self._on_species_completer_activated)
        style_completer_popup(self._species_completer)
        self.edit_species.setCompleter(self._species_completer)
        self.sp_input_row.addWidget(self.edit_species, 1)

        self.btn_plus_species = QPushButton("＋")
        self.btn_plus_species.setFixedSize(32, 30)
        self.btn_plus_species.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_plus_species.setToolTip("支持多鸟共存：输入框已填鸟名时直接追加到当前照片，未填时弹出多选搜索框")
        self.btn_plus_species.setStyleSheet(
            "QPushButton { font-size: 15px; font-weight: 800; padding: 0px; "
            "background-color: #12362B; border: 1px solid #10B981; color: #6EE7B7; border-radius: 7px; } "
            "QPushButton:hover { background-color: #184A3B; border-color: #34D399; color: #FFFFFF; } "
            "QPushButton:disabled { background-color: #151A24; border-color: #222A3A; color: #475569; }"
        )
        self.btn_plus_species.clicked.connect(self._on_plus_add_species)
        self.sp_input_row.addWidget(self.btn_plus_species)
        sp_layout.addLayout(self.sp_input_row)

        # Recent recommendation: strictly ONLY the 1 most recently selected species
        self.recent_species_box = QWidget()
        self.recent_species_box.setStyleSheet("background: transparent;")
        self.recent_species_layout = QHBoxLayout(self.recent_species_box)
        self.recent_species_layout.setContentsMargins(0, 1, 0, 1)
        self.recent_species_layout.setSpacing(5)
        sp_layout.addWidget(self.recent_species_box)

        # Same-Date Personal Birding Report Section (hidden unless photo's date has reports!)
        sep_cl = QFrame()
        sep_cl.setFixedHeight(1)
        sep_cl.setStyleSheet("background-color: #202838;")
        sp_layout.addWidget(sep_cl)

        self.cl_priority_box = QWidget()
        self.cl_priority_box.setStyleSheet("background: transparent;")
        cl_box_v = QVBoxLayout(self.cl_priority_box)
        cl_box_v.setContentsMargins(0, 2, 0, 0)
        cl_box_v.setSpacing(5)

        cl_hdr_row = QHBoxLayout()
        cl_hdr_row.setSpacing(4)
        self.lbl_cl_banner = QLabel("观鸟报告")
        self.lbl_cl_banner.setWordWrap(True)
        self.lbl_cl_banner.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 600; background: transparent;")
        cl_hdr_row.addWidget(self.lbl_cl_banner, 1)

        self.btn_apply_cl_loc = QPushButton("套用地点")
        self.btn_apply_cl_loc.setVisible(False)
        self.btn_apply_cl_loc.clicked.connect(self._apply_checklist_location_to_photos)

        self.btn_open_cl_mgr = QPushButton("＋ 添加报告")
        self.btn_open_cl_mgr.setObjectName("SubtleActionBtn")
        self.btn_open_cl_mgr.setToolTip("手动添加或输入观鸟记录中心报告ID/链接获取该日期观鸟报告")
        self.btn_open_cl_mgr.setStyleSheet("font-size: 11px; padding: 2px 8px;")
        self.btn_open_cl_mgr.clicked.connect(self._request_open_checklist_manager)
        cl_hdr_row.addWidget(self.btn_open_cl_mgr)
        cl_box_v.addLayout(cl_hdr_row)

        self.cl_report_area = QWidget()
        self.cl_report_area.setObjectName("ClReportArea")
        self.cl_report_area.setStyleSheet("background: transparent;")
        self.cl_report_buttons_layout = QVBoxLayout(self.cl_report_area)
        self.cl_report_buttons_layout.setContentsMargins(0, 0, 0, 0)
        self.cl_report_buttons_layout.setSpacing(5)
        self.cl_report_area.setVisible(False)
        cl_box_v.addWidget(self.cl_report_area)

        sp_layout.addWidget(self.cl_priority_box)
        root.addWidget(card_species)

        # ---- 3. Date & Location Studio Card ----
        card_loc, loc_layout = _make_card("时间与观鸟点", "省市 · 地图 · eBird")

        date_row = QHBoxLayout()
        date_row.setSpacing(5)
        self.edit_date = QLineEdit()
        self.edit_date.setPlaceholderText("YYYY-MM-DD (如 2026-10-05)")
        self.edit_date.returnPressed.connect(self._apply_date)
        self.btn_save_date = QPushButton("保存")
        self.btn_save_date.setObjectName("SubtleActionBtn")
        self.btn_save_date.clicked.connect(self._apply_date)
        lbl_dt = QLabel("日期")
        lbl_dt.setStyleSheet("color: #94A3B8; font-size: 12px; background: transparent;")
        date_row.addWidget(lbl_dt)
        date_row.addWidget(self.edit_date, 1)
        date_row.addWidget(self.btn_save_date)
        loc_layout.addLayout(date_row)

        gps_row = QHBoxLayout()
        gps_row.setSpacing(5)
        self.lbl_gps = QLabel("GPS：-")
        self.lbl_gps.setStyleSheet("color: #64748B; font-size: 11px; background: transparent;")
        gps_row.addWidget(self.lbl_gps, 1)

        self.btn_open_ebird_spot = QPushButton("eBird")
        self.btn_open_ebird_spot.setStyleSheet(
            "QPushButton { font-size: 11px; padding: 2px 7px; color: #6EE7B7; background-color: #112A24; "
            "border: 1px solid #1F4E40; border-radius: 5px; }"
        )
        self.btn_open_ebird_spot.setVisible(False)
        self.btn_open_ebird_spot.clicked.connect(self._open_current_ebird_url)
        gps_row.addWidget(self.btn_open_ebird_spot)

        self.btn_map_pick = QPushButton("地图选点")
        self.btn_map_pick.setToolTip("在地图上点击或拖动标记微调拍摄经纬度、省市与观鸟点")
        self.btn_map_pick.setStyleSheet(
            "QPushButton { font-size: 11px; padding: 2px 8px; color: #7DD3FC; background-color: #132234; "
            "border: 1px solid #1E3A5F; border-radius: 5px; font-weight: 600; } "
            "QPushButton:hover { background-color: #1A304A; }"
        )
        self.btn_map_pick.clicked.connect(self._open_map_picker_for_selection)
        gps_row.addWidget(self.btn_map_pick)
        loc_layout.addLayout(gps_row)

        admin_row = QHBoxLayout()
        admin_row.setSpacing(5)
        self.combo_loc_prov = QComboBox()
        self.combo_loc_prov.setEditable(True)
        self.combo_loc_prov.setMinimumContentsLength(4)
        self.combo_loc_prov.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combo_loc_prov.addItem("", "")
        for p in list_provinces():
            self.combo_loc_prov.addItem(p, p)
        self.combo_loc_prov.currentIndexChanged.connect(self._on_inspector_prov_changed)

        self.combo_loc_city = QComboBox()
        self.combo_loc_city.setEditable(True)
        self.combo_loc_city.setMinimumContentsLength(4)
        self.combo_loc_city.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combo_loc_city.addItem("", "")

        style_completer_popup(self.combo_loc_prov.completer())
        style_completer_popup(self.combo_loc_city.completer())

        lbl_pv = QLabel("省")
        lbl_pv.setStyleSheet("color: #94A3B8; font-size: 12px; background: transparent;")
        lbl_ct = QLabel("市")
        lbl_ct.setStyleSheet("color: #94A3B8; font-size: 12px; background: transparent;")
        admin_row.addWidget(lbl_pv)
        admin_row.addWidget(self.combo_loc_prov, 1)
        admin_row.addWidget(lbl_ct)
        admin_row.addWidget(self.combo_loc_city, 1)
        loc_layout.addLayout(admin_row)

        loc_row = QHBoxLayout()
        loc_row.setSpacing(5)
        self.edit_location = QLineEdit()
        self.edit_location.setPlaceholderText("输入常用点 / 搜eBird热点(拼音如 ymy) / L码")
        self.edit_location.setClearButtonEnabled(True)
        self.edit_location.textEdited.connect(self._on_location_text_edited)
        self.edit_location.returnPressed.connect(self._apply_location)
        self._loc_completer_model = QStringListModel(self)
        self._loc_completer = QCompleter(self._loc_completer_model, self)
        self._loc_completer.setCompletionMode(QCompleter.CompletionMode.UnfilteredPopupCompletion)
        self._loc_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._loc_completer.setMaxVisibleItems(14)
        self._loc_completer.activated.connect(self._on_location_completer_activated)
        style_completer_popup(self._loc_completer)
        self.edit_location.setCompleter(self._loc_completer)

        self.btn_save_loc = QPushButton("保存")
        self.btn_save_loc.setObjectName("SubtleActionBtn")
        self.btn_save_loc.clicked.connect(self._apply_location)
        loc_row.addWidget(self.edit_location, 1)
        loc_row.addWidget(self.btn_save_loc)
        loc_layout.addLayout(loc_row)

        self.fav_spots_box = QWidget()
        self.fav_spots_box.setStyleSheet("background: transparent;")
        self.fav_spots_layout = QGridLayout(self.fav_spots_box)
        self.fav_spots_layout.setContentsMargins(0, 2, 0, 0)
        self.fav_spots_layout.setSpacing(4)
        loc_layout.addWidget(self.fav_spots_box)

        self.btn_manage_locations = QPushButton("管理常用观鸟点与 eBird 热点关联...")
        self.btn_manage_locations.setObjectName("SubtleActionBtn")
        self.btn_manage_locations.clicked.connect(self.open_location_manager_requested.emit)
        loc_layout.addWidget(self.btn_manage_locations)

        root.addWidget(card_loc)

        # ---- 4. Multi-Album Membership Studio Card ----
        card_albums, alb_layout = _make_card("所属相册", "支持一图多属")

        self.album_checks_container = QWidget()
        self.album_checks_container.setStyleSheet("background: transparent;")
        self.album_checks_layout = QVBoxLayout(self.album_checks_container)
        self.album_checks_layout.setContentsMargins(2, 0, 2, 2)
        self.album_checks_layout.setSpacing(5)
        alb_layout.addWidget(self.album_checks_container)

        new_alb_row = QHBoxLayout()
        new_alb_row.setSpacing(5)
        self.edit_new_album = QLineEdit()
        self.edit_new_album.setPlaceholderText("新建相册名（如：年度飞版）")
        self.edit_new_album.returnPressed.connect(self._create_and_assign_album)
        self.btn_add_alb = QPushButton("＋ 新建")
        self.btn_add_alb.setObjectName("SubtleActionBtn")
        self.btn_add_alb.clicked.connect(self._create_and_assign_album)
        new_alb_row.addWidget(self.edit_new_album, 1)
        new_alb_row.addWidget(self.btn_add_alb)
        alb_layout.addLayout(new_alb_row)

        root.addWidget(card_albums)

        # ---- 5. Notes & EXIF Metadata Studio Cards ----
        card_notes, notes_layout = _make_card("观鸟手记")
        self.edit_notes = QPlainTextEdit()
        self.edit_notes.setPlaceholderText("记录行为特征、羽色细节、生境或同行鸟友...")
        self.edit_notes.setMaximumHeight(66)
        self.btn_save_notes = QPushButton("保存手记")
        self.btn_save_notes.setObjectName("SubtleActionBtn")
        self.btn_save_notes.clicked.connect(self._apply_notes)
        notes_layout.addWidget(self.edit_notes)
        notes_layout.addWidget(self.btn_save_notes)
        root.addWidget(card_notes)

        card_exif, exif_v = _make_card("光学参数与原片", "EXIF")
        exif_form = QFormLayout()
        exif_form.setContentsMargins(0, 2, 0, 2)
        exif_form.setSpacing(5)
        exif_form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        self.lbl_exif_dim = QLabel("-")
        self.lbl_exif_cam = QLabel("-")
        self.lbl_exif_lens = QLabel("-")
        self.lbl_exif_lens.setWordWrap(True)
        self.lbl_exif_exp = QLabel("-")
        self.lbl_exif_exp.setStyleSheet("color: #7DD3FC; font-weight: 600; background: transparent;")
        self.lbl_exif_time = QLabel("-")
        self.lbl_exif_path = QLabel("-")
        self.lbl_exif_path.setWordWrap(True)
        self.lbl_exif_path.setMinimumWidth(10)
        self.lbl_exif_path.setStyleSheet("color: #64748B; font-size: 11px; background: transparent;")

        for val_w in (self.lbl_exif_dim, self.lbl_exif_cam, self.lbl_exif_lens, self.lbl_exif_exp, self.lbl_exif_time):
            val_w.setMinimumWidth(10)
            if val_w is not self.lbl_exif_exp:
                val_w.setStyleSheet("color: #CBD5E1; font-size: 12px; background: transparent;")

        def _exif_key(txt: str) -> QLabel:
            k = QLabel(txt)
            k.setStyleSheet("color: #64748B; font-size: 11px; background: transparent;")
            return k

        exif_form.addRow(_exif_key("画幅大小"), self.lbl_exif_dim)
        exif_form.addRow(_exif_key("相机机身"), self.lbl_exif_cam)
        exif_form.addRow(_exif_key("拍摄镜头"), self.lbl_exif_lens)
        exif_form.addRow(_exif_key("曝光参数"), self.lbl_exif_exp)
        exif_form.addRow(_exif_key("快门时刻"), self.lbl_exif_time)
        exif_form.addRow(_exif_key("存储路径"), self.lbl_exif_path)
        exif_v.addLayout(exif_form)

        self.btn_reveal = QPushButton("在资源管理器中定位原图")
        self.btn_reveal.setObjectName("SubtleActionBtn")
        self.btn_reveal.clicked.connect(self._reveal_in_explorer)
        exif_v.addWidget(self.btn_reveal)

        root.addWidget(card_exif)
        root.addStretch(1)

        self._seed_recent_species_from_db()
        self.refresh_completers()
        self.set_selected_photos([])

    # ---------------- Helpers & Refreshers ----------------

    def _show_feedback(self, msg: str) -> None:
        self.lbl_feedback.setText(msg)
        self.lbl_feedback.setVisible(True)
        self._feedback_timer.start(3500)

    def _seed_recent_species_from_db(self) -> None:
        self._recent_species = []
        summary = self.catalog.db.get_photographed_species_summary()
        for item in summary[:1]:
            sp = str(item.get("species_cn") or "")
            if sp:
                self._recent_species = [sp]
                break
        self._render_recent_species_buttons()

    def refresh_completers(self) -> None:
        self._render_favorite_spot_buttons()
        self._refresh_date_checklist_priority()

    @staticmethod
    def _clear_layout(layout) -> None:
        while layout.count():
            child = layout.takeAt(0)
            w = child.widget()
            if w is not None:
                w.hide()
                w.setParent(None)
                w.deleteLater()

    def _render_favorite_spot_buttons(self) -> None:
        self._clear_layout(self.fav_spots_layout)

        favs = self.ebird_svc.list_favorites()[:8]
        for idx, fav in enumerate(favs):
            short = fav.name if len(fav.name) <= 9 else fav.name[:8] + "…"
            btn = QPushButton(f"★ {short}")
            btn.setObjectName("SubtleActionBtn")
            admin_tip = f"\n省市: {fav.admin_label}" if fav.admin_label else ""
            ebird_tip = f"\neBird: {fav.ebird_loc_id} ({fav.ebird_loc_name})" if fav.ebird_loc_id else ""
            btn.setToolTip(f"一键设为常用观鸟点：{fav.name}{admin_tip}{ebird_tip}")
            btn.setStyleSheet("font-size: 11px; padding: 3px 6px;")
            btn.clicked.connect(
                lambda _c=False, f=fav: self.apply_external_location(
                    f.name, f.ebird_loc_id or "", f.lat, f.lng, f.province, f.city
                )
            )
            self.fav_spots_layout.addWidget(btn, idx // 2, idx % 2)

    def _on_location_text_edited(self, text: str) -> None:
        kw = text.strip()
        items: list[str] = []
        seen: set[str] = set()

        # 1. Favorite locations first
        kw_low = kw.lower()
        for fav in self.ebird_svc.list_favorites():
            if not kw or kw_low in fav.name.lower() or kw_low in (fav.ebird_loc_name or "").lower() or kw_low in (fav.ebird_loc_id or "").lower():
                tag = f" [{fav.ebird_loc_id}]" if fav.ebird_loc_id else ""
                label = f"⭐ {fav.name}{tag}"
                items.append(label)
                seen.add(fav.name)

        # 2. Cached eBird Hotspots (supports Chinese, English, Pinyin initials, L-code)
        if kw:
            for hs in self.ebird_svc.search_cached_hotspots(kw, limit=15):
                short = suggest_short_spot_name(hs.loc_name, hs.subnational1_code)
                sp_info = f" · {hs.num_species}种" if hs.num_species else ""
                items.append(f"🧭 {short} [{hs.loc_id}{sp_info}]")

        # 3. Historical location names in DB
        for hist in self.catalog.db.list_distinct_location_names():
            if hist not in seen and (not kw or kw_low in hist.lower()):
                items.append(f"📍 {hist}")
                if len(items) >= 22:
                    break

        self._loc_completer_model.setStringList(items[:22])
        if items:
            self._loc_completer.complete()

    def _on_location_completer_activated(self, text: str) -> None:
        def _apply_picked_loc() -> None:
            self.edit_location.setText(text)
            self._apply_location()

        QTimer.singleShot(0, _apply_picked_loc)

    def _request_open_checklist_manager(self) -> None:
        loc_hint = self.edit_location.text().strip()
        self.open_checklist_manager_requested.emit(self._active_date_str, loc_hint)

    def _apply_checklist_location_to_photos(self) -> None:
        for cl in self._active_date_checklists:
            if cl.location_name:
                self.apply_external_location(
                    cl.location_name,
                    cl.ebird_loc_id or "",
                    cl.lat,
                    cl.lng,
                    cl.province,
                    cl.city,
                )
                return

    def _refresh_date_checklist_priority(self) -> None:
        self._clear_layout(self.cl_report_buttons_layout)

        if not self._selected_photos or not self._active_date_str:
            self._active_date_checklists = []
            self._active_date_items = []
            self.lbl_cl_banner.setText("观鸟报告")
            self.lbl_cl_banner.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 600; background: transparent;")
            self.btn_open_cl_mgr.setText("＋ 添加报告")
            self.cl_report_area.setVisible(False)
            return

        loc_pref = self.edit_location.text().strip()
        cls_list, items = self.catalog.db.get_checklist_species_for_date(
            self._active_date_str, preferred_location=loc_pref
        )
        self._active_date_checklists = cls_list
        self._active_date_items = items

        # Rule 1: If no birding report exists on this photo's date, do NOT display any report!
        if not cls_list:
            self.lbl_cl_banner.setText("当日观鸟报告：暂无")
            self.lbl_cl_banner.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 600; background: transparent;")
            self.btn_open_cl_mgr.setText("＋ 添加报告")
            self.cl_report_area.setVisible(False)
            return

        # Rule 2: List 1 compact button per report on this date (date · location · total species count)
        self.lbl_cl_banner.setText(
            "当日观鸟报告" if len(cls_list) == 1 else f"当日观鸟报告（{len(cls_list)} 份）"
        )
        self.lbl_cl_banner.setStyleSheet("color: #6EE7B7; font-size: 11px; font-weight: 700; background: transparent;")
        self.btn_open_cl_mgr.setText("＋ 添加")

        for cl in cls_list:
            loc_raw = (cl.location_name or cl.admin_label or "未填地点").strip()
            loc_disp = loc_raw if len(loc_raw) <= 12 else loc_raw[:11] + "…"
            sp_cnt = cl.species_count or len(cl.items)
            btn_label = f"{cl.obs_date}  ·  {loc_disp}  ·  {sp_cnt}种"
            rep_btn = QPushButton(btn_label)
            rep_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            rep_btn.setToolTip(
                f"点击选择该报告中的鸟种（A–Z 拼音首字母排序 · 支持多选）\n"
                f"观鸟日期：{cl.obs_date}\n"
                f"观鸟地点：{loc_raw}\n"
                f"记录鸟种：共 {sp_cnt} 种"
            )
            rep_btn.setStyleSheet(
                "QPushButton { font-size: 11px; font-weight: 600; padding: 6px 10px; text-align: left; "
                "background-color: #11241E; border: 1px solid #1E4E3F; color: #D1FAE5; border-radius: 7px; } "
                "QPushButton:hover { background-color: #17362C; border-color: #10B981; color: #FFFFFF; }"
            )
            rep_btn.clicked.connect(
                lambda _c=False, cid=cl.checklist_id: self._open_report_species_picker(initial_checklist_id=cid)
            )
            self.cl_report_buttons_layout.addWidget(rep_btn)

        self.cl_report_area.setVisible(True)

    def _on_species_text_edited(self, text: str) -> None:
        import re

        kw = text.strip()
        if not kw:
            # Even with empty input, offer same-date checklist birds if available
            if self._active_date_items:
                top_only = [
                    f"📋 [当日记录·{it.count_str}只] {it.common_name_cn} ({it.scientific_name})"
                    for it in self._active_date_items[:20]
                ]
                self._species_completer_model.setStringList(top_only)
            else:
                self._species_completer_model.setStringList([])
            return

        formatted: list[str] = []
        seen: set[str] = set()

        # 1. TOP PRIORITY: Match species recorded in the user's personal checklist on this photo's date!
        kw_low = kw.lower()
        alpha_kw = re.sub(r"[\s\-_·']", "", kw_low)
        py_alt = alpha_kw.replace("u:", "v").replace("ü", "v")

        if self._active_date_items:
            scored_cl: list[tuple[int, ChecklistItem, object]] = []
            for it in self._active_date_items:
                taxon = self.catalog.taxonomy.lookup_by_cn(it.common_name_cn) or self.catalog.taxonomy.lookup(it.scientific_name)
                if taxon is not None:
                    tier = self.catalog.taxonomy.score_entry(taxon, kw_low, alpha_kw, py_alt)
                    if tier is not None:
                        scored_cl.append((tier, it, taxon))
                elif kw_low in it.common_name_cn.lower() or kw_low in it.scientific_name.lower():
                    scored_cl.append((1, it, None))

            scored_cl.sort(key=lambda x: (x[0], -x[1].count_num))
            for _tier, it, taxon_obj in scored_cl:
                seen.add(it.common_name_cn)
                cnt_lbl = f"·{it.count_str}" if it.count_str else ""
                if taxon_obj is not None:
                    py_tag = f" [{taxon_obj.pinyin_initials}]" if taxon_obj.pinyin_initials else ""  # type: ignore[attr-defined]
                    fam_tag = f" · {taxon_obj.family_cn}" if taxon_obj.family_cn else ""  # type: ignore[attr-defined]
                    formatted.append(
                        f"📋 [当日记录{cnt_lbl}] {it.common_name_cn}{py_tag}{fam_tag} ({taxon_obj.scientific_name})"  # type: ignore[attr-defined]
                    )
                else:
                    formatted.append(f"📋 [当日记录{cnt_lbl}] {it.common_name_cn}")

        # 2. Global + China checklist fallback
        matches = self.catalog.taxonomy.search(kw, limit=25, prefer_china=True)
        for entry in matches:
            if entry.common_name_cn in seen:
                continue
            seen.add(entry.common_name_cn)
            prefix = "" if entry.in_china else "🌏 "
            py_tag = f" [{entry.pinyin_initials}]" if entry.pinyin_initials else ""
            fam_tag = f" · {entry.family_cn}" if entry.family_cn else ""
            formatted.append(
                f"{prefix}{entry.common_name_cn} {py_tag}{fam_tag} ({entry.scientific_name})"
            )
        self._species_completer_model.setStringList(formatted[:28])
        if formatted:
            self._species_completer.complete()

    def _sync_rating_and_flag_ui(self, rating: int | None, flag: int | None) -> None:
        for idx, b in enumerate(self._star_buttons):
            if rating is None:
                b.setChecked(False)
            elif rating == 0:
                b.setChecked(idx == 0)
            else:
                b.setChecked(1 <= idx <= rating)

        self.btn_pick.setChecked(flag is not None and flag > 0)
        self.btn_unflag.setChecked(flag is not None and flag == 0)
        self.btn_reject.setChecked(flag is not None and flag < 0)

    def set_selected_photos(self, photos: list[PhotoRecord]) -> None:
        """Populate inspector for ANY selected photos (both catalog and un-imported disk photos)."""
        self._selected_photos = list(photos)
        has_sel = len(self._selected_photos) > 0

        for widget in (
            *self._star_buttons,
            self.btn_pick,
            self.btn_unflag,
            self.btn_reject,
            self.btn_plus_species,
            self.edit_species,
            self.edit_date,
            self.btn_save_date,
            self.btn_map_pick,
            self.combo_loc_prov,
            self.combo_loc_city,
            self.edit_location,
            self.btn_save_loc,
            self.edit_notes,
            self.btn_save_notes,
            self.btn_reveal,
        ):
            widget.setEnabled(has_sel)

        # Creating a new album is always allowed; button text adapts to whether photos are selected
        self.edit_new_album.setEnabled(True)
        self.btn_add_alb.setEnabled(True)
        self.btn_add_alb.setText("+ 新建并加入" if has_sel else "+ 新建相册")

        if not has_sel:
            self._sync_rating_and_flag_ui(None, None)
            self._current_ebird_loc_id = None
            self._active_date_str = ""
            self._refresh_date_checklist_priority()
            self.btn_open_ebird_spot.setVisible(False)
            self.lbl_selection.setText("未选中照片\n（在中间网格点击或框选照片即可编辑归类）")
            self.lbl_current_species.setText("当前鸟种：-")
            self._render_current_species_tags()
            self._render_recent_species_buttons()
            self.edit_species.clear()
            self.edit_date.clear()
            self._set_inspector_admin_combos("", "")
            self.edit_location.clear()
            self.edit_notes.clear()
            self.lbl_gps.setText("GPS：-")
            self.lbl_exif_dim.setText("-")
            self.lbl_exif_cam.setText("-")
            self.lbl_exif_lens.setText("-")
            self.lbl_exif_exp.setText("-")
            self.lbl_exif_time.setText("-")
            self.lbl_exif_path.setText("-")
            self._rebuild_album_checkboxes([])
            return

        if len(self._selected_photos) == 1:
            p = self._selected_photos[0]
            self._sync_rating_and_flag_ui(p.rating, p.pick_flag)
            # For un-indexed disk photos, lazily read lightweight header EXIF (< 2ms, no pixel decode)
            if p.photo_id is None and p.exif.taken_at is None and p.exif.camera_model is None:
                fp = Path(p.file_path)
                if fp.exists():
                    p.exif = extract_exif(fp)
                    p.taken_date = p.taken_date or derive_taken_date(p.exif.taken_at, p.file_mtime)
                    if (p.width == 0 or p.height == 0) and not p.is_raw:
                        try:
                            with Image.open(fp) as im:
                                p.width, p.height = im.size
                        except Exception:
                            pass

            status_badge = "" if p.photo_id is not None else " [磁盘预览·编辑即自动入库]"
            stars_txt = f" · {'★' * p.rating}" if p.rating > 0 else ""
            flag_txt = " · ⚑留片" if p.pick_flag > 0 else (" · ✕淘汰" if p.pick_flag < 0 else "")
            self.lbl_selection.setText(f"已选：{p.file_name}{stars_txt}{flag_txt}{status_badge}")

            if p.has_assigned_species:
                sp_list = p.all_species_cn
                if len(sp_list) == 1:
                    sci_txt = f" ({p.effective_scientific_name})" if p.effective_scientific_name else ""
                    self.lbl_current_species.setText(f"当前鸟种：{sp_list[0]}{sci_txt}")
                else:
                    self.lbl_current_species.setText(
                        f"当前鸟种（共 {len(sp_list)} 种共存）：{' / '.join(sp_list)}"
                    )
            else:
                self.lbl_current_species.setText("当前鸟种：未归类")
            self.edit_species.clear()
            self._render_current_species_tags()
            self._render_recent_species_buttons()

            self.edit_date.setText(p.taken_date or "")
            self.edit_location.setText(p.location_name or "")
            self.edit_notes.setPlainText(p.notes or "")
            self._active_date_str = (p.taken_date or "")[:10]
            self._refresh_date_checklist_priority()

            eff_prov = p.location_province
            eff_city = p.location_city
            if not eff_prov and (p.exif.gps_lat is not None or p.location_name):
                eff_prov, eff_city = infer_province_city(
                    p.exif.gps_lat, p.exif.gps_lon, text_hint=p.location_name
                )
            self._set_inspector_admin_combos(eff_prov, eff_city)

            # Resolve eBird ID directly from photo or matching favorite location
            ebird_id = p.ebird_loc_id
            if not ebird_id and p.location_name:
                fav = self.catalog.db.get_favorite_location_by_name(p.location_name)
                if fav and fav.ebird_loc_id:
                    ebird_id = fav.ebird_loc_id
            self._current_ebird_loc_id = ebird_id
            if ebird_id:
                self.btn_open_ebird_spot.setText(f"🌐 eBird:{ebird_id}")
                self.btn_open_ebird_spot.setVisible(True)
            else:
                self.btn_open_ebird_spot.setVisible(False)

            if p.exif.gps_lat is not None and p.exif.gps_lon is not None:
                self.lbl_gps.setText(f"GPS：{p.exif.gps_lat:.5f}, {p.exif.gps_lon:.5f}")
            else:
                self.lbl_gps.setText("GPS：无内嵌经纬度")

            size_mb = p.file_size / (1024 * 1024)
            raw_tag = " [RAW]" if p.is_raw else ""
            dim_txt = f"{p.width}×{p.height} · " if (p.width and p.height) else ""
            self.lbl_exif_dim.setText(f"{dim_txt}{size_mb:.1f} MB{raw_tag}")
            cam = " ".join(x for x in (p.exif.camera_make, p.exif.camera_model) if x) or "-"
            self.lbl_exif_cam.setText(cam)
            self.lbl_exif_lens.setText(p.exif.lens_model or "-")
            exp_parts = []
            if p.exif.focal_length_mm:
                exp_parts.append(f"{p.exif.focal_length_mm:.0f}mm")
            if p.exif.aperture:
                exp_parts.append(f"f/{p.exif.aperture}")
            if p.exif.shutter_speed:
                exp_parts.append(f"{p.exif.shutter_speed}s")
            if p.exif.iso:
                exp_parts.append(f"ISO {p.exif.iso}")
            self.lbl_exif_exp.setText(" · ".join(exp_parts) or "-")
            self.lbl_exif_time.setText(p.exif.taken_at or p.taken_date or "-")
            wrappable_path = p.file_path.replace("\\", "\\\u200b").replace("/", "/\u200b")
            self.lbl_exif_path.setText(wrappable_path)
            self.lbl_exif_path.setToolTip(p.file_path)
        else:
            count = len(self._selected_photos)
            ratings = {p.rating for p in self._selected_photos}
            flags = {p.pick_flag for p in self._selected_photos}
            self._sync_rating_and_flag_ui(
                next(iter(ratings)) if len(ratings) == 1 else None,
                next(iter(flags)) if len(flags) == 1 else None,
            )
            self.lbl_selection.setText(f"批量选中 {count} 张照片（点击下方操作将同步应用到全部选中项）")
            distinct_sp: list[str] = []
            for p in self._selected_photos:
                for s in p.all_species_cn:
                    if s not in distinct_sp:
                        distinct_sp.append(s)
            if len(distinct_sp) == 1:
                self.lbl_current_species.setText(f"当前鸟种：{distinct_sp[0]}")
            elif len(distinct_sp) > 1:
                self.lbl_current_species.setText(f"当前鸟种：包含 {len(distinct_sp)} 种鸟类（{' / '.join(distinct_sp[:4])}）")
            else:
                self.lbl_current_species.setText("当前鸟种：均未归类")
            self.edit_species.clear()
            self._render_current_species_tags()
            self._render_recent_species_buttons()

            distinct_dates = {p.taken_date for p in self._selected_photos if p.taken_date}
            only_date = next(iter(distinct_dates)) if len(distinct_dates) == 1 else ""
            self.edit_date.setText(only_date)
            self._active_date_str = (only_date or "")[:10]

            distinct_locs = {p.location_name for p in self._selected_photos if p.location_name}
            self.edit_location.setText(next(iter(distinct_locs)) if len(distinct_locs) == 1 else "")
            distinct_provs = {p.location_province for p in self._selected_photos if p.location_province}
            distinct_cities = {p.location_city for p in self._selected_photos if p.location_city}
            self._set_inspector_admin_combos(
                next(iter(distinct_provs)) if len(distinct_provs) == 1 else "",
                next(iter(distinct_cities)) if len(distinct_cities) == 1 else "",
            )
            self._current_ebird_loc_id = None
            self.btn_open_ebird_spot.setVisible(False)
            self._refresh_date_checklist_priority()

            self.lbl_gps.setText(f"已选 {count} 张照片")
            self.lbl_exif_dim.setText(f"共 {count} 个文件")
            self.lbl_exif_cam.setText("-")
            self.lbl_exif_lens.setText("-")
            self.lbl_exif_exp.setText("-")
            self.lbl_exif_time.setText("-")
            self.lbl_exif_path.setText("-")

        existing_ids = [p.photo_id for p in self._selected_photos if p.photo_id is not None]
        self._rebuild_album_checkboxes(existing_ids, total_selected=len(self._selected_photos))

    # ---------------- Internal Actions (Auto-Indexes Un-Imported Photos!) ----------------

    def _ensure_selected_ids(self) -> list[int]:
        if not self._selected_photos:
            return []
        return self.catalog.ensure_indexed(self._selected_photos)

    def _find_same_date_checklist_for_species(self, species_cn_list: list[str]) -> BirdingChecklist | None:
        """Find a same-date checklist containing any of `species_cn_list` that has location info."""
        if not self._active_date_checklists or not self._active_date_items or not species_cn_list:
            return None
        same_date_names = {it.common_name_cn for it in self._active_date_items}
        matched_names = set(species_cn_list) & same_date_names
        if not matched_names:
            return None

        if len(self._active_date_checklists) == 1:
            only = self._active_date_checklists[0]
            if only.location_name or only.province or only.city:
                return only
            return None

        for cl in self._active_date_checklists:
            if not (cl.location_name or cl.province or cl.city):
                continue
            full = self.catalog.db.get_checklist(cl.checklist_id)
            if full and ({it.common_name_cn for it in full.items} & matched_names):
                return full
        for cl in self._active_date_checklists:
            if cl.location_name or cl.province or cl.city:
                return cl
        return None

    def _auto_complete_location_from_checklist(
        self,
        ids: list[int],
        checklist: BirdingChecklist | None,
        *,
        explicit_from_report: bool = False,
    ) -> str:
        """Auto-fill report birding location onto photos when assigning report species.

        When `explicit_from_report=True` (selected directly from report popup or `📋` dropdown item),
        applies the report's location to all selected `ids`. When `False` (typed species matching a
        same-date report), completes location for selected photos that do not yet have a custom location.
        """
        if checklist is None or not ids:
            return ""
        loc_str = (checklist.location_name or checklist.admin_label or "").strip()
        if not loc_str and not checklist.province and not checklist.city:
            return ""

        if explicit_from_report:
            target_ids = ids
        else:
            unlocated = [
                p.photo_id
                for p in self._selected_photos
                if p.photo_id is not None and not (p.location_name or "").strip()
            ]
            # If ensure_indexed just assigned IDs to previously unindexed disk photos, check DB if needed
            if not unlocated:
                for pid in ids:
                    rec = self.catalog.db.get_photo(pid, include_detections=False)
                    if rec is not None and not (rec.location_name or "").strip():
                        unlocated.append(pid)
            target_ids = unlocated

        if not target_ids:
            return ""

        resolved_name, _lid = self.ebird_svc.apply_location_to_photos(
            target_ids,
            loc_str,
            explicit_ebird_loc_id=checklist.ebird_loc_id or None,
            province=checklist.province,
            city=checklist.city,
            fallback_lat=checklist.lat,
            fallback_lon=checklist.lng,
            override_gps=False,
        )
        if resolved_name:
            self.edit_location.setText(resolved_name)
        if checklist.province or checklist.city:
            self._set_inspector_admin_combos(checklist.province, checklist.city)
        self.refresh_completers()
        return resolved_name or loc_str

    def _on_species_completer_activated(self, text: str) -> None:
        from_report_item = text.strip().startswith("📋")

        def _apply_picked() -> None:
            resolved = self.catalog.resolve_taxon(text)
            self.edit_species.setText(resolved.common_name_cn)
            self._apply_species(explicit_from_report=from_report_item)

        QTimer.singleShot(0, _apply_picked)

    def _apply_rating(self, rating: int) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        desc = "清除星标" if rating == 0 else f"设为 {rating}★ 星标"
        with self.undo_manager.record(ids, desc):
            self.catalog.db.batch_update_attributes(ids, rating=rating)
        msg = f"✓ 已清除星标（{len(ids)} 张）" if rating == 0 else f"✓ 已设为 {rating}★ 星标（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _apply_pick_flag(self, flag: int) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        label = {1: "留片", 0: "无标记", -1: "淘汰"}.get(flag, "")
        with self.undo_manager.record(ids, f"标记为「{label}」"):
            self.catalog.db.batch_update_attributes(ids, pick_flag=flag)
        msg = f"✓ 已标记为「{label}」（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _resolve_typed_species_input(self, text: str) -> str:
        """Resolve typed text, giving top priority to same-date checklist birds for Pinyin/shorthand."""
        import re

        resolved_input = text.strip()
        if (
            self._active_date_items
            and not resolved_input.startswith("📋")
            and self.catalog.taxonomy.lookup_by_cn(resolved_input) is None
            and self.catalog.taxonomy.lookup(resolved_input) is None
        ):
            kw_low = resolved_input.lower()
            alpha_kw = re.sub(r"[\s\-_·']", "", kw_low)
            py_alt = alpha_kw.replace("u:", "v").replace("ü", "v")
            best_cl_match: tuple[int, int, str] | None = None
            for it in self._active_date_items:
                taxon = self.catalog.taxonomy.lookup_by_cn(it.common_name_cn) or self.catalog.taxonomy.lookup(
                    it.scientific_name
                )
                if taxon is not None:
                    tier = self.catalog.taxonomy.score_entry(taxon, kw_low, alpha_kw, py_alt)
                    if tier is not None:
                        cand = (tier, -it.count_num, taxon.common_name_cn)
                        if best_cl_match is None or cand < best_cl_match:
                            best_cl_match = cand
            if best_cl_match is not None:
                resolved_input = best_cl_match[2]
        return resolved_input

    def _apply_species(self, *, explicit_from_report: bool = False) -> None:
        text = self.edit_species.text().strip()
        if not text:
            self._show_feedback("请输入鸟种名称后再点击归入")
            return
        ids = self._ensure_selected_ids()
        if not ids:
            return

        if text.startswith("📋"):
            explicit_from_report = True
        resolved_input = self._resolve_typed_species_input(text)
        preview_taxon = self.catalog.resolve_taxon(resolved_input)

        with self.undo_manager.record(ids, f"归入鸟种「{preview_taxon.common_name_cn}」"):
            entry = self.catalog.assign_species(ids, resolved_input)
            matched_cl = self._find_same_date_checklist_for_species([entry.common_name_cn])
            filled_loc = self._auto_complete_location_from_checklist(
                ids, matched_cl, explicit_from_report=explicit_from_report
            )

        self.edit_species.clear()
        self._push_recent_species(entry.common_name_cn)
        loc_suffix = f"，并自动补全观鸟点「{filled_loc}」" if filled_loc else ""
        msg = f"✓ 已归入鸟种「{entry.common_name_cn}」（{len(ids)} 张）{loc_suffix}"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _apply_quick_species(self, species_cn: str) -> None:
        self.edit_species.setText(species_cn)
        self._apply_species()

    def _append_species_list(
        self,
        species_inputs: list[str],
        *,
        source_checklist: BirdingChecklist | None = None,
        explicit_from_report: bool = False,
    ) -> None:
        cleaned = [s.strip() for s in species_inputs if s and s.strip()]
        if not cleaned:
            return
        ids = self._ensure_selected_ids()
        if not ids:
            return
        preview_names = [self.catalog.resolve_taxon(s).common_name_cn for s in cleaned]
        desc_names = " / ".join(preview_names[:3]) + (" 等" if len(preview_names) > 3 else "")

        filled_loc = ""
        with self.undo_manager.record(ids, f"添加共存鸟种「{desc_names}」"):
            entries = self.catalog.add_species(ids, cleaned)
            if entries:
                cn_list = [e.common_name_cn for e in entries]
                cl_to_use = source_checklist or self._find_same_date_checklist_for_species(cn_list)
                filled_loc = self._auto_complete_location_from_checklist(
                    ids, cl_to_use, explicit_from_report=explicit_from_report
                )

        self.edit_species.clear()
        if entries:
            self._push_recent_species(entries[-1].common_name_cn)
            names_str = " / ".join(e.common_name_cn for e in entries)
            loc_suffix = f"，并自动补全观鸟点「{filled_loc}」" if filled_loc else ""
            msg = f"✓ 已添加共存鸟种「{names_str}」（{len(ids)} 张）{loc_suffix}"
            self._show_feedback(msg)
            self.photos_modified.emit(msg)

    def _set_exact_species_list(
        self,
        species_inputs: list[str],
        *,
        source_checklist: BirdingChecklist | None = None,
        explicit_from_report: bool = False,
    ) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        preview_names = [self.catalog.resolve_taxon(s).common_name_cn for s in species_inputs if s.strip()]
        if preview_names:
            desc_lbl = " / ".join(preview_names[:3]) + (" 等" if len(preview_names) > 3 else "")
            desc = f"设置鸟种「{desc_lbl}」"
        else:
            desc = "清空鸟种标签"

        filled_loc = ""
        with self.undo_manager.record(ids, desc):
            entries = self.catalog.set_species_list(ids, species_inputs)
            if entries:
                cn_list = [e.common_name_cn for e in entries]
                cl_to_use = source_checklist or self._find_same_date_checklist_for_species(cn_list)
                filled_loc = self._auto_complete_location_from_checklist(
                    ids, cl_to_use, explicit_from_report=explicit_from_report
                )

        self.edit_species.clear()
        if entries:
            self._push_recent_species(entries[-1].common_name_cn)
            names_str = " / ".join(e.common_name_cn for e in entries)
            loc_suffix = f"，并自动补全观鸟点「{filled_loc}」" if filled_loc else ""
            msg = f"✓ 已设为鸟种「{names_str}」（{len(ids)} 张）{loc_suffix}"
        else:
            msg = f"✓ 已清除鸟种标签（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _remove_single_species(self, species_cn: str) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        with self.undo_manager.record(ids, f"移除鸟种「{species_cn}」"):
            self.catalog.remove_species(ids, species_cn)
        msg = f"✓ 已移除照片中的鸟种「{species_cn}」（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _on_plus_add_species(self) -> None:
        if not self._selected_photos:
            self._show_feedback("请先在中间网格选中照片后再添加鸟种")
            return
        typed = self.edit_species.text().strip()
        if typed:
            resolved_input = self._resolve_typed_species_input(typed)
            self._append_species_list([resolved_input])
            return

        existing_sp: list[str] = []
        if len(self._selected_photos) == 1:
            existing_sp = list(self._selected_photos[0].all_species_cn)
        else:
            for p in self._selected_photos:
                for s in p.all_species_cn:
                    if s not in existing_sp:
                        existing_sp.append(s)

        dlg = QuickAddSpeciesDialog(
            self.window(),
            self.catalog,
            same_date_items=self._active_date_items,
            already_on_photo=existing_sp,
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._append_species_list(dlg.species_to_add())

    def _open_report_species_picker(self, initial_checklist_id: int | None = None) -> None:
        if not self._selected_photos:
            self._show_feedback("请先在中间网格选中需要归类的照片")
            return
        # Show checklists on this photo's date first (plus any others in combo if needed)
        same_date_cls = list(self._active_date_checklists)
        all_cls = same_date_cls if same_date_cls else self.catalog.db.list_checklists(limit=200)
        if not all_cls:
            self._request_open_checklist_manager()
            return

        if len(self._selected_photos) == 1:
            existing_sp = list(self._selected_photos[0].all_species_cn)
        else:
            common_set = set(self._selected_photos[0].all_species_cn)
            for p in self._selected_photos[1:]:
                common_set &= set(p.all_species_cn)
            existing_sp = [s for s in self._selected_photos[0].all_species_cn if s in common_set]

        dlg = ChecklistSpeciesPickerDialog(
            self.window(),
            self.catalog,
            all_cls,
            preferred_date=self._active_date_str,
            initial_checklist_id=initial_checklist_id,
            existing_photo_species=existing_sp,
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            picked = dlg.selected_species()
            rep_cl = dlg.matched_checklist()
            if dlg.result_mode() == "add":
                self._append_species_list(picked, source_checklist=rep_cl, explicit_from_report=True)
            else:
                self._set_exact_species_list(picked, source_checklist=rep_cl, explicit_from_report=True)

    def _render_current_species_tags(self) -> None:
        self._clear_layout(self.current_species_tags_layout)

        if not self._selected_photos:
            self.current_species_tags_box.setVisible(False)
            return

        tag_counts: dict[str, int] = {}
        ordered_tags: list[str] = []
        for p in self._selected_photos:
            for sp in p.all_species_cn:
                if sp not in tag_counts:
                    tag_counts[sp] = 0
                    ordered_tags.append(sp)
                tag_counts[sp] += 1

        if not ordered_tags:
            self.current_species_tags_box.setVisible(False)
            return

        total_sel = len(self._selected_photos)
        for idx, sp in enumerate(ordered_tags):
            cnt_suffix = f" ({tag_counts[sp]}/{total_sel})" if total_sel > 1 else ""
            pill = QPushButton(f"● {sp}{cnt_suffix}  ×")
            pill.setCursor(Qt.CursorShape.PointingHandCursor)
            pill.setToolTip(f"点击从选中照片中移除鸟种「{sp}」")
            pill.setStyleSheet(
                "QPushButton { font-size: 11px; font-weight: 600; padding: 3px 9px; background-color: #122E26; "
                "border: 1px solid #1F5C48; border-radius: 11px; color: #6EE7B7; } "
                "QPushButton:hover { background-color: #3B1822; border-color: #F43F5E; color: #FDA4AF; }"
            )
            pill.clicked.connect(lambda _c=False, name=sp: self._remove_single_species(name))
            self.current_species_tags_layout.addWidget(pill, idx // 2, idx % 2)

        self.current_species_tags_box.setVisible(True)

    def _clear_species(self) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        with self.undo_manager.record(ids, "清空鸟种标签"):
            self.catalog.clear_species(ids)
        self.edit_species.clear()
        msg = f"✓ 已清除鸟种标签（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _push_recent_species(self, species_cn: str) -> None:
        if not species_cn:
            return
        # Strictly keep ONLY the 1 most recently selected bird species!
        self._recent_species = [species_cn]
        self._render_recent_species_buttons()

    def _render_recent_species_buttons(self) -> None:
        self._clear_layout(self.recent_species_layout)

        if not self._recent_species:
            self.recent_species_box.setVisible(False)
            return

        sp = self._recent_species[0]
        has_sel = len(self._selected_photos) > 0

        lbl = QLabel("最近:")
        lbl.setStyleSheet("color: #64748B; font-size: 11px; background: transparent;")
        self.recent_species_layout.addWidget(lbl)

        btn_set = QPushButton(f"● {sp}")
        btn_set.setObjectName("SubtleActionBtn")
        btn_set.setEnabled(has_sel)
        btn_set.setToolTip(f"一键将选中照片设为最近选择的鸟种「{sp}」")
        btn_set.setStyleSheet("font-size: 11px; padding: 3px 9px; color: #CBD5E1;")
        btn_set.clicked.connect(lambda _c=False, name=sp: self._apply_quick_species(name))
        self.recent_species_layout.addWidget(btn_set, 1)

        btn_add = QPushButton("＋")
        btn_add.setObjectName("SubtleActionBtn")
        btn_add.setFixedWidth(26)
        btn_add.setEnabled(has_sel)
        btn_add.setToolTip(f"将最近选择的「{sp}」作为共存鸟种追加到选中照片")
        btn_add.setStyleSheet("font-size: 12px; font-weight: 700; padding: 2px 0px; color: #6EE7B7;")
        btn_add.clicked.connect(lambda _c=False, name=sp: self._append_species_list([name]))
        self.recent_species_layout.addWidget(btn_add)

        self.recent_species_box.setVisible(True)

    def _apply_date(self) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        new_date = self.edit_date.text().strip()
        with self.undo_manager.record(ids, f"修改拍摄日期 ({new_date or '恢复默认'})"):
            self.catalog.db.batch_update_attributes(ids, manual_date=new_date)
        self._active_date_str = new_date[:10]
        self._refresh_date_checklist_priority()
        msg = f"✓ 已保存拍摄日期：{new_date or '恢复默认'}（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _set_inspector_admin_combos(self, province: str, city: str) -> None:
        self._syncing_loc_admin = True
        try:
            prov_norm = normalize_province_name(province)
            self.combo_loc_prov.setCurrentText(prov_norm)
            self.combo_loc_city.clear()
            self.combo_loc_city.addItem("", "")
            for ce in list_cities(prov_norm):
                self.combo_loc_city.addItem(ce.city, ce.city)
            self.combo_loc_city.setCurrentText(city.strip())
        finally:
            self._syncing_loc_admin = False

    def _on_inspector_prov_changed(self, _idx: int) -> None:
        if self._syncing_loc_admin:
            return
        prov = normalize_province_name(self.combo_loc_prov.currentText())
        self._syncing_loc_admin = True
        try:
            self.combo_loc_city.clear()
            self.combo_loc_city.addItem("", "")
            for ce in list_cities(prov):
                self.combo_loc_city.addItem(ce.city, ce.city)
        finally:
            self._syncing_loc_admin = False

    def _open_map_picker_for_selection(self) -> None:
        if not self._selected_photos:
            return
        init_lat: float | None = None
        init_lng: float | None = None
        for p in self._selected_photos:
            if p.exif.gps_lat is not None and p.exif.gps_lon is not None:
                init_lat, init_lng = p.exif.gps_lat, p.exif.gps_lon
                break

        cur_loc = self.edit_location.text().strip()
        if init_lat is None and cur_loc:
            fav = self.catalog.db.get_favorite_location_by_name(cur_loc)
            if fav and fav.lat is not None and fav.lng is not None:
                init_lat, init_lng = fav.lat, fav.lng

        dlg = MapPickerDialog(
            self.window(),
            self.ebird_svc,
            initial_lat=init_lat,
            initial_lng=init_lng,
            initial_province=self.combo_loc_prov.currentText().strip(),
            initial_city=self.combo_loc_city.currentText().strip(),
            initial_spot_name=cur_loc,
            initial_ebird_id=self._current_ebird_loc_id or "",
            photo_count=len(self._selected_photos),
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            res = dlg.picked_result()
            if res is not None:
                self.apply_external_location(
                    res.spot_name,
                    res.ebird_loc_id or "",
                    res.lat,
                    res.lng,
                    res.province,
                    res.city,
                    override_gps=True,
                )
                if res.save_as_favorite:
                    self.albums_modified.emit()

    def _apply_location(self) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        raw_loc = self.edit_location.text().strip()
        prov = self.combo_loc_prov.currentText().strip()
        city = self.combo_loc_city.currentText().strip()
        with self.undo_manager.record(ids, f"修改观鸟点「{raw_loc or '清空'}」"):
            resolved_name, resolved_lid = self.ebird_svc.apply_location_to_photos(
                ids,
                raw_loc,
                province=prov,
                city=city,
            )
        self.edit_location.setText(resolved_name)
        self.refresh_completers()
        ebird_note = f" (关联 eBird {resolved_lid})" if resolved_lid else ""
        msg = f"✓ 已保存观鸟点：{resolved_name or '已清空'}{ebird_note}（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def apply_external_location(
        self,
        name: str,
        ebird_loc_id: str = "",
        lat: float | None = None,
        lng: float | None = None,
        province: str = "",
        city: str = "",
        *,
        override_gps: bool = False,
    ) -> None:
        """Apply a Favorite Location, eBird Hotspot, or Map-Adjusted Point to selected photos."""
        ids = self._ensure_selected_ids()
        if not ids:
            self._show_feedback("请先选中需要设置观鸟点的照片")
            return
        with self.undo_manager.record(ids, f"设置观鸟点「{name or '清空'}」"):
            resolved_name, resolved_lid = self.ebird_svc.apply_location_to_photos(
                ids,
                name,
                explicit_ebird_loc_id=ebird_loc_id or None,
                province=province,
                city=city,
                fallback_lat=lat,
                fallback_lon=lng,
                override_gps=override_gps,
            )
        self.edit_location.setText(resolved_name)
        if province or city:
            self._set_inspector_admin_combos(province, city)
        self.refresh_completers()
        ebird_note = f" (eBird {resolved_lid})" if resolved_lid else ""
        gps_note = f" · 坐标 {lat:.4f},{lng:.4f}" if (override_gps and lat is not None and lng is not None) else ""
        msg = f"✓ 已设为观鸟点「{resolved_name}」{ebird_note}{gps_note}（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _open_current_ebird_url(self) -> None:
        if self._current_ebird_loc_id:
            QDesktopServices.openUrl(QUrl(f"https://ebird.org/hotspot/{self._current_ebird_loc_id}"))

    def _apply_notes(self) -> None:
        ids = self._ensure_selected_ids()
        if not ids:
            return
        with self.undo_manager.record(ids, "修改观鸟手记"):
            self.catalog.db.batch_update_attributes(ids, notes=self.edit_notes.toPlainText())
        msg = f"✓ 已保存备注（{len(ids)} 张）"
        self._show_feedback(msg)
        self.photos_modified.emit(msg)

    def _rebuild_album_checkboxes(self, existing_photo_ids: list[int], total_selected: int = 0) -> None:
        self._updating_checks = True
        self._clear_layout(self.album_checks_layout)

        albums = self.catalog.list_albums()
        counts = (
            self.catalog.db.get_album_membership_counts(existing_photo_ids)
            if existing_photo_ids
            else {}
        )

        if not albums:
            lbl = QLabel("（暂无自定义相册，在下方输入名称即可新建）")
            lbl.setStyleSheet("color: #6e737b; font-size: 12px;")
            self.album_checks_layout.addWidget(lbl)
        else:
            for alb in albums:
                cb = QCheckBox(f"{alb.name} ({alb.photo_count})")
                cb.setEnabled(total_selected > 0)
                in_cnt = counts.get(alb.album_id, 0)
                if total_selected > 0 and in_cnt == total_selected:
                    cb.setCheckState(Qt.CheckState.Checked)
                elif in_cnt > 0:
                    cb.setTristate(True)
                    cb.setCheckState(Qt.CheckState.PartiallyChecked)
                else:
                    cb.setCheckState(Qt.CheckState.Unchecked)

                cb.clicked.connect(
                    lambda checked, aid=alb.album_id, aname=alb.name, box=cb: self._on_album_check_clicked(
                        aid, aname, checked, box
                    )
                )
                self.album_checks_layout.addWidget(cb)

        self._updating_checks = False

    def _on_album_check_clicked(self, album_id: int, album_name: str, checked: bool, box: QCheckBox) -> None:
        if self._updating_checks:
            return
        box.setTristate(False)
        ids = self._ensure_selected_ids()
        if not ids:
            return
        if checked:
            with self.undo_manager.record(ids, f"加入相册「{album_name}」"):
                self.catalog.db.add_photos_to_album(album_id, ids)
            msg = f"✓ 已加入相册「{album_name}」（{len(ids)} 张）"
        else:
            with self.undo_manager.record(ids, f"移出相册「{album_name}」"):
                self.catalog.db.remove_photos_from_album(album_id, ids)
            msg = f"✓ 已从相册「{album_name}」移出（{len(ids)} 张）"
        self._show_feedback(msg)
        self.albums_modified.emit()
        self.photos_modified.emit(msg)

    def _create_and_assign_album(self) -> None:
        name = self.edit_new_album.text().strip()
        if not name:
            return
        existed_before = any(a.name == name for a in self.catalog.list_albums())
        ids = self._ensure_selected_ids()
        before_snap = self.catalog.db.capture_photos_snapshot(ids) if ids else {}

        alb = self.catalog.db.create_album(name)
        self.edit_new_album.clear()
        if ids:
            self.catalog.db.add_photos_to_album(alb.album_id, ids)
            msg = f"✓ 已新建相册「{alb.name}」并加入 {len(ids)} 张照片"
        else:
            msg = f"✓ 已新建自定义相册「{alb.name}」"

        if not existed_before:
            self.undo_manager.push_album_creation(
                created_album_id=alb.album_id,
                photo_ids=ids,
                before_snapshot=before_snap,
                description=f"新建相册「{alb.name}」",
            )
        elif ids:
            after_snap = self.catalog.db.capture_photos_snapshot(ids)
            if after_snap != before_snap:
                from bird_gallery.undo import UndoEntry

                self.undo_manager._stack.append(
                    UndoEntry(description=f"加入相册「{alb.name}」", photo_ids=ids, before_snapshot=before_snap)
                )
                self.undo_manager._notify()

        self._show_feedback(msg)
        self.albums_modified.emit()
        self.photos_modified.emit(msg)

    def _reveal_in_explorer(self) -> None:
        if not self._selected_photos:
            return
        path = Path(self._selected_photos[0].file_path)
        if not path.exists():
            return
        if os.name == "nt":
            subprocess.Popen(["explorer", f"/select,{path}"])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path.parent)])

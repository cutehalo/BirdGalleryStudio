"""Application entry point for launching the PySide6 Bird Gallery desktop app (Windows .exe & macOS .app)."""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from bird_gallery.gui.main_window import MainWindow
from bird_gallery.gui.theme import DARK_STYLESHEET, enable_windows_dark_titlebar
from bird_gallery.paths import resolve_app_data_dir


def _resolve_portable_base_dir() -> Path:
    return resolve_app_data_dir()


def _resolve_bundled_icon() -> Path | None:
    icon_names = ("app_icon.icns", "app_icon.ico") if sys.platform == "darwin" else ("app_icon.ico", "app_icon.icns")
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        for name in icon_names:
            candidate = Path(meipass) / "data" / name
            if candidate.exists():
                return candidate
    repo_data = Path(__file__).resolve().parents[2] / "data"
    for name in icon_names:
        repo_candidate = repo_data / name
        if repo_candidate.exists():
            return repo_candidate
    return None


def launch_gui(
    db_path: Path | None = None,
    thumbnail_dir: Path | None = None,
    taxonomy_csv: Path | None = None,
    *,
    smoke_test_out: Path | None = None,
) -> int:
    base_dir = _resolve_portable_base_dir()
    resolved_db = db_path or (base_dir / "bird_gallery.db")
    resolved_thumbs = thumbnail_dir or (base_dir / ".bird_gallery_cache" / "thumbs")

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("鸟羽集")
    app.setStyleSheet(DARK_STYLESHEET)

    icon_path = _resolve_bundled_icon()
    if icon_path is not None:
        icon = QIcon(str(icon_path))
        app.setWindowIcon(icon)

    win = MainWindow(
        db_path=resolved_db,
        thumbnail_dir=resolved_thumbs,
        taxonomy_csv=taxonomy_csv,
    )
    win.show()
    enable_windows_dark_titlebar(win)

    if smoke_test_out is not None:
        def _verify_and_quit() -> None:
            from PySide6.QtWebEngineWidgets import QWebEngineView

            wv = QWebEngineView()
            overview = win.catalog.get_field_guide()
            msg = (
                f"SMOKE_OK title={win.windowTitle()} webengine=ok "
                f"species_loaded={overview.total_checklist_count} db={resolved_db}"
            )
            wv.deleteLater()
            smoke_test_out.write_text(msg, encoding="utf-8")
            if sys.stdout is not None:
                print(msg)
            win.close()
            app.quit()

        QTimer.singleShot(300, _verify_and_quit)

    return app.exec()


def main() -> None:
    smoke_out: Path | None = None
    custom_db: Path | None = None
    custom_thumbs: Path | None = None
    for idx, arg in enumerate(sys.argv):
        if arg == "--smoke-test-out" and idx + 1 < len(sys.argv):
            smoke_out = Path(sys.argv[idx + 1])
        elif arg == "--db" and idx + 1 < len(sys.argv):
            custom_db = Path(sys.argv[idx + 1])
        elif arg == "--thumbs" and idx + 1 < len(sys.argv):
            custom_thumbs = Path(sys.argv[idx + 1])
    raise SystemExit(
        launch_gui(
            db_path=custom_db,
            thumbnail_dir=custom_thumbs,
            smoke_test_out=smoke_out,
        )
    )


if __name__ == "__main__":
    main()

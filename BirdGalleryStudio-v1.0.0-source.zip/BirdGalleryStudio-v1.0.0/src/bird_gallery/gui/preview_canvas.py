"""Lightroom-style Loupe single-image zoom/pan preview widget (non-blocking worker lifecycle)."""

from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor, QImage, QPainter, QPixmap, QWheelEvent
from PySide6.QtWidgets import (
    QGraphicsPixmapItem,
    QGraphicsScene,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.gui.workers import HighResPreviewWorker, WorkerTracker
from bird_gallery.models import PhotoRecord


class _ImageGraphicsView(QGraphicsView):
    zoom_changed = Signal(float)

    def __init__(self) -> None:
        super().__init__()
        self._scene = QGraphicsScene(self)
        self.setScene(self._scene)
        self._pixmap_item = QGraphicsPixmapItem()
        self._pixmap_item.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
        self._scene.addItem(self._pixmap_item)

        self.setBackgroundBrush(QBrush(QColor("#090C12")))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setFrameShape(QGraphicsView.Shape.NoFrame)

        self._fit_mode = True
        self._zoom_factor = 1.0

    def set_pixmap(self, pixmap: QPixmap) -> None:
        self._pixmap_item.setPixmap(pixmap)
        self._scene.setSceneRect(pixmap.rect())
        if self._fit_mode:
            self.fit_to_window()
        else:
            self.zoom_100()

    def fit_to_window(self) -> None:
        pix = self._pixmap_item.pixmap()
        if pix.isNull():
            return
        self._fit_mode = True
        self.resetTransform()
        self.fitInView(self._pixmap_item, Qt.AspectRatioMode.KeepAspectRatio)
        self._zoom_factor = self.transform().m11()
        self.zoom_changed.emit(self._zoom_factor)

    def zoom_100(self) -> None:
        pix = self._pixmap_item.pixmap()
        if pix.isNull():
            return
        self._fit_mode = False
        self.resetTransform()
        self._zoom_factor = 1.0
        self.zoom_changed.emit(self._zoom_factor)

    def wheelEvent(self, event: QWheelEvent) -> None:
        pix = self._pixmap_item.pixmap()
        if pix.isNull():
            return
        self._fit_mode = False
        delta = event.angleDelta().y()
        factor = 1.18 if delta > 0 else (1.0 / 1.18)
        next_zoom = self._zoom_factor * factor
        if 0.08 <= next_zoom <= 10.0:
            self.scale(factor, factor)
            self._zoom_factor = next_zoom
            self.zoom_changed.emit(self._zoom_factor)

    def mouseDoubleClickEvent(self, event) -> None:
        if self._fit_mode:
            self.zoom_100()
        else:
            self.fit_to_window()
        super().mouseDoubleClickEvent(event)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self._fit_mode and not self._pixmap_item.pixmap().isNull():
            self.fit_to_window()


class LoupePreviewWidget(QWidget):
    """Single-photo high-res preview with zoom controls, EXIF HUD, and safe async loading."""

    prev_requested = Signal()
    next_requested = Signal()
    back_to_grid_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._tracker = WorkerTracker(self)
        self._active_worker: HighResPreviewWorker | None = None
        self._request_id = 0
        self._current_path: str = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        top_bar = QWidget()
        top_bar.setStyleSheet("background-color: #0E121A; border-bottom: 1px solid #1C2332;")
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(12, 7, 12, 7)
        top_layout.setSpacing(6)

        self.btn_back = QPushButton("← 返回网格  G")
        self.btn_back.setObjectName("SubtleActionBtn")
        self.btn_back.clicked.connect(self.back_to_grid_requested.emit)
        top_layout.addWidget(self.btn_back)

        self.lbl_info = QLabel("双击画面切换「适应窗口 / 1:1」，滚轮无级缩放")
        self.lbl_info.setStyleSheet("color: #E2E8F0; font-size: 12px; font-weight: 600; padding-left: 8px; border: none;")
        top_layout.addWidget(self.lbl_info, 1)

        self.lbl_zoom = QLabel("100%")
        self.lbl_zoom.setStyleSheet(
            "color: #6EE7B7; background-color: #132824; border: 1px solid #1F4D3F; "
            "border-radius: 5px; padding: 2px 8px; font-size: 11px; font-weight: 700;"
        )
        top_layout.addWidget(self.lbl_zoom)

        self.btn_fit = QPushButton("适应窗口")
        self.btn_100 = QPushButton("1:1 原尺寸")
        self.btn_prev = QPushButton("◀")
        self.btn_next = QPushButton("▶")
        self.btn_prev.setFixedWidth(32)
        self.btn_next.setFixedWidth(32)

        for b in (self.btn_fit, self.btn_100, self.btn_prev, self.btn_next):
            b.setObjectName("SubtleActionBtn")
            top_layout.addWidget(b)

        layout.addWidget(top_bar)

        self.canvas = _ImageGraphicsView()
        self.canvas.zoom_changed.connect(self._on_zoom_changed)
        layout.addWidget(self.canvas, 1)

        self.btn_fit.clicked.connect(self.canvas.fit_to_window)
        self.btn_100.clicked.connect(self.canvas.zoom_100)
        self.btn_prev.clicked.connect(self.prev_requested.emit)
        self.btn_next.clicked.connect(self.next_requested.emit)

    def _on_zoom_changed(self, factor: float) -> None:
        self.lbl_zoom.setText(f"{factor * 100:.0f}%")

    def display_photo_record(self, photo: PhotoRecord) -> None:
        species = photo.display_species_full
        loc = f" · 📍{photo.display_location}" if photo.display_location else ""
        date_txt = f" · 📅{photo.taken_date}" if photo.taken_date else ""
        stars = f" · {'★' * photo.rating}" if photo.rating > 0 else ""
        exif_bits: list[str] = []
        if photo.exif.camera_model:
            exif_bits.append(photo.exif.camera_model)
        if photo.exif.focal_length_mm:
            exif_bits.append(f"{photo.exif.focal_length_mm:.0f}mm")
        if photo.exif.aperture:
            exif_bits.append(f"f/{photo.exif.aperture}")
        if photo.exif.shutter_speed:
            exif_bits.append(f"{photo.exif.shutter_speed}s")
        if photo.exif.iso:
            exif_bits.append(f"ISO {photo.exif.iso}")
        exif_str = f"   {' · '.join(exif_bits)}" if exif_bits else ""
        self.lbl_info.setText(f"{photo.file_name}   ·   {species}{date_txt}{loc}{stars}{exif_str}")
        self.display_file_path(Path(photo.file_path), fallback_thumb=photo.thumbnail_path)

    def display_file_path(self, path: Path, *, fallback_thumb: str | None = None) -> None:
        self._request_id += 1
        req_id = self._request_id
        self._current_path = str(path)

        if self._active_worker is not None:
            self._active_worker.cancel()

        if not os.path.exists(self._current_path):
            self.lbl_info.setText(f"原文件不存在: {path}")
            return

        # Only show fallback immediately if it is an already-small cached thumbnail file (< 1MB)
        if fallback_thumb and os.path.exists(fallback_thumb):
            try:
                if os.path.getsize(fallback_thumb) < 1_500_000:
                    quick_pix = QPixmap(fallback_thumb)
                    if not quick_pix.isNull():
                        self.canvas.set_pixmap(quick_pix)
            except OSError:
                pass

        worker = HighResPreviewWorker(req_id, path, max_edge=2560)
        worker.image_loaded.connect(self._on_high_res_loaded)
        worker.load_failed.connect(self._on_load_failed)
        self._active_worker = worker
        self._tracker.start(worker)

    def _on_high_res_loaded(self, req_id: int, file_path: str, qimg: QImage, _w: int, _h: int) -> None:
        if req_id != self._request_id or file_path != self._current_path:
            return
        self.canvas.set_pixmap(QPixmap.fromImage(qimg))

    def _on_load_failed(self, req_id: int, file_path: str, err: str) -> None:
        if req_id == self._request_id and file_path == self._current_path:
            self.lbl_info.setText(f"加载预览失败: {err}")

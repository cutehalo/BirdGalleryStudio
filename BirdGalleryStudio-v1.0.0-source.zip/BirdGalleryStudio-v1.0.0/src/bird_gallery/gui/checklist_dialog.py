"""Personal Birding Checklists Sync / Import & Management Dialog (BirdReport.cn ID/URL Sync + Excel/CSV + eBird)."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from PySide6.QtCore import QItemSelectionModel, QSignalBlocker, QThread, QUrl, Qt, Signal
from PySide6.QtGui import QColor, QDesktopServices, QKeySequence, QMouseEvent, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.checklists import (
    ParsedChecklistDraft,
    PersonalChecklistService,
    normalize_date_str,
)
from bird_gallery.gui.theme import enable_windows_dark_titlebar
from bird_gallery.gui.workers import WorkerTracker
from bird_gallery.models import BirdingChecklist, ChecklistItem


class _BirdReportSyncWorker(QThread):
    status_changed = Signal(str)
    finished_ok = Signal(object)  # list[BirdingChecklist]
    failed = Signal(str)

    def __init__(self, db_path_str: str, raw_id_or_url: str) -> None:
        super().__init__()
        self.db_path_str = db_path_str
        self.raw_id_or_url = raw_id_or_url

    def run(self) -> None:
        try:
            from bird_gallery.db import GalleryDatabase

            svc = PersonalChecklistService(GalleryDatabase(self.db_path_str))
            res = svc.sync_birdreport_by_id_or_url(
                self.raw_id_or_url,
                on_status=lambda msg: self.status_changed.emit(msg),
            )
            self.finished_ok.emit(res)
        except Exception as exc:
            self.failed.emit(str(exc))


class _EBirdChecklistSyncWorker(QThread):
    finished_ok = Signal(object)  # list[BirdingChecklist]
    failed = Signal(str)

    def __init__(self, db_path_str: str, raw_ids: str) -> None:
        super().__init__()
        self.db_path_str = db_path_str
        self.raw_ids = raw_ids

    def run(self) -> None:
        try:
            from bird_gallery.db import GalleryDatabase

            svc = PersonalChecklistService(GalleryDatabase(self.db_path_str))
            res = svc.sync_ebird_checklists(self.raw_ids)
            self.finished_ok.emit(res)
        except Exception as exc:
            self.failed.emit(str(exc))


class _CheckableChecklistTable(QTableWidget):
    """Table supporting both single-click checkbox multi-toggle (Col 0) and Shift/Ctrl/drag ExtendedSelection."""

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            idx = self.indexAt(event.position().toPoint())
            if idx.isValid() and idx.column() == 0 and event.modifiers() == Qt.KeyboardModifier.NoModifier:
                sel_model = self.selectionModel()
                if sel_model is not None:
                    sel_model.select(
                        idx,
                        QItemSelectionModel.SelectionFlag.Toggle | QItemSelectionModel.SelectionFlag.Rows,
                    )
                    sel_model.setCurrentIndex(idx, QItemSelectionModel.SelectionFlag.NoUpdate)
                event.accept()
                return
        super().mousePressEvent(event)


class ChecklistManagerDialog(QDialog):
    """Manage personal birding checklists & sync directly via BirdReport.cn ID/URL, XLSX/CSV, or eBird S-ID."""

    checklists_changed = Signal()
    jump_to_date_requested = Signal(str)  # YYYY-MM-DD

    def __init__(
        self,
        parent: QWidget | None,
        checklist_service: PersonalChecklistService,
        *,
        initial_date: str = "",
        initial_location: str = "",
    ) -> None:
        super().__init__(parent)
        self.svc = checklist_service
        self._tracker = WorkerTracker(self)
        self._checklists: list[BirdingChecklist] = []
        self._current_draft: ParsedChecklistDraft | None = None

        self.setWindowTitle("📋 个人观鸟记录同步与管理（支持报告导出 Excel 批量拆分导入 / ID 链接同步）")
        self.resize(1200, 740)
        enable_windows_dark_titlebar(self)

        default_d = normalize_date_str(initial_date) or date.today().isoformat()

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        root.addWidget(splitter, 1)

        # ================= LEFT PANE: Saved Personal Checklists & Species Detail =================
        self.left_box = QGroupBox("📚 已同步的本人观鸟记录单（自动关联同日照片优先推荐鸟种）")
        left_v = QVBoxLayout(self.left_box)
        left_v.setSpacing(6)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(6)
        filter_row.addWidget(QLabel("筛选:"))
        self.edit_filter_date = QLineEdit()
        self.edit_filter_date.setPlaceholderText("输入日期(如 2025-04)、地点、省市或报告编号筛选...")
        self.edit_filter_date.setClearButtonEnabled(True)
        self.edit_filter_date.textChanged.connect(lambda _t: self._refresh_checklists_table())
        filter_row.addWidget(self.edit_filter_date, 1)

        self.btn_select_all_cl = QPushButton("全选")
        self.btn_select_all_cl.setObjectName("SubtleActionBtn")
        self.btn_select_all_cl.setToolTip("全选当前列表中的所有观鸟记录（Ctrl+A）")
        self.btn_select_all_cl.clicked.connect(self.select_all_checklists)
        filter_row.addWidget(self.btn_select_all_cl)

        self.btn_clear_sel_cl = QPushButton("取消选择")
        self.btn_clear_sel_cl.setObjectName("SubtleActionBtn")
        self.btn_clear_sel_cl.setToolTip("取消当前多选状态")
        self.btn_clear_sel_cl.clicked.connect(self.cl_table_clear_selection)
        filter_row.addWidget(self.btn_clear_sel_cl)
        left_v.addLayout(filter_row)

        self.cl_table = _CheckableChecklistTable(0, 5)
        self.cl_table.setHorizontalHeaderLabels(["✓", "观测日期", "观鸟点 / 省市", "鸟种数", "来源 / 编号"])
        self.cl_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.cl_table.setColumnWidth(0, 32)
        self.cl_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.cl_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.cl_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.cl_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.cl_table.horizontalHeader().sectionClicked.connect(self._on_header_section_clicked)
        self.cl_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.cl_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.cl_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.cl_table.setToolTip("提示：点击左侧勾选框可逐条多选，也可按住 Shift 连选、拖拽框选或 Ctrl 多选后批量删除")
        self.cl_table.itemSelectionChanged.connect(self._on_checklist_selected)
        self._del_shortcut = QShortcut(QKeySequence.StandardKey.Delete, self.cl_table)
        self._del_shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self._del_shortcut.activated.connect(self._delete_selected_checklists)
        left_v.addWidget(self.cl_table, 3)

        self.lbl_detail_header = QLabel("记录明细：（在上方选择记录查看，支持勾选或 Shift 连选批量删除）")
        self.lbl_detail_header.setStyleSheet("color: #7ee2b8; font-weight: 600;")
        left_v.addWidget(self.lbl_detail_header)

        self.items_table = QTableWidget(0, 3)
        self.items_table.setHorizontalHeaderLabels(["鸟种中文名", "拉丁学名", "观测数量"])
        self.items_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.items_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.items_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.items_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        left_v.addWidget(self.items_table, 3)

        cl_btn_row = QHBoxLayout()
        cl_btn_row.setSpacing(6)
        self.btn_jump_photos = QPushButton("📸 查看该日照片")
        self.btn_jump_photos.clicked.connect(self._jump_to_selected_date)

        self.btn_add_sp = QPushButton("➕ 手动补录鸟种")
        self.btn_add_sp.clicked.connect(self._manual_add_species_to_selected)

        self.btn_del_cl = QPushButton("🗑 删除所选")
        self.btn_del_cl.clicked.connect(lambda: self._delete_selected_checklists())

        self.btn_clear_all_cl = QPushButton("🧹 清空全部")
        self.btn_clear_all_cl.setToolTip("一键清空所有已导入的观鸟记录（不会删除任何照片）")
        self.btn_clear_all_cl.setStyleSheet(
            "QPushButton { color: #FCA5A5; background-color: #2A161B; border: 1px solid #5C2430; } "
            "QPushButton:hover { background-color: #3D1D24; border-color: #EF4444; color: #FFFFFF; } "
            "QPushButton:disabled { color: #475569; background-color: #151A24; border-color: #222A3A; }"
        )
        self.btn_clear_all_cl.clicked.connect(lambda: self._clear_all_checklists())

        for b in (self.btn_jump_photos, self.btn_add_sp, self.btn_del_cl, self.btn_clear_all_cl):
            cl_btn_row.addWidget(b)
        left_v.addLayout(cl_btn_row)

        splitter.addWidget(self.left_box)

        # ================= RIGHT PANE: Sync / Import Channels =================
        right_box = QGroupBox("📥 同步本人观鸟记录")
        right_v = QVBoxLayout(right_box)

        self.tabs = QTabWidget()
        right_v.addWidget(self.tabs, 1)

        # ---- Tab 1: BirdReport.cn Direct ID / URL Sync (Primary) + Optional Text Paste ----
        tab_br = QWidget()
        br_v = QVBoxLayout(tab_br)
        br_v.setSpacing(10)

        # Primary Box: Direct Report ID or Report URL Sync!
        id_sync_grp = QGroupBox("🔗 填写「报告ID」或「报告链接」一键获取鸟种（推荐）")
        id_sync_v = QVBoxLayout(id_sync_grp)
        id_sync_v.setSpacing(8)

        lbl_id_guide = QLabel(
            "只需输入中国观鸟记录中心的<b>报告编号 ID</b>（如 <code>2026112501740</code>）或直接粘贴<b>报告网页链接</b>"
            "（<code>https://www.birdreport.cn/home/record/page.html?param=...</code>），点击同步即可自动提取观测日期、地点与全部鸟种信息！<br>"
            "<span style='color:#9da3ae;'>（注：粘贴完整报告链接通常无需验证直接秒抓；若仅填数字报告ID首次查询触发记录中心官方滑块验证，在弹出窗口滑一下即可自动完成抓取并关闭窗口。）</span>"
        )
        lbl_id_guide.setWordWrap(True)
        lbl_id_guide.setStyleSheet("color: #dbeafe; font-size: 12px;")
        id_sync_v.addWidget(lbl_id_guide)

        input_row = QHBoxLayout()
        self.edit_br_id_or_url = QLineEdit()
        self.edit_br_id_or_url.setPlaceholderText(
            "输入报告ID（如 2026112501740）或粘贴报告链接（https://www.birdreport.cn/home/record/page.html?param=...）"
        )
        self.edit_br_id_or_url.setClearButtonEnabled(True)
        self.edit_br_id_or_url.setMinimumHeight(34)
        self.edit_br_id_or_url.returnPressed.connect(self._start_birdreport_id_sync)
        input_row.addWidget(self.edit_br_id_or_url, 1)

        self.btn_sync_br_id = QPushButton("🔄 获取报告鸟种")
        self.btn_sync_br_id.setObjectName("PrimaryButton")
        self.btn_sync_br_id.setMinimumHeight(34)
        self.btn_sync_br_id.setMinimumWidth(135)
        self.btn_sync_br_id.clicked.connect(self._start_birdreport_id_sync)
        input_row.addWidget(self.btn_sync_br_id)
        id_sync_v.addLayout(input_row)

        self.lbl_br_sync_status = QLabel("就绪：支持单个或多个报告ID / 报告链接（空格或逗号分隔）。")
        self.lbl_br_sync_status.setWordWrap(True)
        self.lbl_br_sync_status.setStyleSheet(
            "color: #a8ffdb; background-color: #17332a; padding: 6px 8px; border-radius: 5px; font-size: 12px;"
        )
        id_sync_v.addWidget(self.lbl_br_sync_status)
        br_v.addWidget(id_sync_grp)

        # Secondary Box: Offline / WeChat Text Paste Fallback
        paste_grp = QGroupBox("📋 备选方式：直接粘贴小程序文案 / 任意鸟单文本解析")
        paste_v = QVBoxLayout(paste_grp)
        paste_v.setSpacing(6)

        meta_row = QHBoxLayout()
        self.edit_paste_date = QLineEdit(default_d)
        self.edit_paste_date.setPlaceholderText("YYYY-MM-DD")
        self.combo_paste_loc = QComboBox()
        self.combo_paste_loc.setEditable(True)
        self.combo_paste_loc.addItem(initial_location.strip(), initial_location.strip())
        for fav in self.svc.db.list_favorite_locations():
            if fav.name != initial_location.strip():
                self.combo_paste_loc.addItem(fav.name, fav.name)

        meta_row.addWidget(QLabel("日期:"))
        meta_row.addWidget(self.edit_paste_date, 1)
        meta_row.addWidget(QLabel("地点:"))
        meta_row.addWidget(self.combo_paste_loc, 2)
        paste_v.addLayout(meta_row)

        self.edit_paste_text = QPlainTextEdit()
        self.edit_paste_text.setPlaceholderText(
            "若不联网或从微信群/小程序复制了纯文字鸟单（如：黑脸琵鹭 12、普通翠鸟 2），也可粘贴于此解析..."
        )
        self.edit_paste_text.textChanged.connect(self._preview_paste_parse)
        paste_v.addWidget(self.edit_paste_text, 1)

        self.lbl_parse_preview = QLabel("")
        self.lbl_parse_preview.setWordWrap(True)
        self.lbl_parse_preview.setStyleSheet("color: #93c5fd; font-size: 11px;")
        paste_v.addWidget(self.lbl_parse_preview)

        paste_btn_row = QHBoxLayout()
        btn_clear_paste = QPushButton("清空文本")
        btn_clear_paste.clicked.connect(self.edit_paste_text.clear)
        self.btn_save_paste = QPushButton("保存粘贴文本鸟单")
        self.btn_save_paste.clicked.connect(self._save_pasted_checklist)
        paste_btn_row.addWidget(btn_clear_paste)
        paste_btn_row.addWidget(self.btn_save_paste, 1)
        paste_v.addLayout(paste_btn_row)

        br_v.addWidget(paste_grp, 1)
        self.tabs.addTab(tab_br, "🇨🇳 中国观鸟记录中心（ID / 链接同步）")

        # ---- Tab 2: Import Excel (.xlsx) / CSV / MyEBirdData.csv ----
        tab_file = QWidget()
        file_v = QVBoxLayout(tab_file)
        file_v.setSpacing(10)

        lbl_file_desc = QLabel(
            "支持一键导入以下所有表格格式：\n"
            "1. 中国观鸟记录中心「定点记+随手记报告记录导出 (.xlsx / .csv)」——自动按「报告编号」拆分为独立观鸟记录，"
            "仅提取「观测开始时间」的开始日期（YYYY-MM-DD，忽略具体时间），并完整读取观测点名称、省市及鸟种数量\n"
            "2. eBird 官网「Download My Data」导出的个人全量历史记录包 `MyEBirdData.csv`\n"
            "3. 任意包含「鸟种 / 中文名、数量（及可选日期、地点）」列的 Excel / CSV 文件。"
        )
        lbl_file_desc.setWordWrap(True)
        lbl_file_desc.setStyleSheet("color: #d1d5db; font-size: 12px;")
        file_v.addWidget(lbl_file_desc)

        file_form = QFormLayout()
        self.edit_file_default_date = QLineEdit(default_d)
        self.edit_file_default_date.setPlaceholderText("仅当表格不含日期/观测开始时间列时生效")
        self.edit_file_default_loc = QLineEdit(initial_location.strip())
        self.edit_file_default_loc.setPlaceholderText("仅当表格不含观测点名称/地点列时生效")
        file_form.addRow("无日期列备用日期:", self.edit_file_default_date)
        file_form.addRow("无地点列备用地点:", self.edit_file_default_loc)
        file_v.addLayout(file_form)

        file_btn_row = QHBoxLayout()
        self.btn_pick_file = QPushButton("📂 选择 .xlsx / .csv 记录文件并导入...")
        self.btn_pick_file.setObjectName("PrimaryButton")
        self.btn_pick_file.setMinimumHeight(36)
        self.btn_pick_file.clicked.connect(self._import_from_file_dialog)
        file_btn_row.addWidget(self.btn_pick_file, 1)

        btn_ebird_dl = QPushButton("🌐 打开 eBird 个人数据导出页")
        btn_ebird_dl.setMinimumHeight(36)
        btn_ebird_dl.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://ebird.org/downloadMyData")))
        file_btn_row.addWidget(btn_ebird_dl)
        file_v.addLayout(file_btn_row)

        self.lbl_file_result = QLabel("")
        self.lbl_file_result.setWordWrap(True)
        self.lbl_file_result.setStyleSheet("color: #7ee2b8; font-size: 12px;")
        file_v.addWidget(self.lbl_file_result)
        file_v.addStretch(1)

        self.tabs.addTab(tab_file, "📄 导入 Excel / CSV / MyEBirdData")

        # ---- Tab 3: eBird Checklist S-Code Online Sync ----
        tab_ebird = QWidget()
        eb_v = QVBoxLayout(tab_ebird)
        eb_v.setSpacing(10)

        lbl_eb_desc = QLabel(
            "如果你同时使用 eBird 记录观鸟，只需粘贴一条或多条 eBird 清单编号（S 开头）或网页链接，"
            "即可通过 eBird 官方接口直接拉取该清单的日期、观鸟点（含省市坐标）及全部鸟种！"
        )
        lbl_eb_desc.setWordWrap(True)
        lbl_eb_desc.setStyleSheet("color: #d1d5db; font-size: 12px;")
        eb_v.addWidget(lbl_eb_desc)

        eb_key_row = QHBoxLayout()
        eb_key_row.addWidget(QLabel("eBird API Key:"))
        self.edit_eb_key = QLineEdit(self.svc.ebird_svc.get_api_key())
        self.edit_eb_key.setPlaceholderText("与常用鸟点共享同一个免费 eBird API Key")
        self.edit_eb_key.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        eb_key_row.addWidget(self.edit_eb_key, 1)
        eb_v.addLayout(eb_key_row)

        self.edit_eb_sub_ids = QPlainTextEdit()
        self.edit_eb_sub_ids.setMaximumHeight(120)
        self.edit_eb_sub_ids.setPlaceholderText(
            "粘贴一个或多个清单编号或链接（每行一个或空格分隔），例如：\n"
            "S198273645\n"
            "https://ebird.org/checklist/S198273645"
        )
        eb_v.addWidget(self.edit_eb_sub_ids)

        self.btn_sync_eb_cl = QPushButton("🔄 在线同步 eBird 清单")
        self.btn_sync_eb_cl.setObjectName("PrimaryButton")
        self.btn_sync_eb_cl.setMinimumHeight(36)
        self.btn_sync_eb_cl.clicked.connect(self._start_ebird_checklist_sync)
        eb_v.addWidget(self.btn_sync_eb_cl)

        self.lbl_eb_sync_status = QLabel("")
        self.lbl_eb_sync_status.setWordWrap(True)
        self.lbl_eb_sync_status.setStyleSheet("color: #7ee2b8; font-size: 12px;")
        eb_v.addWidget(self.lbl_eb_sync_status)
        eb_v.addStretch(1)

        self.tabs.addTab(tab_ebird, "🧭 eBird 清单(S码)同步")

        splitter.addWidget(right_box)
        splitter.setSizes([560, 620])

        # Bottom Row
        bot_row = QHBoxLayout()
        bot_row.addStretch(1)
        btn_done = QPushButton("完成关闭")
        btn_done.clicked.connect(self.accept)
        bot_row.addWidget(btn_done)
        root.addLayout(bot_row)

        self._refresh_checklists_table(select_date=initial_date)
        self.edit_br_id_or_url.setFocus()

    # ---------------- Left Pane Logic ----------------

    def select_all_checklists(self) -> None:
        if self.cl_table.rowCount() > 0:
            self.cl_table.selectAll()

    def cl_table_clear_selection(self) -> None:
        self.cl_table.clearSelection()

    def _on_header_section_clicked(self, logical_index: int) -> None:
        if logical_index != 0 or self.cl_table.rowCount() == 0:
            return
        if len(self._selected_checklist_rows()) == self.cl_table.rowCount():
            self.cl_table.clearSelection()
        else:
            self.cl_table.selectAll()

    def _selected_checklist_rows(self) -> list[int]:
        sel_model = self.cl_table.selectionModel()
        if sel_model is None:
            return []
        rows = sorted({idx.row() for idx in sel_model.selectedRows() if 0 <= idx.row() < len(self._checklists)})
        return rows

    def selected_checklists(self) -> list[BirdingChecklist]:
        return [self._checklists[r] for r in self._selected_checklist_rows()]

    def _sync_row_check_marks(self, selected_rows_set: set[int]) -> None:
        checked_fg = QColor("#34D399")
        unchecked_fg = QColor("#64748B")
        with QSignalBlocker(self.cl_table):
            for r_idx in range(self.cl_table.rowCount()):
                it = self.cl_table.item(r_idx, 0)
                if it is None:
                    continue
                is_sel = r_idx in selected_rows_set
                it.setText("☑" if is_sel else "☐")
                it.setForeground(checked_fg if is_sel else unchecked_fg)

    def _refresh_checklists_table(self, select_date: str = "") -> None:
        kw_filter = self.edit_filter_date.text().strip()
        total_in_db = self.svc.db.count_checklists()
        self._checklists = self.svc.db.list_checklists(keyword=kw_filter, include_items=False, limit=5000)
        if kw_filter:
            self.left_box.setTitle(
                f"📚 已同步的本人观鸟记录单（筛选出 {len(self._checklists)} / {total_in_db} 篇 · 支持多选批量删除）"
            )
        else:
            self.left_box.setTitle(
                f"📚 已同步的本人观鸟记录单（共 {total_in_db} 篇 · 支持勾选或 Shift 连选批量删除）"
            )
        self.btn_clear_all_cl.setEnabled(total_in_db > 0)
        self.btn_select_all_cl.setEnabled(len(self._checklists) > 0)

        src_labels = {"birdreport": "记录中心", "ebird": "eBird", "manual": "手动录入"}
        target_row = 0
        with QSignalBlocker(self.cl_table):
            self.cl_table.clearSelection()
            self.cl_table.setRowCount(len(self._checklists))
            for r_idx, cl in enumerate(self._checklists):
                chk_item = QTableWidgetItem("☐")
                chk_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                chk_item.setForeground(QColor("#64748B"))

                dt_lbl = cl.obs_date if cl.source == "birdreport" else f"{cl.obs_date} {cl.obs_time}".strip()
                loc_parts = [x for x in (cl.admin_label, cl.location_name) if x]
                loc_lbl = " · ".join(loc_parts) if loc_parts else "（未填地点）"
                src_txt = src_labels.get(cl.source, cl.source)
                if cl.external_id:
                    src_txt = f"{src_txt} · {cl.external_id}"

                self.cl_table.setItem(r_idx, 0, chk_item)
                self.cl_table.setItem(r_idx, 1, QTableWidgetItem(dt_lbl))
                self.cl_table.setItem(r_idx, 2, QTableWidgetItem(loc_lbl))
                self.cl_table.setItem(r_idx, 3, QTableWidgetItem(f"{cl.species_count} 种"))
                self.cl_table.setItem(r_idx, 4, QTableWidgetItem(src_txt))
                if select_date and cl.obs_date == select_date[:10]:
                    target_row = r_idx

        if self._checklists:
            self.cl_table.selectRow(target_row)
            self._on_checklist_selected()
        else:
            self.items_table.setRowCount(0)
            self._update_delete_button_state(0)
            if kw_filter and total_in_db > 0:
                self.lbl_detail_header.setText(f"未找到匹配「{kw_filter}」的观鸟记录")
            else:
                self.lbl_detail_header.setText("暂无观鸟记录（请在右侧导入 Excel/CSV 或输入报告ID/链接同步）")

    def _update_delete_button_state(self, sel_count: int) -> None:
        self.btn_clear_sel_cl.setEnabled(sel_count > 0)
        self.btn_del_cl.setEnabled(sel_count > 0)
        self.btn_jump_photos.setEnabled(sel_count == 1)
        self.btn_add_sp.setEnabled(sel_count == 1)
        if sel_count <= 1:
            self.btn_del_cl.setText("🗑 删除所选 (1)" if sel_count == 1 else "🗑 删除所选")
            self.btn_del_cl.setStyleSheet("")
        else:
            self.btn_del_cl.setText(f"🗑 批量删除 ({sel_count} 篇)")
            self.btn_del_cl.setStyleSheet(
                "QPushButton { color: #FECACA; background-color: #451A23; border: 1px solid #DC2626; font-weight: 700; } "
                "QPushButton:hover { background-color: #5B212D; border-color: #F87171; color: #FFFFFF; }"
            )

    def _selected_checklist(self) -> BirdingChecklist | None:
        rows = self._selected_checklist_rows()
        if not rows:
            row = self.cl_table.currentRow()
            if 0 <= row < len(self._checklists):
                return self.svc.db.get_checklist(self._checklists[row].checklist_id)
            return None
        cur = self.cl_table.currentRow()
        target_r = cur if cur in rows else rows[-1]
        return self.svc.db.get_checklist(self._checklists[target_r].checklist_id)

    def _on_checklist_selected(self) -> None:
        sel_rows = self._selected_checklist_rows()
        self._sync_row_check_marks(set(sel_rows))
        self._update_delete_button_state(len(sel_rows))

        if not sel_rows:
            self.items_table.setRowCount(0)
            self.lbl_detail_header.setText("未选中记录（点击行或左侧勾选框可单选/多选）")
            return

        cl = self._selected_checklist()
        if cl is None:
            self.items_table.setRowCount(0)
            return

        if len(sel_rows) > 1:
            total_sp_records = sum(self._checklists[r].species_count for r in sel_rows)
            self.lbl_detail_header.setText(
                f"☑ 已多选 {len(sel_rows)} 篇观鸟记录（合计 {total_sp_records} 条鸟种记录 · 可点击下方「批量删除」或按 Delete 键）"
            )
        else:
            loc = cl.location_name or cl.admin_label or "未命名地点"
            ext = f" [{cl.external_id}]" if cl.external_id else ""
            self.lbl_detail_header.setText(f"📋 {cl.obs_date}{ext} · {loc}（共 {len(cl.items)} 种）")

        self.items_table.setRowCount(len(cl.items))
        for idx, it in enumerate(cl.items):
            self.items_table.setItem(idx, 0, QTableWidgetItem(it.common_name_cn))
            self.items_table.setItem(idx, 1, QTableWidgetItem(it.scientific_name or "-"))
            self.items_table.setItem(idx, 2, QTableWidgetItem(it.count_str))

    def _jump_to_selected_date(self) -> None:
        cl = self._selected_checklist()
        if cl is None:
            return
        self.jump_to_date_requested.emit(cl.obs_date)
        self.accept()

    def _manual_add_species_to_selected(self) -> None:
        cl = self._selected_checklist()
        if cl is None:
            QMessageBox.information(self, "提示", "请先在左侧选择一篇观鸟记录。")
            return
        txt, ok = QInputDialog.getText(self, "补录鸟种", "输入鸟种中文名、拼音首字母(如 ptcn)或学名（可加空格写数量，如：普通翠鸟 2）：")
        if not ok or not txt.strip():
            return
        parts = txt.strip().split()
        cnt = 1
        sp_raw = txt.strip()
        if len(parts) >= 2 and parts[-1].isdigit():
            cnt = int(parts[-1])
            sp_raw = " ".join(parts[:-1])

        taxon = self.svc.resolve_species_any(sp_raw)
        if taxon is None:
            matches = self.svc.taxonomy.search(sp_raw, limit=1, prefer_china=True)
            taxon = matches[0] if matches else None

        cn = taxon.common_name_cn if taxon else sp_raw
        sci = taxon.scientific_name if taxon else ""
        cl.items.append(ChecklistItem(common_name_cn=cn, scientific_name=sci, count_num=cnt, count_str=str(cnt)))
        self.svc.db.upsert_checklist(
            cl.obs_date,
            cl.items,
            checklist_id=cl.checklist_id,
            obs_time=cl.obs_time,
            source=cl.source,
            external_id=cl.external_id,
            location_name=cl.location_name,
            province=cl.province,
            city=cl.city,
            ebird_loc_id=cl.ebird_loc_id,
            lat=cl.lat,
            lng=cl.lng,
            notes=cl.notes,
        )
        self._refresh_checklists_table(select_date=cl.obs_date)
        self.checklists_changed.emit()

    def _delete_selected_checklists(self, *, confirm: bool = True) -> int:
        chosen = self.selected_checklists()
        if not chosen:
            return 0

        if confirm:
            if len(chosen) == 1:
                only = chosen[0]
                prompt = f"确定删除 {only.obs_date}（{only.location_name or '未填地点'}）的观鸟记录吗？"
                title = "删除记录"
            else:
                preview_lines = [
                    f"• {c.obs_date} · {c.location_name or c.admin_label or '未填地点'}（{c.species_count} 种）"
                    for c in chosen[:5]
                ]
                if len(chosen) > 5:
                    preview_lines.append(f"• ... 等共 {len(chosen)} 篇记录")
                prompt = (
                    f"确定批量删除选中的 {len(chosen)} 篇观鸟记录吗？\n\n"
                    + "\n".join(preview_lines)
                    + "\n\n（注：仅删除观鸟报告单，不会删除您的任何照片。）"
                )
                title = "批量删除观鸟记录"

            ans = QMessageBox.question(self, title, prompt)
            if ans != QMessageBox.StandardButton.Yes:
                return 0

        deleted = self.svc.db.delete_checklists([c.checklist_id for c in chosen])
        self._refresh_checklists_table()
        self.checklists_changed.emit()
        return deleted

    def _delete_selected_checklist(self) -> None:
        self._delete_selected_checklists(confirm=True)

    def _clear_all_checklists(self, *, confirm: bool = True) -> int:
        total = self.svc.db.count_checklists()
        if total <= 0:
            return 0
        if confirm:
            ans = QMessageBox.question(
                self,
                "清空全部观鸟记录",
                f"确定要一次性清空全部 {total} 篇已导入的观鸟记录吗？\n\n（注：仅清空观鸟报告单，不会删除您的任何照片或鸟种标签。）",
            )
            if ans != QMessageBox.StandardButton.Yes:
                return 0
        deleted = self.svc.db.clear_all_checklists()
        self._refresh_checklists_table()
        self.checklists_changed.emit()
        return deleted

    # ---------------- Right Pane: Tab 1 (BirdReport ID / URL Sync + Paste) ----------------

    def _start_birdreport_id_sync(self) -> None:
        raw = self.edit_br_id_or_url.text().strip()
        if not raw:
            QMessageBox.information(
                self,
                "请输入报告ID或链接",
                "请输入中国观鸟记录中心的报告编号（如 2026112501740）或粘贴报告链接（https://www.birdreport.cn/home/record/page.html?param=...）。",
            )
            return

        from bird_gallery.gui.birdreport_web_dialog import BirdReportWebSyncDialog

        try:
            web_dlg = BirdReportWebSyncDialog(self, self.svc, raw)
        except ValueError as exc:
            QMessageBox.warning(self, "格式提示", str(exc))
            return

        self.lbl_br_sync_status.setText("🔄 正在通过内置浏览器窗口读取观鸟记录中心报告...")
        if web_dlg.exec() == QDialog.DialogCode.Accepted:
            synced = web_dlg.synced_checklists()
            if synced:
                self.edit_br_id_or_url.clear()
                first = synced[0]
                total_sp = sum(c.species_count for c in synced)
                loc_info = f" · {first.location_name}" if first.location_name else ""
                ext_info = f" {first.external_id}" if first.external_id else ""
                self.lbl_br_sync_status.setText(
                    f"✓ 同步成功！报告{ext_info}（{first.obs_date}{loc_info}，共 {total_sp} 种鸟类）已保存并关联同日照片！"
                )
                self._refresh_checklists_table(select_date=first.obs_date)
                self.checklists_changed.emit()
                return
        self.lbl_br_sync_status.setText("已关闭获取窗口（如需重试，输入报告ID或链接点击“获取报告鸟种”即可）。")

    def _preview_paste_parse(self) -> None:
        raw = self.edit_paste_text.toPlainText()
        if not raw.strip():
            self._current_draft = None
            self.lbl_parse_preview.clear()
            return

        if self.svc.is_tabular_checklist_text(raw):
            self._current_draft = None
            line_cnt = sum(1 for ln in raw.splitlines() if ln.strip()) - 1
            self.lbl_parse_preview.setText(
                f"✓ 检测到导出的多列记录表格（约 {max(1, line_cnt)} 行），点击下方「保存粘贴文本鸟单」即可按报告编号自动拆分导入！"
            )
            return

        direct = self.svc.parse_birdreport_text(raw)
        draft = self.svc.parse_birdreport_text(
            raw,
            default_date=self.edit_paste_date.text().strip(),
            default_location=self.combo_paste_loc.currentText().strip(),
        )
        self._current_draft = draft
        if direct.obs_date and direct.obs_date != self.edit_paste_date.text().strip():
            self.edit_paste_date.setText(direct.obs_date)
        if direct.location_name and direct.location_name != self.combo_paste_loc.currentText().strip():
            self.combo_paste_loc.setCurrentText(direct.location_name)

        if not draft.items:
            self.lbl_parse_preview.setText("尚未识别出标准中文鸟名")
        else:
            preview_names = "、".join(f"{it.common_name_cn}({it.count_str})" for it in draft.items[:10])
            more = f" 等共 {len(draft.items)} 种" if len(draft.items) > 10 else f"（共 {len(draft.items)} 种）"
            self.lbl_parse_preview.setText(f"✓ 识别预览：{preview_names}{more}")

    def _save_pasted_checklist(self) -> None:
        raw = self.edit_paste_text.toPlainText()
        if self.svc.is_tabular_checklist_text(raw):
            try:
                cl_cnt, sp_cnt = self.svc.import_tabular_text(
                    raw,
                    default_date=self.edit_paste_date.text().strip(),
                    default_location=self.combo_paste_loc.currentText().strip(),
                )
            except Exception as exc:
                QMessageBox.warning(self, "无法保存", str(exc))
                return
            self.edit_paste_text.clear()
            self.combo_paste_loc.setCurrentText("")
            self.lbl_parse_preview.setText(f"✓ 已按报告编号拆分保存 {cl_cnt} 篇观鸟记录（累计 {sp_cnt} 条鸟种记录）")
            self._refresh_checklists_table()
            self.checklists_changed.emit()
            return

        direct = self.svc.parse_birdreport_text(raw)
        draft = self.svc.parse_birdreport_text(
            raw,
            default_date=self.edit_paste_date.text().strip(),
            default_location=self.combo_paste_loc.currentText().strip(),
        )
        draft.obs_date = direct.obs_date or normalize_date_str(self.edit_paste_date.text().strip()) or draft.obs_date
        draft.location_name = direct.location_name or self.combo_paste_loc.currentText().strip() or draft.location_name

        try:
            saved = self.svc.save_parsed_draft(draft, source="birdreport")
        except ValueError as exc:
            QMessageBox.warning(self, "无法保存", str(exc))
            return

        self.edit_paste_text.clear()
        self.combo_paste_loc.setCurrentText("")
        self.lbl_parse_preview.setText(f"✓ 已保存 {saved.obs_date} 鸟单（共 {saved.species_count} 种）")
        self._refresh_checklists_table(select_date=saved.obs_date)
        self.checklists_changed.emit()

    # ---------------- Right Pane: Tab 2 (File Import) ----------------

    def _import_from_file_dialog(self) -> None:
        file_str, _ = QFileDialog.getOpenFileName(
            self,
            "选择观鸟记录表格文件 (.xlsx / .csv)",
            str(Path.home()),
            "观鸟记录文件 (*.xlsx *.csv *.tsv *.txt);;所有文件 (*.*)",
            options=QFileDialog.Option.DontUseNativeDialog,
        )
        if not file_str:
            return
        try:
            cl_cnt, sp_cnt = self.svc.import_checklist_file(
                file_str,
                default_date=self.edit_file_default_date.text().strip(),
                default_location=self.edit_file_default_loc.text().strip(),
            )
        except Exception as exc:
            QMessageBox.warning(self, "导入失败", str(exc))
            return

        self.lbl_file_result.setText(f"✓ 导入成功！共归档 {cl_cnt} 篇观鸟记录（累计 {sp_cnt} 条鸟种记录）。")
        self._refresh_checklists_table()
        self.checklists_changed.emit()

    # ---------------- Right Pane: Tab 3 (eBird S-ID Sync) ----------------

    def _start_ebird_checklist_sync(self) -> None:
        key = self.edit_eb_key.text().strip()
        if key:
            self.svc.ebird_svc.set_api_key(key)
        if not self.svc.ebird_svc.get_api_key():
            QMessageBox.warning(self, "缺少 API Key", "请先填入免费的 eBird API Key。")
            return

        raw_ids = self.edit_eb_sub_ids.toPlainText().strip()
        if not raw_ids:
            QMessageBox.information(self, "提示", "请输入至少一个 eBird 清单编号（如 S198273645）或链接。")
            return

        self.btn_sync_eb_cl.setEnabled(False)
        self.lbl_eb_sync_status.setText("正在连接 eBird 官方服务器同步清单...")

        worker = _EBirdChecklistSyncWorker(str(self.svc.db.db_path), raw_ids)
        worker.finished_ok.connect(self._on_ebird_sync_done)
        worker.failed.connect(self._on_ebird_sync_failed)
        self._tracker.start(worker)

    def _on_ebird_sync_done(self, res_obj: object) -> None:
        self.btn_sync_eb_cl.setEnabled(True)
        synced: list[BirdingChecklist] = res_obj  # type: ignore[assignment]
        if not synced:
            self.lbl_eb_sync_status.setText("⚠ 未能拉取到有效鸟种数据，请检查清单编号是否正确。")
            return
        total_sp = sum(c.species_count for c in synced)
        self.edit_eb_sub_ids.clear()
        self.lbl_eb_sync_status.setText(f"✓ 同步成功！已拉取 {len(synced)} 篇 eBird 清单（共 {total_sp} 种鸟类）。")
        self._refresh_checklists_table(select_date=synced[0].obs_date)
        self.checklists_changed.emit()

    def _on_ebird_sync_failed(self, err: str) -> None:
        self.btn_sync_eb_cl.setEnabled(True)
        self.lbl_eb_sync_status.setText("")
        QMessageBox.warning(self, "eBird 同步失败", err)

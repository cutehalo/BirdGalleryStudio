"""Favorite Birding Locations (with Province + Prefecture/City), Embedded Map Adjuster & eBird Hotspot Center."""

from __future__ import annotations

from PySide6.QtCore import QThread, QTimer, QUrl, Qt, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.china_regions import (
    PROVINCE_TO_EBIRD_CODE,
    format_province_city,
    get_city_entry,
    get_province_center,
    infer_province_city,
    list_cities,
    list_provinces,
    normalize_province_name,
)
from bird_gallery.ebird import (
    EBirdLocationService,
    extract_ebird_loc_id,
    format_region_label,
    suggest_short_spot_name,
)
from bird_gallery.gui.map_picker import MAP_LAYERS, MapPickerDialog, SlippyMapWidget
from bird_gallery.gui.workers import WorkerTracker
from bird_gallery.models import EBirdHotspot, FavoriteLocation


class _EBirdSyncWorker(QThread):
    finished_ok = Signal(int, str)  # count, detail
    failed = Signal(str)

    def __init__(self, db_path_str: str, regions: str) -> None:
        super().__init__()
        self.db_path_str = db_path_str
        self.regions = regions

    def run(self) -> None:
        try:
            from bird_gallery.db import GalleryDatabase

            svc = EBirdLocationService(GalleryDatabase(self.db_path_str))
            total, details = svc.sync_regions(self.regions)
            self.finished_ok.emit(total, ", ".join(details))
        except Exception as exc:
            self.failed.emit(str(exc))


class _EBirdNearbyWorker(QThread):
    finished_ok = Signal(object)  # list[EBirdHotspot]
    failed = Signal(str)

    def __init__(self, db_path_str: str, lat: float, lng: float) -> None:
        super().__init__()
        self.db_path_str = db_path_str
        self.lat = lat
        self.lng = lng

    def run(self) -> None:
        try:
            from bird_gallery.db import GalleryDatabase

            svc = EBirdLocationService(GalleryDatabase(self.db_path_str))
            spots = svc.find_nearby_hotspots(self.lat, self.lng, dist_km=25.0, try_online=True, limit=40)
            self.finished_ok.emit(spots)
        except Exception as exc:
            self.failed.emit(str(exc))


class LocationManagerDialog(QDialog):
    """Three-part dialog: Favorite Birding Spots (with Province/City) + Interactive Map Adjuster + eBird Hotspots."""

    favorites_changed = Signal()
    # (name, ebird_loc_id, lat, lng, province, city)
    apply_location_requested = Signal(str, str, object, object, str, str)

    def __init__(
        self,
        parent: QWidget | None,
        ebird_service: EBirdLocationService,
        *,
        active_photo_gps: tuple[float, float] | None = None,
        has_selected_photos: bool = False,
    ) -> None:
        super().__init__(parent)
        self.svc = ebird_service
        self.active_photo_gps = active_photo_gps
        self.has_selected_photos = has_selected_photos
        self._tracker = WorkerTracker(self)
        self._syncing_fav_combos = False
        self._syncing_filter_combos = False

        self._favorites: list[FavoriteLocation] = []
        self._hotspots: list[EBirdHotspot] = []
        self._editing_fav_id: int | None = None

        self.setWindowTitle("📍 常用观鸟点（省/地市） · 地图选点微调 · eBird 关联中心")
        self.resize(1240, 760)

        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(120)
        self._search_timer.timeout.connect(self._run_hotspot_search)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        root.addWidget(splitter, 1)

        # ================= LEFT PANE: Favorite Locations + Interactive Map Adjuster =================
        left_box = QGroupBox("⭐ 我的常用观鸟点（支持省/地市分级与地图落针微调）")
        left_layout = QVBoxLayout(left_box)
        left_layout.setSpacing(6)

        self.fav_table = QTableWidget(0, 4)
        self.fav_table.setHorizontalHeaderLabels(["常用名称", "省 · 地市", "关联 eBird", "经纬度"])
        self.fav_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.fav_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.fav_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.fav_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.fav_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.fav_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.fav_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.fav_table.setMinimumHeight(145)
        self.fav_table.itemSelectionChanged.connect(self._on_fav_row_selected)
        left_layout.addWidget(self.fav_table, 2)

        # Embedded Interactive Map Adjuster for Favorite Location
        map_grp = QGroupBox("🗺 地图选点与坐标微调（点击地图或拖动红针即可调整下方经纬度并自动识别省市）")
        map_v = QVBoxLayout(map_grp)
        map_v.setContentsMargins(6, 6, 6, 6)
        map_v.setSpacing(4)

        map_bar = QHBoxLayout()
        self.combo_map_layer = QComboBox()
        for spec in MAP_LAYERS:
            self.combo_map_layer.addItem(spec.title, spec.layer_id)
        self.combo_map_layer.currentIndexChanged.connect(lambda idx: self.preview_map.set_layer_index(idx))
        map_bar.addWidget(self.combo_map_layer, 1)

        btn_big_map = QPushButton("🔍 弹出全屏大地图选点...")
        btn_big_map.clicked.connect(self._open_fullscreen_map_for_form)
        map_bar.addWidget(btn_big_map)
        map_v.addLayout(map_bar)

        init_lat = active_photo_gps[0] if active_photo_gps else 35.8617
        init_lng = active_photo_gps[1] if active_photo_gps else 104.1954
        init_z = 13 if active_photo_gps else 4
        self.preview_map = SlippyMapWidget(
            self,
            initial_lat=init_lat,
            initial_lng=init_lng,
            initial_zoom=init_z,
        )
        self.preview_map.setMinimumHeight(215)
        if active_photo_gps:
            self.preview_map.set_pin(active_photo_gps[0], active_photo_gps[1], pan_to=True, zoom=14)
        self.preview_map.pin_changed.connect(self._on_preview_map_pin_changed)
        self.preview_map.hotspot_clicked.connect(self._on_preview_map_hotspot_clicked)
        map_v.addWidget(self.preview_map, 1)
        left_layout.addWidget(map_grp, 3)

        # Edit/Create Form with Province + Prefecture/City
        edit_grp = QGroupBox("新增 / 编辑常用观鸟点")
        form = QFormLayout(edit_grp)
        form.setSpacing(5)

        self.edit_fav_name = QLineEdit()
        self.edit_fav_name.setPlaceholderText("必填，如：深圳湾公园北湾鹭港 / 北京·奥森北园")
        form.addRow("常用名称:", self.edit_fav_name)

        admin_row = QHBoxLayout()
        self.combo_fav_prov = QComboBox()
        self.combo_fav_prov.setEditable(True)
        self.combo_fav_prov.addItem("", "")
        for p in list_provinces():
            self.combo_fav_prov.addItem(p, p)
        self.combo_fav_prov.currentIndexChanged.connect(self._on_fav_prov_combo_changed)

        self.combo_fav_city = QComboBox()
        self.combo_fav_city.setEditable(True)
        self.combo_fav_city.setMinimumWidth(135)
        self.combo_fav_city.addItem("", "")
        self.combo_fav_city.currentIndexChanged.connect(self._on_fav_city_combo_changed)

        self.edit_fav_ebird_id = QLineEdit()
        self.edit_fav_ebird_id.setPlaceholderText("可选 L码 (如 L2586431)")

        admin_row.addWidget(QLabel("省/区:"))
        admin_row.addWidget(self.combo_fav_prov, 1)
        admin_row.addWidget(QLabel("地市:"))
        admin_row.addWidget(self.combo_fav_city, 1)
        admin_row.addWidget(QLabel("eBird:"))
        admin_row.addWidget(self.edit_fav_ebird_id, 1)
        form.addRow("行政区划:", admin_row)

        self.edit_fav_ebird_name = QLineEdit()
        self.edit_fav_ebird_name.setPlaceholderText("关联的 eBird 官方鸟点原名（右侧绑定自动带入或选填）")
        form.addRow("eBird 原名:", self.edit_fav_ebird_name)

        coord_row = QHBoxLayout()
        self.edit_fav_lat = QLineEdit()
        self.edit_fav_lat.setPlaceholderText("纬度 (如 22.5212)")
        self.edit_fav_lng = QLineEdit()
        self.edit_fav_lng.setPlaceholderText("经度 (如 113.9921)")
        btn_pin_from_input = QPushButton("定位到地图")
        btn_pin_from_input.clicked.connect(self._locate_form_coords_on_map)
        coord_row.addWidget(QLabel("纬度:"))
        coord_row.addWidget(self.edit_fav_lat, 1)
        coord_row.addWidget(QLabel("经度:"))
        coord_row.addWidget(self.edit_fav_lng, 1)
        coord_row.addWidget(btn_pin_from_input)
        form.addRow("精确坐标:", coord_row)

        self.edit_fav_notes = QLineEdit()
        self.edit_fav_notes.setPlaceholderText("可选备注：常见目标鸟种、生境、最佳潮汐/机位等")
        form.addRow("地点备注:", self.edit_fav_notes)

        fav_btn_row = QHBoxLayout()
        self.btn_save_fav = QPushButton("✓ 保存常用观鸟点")
        self.btn_save_fav.setObjectName("PrimaryButton")
        self.btn_save_fav.clicked.connect(self._save_favorite)

        self.btn_new_fav = QPushButton("清空新建")
        self.btn_new_fav.clicked.connect(self._clear_fav_form)

        self.btn_del_fav = QPushButton("🗑 删除")
        self.btn_del_fav.clicked.connect(self._delete_selected_favorite)

        self.btn_apply_fav = QPushButton("📌 应用到选中照片")
        self.btn_apply_fav.setEnabled(self.has_selected_photos)
        self.btn_apply_fav.clicked.connect(self._apply_selected_favorite_to_photos)

        for b in (self.btn_save_fav, self.btn_new_fav, self.btn_del_fav, self.btn_apply_fav):
            fav_btn_row.addWidget(b)
        form.addRow(fav_btn_row)

        left_layout.addWidget(edit_grp)
        splitter.addWidget(left_box)

        # ================= RIGHT PANE: eBird Hotspots Search & Sync =================
        right_box = QGroupBox("🧭 eBird 官方鸟点搜索与本地同步（按省/地市筛选或拼音快搜）")
        right_layout = QVBoxLayout(right_box)
        right_layout.setSpacing(7)

        # 1. API Key & Region Sync Bar
        sync_grp = QGroupBox("eBird API 同步设置（同步一次即可永久离线秒搜）")
        sync_layout = QVBoxLayout(sync_grp)
        sync_layout.setSpacing(5)

        key_row = QHBoxLayout()
        key_row.addWidget(QLabel("API Key:"))
        self.edit_api_key = QLineEdit(self.svc.get_api_key())
        self.edit_api_key.setPlaceholderText("粘贴你的免费 eBird API Token")
        self.edit_api_key.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        key_row.addWidget(self.edit_api_key, 1)

        btn_save_key = QPushButton("保存Key")
        btn_save_key.clicked.connect(self._save_api_key)
        btn_get_key = QPushButton("🔑 免费申请Key")
        btn_get_key.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://ebird.org/api/keygen")))
        key_row.addWidget(btn_save_key)
        key_row.addWidget(btn_get_key)
        sync_layout.addLayout(key_row)

        region_row = QHBoxLayout()
        region_row.addWidget(QLabel("同步地区:"))
        self.combo_region = QComboBox()
        self.combo_region.setEditable(True)
        presets = [
            "CN,HK,TW,MO",
            "CN-11 (北京)",
            "CN-31 (上海)",
            "CN-44 (广东)",
            "CN-53 (云南)",
            "CN-51 (四川)",
            "CN-32 (江苏)",
            "CN-33 (浙江)",
            "CN-35 (福建)",
            "CN-36 (江西)",
        ]
        self.combo_region.addItems(presets)
        self.combo_region.setCurrentText(self.svc.get_sync_regions())
        region_row.addWidget(self.combo_region, 1)

        self.btn_sync = QPushButton("🔄 同步该地区 eBird 鸟点")
        self.btn_sync.setObjectName("PrimaryButton")
        self.btn_sync.clicked.connect(self._start_region_sync)
        region_row.addWidget(self.btn_sync)
        sync_layout.addLayout(region_row)

        self.lbl_cache_status = QLabel("")
        self.lbl_cache_status.setStyleSheet("color: #7ee2b8; font-size: 12px;")
        sync_layout.addWidget(self.lbl_cache_status)
        right_layout.addWidget(sync_grp)

        # 2. Province + Prefecture/City Filter & Fast Hotspot Search Bar
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("筛选省/市:"))
        self.combo_filter_prov = QComboBox()
        self.combo_filter_prov.addItem("全部省份", "")
        for p in list_provinces():
            self.combo_filter_prov.addItem(p, p)
        self.combo_filter_prov.currentIndexChanged.connect(self._on_filter_prov_changed)
        filter_row.addWidget(self.combo_filter_prov)

        self.combo_filter_city = QComboBox()
        self.combo_filter_city.setMinimumWidth(135)
        self.combo_filter_city.addItem("全部地市", "")
        self.combo_filter_city.currentIndexChanged.connect(lambda _i: self._run_hotspot_search())
        filter_row.addWidget(self.combo_filter_city)

        self.btn_gps_nearby = QPushButton("📡 按当前照片GPS搜周边")
        self.btn_gps_nearby.setEnabled(self.active_photo_gps is not None)
        if self.active_photo_gps is not None:
            self.btn_gps_nearby.setToolTip(f"当前照片 GPS: {self.active_photo_gps[0]:.4f}, {self.active_photo_gps[1]:.4f}")
        self.btn_gps_nearby.clicked.connect(self._search_nearby_by_photo_gps)
        filter_row.addWidget(self.btn_gps_nearby, 1)
        right_layout.addLayout(filter_row)

        search_row = QHBoxLayout()
        self.edit_hotspot_search = QLineEdit()
        self.edit_hotspot_search.setPlaceholderText("搜鸟点中英文名 / 地市名 / 拼音首字母(如 ymy、szw) / L码 / 粘贴eBird链接...")
        self.edit_hotspot_search.setClearButtonEnabled(True)
        self.edit_hotspot_search.textChanged.connect(lambda _t: self._search_timer.start())
        search_row.addWidget(self.edit_hotspot_search, 1)
        right_layout.addLayout(search_row)

        # 3. Hotspot Results Table
        self.hotspot_table = QTableWidget(0, 4)
        self.hotspot_table.setHorizontalHeaderLabels(["eBird 鸟点名称", "省 · 地市", "鸟种数", "L码 / 距离"])
        self.hotspot_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.hotspot_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.hotspot_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.hotspot_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.hotspot_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.hotspot_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.hotspot_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hotspot_table.itemSelectionChanged.connect(self._on_hotspot_row_selected)
        right_layout.addWidget(self.hotspot_table, 1)

        # 4. Hotspot Action Buttons
        hs_btn_row = QHBoxLayout()
        self.btn_add_hs_to_fav = QPushButton("⭐ 添加为常用观鸟点")
        self.btn_add_hs_to_fav.setObjectName("PrimaryButton")
        self.btn_add_hs_to_fav.clicked.connect(self._add_selected_hotspot_as_favorite)

        self.btn_bind_hs = QPushButton("🔗 带入左侧表单微调")
        self.btn_bind_hs.clicked.connect(self._bind_hotspot_to_left_form)

        self.btn_apply_hs = QPushButton("📌 直接应用到照片")
        self.btn_apply_hs.setEnabled(self.has_selected_photos)
        self.btn_apply_hs.clicked.connect(self._apply_selected_hotspot_to_photos)

        self.btn_open_web = QPushButton("🌐 打开 eBird 网页")
        self.btn_open_web.clicked.connect(self._open_selected_hotspot_web)

        for b in (self.btn_add_hs_to_fav, self.btn_bind_hs, self.btn_apply_hs, self.btn_open_web):
            hs_btn_row.addWidget(b)
        right_layout.addLayout(hs_btn_row)

        splitter.addWidget(right_box)
        splitter.setSizes([630, 590])

        # Bottom Close Row
        bottom_row = QHBoxLayout()
        bottom_row.addStretch(1)
        btn_close = QPushButton("完成关闭")
        btn_close.clicked.connect(self.accept)
        bottom_row.addWidget(btn_close)
        root.addLayout(bottom_row)

        self._refresh_favorites_table()
        self._update_cache_status_label()
        self._run_hotspot_search()

    def closeEvent(self, event) -> None:
        self.preview_map.shutdown()
        super().closeEvent(event)

    def done(self, result: int) -> None:
        self.preview_map.shutdown()
        super().done(result)

    # ---------------- Cascading Province/City Helpers ----------------

    def _set_fav_admin_combos(self, province: str, city: str) -> None:
        self._syncing_fav_combos = True
        try:
            prov_norm = normalize_province_name(province)
            self.combo_fav_prov.setCurrentText(prov_norm)
            self.combo_fav_city.clear()
            self.combo_fav_city.addItem("", "")
            for ce in list_cities(prov_norm):
                self.combo_fav_city.addItem(ce.city, ce.city)
            self.combo_fav_city.setCurrentText(city.strip())
        finally:
            self._syncing_fav_combos = False

    def _on_fav_prov_combo_changed(self, _idx: int) -> None:
        if self._syncing_fav_combos:
            return
        prov = normalize_province_name(self.combo_fav_prov.currentText())
        self._syncing_fav_combos = True
        try:
            self.combo_fav_city.clear()
            self.combo_fav_city.addItem("", "")
            for ce in list_cities(prov):
                self.combo_fav_city.addItem(ce.city, ce.city)
        finally:
            self._syncing_fav_combos = False

        if prov and not self.edit_fav_lat.text().strip():
            pc = get_province_center(prov)
            if pc is not None:
                self.preview_map.set_view(pc[0], pc[1], 8)

    def _on_fav_city_combo_changed(self, _idx: int) -> None:
        if self._syncing_fav_combos:
            return
        prov = normalize_province_name(self.combo_fav_prov.currentText())
        city = self.combo_fav_city.currentText().strip()
        if city:
            ce = get_city_entry(prov, city)
            if ce is not None:
                self.preview_map.set_view(ce.lat, ce.lng, 12)

    def _on_preview_map_pin_changed(self, lat: float, lng: float) -> None:
        self.edit_fav_lat.setText(f"{lat:.6f}")
        self.edit_fav_lng.setText(f"{lng:.6f}")
        prov, city = infer_province_city(lat, lng)
        if prov or city:
            self._set_fav_admin_combos(prov, city)

    def _on_preview_map_hotspot_clicked(self, hs_obj: object) -> None:
        hs: EBirdHotspot = hs_obj  # type: ignore[assignment]
        self.edit_fav_ebird_id.setText(hs.loc_id)
        self.edit_fav_ebird_name.setText(hs.loc_name)
        if not self.edit_fav_name.text().strip():
            self.edit_fav_name.setText(suggest_short_spot_name(hs.loc_name, hs.subnational1_code))

    def _locate_form_coords_on_map(self) -> None:
        try:
            lat = float(self.edit_fav_lat.text().strip())
            lng = float(self.edit_fav_lng.text().strip())
        except ValueError:
            QMessageBox.information(self, "提示", "请先输入有效的十进制纬度与经度。")
            return
        self.preview_map.set_pin(lat, lng, pan_to=True, zoom=14, emit_signal=True)

    def _open_fullscreen_map_for_form(self) -> None:
        lat: float | None = None
        lng: float | None = None
        try:
            if self.edit_fav_lat.text().strip() and self.edit_fav_lng.text().strip():
                lat = float(self.edit_fav_lat.text().strip())
                lng = float(self.edit_fav_lng.text().strip())
        except ValueError:
            pass

        dlg = MapPickerDialog(
            self,
            self.svc,
            initial_lat=lat,
            initial_lng=lng,
            initial_province=self.combo_fav_prov.currentText().strip(),
            initial_city=self.combo_fav_city.currentText().strip(),
            initial_spot_name=self.edit_fav_name.text().strip(),
            initial_ebird_id=self.edit_fav_ebird_id.text().strip(),
            photo_count=0,
        )
        dlg.chk_save_fav.setVisible(False)
        dlg.chk_save_fav.setChecked(False)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            res = dlg.picked_result()
            if res is not None:
                self.edit_fav_lat.setText(f"{res.lat:.6f}")
                self.edit_fav_lng.setText(f"{res.lng:.6f}")
                self._set_fav_admin_combos(res.province, res.city)
                if res.spot_name:
                    self.edit_fav_name.setText(res.spot_name)
                if res.ebird_loc_id:
                    self.edit_fav_ebird_id.setText(res.ebird_loc_id)
                self.preview_map.set_pin(res.lat, res.lng, pan_to=True, zoom=15, emit_signal=False)

    # ---------------- Favorites Logic ----------------

    def _refresh_favorites_table(self) -> None:
        self._favorites = self.svc.list_favorites()
        self.fav_table.setRowCount(len(self._favorites))
        for r_idx, fav in enumerate(self._favorites):
            self.fav_table.setItem(r_idx, 0, QTableWidgetItem(f"⭐ {fav.name}"))
            self.fav_table.setItem(r_idx, 1, QTableWidgetItem(fav.admin_label or "-"))
            self.fav_table.setItem(r_idx, 2, QTableWidgetItem(fav.ebird_loc_id or "-"))
            coord_str = f"{fav.lat:.4f}, {fav.lng:.4f}" if (fav.lat is not None and fav.lng is not None) else "-"
            self.fav_table.setItem(r_idx, 3, QTableWidgetItem(coord_str))
        self.preview_map.set_overlay_data(hotspots=self._hotspots, favorites=self._favorites)

    def _on_fav_row_selected(self) -> None:
        row = self.fav_table.currentRow()
        if not (0 <= row < len(self._favorites)):
            return
        fav = self._favorites[row]
        self._editing_fav_id = fav.fav_id
        self.edit_fav_name.setText(fav.name)
        self._set_fav_admin_combos(fav.province, fav.city)
        self.edit_fav_ebird_id.setText(fav.ebird_loc_id or "")
        self.edit_fav_ebird_name.setText(fav.ebird_loc_name)
        self.edit_fav_lat.setText(f"{fav.lat:.6f}" if fav.lat is not None else "")
        self.edit_fav_lng.setText(f"{fav.lng:.6f}" if fav.lng is not None else "")
        self.edit_fav_notes.setText(fav.notes)
        self.btn_save_fav.setText("✓ 更新常用观鸟点")
        if fav.lat is not None and fav.lng is not None:
            self.preview_map.set_pin(fav.lat, fav.lng, pan_to=True, zoom=14, emit_signal=False)

    def _clear_fav_form(self) -> None:
        self._editing_fav_id = None
        self.fav_table.clearSelection()
        self.edit_fav_name.clear()
        self._set_fav_admin_combos("", "")
        self.edit_fav_ebird_id.clear()
        self.edit_fav_ebird_name.clear()
        self.edit_fav_lat.clear()
        self.edit_fav_lng.clear()
        self.edit_fav_notes.clear()
        self.btn_save_fav.setText("✓ 保存常用观鸟点")

    def _save_favorite(self) -> None:
        name = self.edit_fav_name.text().strip()
        if not name:
            QMessageBox.warning(self, "提示", "请输入常用观鸟点名称。")
            return

        def _parse_float(txt: str) -> float | None:
            t = txt.strip()
            if not t:
                return None
            return float(t)

        try:
            lat = _parse_float(self.edit_fav_lat.text())
            lng = _parse_float(self.edit_fav_lng.text())
        except ValueError:
            QMessageBox.warning(self, "坐标格式有误", "纬度和经度请输入十进制数字（例如 39.992 和 116.391），或留空。")
            return

        prov = normalize_province_name(self.combo_fav_prov.currentText().strip())
        city = self.combo_fav_city.currentText().strip()
        raw_lid = self.edit_fav_ebird_id.text().strip()
        lid = extract_ebird_loc_id(raw_lid) or (raw_lid if raw_lid else None)

        self.svc.db.upsert_favorite_location(
            name,
            fav_id=self._editing_fav_id,
            province=prov,
            city=city,
            region=format_province_city(prov, city),
            ebird_loc_id=lid,
            ebird_loc_name=self.edit_fav_ebird_name.text(),
            lat=lat,
            lng=lng,
            notes=self.edit_fav_notes.text(),
        )
        self._clear_fav_form()
        self._refresh_favorites_table()
        self.favorites_changed.emit()

    def _delete_selected_favorite(self) -> None:
        row = self.fav_table.currentRow()
        if not (0 <= row < len(self._favorites)):
            return
        fav = self._favorites[row]
        ans = QMessageBox.question(self, "删除常用观鸟点", f"确定从常用列表中移除「{fav.name}」吗？（不影响已归档的照片）")
        if ans == QMessageBox.StandardButton.Yes:
            self.svc.db.delete_favorite_location(fav.fav_id)
            self._clear_fav_form()
            self._refresh_favorites_table()
            self.favorites_changed.emit()

    def _apply_selected_favorite_to_photos(self) -> None:
        row = self.fav_table.currentRow()
        if not (0 <= row < len(self._favorites)):
            QMessageBox.information(self, "提示", "请先在左侧表格点选一个常用观鸟点。")
            return
        fav = self._favorites[row]
        self.apply_location_requested.emit(
            fav.name,
            fav.ebird_loc_id or "",
            fav.lat,
            fav.lng,
            fav.province,
            fav.city,
        )
        self.accept()

    # ---------------- eBird Hotspots Sync & Search ----------------

    def _save_api_key(self) -> None:
        self.svc.set_api_key(self.edit_api_key.text())
        self._update_cache_status_label("✓ 已保存 eBird API Key")

    def _update_cache_status_label(self, prefix: str = "") -> None:
        cnt = self.svc.db.count_ebird_hotspots()
        msg = f"本地已缓存 {cnt} 个 eBird 官方鸟点"
        if cnt == 0:
            msg += "（填入上方免费 API Key 后点击“同步”即可下载全国鸟点离线秒搜）"
        if prefix:
            msg = f"{prefix} · {msg}"
        self.lbl_cache_status.setText(msg)

    def _start_region_sync(self) -> None:
        self.svc.set_api_key(self.edit_api_key.text())
        raw_reg = self.combo_region.currentText().strip()
        if "(" in raw_reg:
            raw_reg = raw_reg.split("(", 1)[0].strip()

        self.btn_sync.setEnabled(False)
        self.lbl_cache_status.setText(f"正在从 eBird 官方服务器同步地区 [{raw_reg}] 鸟点数据，请稍候...")

        worker = _EBirdSyncWorker(str(self.svc.db.db_path), raw_reg)
        worker.finished_ok.connect(self._on_sync_done)
        worker.failed.connect(self._on_sync_failed)
        self._tracker.start(worker)

    def _on_sync_done(self, total: int, detail: str) -> None:
        self.btn_sync.setEnabled(True)
        self._update_cache_status_label(f"✓ 同步成功（共更新 {total} 个鸟点: {detail}）")
        self._run_hotspot_search()

    def _on_sync_failed(self, err: str) -> None:
        self.btn_sync.setEnabled(True)
        self._update_cache_status_label("")
        QMessageBox.warning(self, "eBird 同步提示", err)

    def _on_filter_prov_changed(self, _idx: int) -> None:
        if self._syncing_filter_combos:
            return
        prov = str(self.combo_filter_prov.currentData() or "")
        self._syncing_filter_combos = True
        try:
            self.combo_filter_city.clear()
            self.combo_filter_city.addItem("全部地市", "")
            for ce in list_cities(prov):
                self.combo_filter_city.addItem(ce.city, ce.city)
        finally:
            self._syncing_filter_combos = False
        self._run_hotspot_search()

    def _run_hotspot_search(self) -> None:
        kw = self.edit_hotspot_search.text().strip()
        prov_filter = str(self.combo_filter_prov.currentData() or "")
        city_filter = str(self.combo_filter_city.currentData() or "")
        ebird_reg_code = PROVINCE_TO_EBIRD_CODE.get(prov_filter, "")

        try:
            spots = self.svc.search_cached_hotspots(kw, region_filter=ebird_reg_code, limit=200)
            if city_filter:
                spots = [s for s in spots if s.city_name == city_filter or city_filter.rstrip("市区县州盟") in (s.city_name or "")]
            spots = spots[:80]
        except Exception:
            spots = []
        self._populate_hotspot_table(spots)

    def _search_nearby_by_photo_gps(self) -> None:
        if self.active_photo_gps is None:
            return
        self.svc.set_api_key(self.edit_api_key.text())
        lat, lng = self.active_photo_gps
        self.btn_gps_nearby.setEnabled(False)
        self.lbl_cache_status.setText(f"正在搜索坐标 ({lat:.4f}, {lng:.4f}) 周边 25km 内的 eBird 鸟点...")

        worker = _EBirdNearbyWorker(str(self.svc.db.db_path), lat, lng)
        worker.finished_ok.connect(self._on_nearby_done)
        worker.failed.connect(self._on_nearby_failed)
        self._tracker.start(worker)

    def _on_nearby_done(self, spots_obj: object) -> None:
        self.btn_gps_nearby.setEnabled(True)
        spots: list[EBirdHotspot] = spots_obj  # type: ignore[assignment]
        self._update_cache_status_label(f"✓ 找到照片周边 {len(spots)} 个 eBird 鸟点")
        self._populate_hotspot_table(spots)

    def _on_nearby_failed(self, err: str) -> None:
        self.btn_gps_nearby.setEnabled(True)
        QMessageBox.warning(self, "GPS 周边搜索失败", err)

    def _populate_hotspot_table(self, spots: list[EBirdHotspot]) -> None:
        self._hotspots = spots
        self.hotspot_table.setRowCount(len(spots))
        for idx, h in enumerate(spots):
            self.hotspot_table.setItem(idx, 0, QTableWidgetItem(h.loc_name))
            prov_lbl = format_region_label(h.country_code, h.subnational1_code)
            admin_lbl = f"{prov_lbl}·{h.city_name}" if (prov_lbl and h.city_name) else (h.city_name or prov_lbl)
            self.hotspot_table.setItem(idx, 1, QTableWidgetItem(admin_lbl))
            sp_txt = f"{h.num_species} 种" if h.num_species else "-"
            self.hotspot_table.setItem(idx, 2, QTableWidgetItem(sp_txt))
            dist_txt = f"{h.distance_km:.1f}km · {h.loc_id}" if h.distance_km is not None else h.loc_id
            self.hotspot_table.setItem(idx, 3, QTableWidgetItem(dist_txt))
        self.preview_map.set_overlay_data(hotspots=spots, favorites=self._favorites)

    def _selected_hotspot(self) -> EBirdHotspot | None:
        row = self.hotspot_table.currentRow()
        if 0 <= row < len(self._hotspots):
            return self._hotspots[row]
        return None

    def _on_hotspot_row_selected(self) -> None:
        h = self._selected_hotspot()
        if h is not None and h.lat is not None and h.lng is not None:
            self.preview_map.set_view(h.lat, h.lng, 14)

    def _add_selected_hotspot_as_favorite(self) -> None:
        h = self._selected_hotspot()
        if h is None:
            QMessageBox.information(self, "提示", "请先在右侧列表点选一个 eBird 鸟点。")
            return
        fav = self.svc.save_favorite_from_hotspot(h)
        self._refresh_favorites_table()
        self.favorites_changed.emit()
        self._update_cache_status_label(f"✓ 已将「{fav.name}」（{fav.admin_label}）加入常用观鸟点并关联 {h.loc_id}")

    def _bind_hotspot_to_left_form(self) -> None:
        h = self._selected_hotspot()
        if h is None:
            QMessageBox.information(self, "提示", "请先在右侧列表点选一个 eBird 鸟点。")
            return
        if not self.edit_fav_name.text().strip():
            self.edit_fav_name.setText(suggest_short_spot_name(h.loc_name, h.subnational1_code))
        prov, city = infer_province_city(
            h.lat,
            h.lng,
            subnational1_code=h.subnational1_code or h.country_code,
            text_hint=h.loc_name,
        )
        self._set_fav_admin_combos(prov, h.city_name or city)
        self.edit_fav_ebird_id.setText(h.loc_id)
        self.edit_fav_ebird_name.setText(h.loc_name)
        if h.lat is not None:
            self.edit_fav_lat.setText(f"{h.lat:.6f}")
        if h.lng is not None:
            self.edit_fav_lng.setText(f"{h.lng:.6f}")
        if h.lat is not None and h.lng is not None:
            self.preview_map.set_pin(h.lat, h.lng, pan_to=True, zoom=14, emit_signal=False)

    def _apply_selected_hotspot_to_photos(self) -> None:
        h = self._selected_hotspot()
        if h is None:
            QMessageBox.information(self, "提示", "请先在右侧列表点选一个 eBird 鸟点。")
            return
        short_name = suggest_short_spot_name(h.loc_name, h.subnational1_code)
        prov, city = infer_province_city(
            h.lat,
            h.lng,
            subnational1_code=h.subnational1_code or h.country_code,
            text_hint=h.loc_name,
        )
        self.apply_location_requested.emit(
            short_name,
            h.loc_id,
            h.lat,
            h.lng,
            prov,
            h.city_name or city,
        )
        self.accept()

    def _open_selected_hotspot_web(self) -> None:
        h = self._selected_hotspot()
        if h is not None:
            QDesktopServices.openUrl(QUrl(h.ebird_url))

"""Bird species sticker icon loader (reads big-year-birding/stickers + bundled mini_stickers)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from PIL import Image
from PySide6.QtGui import QIcon, QImage, QPixmap


def _candidate_data_dirs() -> list[Path]:
    dirs: list[Path] = []
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
        dirs.append(exe_dir / "data")
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        dirs.append(Path(meipass) / "data")
    dirs.append(Path(__file__).resolve().parents[3] / "data")
    return dirs


def _candidate_live_sticker_dirs() -> list[Path]:
    """Candidate live `big-year-birding/stickers` directories on disk."""
    dirs: list[Path] = []
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
        dirs.extend(
            [
                exe_dir / "stickers",
                exe_dir.parent / "big-year-birding" / "stickers",
                exe_dir.parent.parent / "big-year-birding" / "stickers",
            ]
        )
    repo_root = Path(__file__).resolve().parents[3]
    dirs.append(repo_root.parent / "big-year-birding" / "stickers")
    dirs.append(Path.home() / ".gemini" / "antigravity" / "scratch" / "big-year-birding" / "stickers")

    unique: list[Path] = []
    seen: set[str] = set()
    for d in dirs:
        key = str(d)
        if key not in seen and d.is_dir():
            seen.add(key)
            unique.append(d)
    return unique


def _pil_rgba_to_qicon(im: Image.Image, target_px: int = 56, crop_alpha: bool = False) -> QIcon:
    rgba = im.convert("RGBA")
    if crop_alpha:
        bbox = rgba.getbbox()
        if bbox:
            rgba = rgba.crop(bbox)
    if rgba.width != target_px or rgba.height != target_px:
        canvas = Image.new("RGBA", (target_px, target_px), (0, 0, 0, 0))
        rgba.thumbnail((target_px - 2, target_px - 2), Image.Resampling.LANCZOS)
        ox = (target_px - rgba.width) // 2
        oy = (target_px - rgba.height) // 2
        canvas.paste(rgba, (ox, oy), rgba)
        rgba = canvas

    raw_bytes = rgba.tobytes("raw", "RGBA")
    qimg = QImage(
        raw_bytes,
        rgba.width,
        rgba.height,
        rgba.width * 4,
        QImage.Format.Format_RGBA8888,
    ).copy()
    return QIcon(QPixmap.fromImage(qimg))


class StickerIconProvider:
    """Resolves species (common_name_cn / scientific_name) to small transparent bird sticker QIcons."""

    def __init__(self, extra_sticker_dir: str | Path | None = None) -> None:
        self._cache: dict[str, QIcon | None] = {}
        self._by_cn: dict[str, str] = {}
        self._by_sci: dict[str, str] = {}
        self._mini_dirs: list[Path] = []
        self._live_dirs: list[Path] = []

        if extra_sticker_dir is not None and Path(extra_sticker_dir).is_dir():
            self._live_dirs.append(Path(extra_sticker_dir))
        self._live_dirs.extend(_candidate_live_sticker_dirs())

        for d in _candidate_data_dirs():
            mini = d / "mini_stickers"
            if mini.is_dir():
                self._mini_dirs.append(mini)
            alias_file = d / "sticker_aliases.json"
            if alias_file.is_file() and not self._by_cn:
                try:
                    payload = json.loads(alias_file.read_text(encoding="utf-8"))
                    self._by_cn = dict(payload.get("by_cn") or {})
                    self._by_sci = dict(payload.get("by_sci") or {})
                except Exception:
                    pass

    def get_species_icon(self, species_cn: str, scientific_name: str = "") -> QIcon | None:
        """Return QIcon for a bird species if a sticker exists, else None (caller uses fallback 🐦)."""
        cache_key = f"{species_cn}|{scientific_name}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        stems = self._candidate_stems(species_cn, scientific_name)
        icon = self._load_first_matching_icon(stems)
        self._cache[cache_key] = icon
        return icon

    def _candidate_stems(self, species_cn: str, scientific_name: str) -> list[str]:
        stems: list[str] = []
        cn = species_cn.strip()
        sci = scientific_name.strip()

        if cn and cn in self._by_cn:
            stems.append(self._by_cn[cn])
        if sci:
            sci_low = sci.lower()
            if sci_low in self._by_sci:
                stems.append(self._by_sci[sci_low])
            stems.append(sci.replace(" ", "_"))
        if cn:
            stems.append(cn)

        # Deduplicate preserving order
        out: list[str] = []
        seen: set[str] = set()
        for s in stems:
            if s and s not in seen:
                seen.add(s)
                out.append(s)
        return out

    def _load_first_matching_icon(self, stems: list[str]) -> QIcon | None:
        for stem in stems:
            # Check if a live sticker exists in big-year-birding/stickers
            live_file: Path | None = None
            for ldir in self._live_dirs:
                for ext in (".webp", ".png"):
                    cand = ldir / f"{stem}{ext}"
                    if cand.is_file():
                        live_file = cand
                        break
                if live_file is not None:
                    break

            # Check pre-cropped 56x56 mini_stickers (0.2ms fast path unless live file was modified more recently)
            for mdir in self._mini_dirs:
                mcand = mdir / f"{stem}.webp"
                if mcand.is_file():
                    if live_file is not None:
                        try:
                            if live_file.stat().st_mtime > mcand.stat().st_mtime + 1.0:
                                break
                        except OSError:
                            pass
                    try:
                        with Image.open(mcand) as im:
                            return _pil_rgba_to_qicon(im, target_px=56, crop_alpha=False)
                    except Exception:
                        continue

            if live_file is not None:
                try:
                    with Image.open(live_file) as im:
                        return _pil_rgba_to_qicon(im, target_px=56, crop_alpha=True)
                except Exception:
                    continue

        return None

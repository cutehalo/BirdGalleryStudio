"""Embedded QtWebEngine dialog for syncing China BirdReport (birdreport.cn) checklists by ID or URL.

Runs entirely inside the application's own Qt window (eliminating external Edge/Chrome subprocess
handoff issues, Startup Boost false exits, popup blockers, and localhost port conflicts).
Never bypasses or auto-solves CAPTCHAs: if birdreport.cn requests slider or code verification,
the user completes it directly in the embedded view and the report is captured automatically once rendered.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import QTimer, QUrl, Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.birdreport_sync import (
    BirdReportTarget,
    RawBirdReportData,
    RawBirdReportSpecies,
    parse_birdreport_inputs,
)
from bird_gallery.checklists import PersonalChecklistService
from bird_gallery.models import BirdingChecklist

# Read-only DOM & Layui table inspection script.
# Handles both /home/search/report.html (auto-triggering safeJump once the user completes slider verification)
# and /home/record/page.html (reading all decrypted species rows up to limit: 1500).
_WEBENGINE_INSPECT_JS_TPL = r"""
(function(expectedSerial) {
    var href = window.location.href || '';
    var path = window.location.pathname || '';

    // Detect official BirdReport human verification widgets:
    // 1) TAC slider/click captcha (#captcha-global-container / #captcha-global-container_mask)
    // 2) Rate-limit 4-char image captcha (.layui-layer-iframe -> /home/code/verify.html)
    var tacBox = document.getElementById('captcha-global-container');
    var tacMask = document.getElementById('captcha-global-container_mask');
    var layerIframe = document.querySelector('.layui-layer-iframe');
    var isVerifyVisible = !!(
        (tacMask && tacMask.offsetParent !== null) ||
        (tacBox && tacBox.offsetParent !== null && tacBox.children.length > 0) ||
        (layerIframe && layerIframe.offsetParent !== null)
    );

    // Helper: collect species rows from Layui table cache or rendered table DOM
    function collectSpeciesItems() {
        var items = [];
        if (window.layui && window.layui.table && window.layui.table.cache) {
            var cacheObj = window.layui.table.cache;
            var cKeys = Object.keys(cacheObj);
            for (var ck = 0; ck < cKeys.length; ck++) {
                var arr = cacheObj[cKeys[ck]];
                if (Array.isArray(arr) && arr.length > 0 && arr[0] && (arr[0].taxon_name || arr[0].taxonName)) {
                    for (var j = 0; j < arr.length; j++) {
                        var r = arr[j];
                        var tn = String(r.taxon_name || r.taxonName || '').trim();
                        if (tn) {
                            items.push({
                                taxon_name: tn,
                                latin_name: String(r.latinname || r.latinName || '').trim(),
                                count_str: String(r.taxon_count != null ? r.taxon_count : (r.taxonCount != null ? r.taxonCount : '1')).trim()
                            });
                        }
                    }
                    if (items.length > 0) return items;
                }
            }
        }

        var trs = document.querySelectorAll('td[data-field="taxon_name"]');
        for (var k = 0; k < trs.length; k++) {
            var tdName = trs[k];
            var tr = tdName.closest('tr');
            if (!tr) continue;
            var cName = (tdName.innerText || tdName.textContent || '').trim();
            var lName = tr.querySelector('td[data-field="latinname"]')?.innerText?.trim() || '';
            var cCnt = tr.querySelector('td[data-field="taxon_count"]')?.innerText?.trim() || '1';
            if (cName) {
                items.push({taxon_name: cName, latin_name: lName, count_str: cCnt});
            }
        }
        return items;
    }

    // 1. Search Results Page (/home/search/report.html)
    if (path.indexOf('/search/report.html') !== -1) {
        var links = document.querySelectorAll('a.safe-report-link');
        for (var i = 0; i < links.length; i++) {
            var a = links[i];
            var txt = (a.innerText || a.textContent || '').trim();
            var param = a.getAttribute('data-param') || '';
            var sign = a.getAttribute('data-sign') || '';
            if (param && sign && (!expectedSerial || txt === expectedSerial)) {
                if (!window.__agy_jumping_serial || window.__agy_jumping_serial !== txt) {
                    window.__agy_jumping_serial = txt;
                    window.location.href = '/home/record/page.html?param=' + param + '&sign=' + sign;
                }
                return JSON.stringify({stage: 'jumping_to_report', serial_id: txt});
            }
        }
        if (isVerifyVisible) {
            return JSON.stringify({stage: 'waiting_verify'});
        }
        var emptyEl = document.querySelector('.layui-table-main .layui-none');
        if (emptyEl && ((emptyEl.innerText || '').indexOf('无') !== -1)) {
            return JSON.stringify({
                stage: 'public_empty',
                serial_id: expectedSerial
            });
        }
        return JSON.stringify({stage: 'loading_search'});
    }

    // 2. Report Detail Page (/home/record/page.html or member detail view)
    if (path.indexOf('/record/page.html') !== -1) {
        if (isVerifyVisible) {
            return JSON.stringify({stage: 'waiting_verify'});
        }
        var serialSpan = document.getElementById('serialid');
        var serialTxt = serialSpan ? (serialSpan.innerText || '').trim() : '';
        var timeBegin = (document.getElementById('timebegin')?.innerText || '').trim();
        var timeEnd = (document.getElementById('timeend')?.innerText || '').trim();
        var pointName = (document.getElementById('pointname')?.innerText || '').trim();
        var noteTxt = (document.getElementById('note')?.innerText || '').trim();
        var taxonCntTxt = (document.getElementById('taxoncount')?.innerText || '').trim();
        var expectedCnt = parseInt(taxonCntTxt, 10) || 0;

        var items = collectSpeciesItems();
        var noneEl = document.querySelector('.taxon-grid .layui-none');

        if (serialTxt.indexOf('观鸟报告') !== -1 && (items.length > 0 || (expectedCnt === 0 && noneEl))) {
            return JSON.stringify({
                stage: 'done',
                serial_id: serialTxt.replace('观鸟报告', '').trim(),
                start_time: timeBegin,
                end_time: timeEnd,
                address: pointName,
                note: noteTxt,
                items: items
            });
        }

        // Check if page finished loading but report is private / under review (errorCode != 2 leaves serialid empty)
        if (document.readyState === 'complete' && !serialTxt && !isVerifyVisible) {
            window.__agy_empty_ticks = (window.__agy_empty_ticks || 0) + 1;
            if (window.__agy_empty_ticks >= 8) {
                return JSON.stringify({stage: 'report_unpublic'});
            }
        }
        return JSON.stringify({stage: 'loading_report'});
    }

    // 3. Member Center or other BirdReport pages: auto-detect if a species table is open
    var memberItems = collectSpeciesItems();
    if (memberItems.length > 0 && path.indexOf('/member/') !== -1) {
        return JSON.stringify({
            stage: 'member_ready',
            count: memberItems.length
        });
    }

    if (isVerifyVisible) {
        return JSON.stringify({stage: 'waiting_verify'});
    }
    return JSON.stringify({stage: 'browsing', href: href});
})(%SERIAL_JSON%);
"""

_MANUAL_EXTRACT_JS = r"""
(function() {
    var serialTxt = (document.getElementById('serialid')?.innerText || '').replace('观鸟报告', '').trim();
    var timeBegin = (document.getElementById('timebegin')?.innerText || '').trim();
    var pointName = (document.getElementById('pointname')?.innerText || '').trim();
    var noteTxt = (document.getElementById('note')?.innerText || '').trim();

    var items = [];
    if (window.layui && window.layui.table && window.layui.table.cache) {
        var cacheObj = window.layui.table.cache;
        var cKeys = Object.keys(cacheObj);
        for (var ck = 0; ck < cKeys.length; ck++) {
            var arr = cacheObj[cKeys[ck]];
            if (Array.isArray(arr) && arr.length > 0 && arr[0] && (arr[0].taxon_name || arr[0].taxonName)) {
                for (var j = 0; j < arr.length; j++) {
                    var r = arr[j];
                    var tn = String(r.taxon_name || r.taxonName || '').trim();
                    if (tn) {
                        items.push({
                            taxon_name: tn,
                            latin_name: String(r.latinname || r.latinName || '').trim(),
                            count_str: String(r.taxon_count != null ? r.taxon_count : (r.taxonCount != null ? r.taxonCount : '1')).trim()
                        });
                    }
                }
                if (items.length > 0) break;
            }
        }
    }

    if (items.length === 0) {
        var trs = document.querySelectorAll('td[data-field="taxon_name"]');
        for (var k = 0; k < trs.length; k++) {
            var tdName = trs[k];
            var tr = tdName.closest('tr');
            if (!tr) continue;
            var cName = (tdName.innerText || tdName.textContent || '').trim();
            var lName = tr.querySelector('td[data-field="latinname"]')?.innerText?.trim() || '';
            var cCnt = tr.querySelector('td[data-field="taxon_count"]')?.innerText?.trim() || '1';
            if (cName) {
                items.push({taxon_name: cName, latin_name: lName, count_str: cCnt});
            }
        }
    }

    return JSON.stringify({
        serial_id: serialTxt,
        start_time: timeBegin,
        address: pointName,
        note: noteTxt,
        items: items,
        body_text: document.body ? (document.body.innerText || '') : ''
    });
})();
"""


def _resolve_webengine_storage_dir() -> Path:
    from bird_gallery.paths import resolve_app_data_dir

    cand = resolve_app_data_dir() / ".bird_gallery_cache" / "webengine_birdreport"
    try:
        cand.mkdir(parents=True, exist_ok=True)
        return cand
    except OSError:
        fallback = Path.home() / ".bird_gallery_cache" / "webengine_birdreport"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


_SHARED_PROFILE = None


def _get_persistent_web_profile(parent_app):
    """Return a singleton persistent QWebEngineProfile so BirdReport cookies/sessions persist."""
    global _SHARED_PROFILE
    if _SHARED_PROFILE is not None:
        return _SHARED_PROFILE

    from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings

    storage_dir = _resolve_webengine_storage_dir()
    profile = QWebEngineProfile("NiaoYuJiBirdReport", parent_app)
    profile.setPersistentStoragePath(str(storage_dir / "storage"))
    profile.setCachePath(str(storage_dir / "cache"))
    profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)

    settings = profile.settings()
    settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
    settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, True)
    settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
    _SHARED_PROFILE = profile
    return profile


class BirdReportWebSyncDialog(QDialog):
    """In-app QtWebEngine browser dialog that loads BirdReport.cn IDs/URLs and auto-extracts bird species."""

    def __init__(
        self,
        parent: QWidget | None,
        checklist_service: PersonalChecklistService,
        raw_input: str,
    ) -> None:
        super().__init__(parent)
        from PySide6.QtWidgets import QApplication
        from PySide6.QtWebEngineCore import QWebEnginePage
        from PySide6.QtWebEngineWidgets import QWebEngineView

        self.svc = checklist_service
        self.targets: list[BirdReportTarget] = parse_birdreport_inputs(raw_input)
        if not self.targets:
            raise ValueError(
                "未识别到有效的观鸟记录中心报告编号（如 2026112501740）或报告链接（https://www.birdreport.cn/home/record/page.html?param=...）。"
            )

        self._target_idx = 0
        self._saved_checklists: list[BirdingChecklist] = []
        self._eval_inflight = False
        self._finished_current = False

        self.setWindowTitle("🇨🇳 中国观鸟记录中心 — 报告自动获取窗口")
        self.resize(1040, 720)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # Top Status Banner + Controls
        top_row = QHBoxLayout()
        top_row.setSpacing(8)

        self.lbl_status = QLabel("🔄 正在连接中国观鸟记录中心加载报告...")
        self.lbl_status.setWordWrap(True)
        self.lbl_status.setStyleSheet(
            "color: #a8ffdb; background-color: #17332a; border: 1px solid #2b6b55; "
            "padding: 7px 10px; border-radius: 6px; font-size: 12px; font-weight: 600;"
        )
        top_row.addWidget(self.lbl_status, 1)

        btn_reload = QPushButton("🔄 刷新")
        btn_reload.setToolTip("重新加载当前网页")
        btn_reload.clicked.connect(lambda: self.web_view.reload())
        top_row.addWidget(btn_reload)

        btn_member = QPushButton("👤 登录个人中心")
        btn_member.setToolTip("若报告刚提交处于“审核中”或设为保密，可登录个人中心打开该报告后点右侧提取")
        btn_member.clicked.connect(self._open_member_center)
        top_row.addWidget(btn_member)

        self.btn_manual_extract = QPushButton("✓ 提取当前页鸟种")
        self.btn_manual_extract.setObjectName("PrimaryButton")
        self.btn_manual_extract.setToolTip("当下方页面已显示出鸟种表格时，也可点击此按钮立即提取保存")
        self.btn_manual_extract.clicked.connect(self._extract_current_page_manually)
        top_row.addWidget(self.btn_manual_extract)

        btn_cancel = QPushButton("关闭")
        btn_cancel.clicked.connect(self.reject)
        top_row.addWidget(btn_cancel)
        root.addLayout(top_row)

        # Custom QWebEnginePage that redirects `window.open` (e.g. safeJump newTab:true) into the same view!
        dialog_ref = self

        class _InPlaceWebPage(QWebEnginePage):
            def createWindow(self, _win_type: QWebEnginePage.WebWindowType) -> QWebEnginePage:
                popup = QWebEnginePage(self.profile(), dialog_ref)

                def _redirect_to_main(new_url: QUrl) -> None:
                    u = new_url.toString()
                    if u and u != "about:blank":
                        self.setUrl(new_url)
                        popup.deleteLater()

                popup.urlChanged.connect(_redirect_to_main)
                return popup

        profile = _get_persistent_web_profile(QApplication.instance())
        self.web_view = QWebEngineView(self)
        self.web_page = _InPlaceWebPage(profile, self.web_view)
        self.web_view.setPage(self.web_page)
        root.addWidget(self.web_view, 1)

        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(450)
        self._poll_timer.timeout.connect(self._poll_page_state)
        self._poll_timer.start()

        self._load_current_target()

    def synced_checklists(self) -> list[BirdingChecklist]:
        return list(self._saved_checklists)

    def _cleanup_web(self) -> None:
        self._poll_timer.stop()
        self.web_view.stop()

    def closeEvent(self, event) -> None:
        self._cleanup_web()
        super().closeEvent(event)

    def reject(self) -> None:
        self._cleanup_web()
        super().reject()

    # ---------------- Navigation & Polling ----------------

    def _load_current_target(self) -> None:
        self._finished_current = False
        self._eval_inflight = False
        target = self.targets[self._target_idx]
        idx_tag = f" ({self._target_idx + 1}/{len(self.targets)})" if len(self.targets) > 1 else ""
        self._set_banner(
            f"🔄 正在加载报告{idx_tag}：{target.value[:48]} ...（显示出鸟种表格后将自动读取保存）",
            kind="info",
        )
        self.web_view.setUrl(QUrl(target.start_url))

    def _open_member_center(self) -> None:
        self._set_banner(
            "👤 已打开个人中心：登录后点开你的某篇观鸟报告详情页，系统会自动识别或点击右上角「✓ 提取当前页鸟种」保存。",
            kind="info",
        )
        self.web_view.setUrl(QUrl("https://www.birdreport.cn/member/index.html"))

    def _set_banner(self, text: str, *, kind: str = "info") -> None:
        styles = {
            "info": (
                "color: #a8ffdb; background-color: #17332a; border: 1px solid #2b6b55; "
                "padding: 7px 10px; border-radius: 6px; font-size: 12px; font-weight: 600;"
            ),
            "verify": (
                "color: #fef08a; background-color: #422006; border: 1px solid #eab308; "
                "padding: 7px 10px; border-radius: 6px; font-size: 12px; font-weight: 700;"
            ),
            "warn": (
                "color: #fecaca; background-color: #451a1a; border: 1px solid #ef4444; "
                "padding: 7px 10px; border-radius: 6px; font-size: 12px; font-weight: 600;"
            ),
        }
        self.lbl_status.setStyleSheet(styles.get(kind, styles["info"]))
        self.lbl_status.setText(text)

    def _poll_page_state(self) -> None:
        if self._eval_inflight or self._finished_current or self._target_idx >= len(self.targets):
            return
        target = self.targets[self._target_idx]
        expected_serial = target.value if target.kind == "serial_id" else ""
        js_code = _WEBENGINE_INSPECT_JS_TPL.replace("%SERIAL_JSON%", json.dumps(expected_serial))

        self._eval_inflight = True
        self.web_page.runJavaScript(js_code, self._on_poll_js_result)

    def _on_poll_js_result(self, raw_val: object) -> None:
        self._eval_inflight = False
        if self._finished_current or not isinstance(raw_val, str) or not raw_val:
            return
        try:
            state = json.loads(raw_val)
        except Exception:
            return

        stage = state.get("stage", "")
        if stage == "waiting_verify":
            self._set_banner(
                "🛡 请在下方观鸟记录中心页面完成官方验证码（拖动拼图滑块或输入4位验证码），验证通过显示鸟种后将自动提取并关闭窗口！",
                kind="verify",
            )
        elif stage == "jumping_to_report":
            sid = state.get("serial_id", "")
            self._set_banner(f"✓ 已定位报告 {sid}，正在加载报告详情与全部鸟种列表...", kind="info")
        elif stage == "public_empty":
            sid = state.get("serial_id", "")
            self._set_banner(
                f"⚠ 公开检索未查到报告 {sid}（刚提交处于“审核中”或设为“保密”的报告公开页暂不可见）："
                "可点击右上角「👤 登录个人中心」打开该报告，再点「✓ 提取当前页鸟种」！",
                kind="warn",
            )
        elif stage == "report_unpublic":
            self._set_banner(
                "⚠ 该报告当前可能处于“审核中”或“保密”状态，公开链接暂未返回内容。可点击右上角「👤 登录个人中心」查看并提取！",
                kind="warn",
            )
        elif stage == "member_ready":
            cnt = state.get("count", 0)
            self._set_banner(
                f"✓ 检测到个人中心页面包含 {cnt} 种鸟类表格，点击右上角「✓ 提取当前页鸟种」即可保存！",
                kind="info",
            )
        elif stage == "done":
            self._finished_current = True
            self._save_extracted_report_dict(state, advance_next=True)

    def _save_extracted_report_dict(self, state: dict[str, object], *, advance_next: bool) -> None:
        raw_items = state.get("items") or []
        sp_list = [
            RawBirdReportSpecies(
                taxon_name=str(it.get("taxon_name") or "").strip(),
                latin_name=str(it.get("latin_name") or "").strip(),
                count_str=str(it.get("count_str") or "1").strip(),
            )
            for it in raw_items  # type: ignore[attr-defined]
            if isinstance(it, dict) and str(it.get("taxon_name") or "").strip()
        ]
        target = self.targets[min(self._target_idx, len(self.targets) - 1)]
        fallback_sid = target.value if target.kind == "serial_id" else ""
        rep = RawBirdReportData(
            serial_id=str(state.get("serial_id") or fallback_sid),
            start_time=str(state.get("start_time") or ""),
            end_time=str(state.get("end_time") or ""),
            address=str(state.get("address") or ""),
            note=str(state.get("note") or ""),
            species=sp_list,
        )
        try:
            saved = self.svc.save_raw_birdreport_data(rep)
            self._saved_checklists.append(saved)
        except Exception as exc:
            self._finished_current = False
            self._set_banner(f"⚠ 保存报告数据失败：{exc}", kind="warn")
            return

        if advance_next:
            self._target_idx += 1
            if self._target_idx < len(self.targets):
                self._load_current_target()
            else:
                self._cleanup_web()
                self.accept()

    def _extract_current_page_manually(self) -> None:
        self.btn_manual_extract.setEnabled(False)

        def _on_manual_js(raw_val: object) -> None:
            self.btn_manual_extract.setEnabled(True)
            if not isinstance(raw_val, str) or not raw_val:
                QMessageBox.warning(self, "提取失败", "当前页面尚未加载完成。")
                return
            data = json.loads(raw_val)
            items = data.get("items") or []
            if items:
                self._finished_current = True
                self._save_extracted_report_dict(data, advance_next=False)
                self._cleanup_web()
                self.accept()
                return

            # Fallback: full-page text longest-match bird parser (works on any personal center / custom layout!)
            body_text = str(data.get("body_text") or "")
            draft = self.svc.parse_birdreport_text(body_text)
            if not draft.items:
                QMessageBox.information(
                    self,
                    "未检测到鸟种列表",
                    "当前页面中尚未识别到鸟种数据，请先等待页面表格加载完成（如有验证码请先完成验证）。",
                )
                return
            if not draft.obs_date:
                target = self.targets[min(self._target_idx, len(self.targets) - 1)]
                if target.kind == "serial_id" and len(target.value) >= 8 and target.value[:8].isdigit():
                    s8 = target.value[:8]
                    draft.obs_date = f"{s8[:4]}-{s8[4:6]}-{s8[6:8]}"
            try:
                saved = self.svc.save_parsed_draft(draft, source="birdreport")
                self._saved_checklists.append(saved)
                self._cleanup_web()
                self.accept()
            except ValueError as exc:
                QMessageBox.warning(self, "缺少日期信息", str(exc))

        self.web_page.runJavaScript(_MANUAL_EXTRACT_JS, _on_manual_js)

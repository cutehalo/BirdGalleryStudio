"""Left navigation sidebar: Multi-dimensional Catalog Tree + Zero-Hang Lazy Disk Browser."""

from __future__ import annotations

import ctypes
import os
import sys
from pathlib import Path

from PySide6.QtCore import QSize, QUrl, Qt, Signal
from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.catalog import CatalogService
from bird_gallery.gui.stickers import StickerIconProvider
from bird_gallery.models import FilterQuery

_DUMMY_ROLE = Qt.ItemDataRole.UserRole + 10


def _list_roots_fast() -> list[tuple[str, str]]:
    """List Windows drive letters or POSIX root without invoking Windows Shell / SHGetFileInfo."""
    if os.name == "nt":
        roots: list[tuple[str, str]] = []
        # Quick shortcuts to common user folders first
        home = Path.home()
        for label, sub in (("🖥 桌面", home / "Desktop"), ("🖼 图片", home / "Pictures"), ("⬇ 下载", home / "Downloads")):
            if sub.exists():
                roots.append((f"{label} ({sub.name})", str(sub)))

        try:
            bitmask = ctypes.windll.kernel32.GetLogicalDrives()
            for idx in range(26):
                if bitmask & (1 << idx):
                    drive = f"{chr(65 + idx)}:\\"
                    roots.append((f"🖴 本地磁盘 ({drive[:2]})", drive))
        except Exception:
            roots.append(("🖴 C:", "C:\\"))
        return roots

    home = Path.home()
    posix_roots: list[tuple[str, str]] = []
    for label, sub in (("🖥 桌面", home / "Desktop"), ("🖼 图片", home / "Pictures"), ("⬇ 下载", home / "Downloads")):
        if sub.exists():
            posix_roots.append((f"{label} ({sub.name})", str(sub)))
    posix_roots.append(("🏠 个人主目录", str(home)))
    if sys.platform == "darwin":
        volumes = Path("/Volumes")
        if volumes.is_dir():
            try:
                for vol in sorted(volumes.iterdir()):
                    if not vol.name.startswith("."):
                        posix_roots.append((f"💾 存储卷 ({vol.name})", str(vol)))
            except OSError:
                pass
    posix_roots.append(("🖴 /", "/"))
    return posix_roots


class LazyDiskTreeWidget(QTreeWidget):
    """Ultra-fast folder tree powered by os.scandir (avoids QFileSystemModel & Shell hangs on Windows)."""

    folder_clicked = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setHeaderHidden(True)
        self.setIndentation(16)
        self.setUniformRowHeights(True)
        self.itemExpanded.connect(self._on_item_expanded)
        self.itemClicked.connect(self._on_item_clicked)
        self._populated = False

    def ensure_roots_loaded(self) -> None:
        if self._populated:
            return
        self._populated = True
        self.clear()
        for label, path_str in _list_roots_fast():
            node = QTreeWidgetItem(self, [label])
            node.setData(0, Qt.ItemDataRole.UserRole, path_str)
            self._add_dummy_child(node)

    @staticmethod
    def _add_dummy_child(item: QTreeWidgetItem) -> None:
        dummy = QTreeWidgetItem(item, ["读取中..."])
        dummy.setData(0, _DUMMY_ROLE, True)

    def _on_item_expanded(self, item: QTreeWidgetItem) -> None:
        if item.childCount() == 1 and item.child(0).data(0, _DUMMY_ROLE):
            item.takeChildren()
            folder_str = str(item.data(0, Qt.ItemDataRole.UserRole) or "")
            if not folder_str:
                return
            subdirs: list[tuple[str, str]] = []
            try:
                with os.scandir(folder_str) as it:
                    for entry in it:
                        try:
                            if entry.name.startswith(".") or entry.name.startswith("$"):
                                continue
                            if entry.is_dir(follow_symlinks=False):
                                subdirs.append((entry.name, entry.path))
                        except OSError:
                            continue
            except OSError:
                err_item = QTreeWidgetItem(item, ["（无访问权限或设备未就绪）"])
                err_item.setForeground(0, QColor("#7a7f87"))
                err_item.setFlags(Qt.ItemFlag.NoItemFlags)
                return

            subdirs.sort(key=lambda x: x[0].lower())
            for name, full_path in subdirs[:1000]:
                child = QTreeWidgetItem(item, [f"📁 {name}"])
                child.setData(0, Qt.ItemDataRole.UserRole, full_path)
                self._add_dummy_child(child)

    def _on_item_clicked(self, item: QTreeWidgetItem, _col: int) -> None:
        path_str = str(item.data(0, Qt.ItemDataRole.UserRole) or "")
        if path_str:
            self.folder_clicked.emit(path_str)


class FastFolderPickerDialog(QDialog):
    """Instant, Shell-extension-free dark folder picker dialog with direct path input."""

    def __init__(self, parent: QWidget | None, title: str = "选择文件夹") -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(560, 480)

        layout = QVBoxLayout(self)
        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("路径:"))
        self.edit_path = QLineEdit()
        self.edit_path.setPlaceholderText("点击下方文件夹，或直接粘贴文件夹路径（如 D:\\鸟片）")
        path_row.addWidget(self.edit_path, 1)
        layout.addLayout(path_row)

        self.disk_tree = LazyDiskTreeWidget(self)
        self.disk_tree.ensure_roots_loaded()
        self.disk_tree.folder_clicked.connect(self.edit_path.setText)
        layout.addWidget(self.disk_tree, 1)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("确定选择")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _validate_and_accept(self) -> None:
        raw = self.edit_path.text().strip().strip('"')
        if not raw or not os.path.isdir(raw):
            QMessageBox.warning(self, "无效目录", "请选择或输入一个存在的文件夹路径。")
            return
        self.edit_path.setText(raw)
        self.accept()

    def selected_folder(self) -> str:
        return self.edit_path.text().strip()


class NavigatorPanel(QWidget):
    """Lightroom-style left sidebar with Catalog Collections/Trees and Direct Disk File Browser."""

    filter_selected = Signal(object, str)  # (FilterQuery, view_title)
    open_field_guide_requested = Signal()
    open_location_manager_requested = Signal()
    open_checklist_manager_requested = Signal()
    disk_folder_selected = Signal(str)  # folder_path for live disk preview
    import_disk_folder_requested = Signal(str)  # folder_path to import into catalog
    albums_changed = Signal()

    def __init__(self, catalog: CatalogService) -> None:
        super().__init__()
        self.catalog = catalog
        self._stickers = StickerIconProvider()
        self._current_disk_path: str = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # ---- Tab 1: 图库与相册导航 ----
        cat_tab = QWidget()
        cat_layout = QVBoxLayout(cat_tab)
        cat_layout.setContentsMargins(8, 8, 8, 6)
        cat_layout.setSpacing(6)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)
        self.btn_new_album = QPushButton("＋ 新建相册")
        self.btn_new_album.setObjectName("SubtleActionBtn")
        self.btn_new_album.clicked.connect(self._create_album_dialog)
        self.btn_open_guide = QPushButton("鸟种图鉴")
        self.btn_open_guide.setObjectName("SubtleActionBtn")
        self.btn_open_guide.clicked.connect(self.open_field_guide_requested.emit)
        btn_row.addWidget(self.btn_new_album, 1)
        btn_row.addWidget(self.btn_open_guide, 1)
        cat_layout.addLayout(btn_row)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(14)
        self.tree.setIconSize(QSize(22, 22))
        self.tree.itemClicked.connect(self._on_tree_item_clicked)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._on_tree_context_menu)
        cat_layout.addWidget(self.tree, 1)

        self.tabs.addTab(cat_tab, "图库导航")

        # ---- Tab 2: 本地磁盘直览（零阻塞目录树） ----
        disk_tab = QWidget()
        disk_layout = QVBoxLayout(disk_tab)
        disk_layout.setContentsMargins(8, 8, 8, 6)
        disk_layout.setSpacing(6)

        disk_hint = QLabel("点击任意磁盘目录秒开预览原片/RAW，无需预先导入：")
        disk_hint.setWordWrap(True)
        disk_hint.setStyleSheet("color: #64748B; font-size: 11px;")
        disk_layout.addWidget(disk_hint)

        jump_row = QHBoxLayout()
        self.edit_quick_path = QLineEdit()
        self.edit_quick_path.setPlaceholderText("输入或粘贴目录路径回车直达...")
        self.edit_quick_path.returnPressed.connect(self._on_quick_path_entered)
        jump_row.addWidget(self.edit_quick_path, 1)
        disk_layout.addLayout(jump_row)

        self.btn_import_current = QPushButton("＋ 导入当前目录到图库")
        self.btn_import_current.setObjectName("PrimaryButton")
        self.btn_import_current.setEnabled(False)
        self.btn_import_current.clicked.connect(self._on_import_current_disk_folder)
        disk_layout.addWidget(self.btn_import_current)

        self.fs_tree = LazyDiskTreeWidget(self)
        self.fs_tree.folder_clicked.connect(self._on_disk_folder_clicked)
        disk_layout.addWidget(self.fs_tree, 1)

        self.tabs.addTab(disk_tab, "磁盘直览")
        self.tabs.currentChanged.connect(self._on_tab_switched)

    def _on_tab_switched(self, tab_idx: int) -> None:
        if tab_idx == 1:
            self.fs_tree.ensure_roots_loaded()

    def _on_quick_path_entered(self) -> None:
        p = self.edit_quick_path.text().strip().strip('"')
        if p and os.path.isdir(p):
            self._on_disk_folder_clicked(p)

    def refresh(self) -> None:
        """Rebuild all catalog navigation sections with up-to-date counts."""
        stats = self.catalog.db.get_stats()
        self.tree.clear()

        bold_font = QFont("Microsoft YaHei UI", 8, QFont.Weight.Bold)
        sec_color = QColor("#64748B")
        muted_color = QColor("#475569")

        def _make_section(title: str, expanded: bool = True) -> QTreeWidgetItem:
            sec = QTreeWidgetItem(self.tree, [title])
            sec.setFont(0, bold_font)
            sec.setForeground(0, sec_color)
            sec.setFlags(Qt.ItemFlag.ItemIsEnabled)
            sec.setExpanded(expanded)
            return sec

        def _add_leaf(
            parent: QTreeWidgetItem,
            label: str,
            query: FilterQuery,
            view_title: str,
            *,
            extra_role: tuple[str, object] | None = None,
        ) -> QTreeWidgetItem:
            node = QTreeWidgetItem(parent, [label])
            node.setData(0, Qt.ItemDataRole.UserRole, (query, view_title))
            if extra_role:
                node.setData(0, Qt.ItemDataRole.UserRole + 1, extra_role)
            return node

        # 1. Quick Smart Views
        sec_overview = _make_section("智能视图", expanded=True)
        _add_leaf(
            sec_overview,
            f"全部照片  ·  {stats['active_photos']}",
            FilterQuery(),
            "全部照片",
        )
        _add_leaf(
            sec_overview,
            f"已归类鸟片  ·  {stats['with_birds']}",
            FilterQuery(has_bird=True),
            "已归类鸟片",
        )
        _add_leaf(
            sec_overview,
            f"待归类照片  ·  {stats['unassigned_photos']}",
            FilterQuery(unassigned_species_only=True),
            "待归类鸟种照片",
        )
        _add_leaf(
            sec_overview,
            f"留片精选  ·  {stats['picked_photos']}",
            FilterQuery(pick_only=True),
            "留片精选",
        )
        _add_leaf(
            sec_overview,
            f"三星及以上  ·  {stats['starred_3plus']}",
            FilterQuery(min_rating=3, sort_by="rating_desc"),
            "3星及以上照片",
        )
        _add_leaf(
            sec_overview,
            f"淘汰回收站  ·  {stats['rejected_photos']}",
            FilterQuery(rejected_only=True, include_rejected=True),
            "已淘汰照片",
        )

        # 2. Custom Virtual Albums
        albums = self.catalog.list_albums()
        sec_albums = _make_section(f"个人相册  ({len(albums)})", expanded=True)
        if not albums:
            placeholder = QTreeWidgetItem(sec_albums, ["暂无相册（点上方新建）"])
            placeholder.setForeground(0, muted_color)
            placeholder.setFlags(Qt.ItemFlag.NoItemFlags)
        else:
            for alb in albums:
                _add_leaf(
                    sec_albums,
                    f"◆  {alb.name}  ·  {alb.photo_count}",
                    FilterQuery(album_id=alb.album_id),
                    f"相册：{alb.name}",
                    extra_role=("album", alb.album_id),
                )

        # 3. Bird Species Tree (按图鉴鸟种：目 -> 科 -> 种)
        sp_tree = self.catalog.get_photographed_species_tree()
        sec_species = _make_section(f"按鸟种查看  ({len(sp_tree)} 目)", expanded=True)
        if not sp_tree:
            empty_sp = QTreeWidgetItem(sec_species, ["归类照片后自动生成分类树"])
            empty_sp.setForeground(0, muted_color)
            empty_sp.setFlags(Qt.ItemFlag.NoItemFlags)
        else:
            for ord_cn, ord_cnt, fam_list in sp_tree:
                ord_node = _add_leaf(
                    sec_species,
                    f"{ord_cn}  ({ord_cnt})",
                    FilterQuery(exact_order_cn=ord_cn),
                    f"鸟种分类：{ord_cn}",
                )
                ord_node.setExpanded(True)
                for fam_cn, fam_cnt, sp_list in fam_list:
                    fam_node = _add_leaf(
                        ord_node,
                        f"{fam_cn}  ({fam_cnt})",
                        FilterQuery(exact_family_cn=fam_cn),
                        f"鸟种分类：{ord_cn} > {fam_cn}",
                    )
                    fam_node.setExpanded(True)
                    for sp_cn, sp_cnt in sp_list:
                        taxon = self.catalog.taxonomy.lookup_by_cn(sp_cn)
                        sci_name = taxon.scientific_name if taxon else ""
                        sticker_icon = self._stickers.get_species_icon(sp_cn, sci_name)
                        if sticker_icon is not None:
                            sp_node = _add_leaf(
                                fam_node,
                                f"{sp_cn}  ·  {sp_cnt}",
                                FilterQuery(exact_species_cn=sp_cn),
                                f"鸟种：{sp_cn}",
                            )
                            sp_node.setIcon(0, sticker_icon)
                        else:
                            _add_leaf(
                                fam_node,
                                f"🐦 {sp_cn}  ·  {sp_cnt}",
                                FilterQuery(exact_species_cn=sp_cn),
                                f"鸟种：{sp_cn}",
                            )

        # 4. Date Timeline (按日期：年 -> 月 -> 日)
        date_tree, undated_cnt = self.catalog.get_date_hierarchy()
        sec_dates = _make_section("时间轴", expanded=True)
        for yr, yr_cnt, ym_list in date_tree:
            yr_node = _add_leaf(
                sec_dates,
                f"{yr} 年  ({yr_cnt})",
                FilterQuery(date_prefix=yr),
                f"日期：{yr} 年",
            )
            yr_node.setExpanded(True)
            for ym, ym_cnt, day_list in ym_list:
                ym_node = _add_leaf(
                    yr_node,
                    f"{ym}  ({ym_cnt})",
                    FilterQuery(date_prefix=ym),
                    f"日期：{ym}",
                )
                for ymd, d_cnt in day_list:
                    _add_leaf(
                        ym_node,
                        f"{ymd}  ·  {d_cnt}",
                        FilterQuery(date_prefix=ymd),
                        f"日期：{ymd}",
                    )
        if undated_cnt > 0:
            _add_leaf(
                sec_dates,
                f"未知日期  ·  {undated_cnt}",
                FilterQuery(undated_only=True),
                "日期：未知日期",
            )

        # 4b. Personal Birding Checklists
        checklists = self.catalog.db.list_checklists(limit=80)
        sec_cls = _make_section(f"观鸟报告  ({len(checklists)})", expanded=len(checklists) > 0)
        if not checklists:
            empty_cl = QTreeWidgetItem(sec_cls, ["未导入报告（点顶栏观鸟报告同步）"])
            empty_cl.setForeground(0, muted_color)
            empty_cl.setFlags(Qt.ItemFlag.NoItemFlags)
        else:
            for cl in checklists:
                loc_txt = f" · {cl.location_name}" if cl.location_name else (f" · {cl.admin_label}" if cl.admin_label else "")
                node_cl = _add_leaf(
                    sec_cls,
                    f"●  {cl.obs_date}{loc_txt}  ({cl.species_count}种)",
                    FilterQuery(date_prefix=cl.obs_date),
                    f"观鸟记录日：{cl.obs_date}{loc_txt}（记录 {cl.species_count} 种）",
                    extra_role=("checklist", cl.checklist_id),
                )
                node_cl.setToolTip(0, f"点击查看 {cl.obs_date} 当天拍摄的全部照片，右侧边栏自动关联该报告的 {cl.species_count} 种鸟类")

        # 5. Location / Birding Hotspots
        loc_tree, unlocated_cnt = self.catalog.get_location_hierarchy()
        sec_locs = _make_section("地理足迹（省 / 市 / 鸟点）", expanded=True)

        if not loc_tree and unlocated_cnt == 0:
            empty_loc = QTreeWidgetItem(sec_locs, ["设置观鸟点或含 GPS 照片后生成"])
            empty_loc.setForeground(0, muted_color)
            empty_loc.setFlags(Qt.ItemFlag.NoItemFlags)
        else:
            for prov_name, prov_cnt, city_list in loc_tree:
                prov_node = _add_leaf(
                    sec_locs,
                    f"{prov_name}  ({prov_cnt})",
                    FilterQuery(location_province=prov_name),
                    f"地区：{prov_name}",
                )
                prov_node.setExpanded(True)
                for city_name, city_cnt, spot_list in city_list:
                    city_node = _add_leaf(
                        prov_node,
                        f"{city_name}  ({city_cnt})",
                        FilterQuery(location_province=prov_name, location_city=city_name),
                        f"地区：{prov_name} · {city_name}",
                    )
                    city_node.setExpanded(True)
                    for loc_key, disp_label, spot_cnt, lid, is_fav in spot_list:
                        icon = "★" if is_fav else "·"
                        ebird_tag = f" [{lid}]" if lid else ""
                        _add_leaf(
                            city_node,
                            f"{icon}  {disp_label}{ebird_tag}  ·  {spot_cnt}",
                            FilterQuery(location_key=loc_key),
                            f"观鸟点：{prov_name}·{city_name} · {disp_label}",
                            extra_role=("location", (loc_key, lid, prov_name, city_name)),
                        )

            if unlocated_cnt > 0:
                _add_leaf(
                    sec_locs,
                    f"未设置地点  ·  {unlocated_cnt}",
                    FilterQuery(location_key="__unlocated__"),
                    "地点：未设置地点",
                    extra_role=("location", ("__unlocated__", None, "", "")),
                )

        # 6. Catalog Folders
        folder_counts = self.catalog.db.get_folder_counts()
        sec_folders = _make_section(f"已导入目录  ({len(folder_counts)})", expanded=False)
        for fpath, cnt in folder_counts:
            p = Path(fpath)
            short_name = f"{p.name}  [{p.parent}] ({cnt})" if p.name else f"{fpath} ({cnt})"
            node = _add_leaf(
                sec_folders,
                short_name,
                FilterQuery(folder_path=fpath, include_subfolders=False),
                f"文件夹：{fpath}",
            )
            node.setToolTip(0, fpath)

    def _on_tree_item_clicked(self, item: QTreeWidgetItem, _col: int) -> None:
        payload = item.data(0, Qt.ItemDataRole.UserRole)
        if payload is not None:
            query, title = payload
            self.filter_selected.emit(query, title)

    def _on_disk_folder_clicked(self, path: str) -> None:
        if path and os.path.isdir(path):
            self._current_disk_path = path
            self.edit_quick_path.setText(path)
            self.btn_import_current.setEnabled(True)
            self.btn_import_current.setText(f"📥 导入「{Path(path).name or path}」到图库")
            self.disk_folder_selected.emit(path)

    def _on_import_current_disk_folder(self) -> None:
        if self._current_disk_path:
            self.import_disk_folder_requested.emit(self._current_disk_path)

    def _create_album_dialog(self) -> None:
        name, ok = QInputDialog.getText(self, "新建自定义相册", "请输入相册名称（如：2026精选、飞版合集、圆明园春迁）：")
        if ok and name.strip():
            self.catalog.db.create_album(name.strip())
            self.refresh()
            self.albums_changed.emit()

    def _on_tree_context_menu(self, pos) -> None:
        item = self.tree.itemAt(pos)
        if item is None:
            return
        extra = item.data(0, Qt.ItemDataRole.UserRole + 1)
        if not extra:
            return

        if extra[0] == "checklist":
            menu = QMenu(self)
            act_cl_mgr = QAction("📋 打开个人观鸟记录同步与管理...", self)
            act_cl_mgr.triggered.connect(self.open_checklist_manager_requested.emit)
            menu.addAction(act_cl_mgr)
            menu.exec(self.tree.viewport().mapToGlobal(pos))
            return

        if extra[0] == "location":
            loc_key, lid, prov_n, city_n = extra[1]  # type: ignore[misc]
            menu = QMenu(self)
            if lid:
                act_web = QAction(f"🌐 在 eBird 查看该鸟点主页 ({lid})", self)
                act_web.triggered.connect(
                    lambda: QDesktopServices.openUrl(QUrl(f"https://ebird.org/hotspot/{lid}"))
                )
                menu.addAction(act_web)
            if loc_key != "__unlocated__":
                act_add_fav = QAction(f"⭐ 将「{loc_key}」加入常用观鸟点", self)
                p_val = "" if prov_n == "其他地区" else str(prov_n or "")
                c_val = "" if city_n == "未分地市" else str(city_n or "")
                act_add_fav.triggered.connect(
                    lambda: (
                        self.catalog.db.upsert_favorite_location(str(loc_key), province=p_val, city=c_val),
                        self.refresh(),
                        self.albums_changed.emit(),
                    )
                )
                menu.addAction(act_add_fav)
            act_mgr = QAction("⚙ 打开常用观鸟点 & 地图选点管理...", self)
            act_mgr.triggered.connect(self.open_location_manager_requested.emit)
            menu.addAction(act_mgr)
            menu.exec(self.tree.viewport().mapToGlobal(pos))
            return

        if extra[0] != "album":
            return

        album_id = int(extra[1])
        menu = QMenu(self)
        act_rename = QAction("✏ 重命名相册", self)
        act_delete = QAction("🗑 删除相册（不删照片）", self)

        def _do_rename() -> None:
            new_name, ok = QInputDialog.getText(self, "重命名相册", "新相册名称：")
            if ok and new_name.strip():
                self.catalog.db.rename_album(album_id, new_name.strip())
                self.refresh()
                self.albums_changed.emit()

        def _do_delete() -> None:
            ans = QMessageBox.question(
                self,
                "确认删除相册",
                "删除自定义相册不会删除任何原照片文件，确定继续吗？",
            )
            if ans == QMessageBox.StandardButton.Yes:
                self.catalog.db.delete_album(album_id)
                self.refresh()
                self.albums_changed.emit()
                self.filter_selected.emit(FilterQuery(), "全部照片")

        act_rename.triggered.connect(_do_rename)
        act_delete.triggered.connect(_do_delete)
        menu.addAction(act_rename)
        menu.addAction(act_delete)
        menu.exec(self.tree.viewport().mapToGlobal(pos))

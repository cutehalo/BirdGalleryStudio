"""Background QThread workers with safe lifecycle management (never blocks the Qt GUI thread)."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Qt, Signal
from PySide6.QtGui import QImage

from bird_gallery.catalog import CatalogService
from bird_gallery.config import (
    ALL_SUPPORTED_EXTENSIONS,
    EngineConfig,
)
from bird_gallery.db import GalleryDatabase
from bird_gallery.image_io import is_raw_file, load_preview_image, save_thumbnail
from bird_gallery.models import FilterQuery, PhotoRecord, ScanSummary
from bird_gallery.taxonomy import TaxonomyMapper


class WorkerTracker(QObject):
    """Keeps Python references to running QThreads until they naturally finish.

    Prevents Qt6's fatal `QThread: Destroyed while thread is still running` crash/hang
    when a user rapidly clicks through multiple folders or photos without waiting.
    """

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._active: set[QThread] = set()

    def start(self, worker: QThread) -> None:
        self._active.add(worker)
        worker.finished.connect(lambda w=worker: self._cleanup(w))
        worker.start()

    def _cleanup(self, worker: QThread) -> None:
        self._active.discard(worker)
        worker.deleteLater()

    def cancel_all(self) -> None:
        for w in list(self._active):
            if hasattr(w, "cancel"):
                w.cancel()


def _pil_to_qimage_scaled(path: Path, box_size: int) -> QImage | None:
    img = load_preview_image(path, max_edge=max(384, box_size * 2))
    rgb = img.convert("RGB")
    raw_bytes = rgb.tobytes("raw", "RGB")
    qimg = QImage(
        raw_bytes,
        rgb.width,
        rgb.height,
        rgb.width * 3,
        QImage.Format.Format_RGB888,
    ).copy()
    return qimg.scaled(
        box_size,
        box_size,
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )


class ImportFolderWorker(QThread):
    """Imports photos & RAW previews into SQLite on a background thread."""

    progress_changed = Signal(int, int, str)  # current, total, status_text
    import_finished = Signal(object)  # ScanSummary
    import_failed = Signal(str)

    def __init__(
        self,
        db_path: Path,
        thumbnail_dir: Path,
        source_folder: Path,
        *,
        default_location: str = "",
        default_album_id: int | None = None,
        force_reimport: bool = False,
    ) -> None:
        super().__init__()
        self.db_path = db_path
        self.thumbnail_dir = thumbnail_dir
        self.source_folder = source_folder
        self.default_location = default_location
        self.default_album_id = default_album_id
        self.force_reimport = force_reimport
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        try:
            cfg = EngineConfig(db_path=self.db_path, thumbnail_dir=self.thumbnail_dir)
            db = GalleryDatabase(self.db_path)
            catalog = CatalogService(db, TaxonomyMapper(), cfg)

            def _on_progress(idx: int, total: int, path: Path, _rec: object, err: str | None) -> None:
                if err == "skipped":
                    msg = f"跳过未变文件: {path.name}"
                elif err:
                    msg = f"读取失败: {path.name}"
                else:
                    msg = f"正在提取预览与EXIF: {path.name}"
                self.progress_changed.emit(idx, total, msg)

            summary: ScanSummary = catalog.import_folder(
                self.source_folder,
                default_location=self.default_location,
                default_album_id=self.default_album_id,
                force_reimport=self.force_reimport,
                on_progress=_on_progress,
                should_cancel=lambda: self._cancelled,
            )
            self.import_finished.emit(summary)
        except Exception as exc:
            self.import_failed.emit(str(exc))


class DiskFolderScanWorker(QThread):
    """Scans a disk folder off the UI thread using fast Win32 os.scandir."""

    folder_scanned = Signal(int, str, object, int)  # request_id, folder_path, list[PhotoRecord], total_count
    scan_failed = Signal(int, str, str)

    def __init__(
        self,
        request_id: int,
        folder: Path,
        db_path: Path,
        max_items: int = 500,
    ) -> None:
        super().__init__()
        self.request_id = request_id
        self.folder = folder
        self.db_path = db_path
        self.max_items = max_items
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        try:
            entries: list[tuple[str, str, int, float]] = []
            total_supported = 0

            with os.scandir(self.folder) as it:
                for entry in it:
                    if self._cancelled:
                        return
                    try:
                        if not entry.is_file(follow_symlinks=False):
                            continue
                        ext = os.path.splitext(entry.name)[1].lower()
                        if ext not in ALL_SUPPORTED_EXTENSIONS:
                            continue
                        total_supported += 1
                        st = entry.stat(follow_symlinks=False)
                        entries.append((entry.name, entry.path, st.st_size, st.st_mtime))
                    except OSError:
                        continue

            if self._cancelled:
                return

            entries.sort(key=lambda x: x[0].lower())
            entries = entries[: self.max_items]

            db = GalleryDatabase(self.db_path)
            norm_folder = str(self.folder.resolve())
            existing_rows = db.query_photos(
                FilterQuery(
                    folder_path=norm_folder,
                    include_subfolders=False,
                    include_rejected=True,
                    limit=max(2000, self.max_items * 2),
                )
            )
            by_name = {r.file_name.lower(): r for r in existing_rows}

            records: list[PhotoRecord] = []
            for fname, fpath, fsize, fmtime in entries:
                if self._cancelled:
                    return
                matched = by_name.get(fname.lower())
                if matched is not None:
                    records.append(matched)
                else:
                    p_obj = Path(fpath)
                    records.append(
                        PhotoRecord(
                            file_path=str(p_obj),
                            folder_path=norm_folder,
                            file_name=fname,
                            file_ext=p_obj.suffix.lower(),
                            file_size=fsize,
                            file_mtime=fmtime,
                            is_raw=is_raw_file(p_obj),
                        )
                    )

            if not self._cancelled:
                self.folder_scanned.emit(self.request_id, norm_folder, records, total_supported)
        except Exception as exc:
            if not self._cancelled:
                self.scan_failed.emit(self.request_id, str(self.folder), str(exc))


class ThumbnailStreamWorker(QThread):
    """Streams decoded, pre-scaled thumbnail QImages in small batches off the UI thread.

    1. If a cached small JPEG thumbnail already exists on disk, loads it directly with QImage (fast ~1ms).
    2. Otherwise decodes & caches a lightweight 384px JPEG thumbnail in `disk_cache_dir` so future visits are instant!
    """

    batch_ready = Signal(int, object)  # request_id, list[tuple[int, str, QImage]] -> (row_idx, thumb_path, qimg)

    def __init__(
        self,
        request_id: int,
        tasks: list[tuple[int, str, str | None]],  # (row_idx, file_path, existing_thumb_path)
        box_size: int,
        disk_cache_dir: Path,
        batch_size: int = 8,
    ) -> None:
        super().__init__()
        self.request_id = request_id
        self.tasks = tasks
        self.box_size = box_size
        self.disk_cache_dir = disk_cache_dir
        self.batch_size = batch_size
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def _cached_disk_thumb_path(self, source_file: str) -> Path:
        key = hashlib.sha1(source_file.encode("utf-8")).hexdigest()[:16]
        return self.disk_cache_dir / f"{key}.jpg"

    def run(self) -> None:
        self.disk_cache_dir.mkdir(parents=True, exist_ok=True)
        batch: list[tuple[int, str, QImage]] = []

        for row_idx, file_path, thumb_path in self.tasks:
            if self._cancelled:
                return

            try:
                resolved_thumb = ""
                qimg: QImage | None = None

                # Case A: Existing catalog thumbnail
                if thumb_path and os.path.exists(thumb_path):
                    tmp = QImage(thumb_path)
                    if not tmp.isNull():
                        resolved_thumb = thumb_path
                        qimg = tmp.scaled(
                            self.box_size,
                            self.box_size,
                            Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation,
                        )

                # Case B: Previously cached disk-browser preview thumbnail
                if qimg is None:
                    cached = self._cached_disk_thumb_path(file_path)
                    if cached.exists():
                        tmp = QImage(str(cached))
                        if not tmp.isNull():
                            resolved_thumb = str(cached)
                            qimg = tmp.scaled(
                                self.box_size,
                                self.box_size,
                                Qt.AspectRatioMode.KeepAspectRatio,
                                Qt.TransformationMode.SmoothTransformation,
                            )

                # Case C: Decode original image/RAW preview off-thread and save compact 384px cache
                if qimg is None and os.path.exists(file_path):
                    src_p = Path(file_path)
                    pil_img = load_preview_image(src_p, max_edge=384)
                    saved_thumb = save_thumbnail(pil_img, src_p, self.disk_cache_dir, max_size=384)
                    resolved_thumb = str(saved_thumb)
                    rgb = pil_img.convert("RGB")
                    raw_bytes = rgb.tobytes("raw", "RGB")
                    tmp = QImage(
                        raw_bytes,
                        rgb.width,
                        rgb.height,
                        rgb.width * 3,
                        QImage.Format.Format_RGB888,
                    ).copy()
                    qimg = tmp.scaled(
                        self.box_size,
                        self.box_size,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    )

                if qimg is not None and not qimg.isNull():
                    batch.append((row_idx, resolved_thumb, qimg))
                    if len(batch) >= self.batch_size:
                        if self._cancelled:
                            return
                        self.batch_ready.emit(self.request_id, batch)
                        batch = []
            except Exception:
                continue

        if batch and not self._cancelled:
            self.batch_ready.emit(self.request_id, batch)


class HighResPreviewWorker(QThread):
    """Asynchronously decodes a high-res standard image or RAW preview into a QImage."""

    image_loaded = Signal(int, str, QImage, int, int)  # request_id, file_path, qimage, orig_w, orig_h
    load_failed = Signal(int, str, str)

    def __init__(self, request_id: int, file_path: Path, max_edge: int = 2560) -> None:
        super().__init__()
        self.request_id = request_id
        self.file_path = file_path
        self.max_edge = max_edge
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        if self._cancelled:
            return
        try:
            pil_img = load_preview_image(self.file_path, max_edge=self.max_edge)
            if self._cancelled:
                return
            rgb = pil_img.convert("RGB")
            raw_bytes = rgb.tobytes("raw", "RGB")
            qimg = QImage(
                raw_bytes,
                rgb.width,
                rgb.height,
                rgb.width * 3,
                QImage.Format.Format_RGB888,
            ).copy()
            if not self._cancelled:
                self.image_loaded.emit(self.request_id, str(self.file_path), qimg, rgb.width, rgb.height)
        except Exception as exc:
            if not self._cancelled:
                self.load_failed.emit(self.request_id, str(self.file_path), str(exc))

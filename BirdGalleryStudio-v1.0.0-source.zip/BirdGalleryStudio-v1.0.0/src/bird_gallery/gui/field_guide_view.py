"""Interactive Bird Field Guide ('鸟种图鉴') with China/Global scope, Life List ('点亮模式'), and Pinyin search."""

from __future__ import annotations

from PySide6.QtCore import QSize, QTimer, Qt, Signal
from PySide6.QtGui import QAction, QColor, QIcon
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.catalog import CatalogService, FieldGuideOverview
from bird_gallery.gui.theme import render_species_guide_pixmap
from bird_gallery.models import FieldGuideSpeciesCard


class FieldGuideView(QWidget):
    """Visual checklist of bird species showing photographed ('lit') vs unphotographed birds."""

    species_selected = Signal(str)  # Emits common_name_cn to filter gallery photos
    assign_selected_photos_to_species = Signal(str)  # Emits common_name_cn

    def __init__(self, catalog: CatalogService) -> None:
        super().__init__()
        self.catalog = catalog
        self._scope = "china"  # "china" | "world"
        self._status_filter = "all"
        self._families_by_order: dict[str, list[str]] = {}
        self._updating_combos = False

        self._search_debounce = QTimer(self)
        self._search_debounce.setSingleShot(True)
        self._search_debounce.setInterval(120)
        self._search_debounce.timeout.connect(self.refresh)

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 14, 16, 10)
        root.setSpacing(12)

        # 1. Hero Life-List Dashboard Card
        banner = QFrame()
        banner.setStyleSheet(
            "QFrame#GuideHeroBanner { "
            "background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #131D28, stop:1 #111622); "
            "border: 1px solid #223044; border-radius: 12px; }"
        )
        banner.setObjectName("GuideHeroBanner")
        banner_layout = QVBoxLayout(banner)
        banner_layout.setContentsMargins(18, 14, 18, 14)
        banner_layout.setSpacing(10)

        top_row = QHBoxLayout()
        title_col = QVBoxLayout()
        title_col.setSpacing(3)
        self.lbl_title = QLabel("个人观鸟生涯图鉴  ·  中国鸟类名录")
        self.lbl_title.setStyleSheet("font-size: 16px; font-weight: 800; color: #F8FAFC; background: transparent;")
        title_col.addWidget(self.lbl_title)

        hint_lbl = QLabel("支持拼音首字母极速检索（如 ptcn 翠鸟、hlpl 黑脸琵鹭） ·  双击卡片查阅照片  ·  右键归入选中照片")
        hint_lbl.setStyleSheet("color: #64748B; font-size: 12px; background: transparent;")
        title_col.addWidget(hint_lbl)
        top_row.addLayout(title_col, 1)

        # Crisp KPI Stat Cluster on the right
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(18)

        self.lbl_kpi_lit = QLabel("0")
        self.lbl_kpi_lit.setStyleSheet("font-size: 20px; font-weight: 800; color: #34D399; background: transparent;")
        self.lbl_kpi_pct = QLabel("0.0%")
        self.lbl_kpi_pct.setStyleSheet("font-size: 20px; font-weight: 800; color: #38BDF8; background: transparent;")
        self.lbl_kpi_photos = QLabel("0")
        self.lbl_kpi_photos.setStyleSheet("font-size: 20px; font-weight: 800; color: #F1F5F9; background: transparent;")

        for val_lbl, cap_txt in (
            (self.lbl_kpi_lit, "已点亮鸟种"),
            (self.lbl_kpi_pct, "名录覆盖率"),
            (self.lbl_kpi_photos, "收录鸟片"),
        ):
            box = QVBoxLayout()
            box.setSpacing(1)
            val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
            cap = QLabel(cap_txt)
            cap.setAlignment(Qt.AlignmentFlag.AlignRight)
            cap.setStyleSheet("font-size: 11px; color: #64748B; background: transparent;")
            box.addWidget(val_lbl)
            box.addWidget(cap)
            kpi_row.addLayout(box)

        top_row.addLayout(kpi_row)
        banner_layout.addLayout(top_row)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(7)
        banner_layout.addWidget(self.progress_bar)

        bottom_banner_row = QHBoxLayout()
        self.lbl_stats = QLabel("已点亮 0 / 0 种 (0.0%) · 共收录 0 张鸟片")
        self.lbl_stats.setStyleSheet("font-size: 12px; color: #94A3B8; background: transparent;")
        bottom_banner_row.addWidget(self.lbl_stats)
        bottom_banner_row.addStretch(1)
        self.lbl_matched_info = QLabel("")
        self.lbl_matched_info.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 600; background: transparent;")
        bottom_banner_row.addWidget(self.lbl_matched_info)
        banner_layout.addLayout(bottom_banner_row)
        root.addWidget(banner)

        # 2. Filter Bar (Segmented Scope + Segmented Lit Status + Order/Family + Spotlight Search)
        filter_row = QHBoxLayout()
        filter_row.setSpacing(8)

        scope_cap = QFrame()
        scope_cap.setObjectName("SegmentedCapsule")
        scope_cap_l = QHBoxLayout(scope_cap)
        scope_cap_l.setContentsMargins(3, 3, 3, 3)
        scope_cap_l.setSpacing(2)

        self.btn_scope_china = QPushButton("中国名录")
        self.btn_scope_world = QPushButton("全球名录")
        for b in (self.btn_scope_china, self.btn_scope_world):
            b.setObjectName("SegmentBtn")
            b.setCheckable(True)
            scope_cap_l.addWidget(b)
        self.btn_scope_china.setChecked(True)
        filter_row.addWidget(scope_cap)

        self.scope_group = QButtonGroup(self)
        self.scope_group.setExclusive(True)
        self.scope_group.addButton(self.btn_scope_china, 0)
        self.scope_group.addButton(self.btn_scope_world, 1)
        self.scope_group.idClicked.connect(self._on_scope_changed)

        status_cap = QFrame()
        status_cap.setObjectName("SegmentedCapsule")
        status_cap_l = QHBoxLayout(status_cap)
        status_cap_l.setContentsMargins(3, 3, 3, 3)
        status_cap_l.setSpacing(2)

        self.btn_all = QPushButton("全部")
        self.btn_lit = QPushButton("已点亮")
        self.btn_unlit = QPushButton("未点亮")
        for b in (self.btn_all, self.btn_lit, self.btn_unlit):
            b.setObjectName("SegmentBtn")
            b.setCheckable(True)
            status_cap_l.addWidget(b)
        self.btn_all.setChecked(True)
        filter_row.addWidget(status_cap)

        self.filter_group = QButtonGroup(self)
        self.filter_group.setExclusive(True)
        self.filter_group.addButton(self.btn_all, 0)
        self.filter_group.addButton(self.btn_lit, 1)
        self.filter_group.addButton(self.btn_unlit, 2)
        self.filter_group.idClicked.connect(self._on_status_btn_clicked)

        self.combo_order = QComboBox()
        self.combo_order.setMinimumWidth(124)
        self.combo_order.currentIndexChanged.connect(self._on_order_changed)
        filter_row.addWidget(self.combo_order)

        self.combo_family = QComboBox()
        self.combo_family.setMinimumWidth(132)
        self.combo_family.currentIndexChanged.connect(self._on_family_changed)
        filter_row.addWidget(self.combo_family)

        self.search_edit = QLineEdit()
        self.search_edit.setObjectName("SpotlightSearch")
        self.search_edit.setPlaceholderText("搜索鸟名 / 拼音首字母(如 ptcn、btb、hlpl) / 全拼 / 学名 / 科属...")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.textChanged.connect(lambda _t: self._search_debounce.start())
        filter_row.addWidget(self.search_edit, 1)

        root.addLayout(filter_row)

        # 3. Species Card Grid
        self.grid = QListWidget()
        self.grid.setObjectName("FieldGuideGrid")
        self.grid.setViewMode(QListWidget.ViewMode.IconMode)
        self.grid.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.grid.setMovement(QListWidget.Movement.Static)
        self.grid.setUniformItemSizes(True)
        self.grid.setIconSize(QSize(194, 138))
        self.grid.setGridSize(QSize(218, 214))
        self.grid.setWordWrap(True)
        self.grid.setSpacing(6)
        self.grid.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.grid.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid.customContextMenuRequested.connect(self._on_context_menu)
        root.addWidget(self.grid, 1)

    def _on_scope_changed(self, btn_id: int) -> None:
        self._scope = "china" if btn_id == 0 else "world"
        scope_label = "中国鸟类名录" if self._scope == "china" else "全球鸟类名录"
        self.lbl_title.setText(f"个人观鸟生涯图鉴  ·  {scope_label}")
        self._updating_combos = True
        self.combo_order.clear()
        self.combo_family.clear()
        self._updating_combos = False
        self.refresh()

    def _on_status_btn_clicked(self, btn_id: int) -> None:
        self._status_filter = {0: "all", 1: "lit", 2: "unlit"}.get(btn_id, "all")
        self.refresh()

    def _on_order_changed(self) -> None:
        if self._updating_combos:
            return
        self._updating_combos = True
        selected_order = self.combo_order.currentData()
        self.combo_family.clear()
        self.combo_family.addItem("全部科", None)
        if selected_order and selected_order in self._families_by_order:
            for fam in self._families_by_order[selected_order]:
                self.combo_family.addItem(fam, fam)
        self._updating_combos = False
        self.refresh()

    def _on_family_changed(self) -> None:
        if not self._updating_combos:
            self.refresh()

    def refresh(self) -> None:
        selected_order = self.combo_order.currentData()
        selected_family = self.combo_family.currentData()

        overview: FieldGuideOverview = self.catalog.get_field_guide(
            scope=self._scope,
            status_filter=self._status_filter,
            order_cn=selected_order,
            family_cn=selected_family,
            keyword=self.search_edit.text(),
            max_cards=360,
        )
        self._families_by_order = overview.families_by_order

        if self.combo_order.count() <= 1 or self.combo_order.count() != len(overview.orders) + 1:
            self._updating_combos = True
            prev_order = selected_order
            self.combo_order.clear()
            self.combo_order.addItem("全部目", None)
            for ord_name in overview.orders:
                self.combo_order.addItem(ord_name, ord_name)
            if prev_order:
                idx = self.combo_order.findData(prev_order)
                if idx >= 0:
                    self.combo_order.setCurrentIndex(idx)
            if self.combo_family.count() == 0:
                self.combo_family.addItem("全部科", None)
            self._updating_combos = False

        total = max(1, overview.total_checklist_count)
        pct = (overview.lit_count / total) * 100.0
        self.lbl_kpi_lit.setText(f"{overview.lit_count} / {overview.total_checklist_count}")
        self.lbl_kpi_pct.setText(f"{pct:.1f}%")
        self.lbl_kpi_photos.setText(str(overview.total_bird_photos))
        self.lbl_stats.setText(
            f"点亮进度：{overview.lit_count} / {overview.total_checklist_count} 种  ·  共收录 {overview.total_bird_photos} 张归类鸟片"
        )
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(overview.lit_count)

        if overview.matched_count > len(overview.cards):
            self.lbl_matched_info.setText(
                f"匹配 {overview.matched_count} 种（当前展示前 {len(overview.cards)} 张卡片，输入拼音/选择目科可精准筛选）"
            )
        else:
            self.lbl_matched_info.setText(f"当前展示 {len(overview.cards)} 种")

        self.grid.setUpdatesEnabled(False)
        self.grid.clear()
        for card in overview.cards:
            self._add_species_card(card)
        self.grid.setUpdatesEnabled(True)

    def _add_species_card(self, card: FieldGuideSpeciesCard) -> None:
        cover = card.cover_thumbnail_path or card.cover_file_path
        pix = render_species_guide_pixmap(
            cover,
            width=190,
            height=136,
            is_lit=card.is_lit,
            photo_count=card.photo_count,
        )
        sci_short = card.scientific_name if len(card.scientific_name) <= 22 else card.scientific_name[:20] + "…"
        caption = f"{card.common_name_cn}\n{sci_short}\n{card.order_cn} · {card.family_cn}"

        item = QListWidgetItem(QIcon(pix), caption)
        item.setData(Qt.ItemDataRole.UserRole, card.common_name_cn)
        item.setData(Qt.ItemDataRole.UserRole + 1, card.is_lit)
        item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        if card.is_lit:
            item.setForeground(QColor("#e8fff4"))
            first_seen = f"\n首次拍摄: {card.first_seen_date}" if card.first_seen_date else ""
            item.setToolTip(
                f"【已点亮】{card.common_name_cn} ({card.scientific_name})\n"
                f"分类：{card.order_cn} > {card.family_cn}\n"
                f"收录照片：{card.photo_count} 张{first_seen}\n"
                f"双击查看该鸟种全部照片"
            )
        else:
            item.setForeground(QColor("#8b9098"))
            item.setToolTip(
                f"【未点亮】{card.common_name_cn} ({card.scientific_name})\n"
                f"分类：{card.order_cn} > {card.family_cn}\n"
                f"英文名：{card.common_name_en}"
            )
        self.grid.addItem(item)

    def _on_item_double_clicked(self, item: QListWidgetItem) -> None:
        species_cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if species_cn:
            self.species_selected.emit(species_cn)

    def _on_context_menu(self, pos) -> None:
        item = self.grid.itemAt(pos)
        if item is None:
            return
        species_cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if not species_cn:
            return

        menu = QMenu(self)
        act_view = QAction(f"🔍 查看「{species_cn}」的所有照片", self)
        act_view.triggered.connect(lambda: self.species_selected.emit(species_cn))
        menu.addAction(act_view)

        act_assign = QAction(f"📌 将当前选中的照片归类为「{species_cn}」", self)
        act_assign.triggered.connect(lambda: self.assign_selected_photos_to_species.emit(species_cn))
        menu.addAction(act_assign)

        menu.exec(self.grid.viewport().mapToGlobal(pos))

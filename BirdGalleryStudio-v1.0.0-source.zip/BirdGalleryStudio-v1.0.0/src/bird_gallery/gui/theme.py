"""Next-generation Obsidian & Emerald Studio UI theme, QSS design system, and HiDPI card renderers."""

from __future__ import annotations

import ctypes
import os
from pathlib import Path

from PIL import Image
from PySide6.QtCore import QPointF, QRect, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPalette,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import QCompleter, QWidget

DARK_STYLESHEET = """
/* =========================================================================
   鸟羽集 · Next-Gen Obsidian & Kingfisher Studio Design System
   Layered Surfaces:
     Canvas L0:   #0B0E14   (Deep cinema stage for photography)
     Chrome L1:   #11151E   (Sidebars & window frame)
     Surface L2:  #161B26   (Elevated cards & panels)
     Control L3:  #1D2432   (Inputs, pills & interactive controls)
     Border:      #232B3A   (Subtle hairline divider)
     Primary:     #10B981   (Kingfisher emerald)
     Selection:   #38BDF8   (Glacial cyan ring)
   ========================================================================= */

QMainWindow, QDialog {
    background-color: #11151E;
    color: #E2E8F0;
    font-family: "PingFang SC", "Microsoft YaHei UI", "-apple-system", "Segoe UI Variable Display", "Segoe UI", sans-serif;
    font-size: 13px;
}

QWidget {
    color: #E2E8F0;
    font-family: "PingFang SC", "Microsoft YaHei UI", "-apple-system", "Segoe UI Variable Display", "Segoe UI", sans-serif;
    font-size: 13px;
}

QToolTip {
    background-color: #18202F;
    color: #F1F5F9;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
}

QSplitter::handle {
    background-color: #1C2230;
    width: 1px;
    height: 1px;
}

QSplitter::handle:hover {
    background-color: #38BDF8;
}

/* ---- Top Command Header Bar ---- */
QFrame#TopHeaderBar {
    background-color: #11151E;
    border-bottom: 1px solid #1E2533;
}

QFrame#CenterSubHeader {
    background-color: #0E121A;
    border-bottom: 1px solid #1B2230;
}

QFrame#SegmentedCapsule {
    background-color: #0B0E14;
    border: 1px solid #212938;
    border-radius: 9px;
}

QPushButton#SegmentBtn {
    background-color: transparent;
    color: #94A3B8;
    border: 1px solid transparent;
    border-radius: 6px;
    padding: 4px 14px;
    font-size: 12px;
    font-weight: 600;
}

QPushButton#SegmentBtn:hover:!checked {
    color: #E2E8F0;
    background-color: rgba(255, 255, 255, 0.04);
}

QPushButton#SegmentBtn:checked {
    background-color: #21293A;
    color: #F8FAFC;
    border: 1px solid #334155;
    font-weight: 700;
}

/* ---- Status Bar ---- */
QStatusBar {
    background-color: #0E1219;
    color: #64748B;
    border-top: 1px solid #1C2331;
    font-size: 12px;
}

QStatusBar::item {
    border: none;
}

/* ---- Modern Sidebar Tabs ---- */
QTabWidget::pane {
    border: none;
    background-color: #11151E;
}

QTabBar {
    background-color: #11151E;
}

QTabBar::tab {
    background-color: transparent;
    color: #64748B;
    padding: 9px 16px;
    margin: 0px 2px;
    border: none;
    border-bottom: 2px solid transparent;
    font-size: 12px;
    font-weight: 600;
}

QTabBar::tab:selected {
    color: #F8FAFC;
    border-bottom: 2px solid #10B981;
    font-weight: 700;
}

QTabBar::tab:hover:!selected {
    color: #CBD5E1;
}

/* ---- Trees, Lists & Tables ---- */
QTreeWidget, QTreeView {
    background-color: #11151E;
    border: none;
    outline: 0;
    padding: 4px;
    selection-background-color: transparent;
}

QTreeWidget::item, QTreeView::item {
    padding: 5px 8px;
    margin: 1px 2px;
    border-radius: 6px;
    color: #CBD5E1;
}

QTreeWidget::item:hover, QTreeView::item:hover {
    background-color: #181F2C;
    color: #F8FAFC;
}

QTreeWidget::item:selected, QTreeView::item:selected {
    background-color: #162B28;
    color: #6EE7B7;
    font-weight: 600;
}

QListWidget {
    background-color: #131822;
    border: 1px solid #232B3A;
    border-radius: 8px;
    outline: 0;
    padding: 4px;
}

QListWidget::item {
    border-radius: 6px;
    padding: 5px 8px;
}

QListWidget::item:hover {
    background-color: #1B2230;
}

QListWidget::item:selected {
    background-color: #19293D;
    color: #F8FAFC;
}

/* Autocomplete Popups (QCompleter creates a top-level QListView / QAbstractItemView) */
QAbstractItemView, QListView {
    background-color: #141A26;
    color: #F8FAFC;
    border: 1px solid #2E3B52;
    border-radius: 8px;
    padding: 4px;
    outline: 0;
    selection-background-color: #143D31;
    selection-color: #6EE7B7;
}

QListView::item {
    background-color: #141A26;
    color: #F1F5F9;
    padding: 6px 10px;
    border-radius: 5px;
}

QListView::item:hover {
    background-color: #1E293B;
    color: #FFFFFF;
}

QListView::item:selected {
    background-color: #143D31;
    color: #6EE7B7;
    font-weight: 700;
}

/* ---- Center Photo Stage, Filmstrip & Field Guide Grids ---- */
QListWidget#PhotoGrid, QListWidget#FieldGuideGrid {
    background-color: #0B0E14;
    border: none;
    border-radius: 0px;
    padding: 12px;
}

QListWidget#FilmstripGrid {
    background-color: #0E121A;
    border: none;
    border-top: 1px solid #1D2432;
    border-radius: 0px;
    padding: 6px 10px;
}

QListWidget#PhotoGrid::item, QListWidget#FilmstripGrid::item, QListWidget#FieldGuideGrid::item {
    background-color: #141923;
    border: 1px solid #1F2635;
    border-radius: 11px;
    margin: 5px;
    padding: 5px;
    color: #CBD5E1;
}

QListWidget#PhotoGrid::item:hover, QListWidget#FieldGuideGrid::item:hover {
    background-color: #1A212E;
    border: 1px solid #36435A;
    color: #F8FAFC;
}

QListWidget#PhotoGrid::item:selected, QListWidget#FilmstripGrid::item:selected, QListWidget#FieldGuideGrid::item:selected {
    background-color: #162436;
    border: 2px solid #38BDF8;
    padding: 4px;
    color: #FFFFFF;
}

QTableWidget {
    background-color: #131822;
    alternate-background-color: #161C27;
    border: 1px solid #232B3A;
    border-radius: 8px;
    gridline-color: #1E2533;
    outline: 0;
}

QTableWidget::item {
    padding: 6px 8px;
}

QTableWidget::item:selected {
    background-color: #17332C;
    color: #6EE7B7;
}

QHeaderView::section {
    background-color: #161C27;
    color: #94A3B8;
    border: none;
    border-bottom: 1px solid #232B3A;
    border-right: 1px solid #1E2533;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 600;
}

/* ---- Buttons ---- */
QPushButton {
    background-color: #1C2331;
    color: #E2E8F0;
    border: 1px solid #2A3447;
    border-radius: 7px;
    padding: 5px 10px;
    min-width: 0px;
    font-weight: 500;
}

QPushButton:hover {
    background-color: #252E40;
    border-color: #3B4963;
    color: #FFFFFF;
}

QPushButton:pressed {
    background-color: #161C27;
}

QPushButton:disabled {
    background-color: #141821;
    border-color: #1E2430;
    color: #475569;
}

QPushButton:checked {
    background-color: #16382E;
    border-color: #10B981;
    color: #6EE7B7;
    font-weight: 700;
}

QPushButton#PrimaryButton {
    background-color: #059669;
    border: 1px solid #10B981;
    color: #FFFFFF;
    font-weight: 700;
}

QPushButton#PrimaryButton:hover {
    background-color: #10B981;
    border-color: #34D399;
}

QPushButton#PrimaryButton:pressed {
    background-color: #047857;
}

QPushButton#PrimaryButton:disabled {
    background-color: #162226;
    border-color: #1F3332;
    color: #475569;
}

QPushButton#GhostButton {
    background-color: transparent;
    border: 1px solid transparent;
    color: #CBD5E1;
    border-radius: 7px;
    padding: 5px 10px;
}

QPushButton#GhostButton:hover {
    background-color: #1B2230;
    border-color: #2A3447;
    color: #FFFFFF;
}

QPushButton#SubtleActionBtn {
    background-color: #161C28;
    border: 1px solid #242E40;
    color: #94A3B8;
    border-radius: 6px;
    padding: 4px 9px;
    font-size: 12px;
}

QPushButton#SubtleActionBtn:hover {
    background-color: #1F2737;
    border-color: #36455E;
    color: #E2E8F0;
}

/* Rating & Flag Pills in Inspector */
QPushButton#StarPill {
    background-color: #131822;
    border: 1px solid #232B3A;
    border-radius: 6px;
    padding: 4px 0px;
    color: #64748B;
    font-size: 12px;
    font-weight: 700;
}

QPushButton#StarPill:hover {
    background-color: #1D2433;
    border-color: #475569;
    color: #FDE68A;
}

QPushButton#StarPill:checked {
    background-color: #2B2312;
    border-color: #F59E0B;
    color: #FBBF24;
}

QPushButton#FlagPickBtn:checked {
    background-color: #12352A;
    border-color: #10B981;
    color: #6EE7B7;
}

QPushButton#FlagNeutralBtn:checked {
    background-color: #202837;
    border-color: #475569;
    color: #E2E8F0;
}

QPushButton#FlagRejectBtn:checked {
    background-color: #361621;
    border-color: #F43F5E;
    color: #FDA4AF;
}

/* ---- Inputs, ComboBoxes & Text Editors ---- */
QLineEdit, QComboBox, QPlainTextEdit {
    background-color: #0E121A;
    color: #F1F5F9;
    border: 1px solid #242D3D;
    border-radius: 7px;
    padding: 5px 10px;
    selection-background-color: #0284C7;
    selection-color: #FFFFFF;
}

QLineEdit:hover, QComboBox:hover, QPlainTextEdit:hover {
    border-color: #334155;
}

QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus {
    border: 1px solid #10B981;
    background-color: #0B0F17;
}

QLineEdit:disabled, QComboBox:disabled, QPlainTextEdit:disabled {
    background-color: #121620;
    border-color: #1B212E;
    color: #475569;
}

QLineEdit#SpotlightSearch {
    background-color: #0B0E14;
    border: 1px solid #222A3A;
    border-radius: 8px;
    padding: 5px 12px;
    color: #F1F5F9;
}

QLineEdit#SpotlightSearch:focus {
    border: 1px solid #38BDF8;
    background-color: #090C12;
}

QComboBox::drop-down {
    border: none;
    width: 22px;
}

QComboBox QAbstractItemView {
    background-color: #161C28;
    border: 1px solid #2E3A4F;
    border-radius: 6px;
    padding: 4px;
    selection-background-color: #16382E;
    selection-color: #6EE7B7;
    outline: 0;
}

/* ---- Inspector Studio Cards & GroupBoxes ---- */
QFrame#InspectorScrollRoot {
    background-color: #11151E;
}

QFrame#InspectorCard {
    background-color: #161B26;
    border: 1px solid #21293A;
    border-radius: 10px;
}

QFrame#SelectionHeroCard {
    background-color: #171E2C;
    border: 1px solid #263248;
    border-radius: 10px;
}

QLabel#CardSectionTitle {
    color: #F1F5F9;
    font-size: 12px;
    font-weight: 700;
    background: transparent;
}

QLabel#CardSectionHint {
    color: #64748B;
    font-size: 11px;
    background: transparent;
}

QGroupBox {
    background-color: #161B26;
    border: 1px solid #21293A;
    border-radius: 10px;
    margin-top: 10px;
    padding: 14px 10px 10px 10px;
    font-weight: 700;
    color: #CBD5E1;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: #94A3B8;
}

/* ---- CheckBoxes ---- */
QCheckBox {
    spacing: 7px;
    color: #CBD5E1;
    background: transparent;
}

QCheckBox:hover {
    color: #FFFFFF;
}

QCheckBox::indicator, QListView::indicator {
    width: 15px;
    height: 15px;
    border-radius: 4px;
    border: 1px solid #38465E;
    background-color: #0E121A;
}

QCheckBox::indicator:hover, QListView::indicator:hover {
    border-color: #10B981;
}

QCheckBox::indicator:checked, QListView::indicator:checked {
    background-color: #10B981;
    border-color: #34D399;
}

QCheckBox::indicator:indeterminate {
    background-color: #0284C7;
    border-color: #38BDF8;
}

/* ---- Sliders & Progress Bars ---- */
QSlider::groove:horizontal {
    height: 4px;
    background: #1E2636;
    border-radius: 2px;
}

QSlider::sub-page:horizontal {
    background: #10B981;
    border-radius: 2px;
}

QSlider::handle:horizontal {
    background: #F8FAFC;
    border: 2px solid #10B981;
    width: 12px;
    height: 12px;
    margin: -5px 0;
    border-radius: 7px;
}

QSlider::handle:horizontal:hover {
    background: #FFFFFF;
    border-color: #34D399;
}

QProgressBar {
    background-color: #0D1118;
    border: 1px solid #1F2838;
    border-radius: 5px;
    text-align: center;
    color: #CBD5E1;
    font-size: 11px;
    font-weight: 600;
    height: 10px;
}

QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #059669, stop:0.6 #10B981, stop:1 #38BDF8);
    border-radius: 4px;
}

/* ---- Menus ---- */
QMenu {
    background-color: #171D2B;
    border: 1px solid #2B364B;
    border-radius: 8px;
    padding: 5px;
}

QMenu::item {
    padding: 6px 22px 6px 12px;
    border-radius: 5px;
    color: #E2E8F0;
}

QMenu::item:selected {
    background-color: #16382E;
    color: #6EE7B7;
}

QMenu::separator {
    height: 1px;
    background: #232C3D;
    margin: 4px 6px;
}

/* ---- Minimalist Floating ScrollBars ---- */
QScrollBar:vertical {
    background: transparent;
    width: 8px;
    margin: 2px 1px;
}

QScrollBar::handle:vertical {
    background: #293346;
    min-height: 28px;
    border-radius: 3px;
}

QScrollBar::handle:vertical:hover {
    background: #475569;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    height: 0px;
    background: transparent;
}

QScrollBar:horizontal {
    background: transparent;
    height: 8px;
    margin: 1px 2px;
}

QScrollBar::handle:horizontal {
    background: #293346;
    min-width: 28px;
    border-radius: 3px;
}

QScrollBar::handle:horizontal:hover {
    background: #475569;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    width: 0px;
    background: transparent;
}
"""


def style_completer_popup(completer: QCompleter | None) -> None:
    """Force high-contrast dark background and crisp light text on QCompleter's top-level popup."""
    if completer is None:
        return
    popup = completer.popup()
    if popup is None:
        return

    pal = popup.palette()
    bg = QColor("#141A26")
    fg = QColor("#F8FAFC")
    hl_bg = QColor("#143D31")
    hl_fg = QColor("#6EE7B7")
    for role in (QPalette.ColorRole.Base, QPalette.ColorRole.Window, QPalette.ColorRole.AlternateBase):
        pal.setColor(role, bg)
    for role in (QPalette.ColorRole.Text, QPalette.ColorRole.WindowText):
        pal.setColor(role, fg)
    pal.setColor(QPalette.ColorRole.Highlight, hl_bg)
    pal.setColor(QPalette.ColorRole.HighlightedText, hl_fg)
    popup.setPalette(pal)
    if popup.viewport() is not None:
        popup.viewport().setPalette(pal)

    popup.setStyleSheet(
        "QAbstractItemView { "
        "background-color: #141A26; color: #F8FAFC; border: 1px solid #2E3B52; "
        "border-radius: 6px; padding: 4px; outline: 0; font-size: 12px; "
        "selection-background-color: #143D31; selection-color: #6EE7B7; } "
        "QAbstractItemView::item { "
        "background-color: #141A26; color: #F8FAFC; padding: 6px 10px; border-radius: 5px; } "
        "QAbstractItemView::item:hover { background-color: #1E293B; color: #FFFFFF; } "
        "QAbstractItemView::item:selected { background-color: #143D31; color: #6EE7B7; font-weight: 700; }"
    )


def enable_windows_dark_titlebar(widget: QWidget) -> None:
    """Enable native Windows 10/11 immersive dark titlebar & obsidian caption color via DWM."""
    if os.name != "nt":
        return
    try:
        hwnd = int(widget.winId())
        dwmapi = ctypes.windll.dwmapi
        dark_mode = ctypes.c_int(1)
        # DWMWA_USE_IMMERSIVE_DARK_MODE = 20 (fallback 19 on older Win10 builds)
        res = dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark_mode), ctypes.sizeof(dark_mode))
        if res != 0:
            dwmapi.DwmSetWindowAttribute(hwnd, 19, ctypes.byref(dark_mode), ctypes.sizeof(dark_mode))
        # DWMWA_CAPTION_COLOR = 35 on Windows 11 (COLORREF is 0x00BBGGRR -> #11151E = 0x001E1511)
        caption_color = ctypes.c_uint32(0x001E1511)
        dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(caption_color), ctypes.sizeof(caption_color))
    except Exception:
        pass


def render_brand_logo_pixmap(size: int = 28) -> QPixmap:
    """Render a crisp vector emerald kingfisher studio emblem for the top header bar."""
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    grad = QLinearGradient(0, 0, size, size)
    grad.setColorAt(0.0, QColor("#0F2926"))
    grad.setColorAt(1.0, QColor("#132033"))

    bg_path = QPainterPath()
    bg_path.addRoundedRect(QRectF(1.0, 1.0, size - 2.0, size - 2.0), size * 0.28, size * 0.28)
    painter.fillPath(bg_path, grad)
    painter.setPen(QPen(QColor("#10B981"), 1.2))
    painter.drawPath(bg_path)

    s = float(size)
    wing = QPainterPath()
    wing.moveTo(s * 0.24, s * 0.62)
    wing.quadTo(s * 0.42, s * 0.24, s * 0.76, s * 0.34)
    wing.quadTo(s * 0.58, s * 0.56, s * 0.24, s * 0.62)
    painter.fillPath(wing, QColor("#34D399"))

    body = QPainterPath()
    body.moveTo(s * 0.22, s * 0.70)
    body.quadTo(s * 0.52, s * 0.48, s * 0.80, s * 0.56)
    body.quadTo(s * 0.50, s * 0.76, s * 0.22, s * 0.70)
    painter.fillPath(body, QColor("#38BDF8"))

    painter.end()
    return pix


def pil_to_qpixmap(img: Image.Image) -> QPixmap:
    """Convert an RGB PIL Image into a QPixmap without disk round-trip."""
    rgb = img.convert("RGB")
    data = rgb.tobytes("raw", "RGB")
    qimg = QImage(data, rgb.width, rgb.height, rgb.width * 3, QImage.Format.Format_RGB888).copy()
    return QPixmap.fromImage(qimg)


def render_photo_card_from_qimage(
    scaled_qimg: QImage | None,
    *,
    box_size: int = 180,
    is_raw: bool = False,
    species_cn: str = "",
    species_list: list[str] | None = None,
    rating: int = 0,
    pick_flag: int = 0,
    placeholder_text: str = "加载中…",
) -> QPixmap:
    """Render a frameless rounded obsidian gallery card showing ALL assigned species pills."""
    canvas = QPixmap(box_size, box_size)
    canvas.fill(Qt.GlobalColor.transparent)

    painter = QPainter(canvas)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    card_rect = QRectF(2.0, 2.0, box_size - 4.0, box_size - 4.0)
    radius = 8.0
    card_path = QPainterPath()
    card_path.addRoundedRect(card_rect, radius, radius)

    # Subtle recessed dark stage behind non-square aspect ratios
    painter.fillPath(card_path, QColor("#0E121A"))

    if species_list is not None:
        tags = [s.strip() for s in species_list if s and s.strip() and s.strip() != "未知鸟种"]
    elif species_cn and species_cn.strip() and species_cn.strip() != "未知鸟种":
        tags = [species_cn.strip()]
    else:
        tags = []

    font_pt = 8 if box_size >= 132 else 7
    font_badge = QFont("Microsoft YaHei UI", font_pt, QFont.Weight.DemiBold)
    painter.setFont(font_badge)
    metrics = painter.fontMetrics()
    pill_h = metrics.height() + 5
    max_row_w = max(48, box_size - 14)

    # Pre-layout ALL species tags into wrapped rows (bottom-up) so every co-occurring species is shown
    tag_rows: list[list[tuple[str, int]]] = []
    if tags:
        cur_row: list[tuple[str, int]] = []
        cur_w = 0
        for sp_name in tags:
            max_txt_w = max(24, max_row_w - 23)
            disp_name = metrics.elidedText(sp_name, Qt.TextElideMode.ElideRight, max_txt_w)
            pw = metrics.horizontalAdvance(disp_name) + 23
            if cur_row and (cur_w + 4 + pw > max_row_w):
                tag_rows.append(cur_row)
                cur_row = [(disp_name, pw)]
                cur_w = pw
            else:
                cur_row.append((disp_name, pw))
                cur_w = pw if not cur_w else (cur_w + 4 + pw)
        if cur_row:
            tag_rows.append(cur_row)

        max_rows = max(1, int(box_size * 0.72) // (pill_h + 3))
        tag_rows = tag_rows[:max_rows]

    avail = box_size - 4
    if scaled_qimg is not None and not scaled_qimg.isNull():
        if scaled_qimg.width() > avail or scaled_qimg.height() > avail:
            draw_img = scaled_qimg.scaled(
                avail,
                avail,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        else:
            draw_img = scaled_qimg
        x = (box_size - draw_img.width()) // 2
        y = (box_size - draw_img.height()) // 2

        painter.save()
        painter.setClipPath(card_path)
        if pick_flag < 0:
            painter.setOpacity(0.38)
        painter.drawImage(x, y, draw_img)
        painter.setOpacity(1.0)

        if tag_rows:
            total_tags_h = len(tag_rows) * pill_h + max(0, len(tag_rows) - 1) * 3
            scrim_h = min(float(box_size - 8), float(total_tags_h + 18))
            grad = QLinearGradient(0, box_size - scrim_h, 0, box_size)
            grad.setColorAt(0.0, QColor(8, 11, 16, 0))
            grad.setColorAt(1.0, QColor(8, 11, 16, 205))
            painter.fillRect(QRectF(2.0, box_size - scrim_h, box_size - 4.0, scrim_h), grad)
        painter.restore()
    else:
        painter.setPen(QPen(QColor("#475569")))
        painter.setFont(QFont("Microsoft YaHei UI", 8))
        painter.drawText(QRect(0, 0, box_size, box_size), Qt.AlignmentFlag.AlignCenter, placeholder_text)
        painter.setFont(font_badge)

    # Subtle 1px inner specular border
    painter.setPen(QPen(QColor(255, 255, 255, 18), 1.0))
    painter.drawPath(card_path)

    # Top-left: Pick / Reject flag
    if pick_flag > 0:
        _draw_frosted_pill(
            painter,
            7,
            7,
            "留片",
            bg=QColor(12, 42, 33, 220),
            fg=QColor("#6EE7B7"),
            border=QColor(16, 185, 129, 140),
            dot_color=QColor("#10B981"),
        )
    elif pick_flag < 0:
        _draw_frosted_pill(
            painter,
            7,
            7,
            "淘汰",
            bg=QColor(52, 18, 28, 220),
            fg=QColor("#FDA4AF"),
            border=QColor(244, 63, 94, 140),
            dot_color=QColor("#F43F5E"),
        )

    # Top-right: Star rating & RAW badge (keeps bottom 100% dedicated to multi-species tags!)
    top_right_y = 7
    if rating > 0:
        stars = "★" * rating
        stars_w = metrics.horizontalAdvance(stars) + 12
        _draw_frosted_pill(
            painter,
            max(7, box_size - stars_w - 7),
            top_right_y,
            stars,
            bg=QColor(17, 21, 30, 218),
            fg=QColor("#FBBF24"),
            border=QColor(251, 191, 36, 90),
        )
        top_right_y += pill_h + 3

    if is_raw:
        raw_w = metrics.horizontalAdvance("RAW") + 12
        _draw_frosted_pill(
            painter,
            max(7, box_size - raw_w - 7),
            top_right_y,
            "RAW",
            bg=QColor(15, 20, 29, 215),
            fg=QColor("#FBBF24"),
            border=QColor(251, 191, 36, 90),
        )

    # Bottom: Render every co-occurring species tag as its own distinct pill
    if tag_rows:
        num_rows = len(tag_rows)
        for r_idx, row_items in enumerate(tag_rows):
            rows_below = num_rows - 1 - r_idx
            row_y = box_size - 7 - pill_h - rows_below * (pill_h + 3)
            cur_x = 7
            for disp_name, pw in row_items:
                _draw_frosted_pill(
                    painter,
                    cur_x,
                    row_y,
                    disp_name,
                    bg=QColor(13, 38, 31, 232),
                    fg=QColor("#A7F3D0"),
                    border=QColor(52, 211, 153, 130),
                    dot_color=QColor("#34D399"),
                )
                cur_x += pw + 4

    painter.end()
    return canvas


def render_photo_card_pixmap(
    thumb_source: str | Path | None,
    *,
    box_size: int = 180,
    is_raw: bool = False,
    species_cn: str = "",
    rating: int = 0,
    pick_flag: int = 0,
) -> QPixmap:
    """Render a square thumbnail card from a small cached thumbnail file path."""
    qimg: QImage | None = None
    if thumb_source and Path(thumb_source).exists():
        loaded = QImage(str(thumb_source))
        if not loaded.isNull():
            avail = box_size - 6
            qimg = loaded.scaled(
                avail,
                avail,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
    return render_photo_card_from_qimage(
        qimg,
        box_size=box_size,
        is_raw=is_raw,
        species_cn=species_cn,
        rating=rating,
        pick_flag=pick_flag,
        placeholder_text="无预览",
    )


def render_species_guide_pixmap(
    cover_source: str | Path | None,
    *,
    width: int = 194,
    height: int = 138,
    is_lit: bool = False,
    photo_count: int = 0,
) -> QPixmap:
    """Render a rounded Bird Field Guide card header (lit species cover vs clean geometric silhouette)."""
    canvas = QPixmap(width, height)
    canvas.fill(Qt.GlobalColor.transparent)

    painter = QPainter(canvas)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    rect = QRectF(1.0, 1.0, width - 2.0, height - 2.0)
    clip = QPainterPath()
    clip.addRoundedRect(rect, 8.0, 8.0)

    if is_lit:
        bg_grad = QLinearGradient(0, 0, width, height)
        bg_grad.setColorAt(0.0, QColor("#102620"))
        bg_grad.setColorAt(1.0, QColor("#121D2B"))
        painter.fillPath(clip, bg_grad)
    else:
        bg_grad = QLinearGradient(0, 0, 0, height)
        bg_grad.setColorAt(0.0, QColor("#121722"))
        bg_grad.setColorAt(1.0, QColor("#0E121B"))
        painter.fillPath(clip, bg_grad)

    loaded = False
    if is_lit and cover_source and Path(cover_source).exists():
        pix = QPixmap(str(cover_source))
        if not pix.isNull():
            scaled = pix.scaled(
                width,
                height,
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            sx = max(0, (scaled.width() - width) // 2)
            sy = max(0, (scaled.height() - height) // 2)
            painter.save()
            painter.setClipPath(clip)
            painter.drawPixmap(0, 0, scaled, sx, sy, width, height)
            top_scrim = QLinearGradient(0, 0, 0, 42)
            top_scrim.setColorAt(0.0, QColor(8, 12, 18, 145))
            top_scrim.setColorAt(1.0, QColor(8, 12, 18, 0))
            painter.fillRect(QRectF(0, 0, width, 42), top_scrim)
            painter.restore()
            loaded = True

    if not loaded:
        # Draw clean minimalist vector bird silhouette instead of noisy system emoji
        cx = width * 0.5
        cy = height * 0.52
        bird = QPainterPath()
        bird.moveTo(cx - 22, cy + 10)
        bird.quadTo(cx - 6, cy - 22, cx + 22, cy - 10)
        bird.quadTo(cx + 8, cy + 6, cx - 22, cy + 10)
        tail = QPainterPath()
        tail.moveTo(cx - 24, cy + 15)
        tail.quadTo(cx + 4, cy + 0, cx + 26, cy + 6)
        tail.quadTo(cx + 2, cy + 20, cx - 24, cy + 15)

        if is_lit:
            painter.fillPath(bird, QColor(52, 211, 153, 175))
            painter.fillPath(tail, QColor(56, 189, 248, 150))
        else:
            painter.fillPath(bird, QColor(71, 85, 105, 85))
            painter.fillPath(tail, QColor(51, 65, 85, 75))
            painter.setPen(QPen(QColor("#475569")))
            painter.setFont(QFont("Microsoft YaHei UI", 8))
            painter.drawText(
                QRect(0, height - 28, width, 20),
                Qt.AlignmentFlag.AlignCenter,
                "待拍摄解锁",
            )

    painter.setPen(QPen(QColor(16, 185, 129, 75) if is_lit else QColor(255, 255, 255, 14), 1.0))
    painter.drawPath(clip)

    painter.setFont(QFont("Microsoft YaHei UI", 8, QFont.Weight.DemiBold))
    if is_lit:
        _draw_frosted_pill(
            painter,
            8,
            8,
            f"已点亮 · {photo_count}张",
            bg=QColor(11, 39, 31, 228),
            fg=QColor("#ECFDF5"),
            border=QColor(16, 185, 129, 150),
            dot_color=QColor("#34D399"),
        )
    else:
        _draw_frosted_pill(
            painter,
            8,
            8,
            "未点亮",
            bg=QColor(18, 23, 34, 205),
            fg=QColor("#64748B"),
            border=QColor(51, 65, 85, 90),
        )

    painter.end()
    return canvas


def _draw_frosted_pill(
    painter: QPainter,
    x: int,
    y: int,
    text: str,
    *,
    bg: QColor,
    fg: QColor,
    border: QColor | None = None,
    dot_color: QColor | None = None,
) -> None:
    metrics = painter.fontMetrics()
    dot_space = 11 if dot_color is not None else 0
    w = metrics.horizontalAdvance(text) + 12 + dot_space
    h = metrics.height() + 5
    rect = QRectF(float(x), float(y), float(w), float(h))

    path = QPainterPath()
    path.addRoundedRect(rect, h / 2.0, h / 2.0)
    painter.fillPath(path, bg)

    if border is not None:
        painter.setPen(QPen(border, 1.0))
        painter.drawPath(path)

    if dot_color is not None:
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(dot_color)
        painter.drawEllipse(QPointF(x + 8.5, y + h / 2.0), 3.0, 3.0)
        text_rect = QRectF(x + dot_space + 3, y, w - dot_space - 6, h)
    else:
        text_rect = rect

    painter.setPen(fg)
    painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, text)

"""Interactive Slippy Map widget & Map Point-Picking / Coordinate Adjustment Dialog (zero WebEngine bloat)."""

from __future__ import annotations

import math
import os
import re
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QObject, QPoint, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import (
    QBrush,
    QColor,
    QCursor,
    QFont,
    QImage,
    QMouseEvent,
    QPainter,
    QPainterPath,
    QPaintEvent,
    QPen,
    QPolygonF,
    QWheelEvent,
)
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.china_regions import (
    format_province_city,
    gcj02_to_wgs84,
    get_city_entry,
    get_province_center,
    infer_province_city,
    list_cities,
    list_provinces,
    normalize_province_name,
    search_cities,
    wgs84_to_gcj02,
)
from bird_gallery.ebird import EBirdLocationService, extract_ebird_loc_id, suggest_short_spot_name
from bird_gallery.gui.workers import WorkerTracker
from bird_gallery.models import EBirdHotspot, FavoriteLocation

_MAX_MERCATOR_LAT = 85.05112878
_TILE_SIZE = 256


@dataclass(slots=True, frozen=True)
class MapLayerSpec:
    layer_id: str
    title: str
    base_url_tpl: str
    overlay_url_tpl: str = ""
    uses_gcj02: bool = True
    max_zoom: int = 18


MAP_LAYERS: list[MapLayerSpec] = [
    MapLayerSpec(
        layer_id="gaode_vec",
        title="🗺 中文电子地图（街道/公园/水系）",
        base_url_tpl="https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}",
        uses_gcj02=True,
        max_zoom=18,
    ),
    MapLayerSpec(
        layer_id="gaode_hyb",
        title="🛰 中文卫星混合图（影像+地名路网）",
        base_url_tpl="https://webst0{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",
        overlay_url_tpl="https://webst0{s}.is.autonavi.com/appmaptile?style=8&x={x}&y={y}&z={z}",
        uses_gcj02=True,
        max_zoom=18,
    ),
    MapLayerSpec(
        layer_id="esri_sat",
        title="🌏 全球卫星影像（Esri WGS-84）",
        base_url_tpl="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        uses_gcj02=False,
        max_zoom=18,
    ),
    MapLayerSpec(
        layer_id="esri_vec",
        title="🧭 全球街道地图（Esri WGS-84）",
        base_url_tpl="https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        uses_gcj02=False,
        max_zoom=18,
    ),
]


def _default_tile_cache_dir() -> Path:
    from bird_gallery.paths import resolve_app_data_dir

    cand = resolve_app_data_dir() / ".bird_gallery_cache" / "map_tiles"
    try:
        cand.mkdir(parents=True, exist_ok=True)
        return cand
    except OSError:
        fallback = Path.home() / ".bird_gallery_cache" / "map_tiles"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


def latlng_to_world_px(lat: float, lng: float, zoom: int) -> tuple[float, float]:
    """Project (lat, lng) to Web Mercator world pixel coordinates at `zoom`."""
    clamped_lat = max(-_MAX_MERCATOR_LAT, min(_MAX_MERCATOR_LAT, lat))
    norm_lng = ((lng + 180.0) % 360.0) - 180.0
    world_px = float(_TILE_SIZE * (1 << zoom))
    x = (norm_lng + 180.0) / 360.0 * world_px
    sin_lat = math.sin(math.radians(clamped_lat))
    y = (0.5 - math.log((1.0 + sin_lat) / (1.0 - sin_lat)) / (4.0 * math.pi)) * world_px
    return x, y


def world_px_to_latlng(x: float, y: float, zoom: int) -> tuple[float, float]:
    """Unproject Web Mercator world pixel coordinates at `zoom` back to (lat, lng)."""
    world_px = float(_TILE_SIZE * (1 << zoom))
    clamped_y = max(0.0, min(world_px, y))
    lng = (x / world_px) * 360.0 - 180.0
    lng = ((lng + 180.0) % 360.0) - 180.0
    n = math.pi - 2.0 * math.pi * clamped_y / world_px
    lat = math.degrees(math.atan(0.5 * (math.exp(n) - math.exp(-n))))
    return lat, lng


class _TileSignalBridge(QObject):
    tile_loaded = Signal(str, int, int, int, QImage)


class TileCacheManager:
    """Asynchronous background slippy-map tile fetcher with LRU memory + disk caching."""

    def __init__(self, cache_dir: Path | None = None, *, network_enabled: bool | None = None) -> None:
        self.cache_dir = cache_dir or _default_tile_cache_dir()
        if network_enabled is None:
            # Avoid noisy external tile fetches during headless offscreen pytest runs unless requested
            network_enabled = os.environ.get("QT_QPA_PLATFORM", "").lower() != "offscreen"
        self.network_enabled = network_enabled

        self.bridge = _TileSignalBridge()
        self._mem_cache: dict[tuple[str, int, int, int], QImage] = {}
        self._inflight: set[tuple[str, int, int, int]] = set()
        self._closed = False
        self._executor = ThreadPoolExecutor(max_workers=6, thread_name_prefix="map-tile")

    def shutdown(self) -> None:
        self._closed = True
        self._executor.shutdown(wait=False, cancel_futures=True)

    def get_or_request(self, spec: MapLayerSpec, z: int, x: int, y: int) -> QImage | None:
        n_tiles = 1 << z
        if y < 0 or y >= n_tiles:
            return None
        x_wrapped = x % n_tiles
        key = (spec.layer_id, z, x_wrapped, y)
        cached = self._mem_cache.get(key)
        if cached is not None:
            return cached

        if not self.network_enabled or self._closed or key in self._inflight:
            return None

        self._inflight.add(key)
        self._executor.submit(self._worker_fetch, spec, z, x_wrapped, y)
        return None

    def get_cached_only(self, layer_id: str, z: int, x: int, y: int) -> QImage | None:
        if z < 0:
            return None
        n_tiles = 1 << z
        if y < 0 or y >= n_tiles:
            return None
        return self._mem_cache.get((layer_id, z, x % n_tiles, y))

    def put_mem_cache(self, layer_id: str, z: int, x: int, y: int, img: QImage) -> None:
        if len(self._mem_cache) > 650:
            # Trim oldest ~150 entries
            for old_k in list(self._mem_cache.keys())[:150]:
                self._mem_cache.pop(old_k, None)
        self._mem_cache[(layer_id, z, x, y)] = img

    @staticmethod
    def _download_bytes(url: str) -> bytes | None:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 NiaoYuJi/1.1",
                "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                return resp.read()
        except Exception:
            return None

    def _worker_fetch(self, spec: MapLayerSpec, z: int, x: int, y: int) -> None:
        key = (spec.layer_id, z, x, y)
        try:
            if self._closed:
                return
            disk_file = self.cache_dir / spec.layer_id / str(z) / f"{x}_{y}.png"
            if disk_file.exists():
                qimg = QImage(str(disk_file))
                if not qimg.isNull():
                    self.bridge.tile_loaded.emit(spec.layer_id, z, x, y, qimg)
                    return

            sub = ((x + y) % 4) + 1
            base_url = spec.base_url_tpl.format(s=sub, x=x, y=y, z=z)
            base_bytes = self._download_bytes(base_url)
            if not base_bytes:
                return
            base_img = QImage.fromData(base_bytes)
            if base_img.isNull():
                return

            final_img = base_img.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
            if spec.overlay_url_tpl:
                ov_url = spec.overlay_url_tpl.format(s=sub, x=x, y=y, z=z)
                ov_bytes = self._download_bytes(ov_url)
                if ov_bytes:
                    ov_img = QImage.fromData(ov_bytes)
                    if not ov_img.isNull():
                        p = QPainter(final_img)
                        p.drawImage(0, 0, ov_img)
                        p.end()

            try:
                disk_file.parent.mkdir(parents=True, exist_ok=True)
                final_img.save(str(disk_file), "PNG")
            except OSError:
                pass

            if not self._closed:
                self.bridge.tile_loaded.emit(spec.layer_id, z, x, y, final_img)
        finally:
            self._inflight.discard(key)


class SlippyMapWidget(QWidget):
    """Interactive pan/zoom slippy map with WGS-84 pin picking, drag-adjustment, and eBird hotspot overlay."""

    pin_changed = Signal(float, float)  # (wgs84_lat, wgs84_lng)
    hotspot_clicked = Signal(object)    # EBirdHotspot
    favorite_clicked = Signal(object)   # FavoriteLocation

    def __init__(
        self,
        parent: QWidget | None = None,
        *,
        initial_lat: float = 35.8617,
        initial_lng: float = 104.1954,
        initial_zoom: int = 5,
        tile_cache: TileCacheManager | None = None,
    ) -> None:
        super().__init__(parent)
        self.setMinimumSize(360, 250)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)

        self._owns_cache = tile_cache is None
        self._tile_cache = tile_cache or TileCacheManager()
        self._tile_cache.bridge.tile_loaded.connect(self._on_tile_loaded)

        self._layer_idx = 0
        self.center_lat = initial_lat
        self.center_lng = initial_lng
        self.zoom = max(3, min(18, initial_zoom))

        self.pin_lat: float | None = None
        self.pin_lng: float | None = None

        self.show_overlays = True
        self._hotspots: list[EBirdHotspot] = []
        self._favorites: list[FavoriteLocation] = []
        self._rendered_hotspots: list[tuple[QPointF, EBirdHotspot]] = []
        self._rendered_favorites: list[tuple[QPointF, FavoriteLocation]] = []

        # Mouse interaction state
        self._press_pos: QPoint | None = None
        self._last_drag_pos: QPoint | None = None
        self._dragging_pin = False
        self._panning_map = False

        # Overlay HUD buttons
        self._btn_zoom_in = QPushButton("+", self)
        self._btn_zoom_out = QPushButton("−", self)
        self._btn_recenter = QPushButton("🎯", self)
        self._btn_recenter.setToolTip("回到当前红色选点位置")
        hud_style = (
            "QPushButton { background-color: rgba(30, 34, 42, 220); color: #e8eaed; "
            "border: 1px solid #4a5160; border-radius: 5px; font-size: 15px; font-weight: bold; } "
            "QPushButton:hover { background-color: #3a7afe; color: #ffffff; }"
        )
        for btn in (self._btn_zoom_in, self._btn_zoom_out, self._btn_recenter):
            btn.setFixedSize(30, 30)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(hud_style)

        self._btn_zoom_in.clicked.connect(lambda: self.set_zoom(self.zoom + 1))
        self._btn_zoom_out.clicked.connect(lambda: self.set_zoom(self.zoom - 1))
        self._btn_recenter.clicked.connect(self.recenter_on_pin)

    def shutdown(self) -> None:
        if self._owns_cache:
            self._tile_cache.shutdown()

    @property
    def active_layer(self) -> MapLayerSpec:
        return MAP_LAYERS[self._layer_idx]

    def set_layer_index(self, idx: int) -> None:
        if 0 <= idx < len(MAP_LAYERS) and idx != self._layer_idx:
            self._layer_idx = idx
            self.zoom = min(self.zoom, self.active_layer.max_zoom)
            self.update()

    def set_zoom(self, new_zoom: int) -> None:
        clamped = max(3, min(self.active_layer.max_zoom, new_zoom))
        if clamped != self.zoom:
            self.zoom = clamped
            self.update()

    def set_view(self, wgs_lat: float, wgs_lng: float, zoom: int | None = None) -> None:
        self.center_lat = max(-84.0, min(84.0, wgs_lat))
        self.center_lng = ((wgs_lng + 180.0) % 360.0) - 180.0
        if zoom is not None:
            self.zoom = max(3, min(self.active_layer.max_zoom, zoom))
        self.update()

    def set_pin(
        self,
        wgs_lat: float | None,
        wgs_lng: float | None,
        *,
        pan_to: bool = True,
        zoom: int | None = None,
        emit_signal: bool = False,
    ) -> None:
        self.pin_lat = wgs_lat
        self.pin_lng = wgs_lng
        if pan_to and wgs_lat is not None and wgs_lng is not None:
            self.center_lat = max(-84.0, min(84.0, wgs_lat))
            self.center_lng = ((wgs_lng + 180.0) % 360.0) - 180.0
            if zoom is not None:
                self.zoom = max(3, min(self.active_layer.max_zoom, zoom))
        self.update()
        if emit_signal and wgs_lat is not None and wgs_lng is not None:
            self.pin_changed.emit(wgs_lat, wgs_lng)

    def recenter_on_pin(self) -> None:
        if self.pin_lat is not None and self.pin_lng is not None:
            self.set_view(self.pin_lat, self.pin_lng, max(self.zoom, 13))

    def set_overlay_data(
        self,
        hotspots: list[EBirdHotspot] | None = None,
        favorites: list[FavoriteLocation] | None = None,
    ) -> None:
        if hotspots is not None:
            self._hotspots = hotspots
        if favorites is not None:
            self._favorites = favorites
        self.update()

    # ---------------- Coordinate Projection Helpers ----------------

    def _wgs_to_layer_latlng(self, wgs_lat: float, wgs_lng: float) -> tuple[float, float]:
        if self.active_layer.uses_gcj02:
            return wgs84_to_gcj02(wgs_lat, wgs_lng)
        return wgs_lat, wgs_lng

    def _layer_latlng_to_wgs(self, map_lat: float, map_lng: float) -> tuple[float, float]:
        if self.active_layer.uses_gcj02:
            return gcj02_to_wgs84(map_lat, map_lng)
        return map_lat, map_lng

    def wgs_to_screen(self, wgs_lat: float, wgs_lng: float) -> QPointF:
        c_lat, c_lng = self._wgs_to_layer_latlng(self.center_lat, self.center_lng)
        cx, cy = latlng_to_world_px(c_lat, c_lng, self.zoom)
        p_lat, p_lng = self._wgs_to_layer_latlng(wgs_lat, wgs_lng)
        px, py = latlng_to_world_px(p_lat, p_lng, self.zoom)
        return QPointF(self.width() / 2.0 + (px - cx), self.height() / 2.0 + (py - cy))

    def screen_to_wgs(self, sx: float, sy: float) -> tuple[float, float]:
        c_lat, c_lng = self._wgs_to_layer_latlng(self.center_lat, self.center_lng)
        cx, cy = latlng_to_world_px(c_lat, c_lng, self.zoom)
        wx = cx + (sx - self.width() / 2.0)
        wy = cy + (sy - self.height() / 2.0)
        map_lat, map_lng = world_px_to_latlng(wx, wy, self.zoom)
        return self._layer_latlng_to_wgs(map_lat, map_lng)

    # ---------------- Painting ----------------

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        x = self.width() - 38
        self._btn_zoom_in.move(x, 10)
        self._btn_zoom_out.move(x, 44)
        self._btn_recenter.move(x, 82)

    def _on_tile_loaded(self, layer_id: str, z: int, x: int, y: int, img: QImage) -> None:
        self._tile_cache.put_mem_cache(layer_id, z, x, y, img)
        if layer_id == self.active_layer.layer_id and abs(z - self.zoom) <= 1:
            self.update()

    def paintEvent(self, _event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

        w, h = self.width(), self.height()
        painter.fillRect(0, 0, w, h, QColor("#18222d"))

        c_lat, c_lng = self._wgs_to_layer_latlng(self.center_lat, self.center_lng)
        cx, cy = latlng_to_world_px(c_lat, c_lng, self.zoom)
        left_wx = cx - w / 2.0
        top_wy = cy - h / 2.0

        tx_min = math.floor(left_wx / _TILE_SIZE)
        tx_max = math.floor((left_wx + w) / _TILE_SIZE)
        ty_min = math.floor(top_wy / _TILE_SIZE)
        ty_max = math.floor((top_wy + h) / _TILE_SIZE)

        spec = self.active_layer
        any_missing = False

        for tx in range(tx_min, tx_max + 1):
            for ty in range(ty_min, ty_max + 1):
                sx = tx * _TILE_SIZE - left_wx
                sy = ty * _TILE_SIZE - top_wy
                dest_rect = QRectF(sx, sy, _TILE_SIZE, _TILE_SIZE)

                img = self._tile_cache.get_or_request(spec, self.zoom, tx, ty)
                if img is not None:
                    painter.drawImage(dest_rect, img)
                else:
                    any_missing = True
                    # Try upscaling parent tile (z - 1) if cached for seamless progressive zoom
                    parent_drawn = False
                    if self.zoom > 3:
                        p_img = self._tile_cache.get_cached_only(spec.layer_id, self.zoom - 1, tx // 2, ty // 2)
                        if p_img is not None:
                            sub_x = (tx % 2) * (_TILE_SIZE // 2)
                            sub_y = (ty % 2) * (_TILE_SIZE // 2)
                            src_rect = QRectF(sub_x, sub_y, _TILE_SIZE // 2, _TILE_SIZE // 2)
                            painter.drawImage(dest_rect, p_img, src_rect)
                            parent_drawn = True
                    if not parent_drawn:
                        painter.setPen(QPen(QColor(58, 82, 108, 90), 1))
                        painter.drawRect(dest_rect)

        # Draw offline graticule lines if tiles haven't loaded yet
        if any_missing and not self._tile_cache.network_enabled:
            painter.setPen(QPen(QColor(90, 140, 190, 70), 1, Qt.PenStyle.DashLine))
            for g_lat in range(15, 56, 5):
                pt = self.wgs_to_screen(float(g_lat), self.center_lng)
                if 0 <= pt.y() <= h:
                    painter.drawLine(0, int(pt.y()), w, int(pt.y()))
            for g_lng in range(75, 136, 5):
                pt = self.wgs_to_screen(self.center_lat, float(g_lng))
                if 0 <= pt.x() <= w:
                    painter.drawLine(int(pt.x()), 0, int(pt.x()), h)

        # Draw overlay markers (eBird Hotspots & Favorite Locations)
        self._rendered_hotspots.clear()
        self._rendered_favorites.clear()

        if self.show_overlays:
            # 1. eBird Hotspots in viewport (limit to 80 highest-species markers to avoid clutter)
            drawn_hs = 0
            for hs in self._hotspots:
                if hs.lat is None or hs.lng is None:
                    continue
                pt = self.wgs_to_screen(hs.lat, hs.lng)
                if -16 <= pt.x() <= w + 16 and -16 <= pt.y() <= h + 16:
                    self._draw_hotspot_marker(painter, pt, hs, show_label=(self.zoom >= 12 and drawn_hs < 25))
                    self._rendered_hotspots.append((pt, hs))
                    drawn_hs += 1
                    if drawn_hs >= 80:
                        break

            # 2. Favorite Birding Spots
            for fav in self._favorites:
                if fav.lat is None or fav.lng is None:
                    continue
                pt = self.wgs_to_screen(fav.lat, fav.lng)
                if -20 <= pt.x() <= w + 20 and -20 <= pt.y() <= h + 20:
                    self._draw_favorite_marker(painter, pt, fav)
                    self._rendered_favorites.append((pt, fav))

        # Draw Primary Selected / Adjustable Pin on top
        if self.pin_lat is not None and self.pin_lng is not None:
            pin_pt = self.wgs_to_screen(self.pin_lat, self.pin_lng)
            self._draw_active_pin(painter, pin_pt)

        # Draw bottom status bar & scale bar
        self._draw_hud_footer(painter, w, h)
        painter.end()

    @staticmethod
    def _draw_hotspot_marker(painter: QPainter, pt: QPointF, hs: EBirdHotspot, *, show_label: bool) -> None:
        painter.save()
        painter.setPen(QPen(QColor("#0d281e"), 1.6))
        painter.setBrush(QBrush(QColor("#2dd4bf")))
        painter.drawEllipse(pt, 6.0, 6.0)
        painter.setBrush(QBrush(QColor("#ffffff")))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(pt, 2.2, 2.2)

        if show_label:
            short = suggest_short_spot_name(hs.loc_name)
            if len(short) > 14:
                short = short[:13] + "…"
            font = QFont("Microsoft YaHei UI", 8)
            painter.setFont(font)
            fm = painter.fontMetrics()
            tw = fm.horizontalAdvance(short) + 10
            th = fm.height() + 4
            box = QRectF(pt.x() + 9, pt.y() - th / 2.0, tw, th)
            painter.setBrush(QBrush(QColor(18, 36, 34, 210)))
            painter.setPen(QPen(QColor("#2dd4bf"), 1))
            painter.drawRoundedRect(box, 4, 4)
            painter.setPen(QColor("#ccfbf1"))
            painter.drawText(box, Qt.AlignmentFlag.AlignCenter, short)
        painter.restore()

    @staticmethod
    def _draw_favorite_marker(painter: QPainter, pt: QPointF, fav: FavoriteLocation) -> None:
        painter.save()
        painter.setPen(QPen(QColor("#422006"), 1.6))
        painter.setBrush(QBrush(QColor("#facc15")))
        painter.drawEllipse(pt, 7.0, 7.0)
        font = QFont("Microsoft YaHei UI", 8, QFont.Weight.Bold)
        painter.setFont(font)
        lbl = f"⭐ {fav.name}"
        fm = painter.fontMetrics()
        tw = fm.horizontalAdvance(lbl) + 10
        th = fm.height() + 4
        box = QRectF(pt.x() + 10, pt.y() - th / 2.0, tw, th)
        painter.setBrush(QBrush(QColor(38, 30, 14, 220)))
        painter.setPen(QPen(QColor("#eab308"), 1))
        painter.drawRoundedRect(box, 4, 4)
        painter.setPen(QColor("#fef08a"))
        painter.drawText(box, Qt.AlignmentFlag.AlignCenter, lbl)
        painter.restore()

    @staticmethod
    def _draw_active_pin(painter: QPainter, pt: QPointF) -> None:
        """Draw high-visibility teardrop pin + precision crosshair at exact target point `pt`."""
        painter.save()
        x, y = pt.x(), pt.y()

        # Ground precision ring + crosshair
        painter.setPen(QPen(QColor(255, 255, 255, 210), 2.5))
        painter.setBrush(QBrush(QColor(239, 68, 68, 55)))
        painter.drawEllipse(QPointF(x, y), 10.0, 10.0)
        painter.setPen(QPen(QColor("#ef4444"), 1.6))
        painter.drawLine(QPointF(x - 14, y), QPointF(x + 14, y))
        painter.drawLine(QPointF(x, y - 14), QPointF(x, y + 14))

        # Teardrop body pointing cleanly at (x, y)
        path = QPainterPath()
        path.moveTo(x, y)
        path.cubicTo(x - 13, y - 14, x - 14, y - 32, x, y - 32)
        path.cubicTo(x + 14, y - 32, x + 13, y - 14, x, y)
        painter.setPen(QPen(QColor("#ffffff"), 2.0))
        painter.setBrush(QBrush(QColor("#ef4444")))
        painter.drawPath(path)

        # Inner white dot
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor("#ffffff")))
        painter.drawEllipse(QPointF(x, y - 20), 4.5, 4.5)
        painter.restore()

    def _draw_hud_footer(self, painter: QPainter, w: int, h: int) -> None:
        painter.save()
        bar_h = 24
        painter.fillRect(0, h - bar_h, w, bar_h, QColor(18, 21, 26, 210))
        font = QFont("Microsoft YaHei UI", 8)
        painter.setFont(font)
        painter.setPen(QColor("#d1d5db"))

        if self.pin_lat is not None and self.pin_lng is not None:
            ns = "N" if self.pin_lat >= 0 else "S"
            ew = "E" if self.pin_lng >= 0 else "W"
            coord_txt = f"📌 选点坐标 (WGS-84): {abs(self.pin_lat):.6f}°{ns}, {abs(self.pin_lng):.6f}°{ew}  ·  缩放 Z{self.zoom}"
        else:
            coord_txt = f"💡 点击地图任意位置落针选点  ·  视野中心: {self.center_lat:.4f}, {self.center_lng:.4f}  ·  Z{self.zoom}"
        painter.drawText(QRectF(10, h - bar_h, w - 140, bar_h), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, coord_txt)

        # Scale bar calculation at current latitude
        meters_per_px = 156543.03392 * math.cos(math.radians(self.center_lat)) / (1 << self.zoom)
        nice_meters = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000]
        target_m = nice_meters[0]
        for m in nice_meters:
            if m / max(0.01, meters_per_px) <= 105:
                target_m = m
        px_len = max(24.0, min(115.0, target_m / max(0.01, meters_per_px)))
        scale_lbl = f"{target_m // 1000} km" if target_m >= 1000 else f"{target_m} m"

        bx_right = w - 12
        bx_left = bx_right - px_len
        by = h - 7
        painter.setPen(QPen(QColor("#93c5fd"), 2))
        painter.drawLine(QPointF(bx_left, by), QPointF(bx_right, by))
        painter.drawLine(QPointF(bx_left, by - 4), QPointF(bx_left, by))
        painter.drawLine(QPointF(bx_right, by - 4), QPointF(bx_right, by))
        painter.setPen(QColor("#93c5fd"))
        painter.drawText(
            QRectF(bx_left - 58, h - bar_h, 54, bar_h),
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
            scale_lbl,
        )
        painter.restore()

    # ---------------- Mouse & Wheel Interaction ----------------

    def _hit_test_pin(self, pos: QPoint) -> bool:
        if self.pin_lat is None or self.pin_lng is None:
            return False
        pt = self.wgs_to_screen(self.pin_lat, self.pin_lng)
        dx = pos.x() - pt.x()
        dy = pos.y() - (pt.y() - 14)
        return (dx * dx + dy * dy) <= (20.0 * 20.0)

    def _hit_test_overlays(self, pos: QPoint) -> tuple[EBirdHotspot | None, FavoriteLocation | None]:
        p = QPointF(pos)
        for pt, fav in reversed(self._rendered_favorites):
            if (p.x() - pt.x()) ** 2 + (p.y() - pt.y()) ** 2 <= 100.0:
                return None, fav
        for pt, hs in reversed(self._rendered_hotspots):
            if (p.x() - pt.x()) ** 2 + (p.y() - pt.y()) ** 2 <= 100.0:
                return hs, None
        return None, None

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position().toPoint()
            self._press_pos = pos
            self._last_drag_pos = pos
            if self._hit_test_pin(pos):
                self._dragging_pin = True
                self._panning_map = False
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
            else:
                self._dragging_pin = False
                self._panning_map = True
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        pos = event.position().toPoint()
        if self._dragging_pin:
            wgs_lat, wgs_lng = self.screen_to_wgs(pos.x(), pos.y())
            self.pin_lat = max(-85.0, min(85.0, wgs_lat))
            self.pin_lng = ((wgs_lng + 180.0) % 360.0) - 180.0
            self.update()
            self.pin_changed.emit(self.pin_lat, self.pin_lng)
            return

        if self._panning_map and self._last_drag_pos is not None:
            dx = pos.x() - self._last_drag_pos.x()
            dy = pos.y() - self._last_drag_pos.y()
            if dx != 0 or dy != 0:
                self.setCursor(Qt.CursorShape.SizeAllCursor)
                c_lat, c_lng = self._wgs_to_layer_latlng(self.center_lat, self.center_lng)
                cx, cy = latlng_to_world_px(c_lat, c_lng, self.zoom)
                new_map_lat, new_map_lng = world_px_to_latlng(cx - dx, cy - dy, self.zoom)
                self.center_lat, self.center_lng = self._layer_latlng_to_wgs(new_map_lat, new_map_lng)
                self._last_drag_pos = pos
                self.update()
            return

        # Hover cursor & tooltips over pin or overlay markers
        if self._hit_test_pin(pos):
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            QToolTip.showText(event.globalPosition().toPoint(), "按住左键拖动可微调选点坐标", self)
        else:
            hs, fav = self._hit_test_overlays(pos)
            if fav is not None:
                self.setCursor(Qt.CursorShape.PointingHandCursor)
                tip = f"⭐ 常用观鸟点：{fav.name}\n区域：{fav.admin_label}"
                if fav.ebird_loc_id:
                    tip += f"\neBird: {fav.ebird_loc_id}"
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)
            elif hs is not None:
                self.setCursor(Qt.CursorShape.PointingHandCursor)
                tip = f"🧭 eBird 鸟点：{hs.loc_name}\n编号：{hs.loc_id} · 记录鸟种：{hs.num_species} 种\n（点击可选用并关联该鸟点）"
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)
            else:
                self.setCursor(Qt.CursorShape.CrossCursor)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position().toPoint()
            was_click = (
                self._press_pos is not None
                and abs(pos.x() - self._press_pos.x()) <= 5
                and abs(pos.y() - self._press_pos.y()) <= 5
            )
            if not self._dragging_pin and was_click:
                hs, fav = self._hit_test_overlays(pos)
                if fav is not None and fav.lat is not None and fav.lng is not None:
                    self.set_pin(fav.lat, fav.lng, pan_to=False, emit_signal=True)
                    self.favorite_clicked.emit(fav)
                elif hs is not None and hs.lat is not None and hs.lng is not None:
                    self.set_pin(hs.lat, hs.lng, pan_to=False, emit_signal=True)
                    self.hotspot_clicked.emit(hs)
                else:
                    wgs_lat, wgs_lng = self.screen_to_wgs(pos.x(), pos.y())
                    self.set_pin(wgs_lat, wgs_lng, pan_to=False, emit_signal=True)

            self._dragging_pin = False
            self._panning_map = False
            self._press_pos = None
            self._last_drag_pos = None
            self.setCursor(Qt.CursorShape.CrossCursor)
        super().mouseReleaseEvent(event)

    def wheelEvent(self, event: QWheelEvent) -> None:
        delta = event.angleDelta().y()
        if delta == 0:
            return
        step = 1 if delta > 0 else -1
        new_zoom = max(3, min(self.active_layer.max_zoom, self.zoom + step))
        if new_zoom == self.zoom:
            return

        # Keep the geographic point under cursor stationary while zooming
        cursor_pt = event.position()
        anchor_wgs_lat, anchor_wgs_lng = self.screen_to_wgs(cursor_pt.x(), cursor_pt.y())
        self.zoom = new_zoom

        a_map_lat, a_map_lng = self._wgs_to_layer_latlng(anchor_wgs_lat, anchor_wgs_lng)
        ax, ay = latlng_to_world_px(a_map_lat, a_map_lng, self.zoom)
        new_cx = ax - (cursor_pt.x() - self.width() / 2.0)
        new_cy = ay - (cursor_pt.y() - self.height() / 2.0)
        nc_map_lat, nc_map_lng = world_px_to_latlng(new_cx, new_cy, self.zoom)
        self.center_lat, self.center_lng = self._layer_latlng_to_wgs(nc_map_lat, nc_map_lng)
        self.update()
        event.accept()


@dataclass(slots=True)
class MapPickedResult:
    lat: float
    lng: float
    province: str
    city: str
    spot_name: str
    ebird_loc_id: str | None = None
    save_as_favorite: bool = False


class MapPickerDialog(QDialog):
    """Full-featured interactive Map Point-Picking & Coordinate Adjustment Dialog."""

    def __init__(
        self,
        parent: QWidget | None,
        ebird_service: EBirdLocationService,
        *,
        initial_lat: float | None = None,
        initial_lng: float | None = None,
        initial_province: str = "",
        initial_city: str = "",
        initial_spot_name: str = "",
        initial_ebird_id: str = "",
        photo_count: int = 0,
    ) -> None:
        super().__init__(parent)
        self.svc = ebird_service
        self.photo_count = photo_count
        self._tracker = WorkerTracker(self)
        self._syncing_combos = False
        self._result: MapPickedResult | None = None

        title = (
            f"🗺 地图选点与坐标微调（将应用到选中的 {photo_count} 张照片）"
            if photo_count > 0
            else "🗺 地图选点与坐标微调"
        )
        self.setWindowTitle(title)
        self.resize(1040, 720)

        # Determine starting viewport & pin
        start_lat = initial_lat
        start_lng = initial_lng
        start_zoom = 14 if (start_lat is not None and start_lng is not None) else 5
        if start_lat is None or start_lng is None:
            ce = get_city_entry(initial_province, initial_city)
            if ce is not None:
                start_lat, start_lng, start_zoom = ce.lat, ce.lng, 11
            elif initial_province:
                pc = get_province_center(initial_province)
                if pc is not None:
                    start_lat, start_lng, start_zoom = pc[0], pc[1], 8

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # ---- Top Control Bar: Layer + Province/City Jump + Search ----
        top_bar = QHBoxLayout()
        top_bar.setSpacing(6)

        self.combo_layer = QComboBox()
        for spec in MAP_LAYERS:
            self.combo_layer.addItem(spec.title, spec.layer_id)
        self.combo_layer.currentIndexChanged.connect(self._on_layer_changed)
        top_bar.addWidget(self.combo_layer)

        top_bar.addWidget(QLabel("省/区:"))
        self.combo_province = QComboBox()
        self.combo_province.addItem("（自动/不限）", "")
        for p in list_provinces():
            self.combo_province.addItem(p, p)
        self.combo_province.currentIndexChanged.connect(self._on_province_changed)
        top_bar.addWidget(self.combo_province)

        top_bar.addWidget(QLabel("地市:"))
        self.combo_city = QComboBox()
        self.combo_city.setMinimumWidth(135)
        self.combo_city.addItem("（选择地市定位）", "")
        self.combo_city.currentIndexChanged.connect(self._on_city_changed)
        top_bar.addWidget(self.combo_city)

        self.edit_jump_search = QLineEdit()
        self.edit_jump_search.setPlaceholderText("搜地市 / 已缓存鸟点(支持拼音如 ymy、szw) / 输入纬度,经度 回车跳转...")
        self.edit_jump_search.returnPressed.connect(self._on_search_jump)
        top_bar.addWidget(self.edit_jump_search, 1)

        btn_jump = QPushButton("🔍 定位")
        btn_jump.clicked.connect(self._on_search_jump)
        top_bar.addWidget(btn_jump)
        root.addLayout(top_bar)

        # ---- Sub-bar: Hints & eBird Overlay Controls ----
        sub_bar = QHBoxLayout()
        lbl_tip = QLabel("💡 左键点击地图落针，按住红色图钉可拖拽微调；滚轮缩放；点击绿色圆点可直接选用周边 eBird 鸟点。")
        lbl_tip.setStyleSheet("color: #93c5fd; font-size: 12px;")
        sub_bar.addWidget(lbl_tip, 1)

        self.chk_show_ebird = QCheckBox("🧭 显示周边鸟点与常用点")
        self.chk_show_ebird.setChecked(True)
        self.chk_show_ebird.toggled.connect(self._on_toggle_overlays)
        sub_bar.addWidget(self.chk_show_ebird)

        self.btn_fetch_online_nearby = QPushButton("📡 拉取当前视野 eBird 鸟点")
        self.btn_fetch_online_nearby.setToolTip("使用已配置的 eBird API Key 在线获取地图中心周边 25km 鸟点")
        self.btn_fetch_online_nearby.clicked.connect(self._fetch_online_nearby_hotspots)
        sub_bar.addWidget(self.btn_fetch_online_nearby)
        root.addLayout(sub_bar)

        # ---- Center Slippy Map ----
        self.map_widget = SlippyMapWidget(
            self,
            initial_lat=start_lat if start_lat is not None else 35.8617,
            initial_lng=start_lng if start_lng is not None else 104.1954,
            initial_zoom=start_zoom,
        )
        if initial_lat is not None and initial_lng is not None:
            self.map_widget.set_pin(initial_lat, initial_lng, pan_to=True, zoom=15, emit_signal=False)
        self.map_widget.pin_changed.connect(self._on_map_pin_moved)
        self.map_widget.hotspot_clicked.connect(self._on_map_hotspot_clicked)
        self.map_widget.favorite_clicked.connect(self._on_map_favorite_clicked)
        root.addWidget(self.map_widget, 1)

        # ---- Bottom Selected Location & Coordinate Details ----
        bot_grp = QGroupBox("当前选点归属地市与观鸟点信息（微调图钉自动反查省市，也可手动微调数字）")
        bot_form = QFormLayout(bot_grp)
        bot_form.setSpacing(6)

        row1 = QHBoxLayout()
        self.edit_lat = QLineEdit(f"{initial_lat:.6f}" if initial_lat is not None else "")
        self.edit_lat.setPlaceholderText("纬度 (如 22.521200)")
        self.edit_lng = QLineEdit(f"{initial_lng:.6f}" if initial_lng is not None else "")
        self.edit_lng.setPlaceholderText("经度 (如 113.992100)")
        btn_locate_coord = QPushButton("按数值移动图钉")
        btn_locate_coord.clicked.connect(self._apply_typed_coords_to_pin)

        self.edit_res_prov = QLineEdit(normalize_province_name(initial_province))
        self.edit_res_prov.setPlaceholderText("省/直辖市")
        self.edit_res_city = QLineEdit(initial_city)
        self.edit_res_city.setPlaceholderText("地级市/自治州/区")

        row1.addWidget(QLabel("纬度:"))
        row1.addWidget(self.edit_lat, 1)
        row1.addWidget(QLabel("经度:"))
        row1.addWidget(self.edit_lng, 1)
        row1.addWidget(btn_locate_coord)
        row1.addSpacing(12)
        row1.addWidget(QLabel("所属省:"))
        row1.addWidget(self.edit_res_prov, 1)
        row1.addWidget(QLabel("所属地市:"))
        row1.addWidget(self.edit_res_city, 1)
        bot_form.addRow("精确坐标 & 省市:", row1)

        row2 = QHBoxLayout()
        self.edit_spot_name = QLineEdit(initial_spot_name)
        self.edit_spot_name.setPlaceholderText("观鸟点具体名称（如：深圳湾公园北湾鹭港 / 圆明园福海）")
        btn_prefix = QPushButton("⚡ 带入省市前缀")
        btn_prefix.clicked.connect(self._prepend_admin_prefix)
        self.edit_ebird_id = QLineEdit(initial_ebird_id)
        self.edit_ebird_id.setPlaceholderText("可选关联 eBird L码")
        self.edit_ebird_id.setMaximumWidth(150)

        row2.addWidget(self.edit_spot_name, 1)
        row2.addWidget(btn_prefix)
        row2.addSpacing(8)
        row2.addWidget(QLabel("关联 eBird:"))
        row2.addWidget(self.edit_ebird_id)
        bot_form.addRow("观鸟点名称:", row2)

        action_row = QHBoxLayout()
        self.chk_save_fav = QCheckBox("⭐ 同时将该地点与精确坐标保存/更新到「我的常用观鸟点」")
        self.chk_save_fav.setChecked(photo_count == 0)
        action_row.addWidget(self.chk_save_fav)
        action_row.addStretch(1)

        btn_cancel = QPushButton("取消")
        btn_cancel.clicked.connect(self.reject)
        confirm_lbl = (
            f"✓ 确认选点并更新 {photo_count} 张照片"
            if photo_count > 0
            else "✓ 确认采用该选点坐标"
        )
        self.btn_confirm = QPushButton(confirm_lbl)
        self.btn_confirm.setObjectName("PrimaryButton")
        self.btn_confirm.clicked.connect(self._confirm_selection)
        action_row.addWidget(btn_cancel)
        action_row.addWidget(self.btn_confirm)
        bot_form.addRow(action_row)

        root.addWidget(bot_grp)

        # Initialize cascading combos & overlay markers
        self._set_province_city_combos(self.edit_res_prov.text(), self.edit_res_city.text())
        if initial_lat is not None and initial_lng is not None and not self.edit_res_prov.text():
            self._auto_fill_admin_from_coords(initial_lat, initial_lng)
        self._reload_overlay_markers()

    def picked_result(self) -> MapPickedResult | None:
        return self._result

    def closeEvent(self, event) -> None:
        self.map_widget.shutdown()
        super().closeEvent(event)

    def reject(self) -> None:
        self.map_widget.shutdown()
        super().reject()

    # ---------------- Handlers ----------------

    def _on_layer_changed(self, idx: int) -> None:
        self.map_widget.set_layer_index(idx)

    def _on_toggle_overlays(self, checked: bool) -> None:
        self.map_widget.show_overlays = checked
        self.map_widget.update()

    def _reload_overlay_markers(self) -> None:
        favs = self.svc.list_favorites()
        hotspots = self.svc.db.load_all_ebird_hotspots()[:400]
        self.map_widget.set_overlay_data(hotspots=hotspots, favorites=favs)

    def _set_province_city_combos(self, province: str, city: str) -> None:
        self._syncing_combos = True
        try:
            prov_norm = normalize_province_name(province)
            p_idx = self.combo_province.findData(prov_norm)
            self.combo_province.setCurrentIndex(p_idx if p_idx >= 0 else 0)

            self.combo_city.clear()
            self.combo_city.addItem("（选择地市定位）", "")
            for ce in list_cities(prov_norm):
                self.combo_city.addItem(ce.city, ce.city)

            if city:
                c_idx = self.combo_city.findData(city)
                if c_idx < 0:
                    # Try prefix match
                    for i in range(1, self.combo_city.count()):
                        if str(self.combo_city.itemData(i)).startswith(city.rstrip("市区县州盟")):
                            c_idx = i
                            break
                if c_idx >= 0:
                    self.combo_city.setCurrentIndex(c_idx)
        finally:
            self._syncing_combos = False

    def _on_province_changed(self, _idx: int) -> None:
        if self._syncing_combos:
            return
        prov = str(self.combo_province.currentData() or "")
        self.edit_res_prov.setText(prov)
        self._syncing_combos = True
        try:
            self.combo_city.clear()
            self.combo_city.addItem("（选择地市定位）", "")
            for ce in list_cities(prov):
                self.combo_city.addItem(ce.city, ce.city)
        finally:
            self._syncing_combos = False

        if prov:
            pc = get_province_center(prov)
            if pc is not None:
                self.map_widget.set_view(pc[0], pc[1], 8)

    def _on_city_changed(self, _idx: int) -> None:
        if self._syncing_combos:
            return
        prov = str(self.combo_province.currentData() or "")
        city = str(self.combo_city.currentData() or "")
        if city:
            self.edit_res_city.setText(city)
            ce = get_city_entry(prov, city)
            if ce is not None:
                self.map_widget.set_view(ce.lat, ce.lng, 12)

    def _auto_fill_admin_from_coords(self, lat: float, lng: float) -> None:
        prov, city = infer_province_city(lat, lng)
        if prov:
            self.edit_res_prov.setText(prov)
        if city:
            self.edit_res_city.setText(city)
        if prov or city:
            self._set_province_city_combos(prov, city)

    def _on_map_pin_moved(self, lat: float, lng: float) -> None:
        self.edit_lat.setText(f"{lat:.6f}")
        self.edit_lng.setText(f"{lng:.6f}")
        self._auto_fill_admin_from_coords(lat, lng)

    def _on_map_hotspot_clicked(self, hs_obj: object) -> None:
        hs: EBirdHotspot = hs_obj  # type: ignore[assignment]
        self.edit_ebird_id.setText(hs.loc_id)
        if not self.edit_spot_name.text().strip():
            self.edit_spot_name.setText(suggest_short_spot_name(hs.loc_name, hs.subnational1_code))

    def _on_map_favorite_clicked(self, fav_obj: object) -> None:
        fav: FavoriteLocation = fav_obj  # type: ignore[assignment]
        self.edit_spot_name.setText(fav.name)
        if fav.ebird_loc_id:
            self.edit_ebird_id.setText(fav.ebird_loc_id)
        if fav.province:
            self.edit_res_prov.setText(fav.province)
        if fav.city:
            self.edit_res_city.setText(fav.city)

    def _on_search_jump(self) -> None:
        raw = self.edit_jump_search.text().strip()
        if not raw:
            return

        # 1. Check direct coordinate pair like "22.5212, 113.9921"
        m_coord = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[,，\s]\s*(-?\d+(?:\.\d+)?)\s*$", raw)
        if m_coord:
            lat, lng = float(m_coord.group(1)), float(m_coord.group(2))
            if -90 <= lat <= 90 and -180 <= lng <= 180:
                self.map_widget.set_pin(lat, lng, pan_to=True, zoom=15, emit_signal=True)
                return

        # 2. Check cached/online eBird hotspots (name, Pinyin initials, or L-code)
        spots = self.svc.search_cached_hotspots(raw, limit=5)
        if spots and spots[0].lat is not None and spots[0].lng is not None:
            top = spots[0]
            self.map_widget.set_pin(top.lat, top.lng, pan_to=True, zoom=15, emit_signal=True)
            self.edit_ebird_id.setText(top.loc_id)
            if not self.edit_spot_name.text().strip():
                self.edit_spot_name.setText(suggest_short_spot_name(top.loc_name, top.subnational1_code))
            return

        # 3. Check prefecture cities / districts (name or Pinyin initials)
        cities = search_cities(raw, limit=3)
        if cities:
            ce = cities[0]
            self._set_province_city_combos(ce.province, ce.city)
            self.edit_res_prov.setText(ce.province)
            self.edit_res_city.setText(ce.city)
            self.map_widget.set_view(ce.lat, ce.lng, 12)
            return

        QMessageBox.information(
            self,
            "未匹配到目标位置",
            "未在省市库或本地缓存鸟点中找到该关键词。\n你可以先选择上方「省/地市」定位后直接在地图上点击落针，或输入十进制「纬度, 经度」。",
        )

    def _fetch_online_nearby_hotspots(self) -> None:
        if not self.svc.get_api_key():
            QMessageBox.information(
                self,
                "尚未设置 eBird API Key",
                "请先在「常用观鸟点 & eBird 鸟点关联中心」填入免费的 eBird API Key，即可拉取任意坐标周边鸟点。",
            )
            return

        from bird_gallery.gui.location_dialog import _EBirdNearbyWorker

        self.btn_fetch_online_nearby.setEnabled(False)
        self.btn_fetch_online_nearby.setText("正在拉取...")
        lat = self.map_widget.pin_lat if self.map_widget.pin_lat is not None else self.map_widget.center_lat
        lng = self.map_widget.pin_lng if self.map_widget.pin_lng is not None else self.map_widget.center_lng

        worker = _EBirdNearbyWorker(str(self.svc.db.db_path), lat, lng)

        def _done(spots_obj: object) -> None:
            self.btn_fetch_online_nearby.setEnabled(True)
            self.btn_fetch_online_nearby.setText("📡 拉取当前视野 eBird 鸟点")
            spots: list[EBirdHotspot] = spots_obj  # type: ignore[assignment]
            self.map_widget.set_overlay_data(hotspots=spots, favorites=self.svc.list_favorites())

        def _err(msg: str) -> None:
            self.btn_fetch_online_nearby.setEnabled(True)
            self.btn_fetch_online_nearby.setText("📡 拉取当前视野 eBird 鸟点")
            QMessageBox.warning(self, "拉取周边鸟点失败", msg)

        worker.finished_ok.connect(_done)
        worker.failed.connect(_err)
        self._tracker.start(worker)

    def _apply_typed_coords_to_pin(self) -> None:
        try:
            lat = float(self.edit_lat.text().strip())
            lng = float(self.edit_lng.text().strip())
        except ValueError:
            QMessageBox.warning(self, "坐标格式有误", "请输入有效的十进制纬度和经度（如 39.9985 和 116.2982）。")
            return
        if not (-90 <= lat <= 90 and -180 <= lng <= 180):
            QMessageBox.warning(self, "坐标超出范围", "纬度需在 -90~90 之间，经度需在 -180~180 之间。")
            return
        self.map_widget.set_pin(lat, lng, pan_to=True, zoom=max(self.map_widget.zoom, 14), emit_signal=True)

    def _prepend_admin_prefix(self) -> None:
        prov = self.edit_res_prov.text().strip()
        city = self.edit_res_city.text().strip()
        prefix = format_province_city(prov, city)
        if not prefix:
            return
        cur = self.edit_spot_name.text().strip()
        if not cur:
            self.edit_spot_name.setText(f"{prefix}·")
            self.edit_spot_name.setFocus()
        elif not cur.startswith(prefix):
            self.edit_spot_name.setText(f"{prefix}·{cur}")

    def _confirm_selection(self) -> None:
        try:
            lat = float(self.edit_lat.text().strip())
            lng = float(self.edit_lng.text().strip())
        except ValueError:
            QMessageBox.information(self, "请先选点", "请在地图上左键点击选择位置，或输入十进制经纬度。")
            return

        prov = normalize_province_name(self.edit_res_prov.text().strip())
        city = self.edit_res_city.text().strip()
        if not prov and not city:
            prov, city = infer_province_city(lat, lng)

        spot_name = self.edit_spot_name.text().strip()
        raw_lid = self.edit_ebird_id.text().strip()
        lid = extract_ebird_loc_id(raw_lid) or (raw_lid if raw_lid else None)

        if not spot_name and (self.chk_save_fav.isChecked() or self.photo_count > 0):
            prefix = format_province_city(prov, city)
            spot_name = f"{prefix} ({lat:.3f}, {lng:.3f})" if prefix else f"选点 ({lat:.4f}, {lng:.4f})"

        if self.chk_save_fav.isChecked() and spot_name:
            self.svc.db.upsert_favorite_location(
                spot_name,
                province=prov,
                city=city,
                ebird_loc_id=lid,
                lat=lat,
                lng=lng,
            )

        self._result = MapPickedResult(
            lat=lat,
            lng=lng,
            province=prov,
            city=city,
            spot_name=spot_name,
            ebird_loc_id=lid,
            save_as_favorite=self.chk_save_fav.isChecked(),
        )
        self.map_widget.shutdown()
        self.accept()

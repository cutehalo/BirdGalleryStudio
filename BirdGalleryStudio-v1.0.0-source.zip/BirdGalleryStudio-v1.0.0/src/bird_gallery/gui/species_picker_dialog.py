"""Popup dialogs for multi-selecting bird species:
1. `ChecklistSpeciesPickerDialog`: Select 1 or multiple species from an imported birding checklist, sorted A-Z by Pinyin initials.
2. `QuickAddSpeciesDialog`: Search & multi-select co-occurring bird species from the full 11,011-species checklist (`+` button).
"""

from __future__ import annotations

import re

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from bird_gallery.catalog import CatalogService
from bird_gallery.gui.theme import enable_windows_dark_titlebar
from bird_gallery.models import BirdingChecklist, ChecklistItem
from bird_gallery.taxonomy import TaxonEntry, compute_pinyin_fields


def sort_checklist_items_by_pinyin(
    items: list[ChecklistItem],
    catalog: CatalogService,
) -> list[tuple[str, str, str, ChecklistItem, TaxonEntry | None]]:
    """Sort checklist items A-Z by Pinyin initials.

    Returns `[(first_letter, pinyin_initials, pinyin_full, item, taxon_or_none)]`.
    """
    enriched: list[tuple[str, str, str, ChecklistItem, TaxonEntry | None]] = []
    for it in items:
        taxon = catalog.taxonomy.lookup_by_cn(it.common_name_cn) or catalog.taxonomy.lookup(it.scientific_name)
        if taxon is not None and taxon.pinyin_initials:
            ini = taxon.pinyin_initials.lower()
            full_py = taxon.pinyin_full.lower()
        else:
            ini, full_py = compute_pinyin_fields(it.common_name_cn)
        first_let = ini[0].upper() if (ini and ini[0].isalpha()) else "#"
        enriched.append((first_let, ini, full_py, it, taxon))

    enriched.sort(key=lambda x: (x[0] == "#", x[1], x[2], x[3].common_name_cn))
    return enriched


class ChecklistSpeciesPickerDialog(QDialog):
    """Popup window listing species from an imported birding report sorted A-Z by Pinyin initials with multi-select."""

    def __init__(
        self,
        parent: QWidget | None,
        catalog: CatalogService,
        checklists: list[BirdingChecklist],
        *,
        preferred_date: str = "",
        initial_checklist_id: int | None = None,
        existing_photo_species: list[str] | None = None,
    ) -> None:
        super().__init__(parent)
        self.catalog = catalog
        self._all_checklists = checklists
        self._preferred_date = preferred_date[:10] if preferred_date else ""
        self._initial_checklist_id = initial_checklist_id
        self._initial_photo_species: set[str] = set(existing_photo_species or [])
        self._checked_species: set[str] = set()
        self._sorted_rows: list[tuple[str, str, str, ChecklistItem, TaxonEntry | None]] = []
        self._active_letter: str = ""
        self._updating_list = False
        self._result_mode: str = "add"  # 'add' (append) | 'set' (replace)

        self.setWindowTitle("选择观鸟报告鸟种  ·  拼音首字母排序与多选")
        self.resize(680, 590)

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 14, 16, 14)
        root.setSpacing(10)

        # 1. Checklist Selector Row (defaults to photo's same-date checklist, switchable to any imported report!)
        cl_row = QHBoxLayout()
        cl_row.addWidget(QLabel("观鸟记录单:"))
        self.combo_cl = QComboBox()
        self._populate_checklist_combo()
        self.combo_cl.currentIndexChanged.connect(self._on_checklist_combo_changed)
        cl_row.addWidget(self.combo_cl, 1)
        root.addLayout(cl_row)

        # 2. Search Filter Box
        search_row = QHBoxLayout()
        self.edit_filter = QLineEdit()
        self.edit_filter.setPlaceholderText("输入拼音首字母 (如 hlpl、fzy) 或鸟种关键字快速筛选...")
        self.edit_filter.setClearButtonEnabled(True)
        self.edit_filter.textChanged.connect(lambda _t: self._rebuild_list_items())
        search_row.addWidget(self.edit_filter, 1)
        root.addLayout(search_row)

        # 3. A-Z Initial Letter Quick Bar
        self.letter_bar = QWidget()
        self.letter_layout = QHBoxLayout(self.letter_bar)
        self.letter_layout.setContentsMargins(0, 0, 0, 0)
        self.letter_layout.setSpacing(3)
        self._letter_group = QButtonGroup(self)
        self._letter_group.setExclusive(True)
        root.addWidget(self.letter_bar)

        # 4. Pinyin-Sorted Checkable Species List
        self.list_widget = QListWidget()
        self.list_widget.setSpacing(2)
        self.list_widget.itemChanged.connect(self._on_item_check_changed)
        self.list_widget.itemClicked.connect(self._on_item_row_clicked)
        root.addWidget(self.list_widget, 1)

        # 5. Checked Summary + Select All / Clear Row
        sel_row = QHBoxLayout()
        self.lbl_summary = QLabel("已勾选 0 种")
        self.lbl_summary.setWordWrap(True)
        self.lbl_summary.setStyleSheet("color: #7ee2b8; font-weight: 600; font-size: 12px;")
        sel_row.addWidget(self.lbl_summary, 1)

        btn_sel_all = QPushButton("全选当前")
        btn_sel_all.clicked.connect(self._check_all_visible)
        btn_clear_all = QPushButton("清空勾选")
        btn_clear_all.clicked.connect(self._uncheck_all)
        sel_row.addWidget(btn_sel_all)
        sel_row.addWidget(btn_clear_all)
        root.addLayout(sel_row)

        # 6. Action Buttons (Synchronized with Multi-Species!)
        btn_row = QHBoxLayout()
        btn_cancel = QPushButton("取消")
        btn_cancel.clicked.connect(self.reject)

        self.btn_set = QPushButton("✓ 设为所选鸟种（覆盖）")
        self.btn_set.setToolTip("将照片的鸟种列表精确更新为当前勾选的这几种鸟")
        self.btn_set.clicked.connect(lambda: self._confirm("set"))

        self.btn_add = QPushButton("＋ 追加所选鸟种（共存）")
        self.btn_add.setObjectName("PrimaryButton")
        self.btn_add.setToolTip("将勾选的鸟种追加到照片中，同时保留照片原本已有的其他鸟种")
        self.btn_add.clicked.connect(lambda: self._confirm("add"))

        btn_row.addWidget(btn_cancel)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_set)
        btn_row.addWidget(self.btn_add)
        root.addLayout(btn_row)

        self._load_selected_checklist_items()
        self.edit_filter.setFocus()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        enable_windows_dark_titlebar(self)

    def selected_species(self) -> list[str]:
        # Preserve Pinyin A-Z order among checked species present in the selected report
        return [
            it.common_name_cn
            for (_l, _ini, _f, it, _tx) in self._sorted_rows
            if it.common_name_cn in self._checked_species
        ]

    def result_mode(self) -> str:
        return self._result_mode

    def matched_checklist(self) -> BirdingChecklist | None:
        """Return the selected BirdingChecklist with location metadata for auto-filling photo location."""
        data = self.combo_cl.currentData()
        if not isinstance(data, tuple):
            return None
        kind, val = data
        if kind == "id":
            cl_id = int(val)
            for c in self._all_checklists:
                if c.checklist_id == cl_id:
                    return c
            return self.catalog.db.get_checklist(cl_id)
        if kind == "date":
            date_str = str(val)
            picked_set = set(self.selected_species())
            same_cls = [c for c in self._all_checklists if c.obs_date == date_str]
            for c in same_cls:
                if not (c.location_name or c.province or c.city):
                    continue
                full = self.catalog.db.get_checklist(c.checklist_id)
                if full and ({it.common_name_cn for it in full.items} & picked_set):
                    return full
            for c in same_cls:
                if c.location_name or c.province or c.city:
                    return c
        return None

    def _populate_checklist_combo(self) -> None:
        self.combo_cl.clear()
        same_date_cls = [c for c in self._all_checklists if self._preferred_date and c.obs_date == self._preferred_date]
        if len(same_date_cls) > 1:
            total_sp = sum(c.species_count for c in same_date_cls)
            self.combo_cl.addItem(
                f"⭐ 当日合并记录：{self._preferred_date}（共 {len(same_date_cls)} 篇 · {total_sp} 种）",
                ("date", self._preferred_date),
            )

        for cl in self._all_checklists:
            loc = cl.location_name or cl.admin_label or "未填地点"
            ext = f" [{cl.external_id}]" if cl.external_id else ""
            star = "⭐ 当日 · " if (self._preferred_date and cl.obs_date == self._preferred_date) else ""
            self.combo_cl.addItem(
                f"{star}{cl.obs_date} · {loc}{ext}（{cl.species_count} 种）",
                ("id", cl.checklist_id),
            )

        selected_idx = 0
        if self._initial_checklist_id is not None:
            for i in range(self.combo_cl.count()):
                if self.combo_cl.itemData(i) == ("id", self._initial_checklist_id):
                    selected_idx = i
                    break
        elif len(same_date_cls) == 1:
            for i in range(self.combo_cl.count()):
                if self.combo_cl.itemData(i) == ("id", same_date_cls[0].checklist_id):
                    selected_idx = i
                    break

        if self.combo_cl.count() > 0:
            self.combo_cl.setCurrentIndex(selected_idx)

    def _on_checklist_combo_changed(self, _idx: int) -> None:
        self._active_letter = ""
        self._load_selected_checklist_items()

    def _load_selected_checklist_items(self) -> None:
        data = self.combo_cl.currentData()
        items: list[ChecklistItem] = []
        if isinstance(data, tuple):
            kind, val = data
            if kind == "date":
                _cls, items = self.catalog.db.get_checklist_species_for_date(str(val))
            elif kind == "id":
                cl = self.catalog.db.get_checklist(int(val))
                if cl is not None:
                    items = cl.items

        self._sorted_rows = sort_checklist_items_by_pinyin(items, self.catalog)
        report_sp_set = {row[3].common_name_cn for row in self._sorted_rows}
        self._checked_species = (self._checked_species | self._initial_photo_species) & report_sp_set
        self._rebuild_letter_buttons()
        self._rebuild_list_items()
        self._update_summary_label()

    def _rebuild_letter_buttons(self) -> None:
        for b in self._letter_group.buttons():
            self._letter_group.removeButton(b)
        while self.letter_layout.count():
            child = self.letter_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        letters = sorted({row[0] for row in self._sorted_rows if row[0] != "#"})
        btn_all = QPushButton("全部")
        btn_all.setCheckable(True)
        btn_all.setChecked(self._active_letter == "")
        btn_all.setStyleSheet("font-size: 11px; padding: 2px 7px;")
        btn_all.clicked.connect(lambda: self._set_letter_filter(""))
        self._letter_group.addButton(btn_all)
        self.letter_layout.addWidget(btn_all)

        for let in letters:
            b = QPushButton(let)
            b.setCheckable(True)
            b.setChecked(self._active_letter == let)
            b.setFixedWidth(26)
            b.setStyleSheet("font-size: 11px; padding: 2px 0px; font-weight: 700;")
            b.clicked.connect(lambda _c=False, l=let: self._set_letter_filter(l))
            self._letter_group.addButton(b)
            self.letter_layout.addWidget(b)

        self.letter_layout.addStretch(1)

    def _set_letter_filter(self, letter: str) -> None:
        self._active_letter = letter
        self._rebuild_list_items()

    def _rebuild_list_items(self) -> None:
        self._updating_list = True
        self.list_widget.clear()

        kw = self.edit_filter.text().strip().lower()
        alpha_kw = re.sub(r"[\s\-_·']", "", kw)
        bold_font = QFont("Microsoft YaHei UI", 10)

        for first_let, ini, full_py, it, taxon in self._sorted_rows:
            if self._active_letter and first_let != self._active_letter:
                continue
            if kw:
                hay_cn = it.common_name_cn.lower()
                hay_sci = (it.scientific_name or (taxon.scientific_name if taxon else "")).lower()
                if not (
                    kw in hay_cn
                    or kw in hay_sci
                    or (alpha_kw and (alpha_kw in ini or alpha_kw in full_py))
                ):
                    continue

            sci = it.scientific_name or (taxon.scientific_name if taxon else "")
            fam = f" · {taxon.family_cn}" if (taxon and taxon.family_cn) else ""
            cnt_txt = f"数量:{it.count_str}" if it.count_str else ""
            meta_parts = [x for x in (cnt_txt, fam.lstrip(" ·"), sci) if x]
            meta_str = f"   ({' · '.join(meta_parts)})" if meta_parts else ""
            ini_badge = f"[{first_let} · {ini}]" if ini else f"[{first_let}]"

            item_w = QListWidgetItem(f"{ini_badge}   {it.common_name_cn}{meta_str}")
            item_w.setFont(bold_font)
            item_w.setData(Qt.ItemDataRole.UserRole, it.common_name_cn)
            item_w.setFlags(
                Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsUserCheckable
            )
            is_checked = it.common_name_cn in self._checked_species
            item_w.setCheckState(Qt.CheckState.Checked if is_checked else Qt.CheckState.Unchecked)
            if is_checked:
                item_w.setForeground(QColor("#6ee7b7"))
            self.list_widget.addItem(item_w)

        self._updating_list = False
        self._update_summary_label()

    def _on_item_row_clicked(self, item: QListWidgetItem) -> None:
        # Allow clicking anywhere on the row text (not only the tiny checkbox square) to toggle selection!
        sp_cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if not sp_cn:
            return
        # Note: if user clicked directly on the checkbox indicator, itemChanged already updated _checked_species;
        # sync check state cleanly based on whether itemChanged just fired or row body was clicked:
        currently_in_set = sp_cn in self._checked_species
        widget_checked = item.checkState() == Qt.CheckState.Checked
        if currently_in_set == widget_checked:
            # Row text was clicked -> toggle!
            new_state = Qt.CheckState.Unchecked if widget_checked else Qt.CheckState.Checked
            item.setCheckState(new_state)

    def _on_item_check_changed(self, item: QListWidgetItem) -> None:
        if self._updating_list:
            return
        sp_cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if not sp_cn:
            return
        if item.checkState() == Qt.CheckState.Checked:
            self._checked_species.add(sp_cn)
            item.setForeground(QColor("#6ee7b7"))
        else:
            self._checked_species.discard(sp_cn)
            item.setForeground(QColor("#e8eaed"))
        self._update_summary_label()

    def _check_all_visible(self) -> None:
        self._updating_list = True
        for i in range(self.list_widget.count()):
            it = self.list_widget.item(i)
            sp_cn = str(it.data(Qt.ItemDataRole.UserRole) or "")
            if sp_cn:
                self._checked_species.add(sp_cn)
                it.setCheckState(Qt.CheckState.Checked)
                it.setForeground(QColor("#6ee7b7"))
        self._updating_list = False
        self._update_summary_label()

    def _uncheck_all(self) -> None:
        self._checked_species.clear()
        self._rebuild_list_items()

    def _update_summary_label(self) -> None:
        sel = self.selected_species()
        if not sel:
            self.lbl_summary.setText("尚未勾选鸟种（点击列表行即可勾选多个同框鸟种）")
        else:
            preview = "、".join(sel[:6])
            more = f" 等 {len(sel)} 种" if len(sel) > 6 else f"（共 {len(sel)} 种）"
            self.lbl_summary.setText(f"✓ 已勾选：{preview}{more}")

    def _confirm(self, mode: str) -> None:
        if mode == "add" and not self._checked_species:
            QMessageBox.information(self, "请勾选鸟种", "请至少勾选一种要添加到照片的鸟类。")
            return
        self._result_mode = mode
        self.accept()


class QuickAddSpeciesDialog(QDialog):
    """Popup dialog opened by the `+` button to search & multi-add co-occurring species from the full checklist."""

    def __init__(
        self,
        parent: QWidget | None,
        catalog: CatalogService,
        *,
        same_date_items: list[ChecklistItem] | None = None,
        already_on_photo: list[str] | None = None,
    ) -> None:
        super().__init__(parent)
        self.catalog = catalog
        self._same_date_items = list(same_date_items or [])
        self._already = set(already_on_photo or [])
        self._checked_to_add: list[str] = []
        self._updating_list = False

        self.setWindowTitle("＋ 为照片添加其他同框鸟种（支持拼音检索与多选）")
        self.resize(580, 500)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(8)

        if self._already:
            lbl_cur = QLabel(f"当前照片已有鸟种：{' / '.join(already_on_photo or [])}")
            lbl_cur.setWordWrap(True)
            lbl_cur.setStyleSheet("color: #93c5fd; font-size: 12px; font-weight: 600;")
            root.addWidget(lbl_cur)

        self.edit_search = QLineEdit()
        self.edit_search.setPlaceholderText("输入鸟名 / 拼音首字母 (如 fzy、dbl、ptcn) / 学名 搜索并勾选...")
        self.edit_search.setClearButtonEnabled(True)
        self.edit_search.textChanged.connect(lambda _t: self._refresh_results())
        root.addWidget(self.edit_search)

        self.list_widget = QListWidget()
        self.list_widget.setSpacing(2)
        self.list_widget.itemChanged.connect(self._on_item_changed)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        root.addWidget(self.list_widget, 1)

        self.lbl_picked = QLabel("待追加鸟种：（请在上方搜索并勾选，可连续搜索勾选多种）")
        self.lbl_picked.setWordWrap(True)
        self.lbl_picked.setStyleSheet("color: #7ee2b8; font-size: 12px; font-weight: 600;")
        root.addWidget(self.lbl_picked)

        btn_row = QHBoxLayout()
        btn_cancel = QPushButton("取消")
        btn_cancel.clicked.connect(self.reject)
        self.btn_ok = QPushButton("＋ 添加所选鸟种到照片")
        self.btn_ok.setObjectName("PrimaryButton")
        self.btn_ok.clicked.connect(self._accept_checked)
        btn_row.addWidget(btn_cancel)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_ok)
        root.addLayout(btn_row)

        self._refresh_results()
        self.edit_search.setFocus()

    def species_to_add(self) -> list[str]:
        return list(self._checked_to_add)

    def _refresh_results(self) -> None:
        self._updating_list = True
        self.list_widget.clear()

        kw = self.edit_search.text().strip()
        rows: list[tuple[str, str]] = []  # (cn, display_label)
        seen: set[str] = set()

        # 1. If keyword is empty, show already-checked items + Pinyin-sorted same-date report birds (or top China birds)
        for c_sp in self._checked_to_add:
            if c_sp not in seen:
                seen.add(c_sp)
                tx = self.catalog.taxonomy.lookup_by_cn(c_sp)
                py_s = f" [{tx.pinyin_initials}]" if (tx and tx.pinyin_initials) else ""
                rows.append((c_sp, f"✓ {c_sp}{py_s}"))

        if not kw:
            for let, ini, _fp, it, tx in sort_checklist_items_by_pinyin(self._same_date_items, self.catalog):
                if it.common_name_cn not in seen and it.common_name_cn not in self._already:
                    seen.add(it.common_name_cn)
                    sci = it.scientific_name or (tx.scientific_name if tx else "")
                    rows.append((it.common_name_cn, f"📋 [{let}·{ini}] {it.common_name_cn}  (当日记录 {it.count_str}只 · {sci})"))
        else:
            matches = self.catalog.taxonomy.search(kw, limit=40, prefer_china=True)
            same_cn_set = {i.common_name_cn for i in self._same_date_items}
            # Put same-date matches first!
            matches.sort(key=lambda e: (0 if e.common_name_cn in same_cn_set else 1))
            for entry in matches:
                if entry.common_name_cn in seen or entry.common_name_cn in self._already:
                    continue
                seen.add(entry.common_name_cn)
                badge = "📋 [当日记录] " if entry.common_name_cn in same_cn_set else ("" if entry.in_china else "🌏 ")
                py_t = f"[{entry.pinyin_initials}]" if entry.pinyin_initials else ""
                rows.append(
                    (
                        entry.common_name_cn,
                        f"{badge}{entry.common_name_cn}  {py_t} · {entry.family_cn} ({entry.scientific_name})",
                    )
                )

        for cn, disp in rows:
            item_w = QListWidgetItem(disp)
            item_w.setData(Qt.ItemDataRole.UserRole, cn)
            item_w.setFlags(
                Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsUserCheckable
            )
            checked = cn in self._checked_to_add
            item_w.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
            if checked:
                item_w.setForeground(QColor("#6ee7b7"))
            self.list_widget.addItem(item_w)

        self._updating_list = False

    def _on_item_clicked(self, item: QListWidgetItem) -> None:
        cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if not cn:
            return
        in_list = cn in self._checked_to_add
        w_checked = item.checkState() == Qt.CheckState.Checked
        if in_list == w_checked:
            item.setCheckState(Qt.CheckState.Unchecked if w_checked else Qt.CheckState.Checked)

    def _on_item_changed(self, item: QListWidgetItem) -> None:
        if self._updating_list:
            return
        cn = str(item.data(Qt.ItemDataRole.UserRole) or "")
        if not cn:
            return
        if item.checkState() == Qt.CheckState.Checked:
            if cn not in self._checked_to_add:
                self._checked_to_add.append(cn)
            item.setForeground(QColor("#6ee7b7"))
        else:
            if cn in self._checked_to_add:
                self._checked_to_add.remove(cn)
            item.setForeground(QColor("#e8eaed"))

        if self._checked_to_add:
            self.lbl_picked.setText(f"待追加 ({len(self._checked_to_add)} 种)：{'、'.join(self._checked_to_add)}")
        else:
            self.lbl_picked.setText("待追加鸟种：（请在上方搜索并勾选，可连续搜索勾选多种）")

    def _accept_checked(self) -> None:
        if not self._checked_to_add:
            # Convenience: if user typed a query and hit OK without checking, resolve top match
            kw = self.edit_search.text().strip()
            if kw:
                entry = self.catalog.resolve_taxon(kw)
                if entry.common_name_cn:
                    self._checked_to_add.append(entry.common_name_cn)
        if not self._checked_to_add:
            QMessageBox.information(self, "提示", "请先搜索并勾选要追加的鸟种。")
            return
        self.accept()

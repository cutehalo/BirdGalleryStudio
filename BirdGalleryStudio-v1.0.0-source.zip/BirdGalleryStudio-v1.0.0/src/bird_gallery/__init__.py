"""Local Bird Gallery desktop application & optional GPU AI engine."""

from __future__ import annotations

from typing import TYPE_CHECKING

from bird_gallery.catalog import CatalogService, FieldGuideOverview
from bird_gallery.checklists import PersonalChecklistService
from bird_gallery.china_regions import (
    CityEntry,
    gcj02_to_wgs84,
    infer_province_city,
    list_cities,
    list_provinces,
    wgs84_to_gcj02,
)
from bird_gallery.classifier import BioClipClassifier, SpeciesClassifier
from bird_gallery.config import EngineConfig
from bird_gallery.db import GalleryDatabase
from bird_gallery.detector import BirdDetector, RawDetection, YoloBirdDetector
from bird_gallery.ebird import EBirdLocationService
from bird_gallery.exporter import ArchiveExporter
from bird_gallery.models import (
    Album,
    BirdDetection,
    BirdingChecklist,
    ChecklistItem,
    EBirdHotspot,
    ExifMetadata,
    ExportItem,
    ExportReport,
    FavoriteLocation,
    FieldGuideSpeciesCard,
    FilterQuery,
    PhotoRecord,
    ReviewStatus,
    ScanSummary,
    SpeciesPrediction,
)
from bird_gallery.review import ReviewService
from bird_gallery.taxonomy import TaxonEntry, TaxonomyMapper

if TYPE_CHECKING:
    from bird_gallery.pipeline import BirdGalleryPipeline
    from bird_gallery.quality import compute_sharpness_metrics


def __getattr__(name: str):
    if name == "BirdGalleryPipeline":
        from bird_gallery.pipeline import BirdGalleryPipeline

        return BirdGalleryPipeline
    if name == "compute_sharpness_metrics":
        from bird_gallery.quality import compute_sharpness_metrics

        return compute_sharpness_metrics
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "Album",
    "ArchiveExporter",
    "BioClipClassifier",
    "BirdDetection",
    "BirdDetector",
    "BirdGalleryPipeline",
    "BirdingChecklist",
    "CatalogService",
    "ChecklistItem",
    "CityEntry",
    "EBirdHotspot",
    "EBirdLocationService",
    "EngineConfig",
    "ExifMetadata",
    "ExportItem",
    "ExportReport",
    "FavoriteLocation",
    "FieldGuideOverview",
    "FieldGuideSpeciesCard",
    "FilterQuery",
    "GalleryDatabase",
    "PersonalChecklistService",
    "PhotoRecord",
    "RawDetection",
    "ReviewService",
    "ReviewStatus",
    "ScanSummary",
    "SpeciesClassifier",
    "SpeciesPrediction",
    "TaxonEntry",
    "TaxonomyMapper",
    "YoloBirdDetector",
    "compute_sharpness_metrics",
    "gcj02_to_wgs84",
    "infer_province_city",
    "list_cities",
    "list_provinces",
    "wgs84_to_gcj02",
]

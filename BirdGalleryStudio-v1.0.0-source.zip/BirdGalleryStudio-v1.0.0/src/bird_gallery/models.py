"""Core domain data structures for bird photos, detections, albums, field guide, and exports."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class ReviewStatus(str, Enum):
    """Manual review workflow state for a photo."""

    UNREVIEWED = "unreviewed"
    CONFIRMED = "confirmed"
    CORRECTED = "corrected"
    REJECTED = "rejected"


@dataclass(slots=True)
class ExifMetadata:
    """Extracted photographic and GPS metadata."""

    taken_at: str | None = None  # ISO-8601 string, e.g. 2026-10-05T07:32:10
    camera_make: str | None = None
    camera_model: str | None = None
    lens_model: str | None = None
    focal_length_mm: float | None = None
    aperture: float | None = None
    shutter_speed: str | None = None
    iso: int | None = None
    gps_lat: float | None = None
    gps_lon: float | None = None


@dataclass(slots=True)
class SpeciesPrediction:
    """Single species candidate produced by a classifier."""

    rank: int
    scientific_name: str
    score: float
    common_name_en: str = ""
    common_name_cn: str = ""
    order_name: str = ""
    order_cn: str = ""
    family_name: str = ""
    family_cn: str = ""
    genus_name: str = ""


@dataclass(slots=True)
class BirdDetection:
    """Detected bird bounding box with sharpness score and species predictions."""

    bbox: tuple[int, int, int, int]  # (x1, y1, x2, y2) in preview image coordinates
    detect_conf: float
    sharpness_score: float = 0.0  # Normalized 0..100 sharpness score inside bird crop
    raw_laplacian_var: float = 0.0
    predictions: list[SpeciesPrediction] = field(default_factory=list)
    detection_id: int | None = None

    @property
    def top_prediction(self) -> SpeciesPrediction | None:
        return self.predictions[0] if self.predictions else None

    @property
    def area(self) -> int:
        x1, y1, x2, y2 = self.bbox
        return max(0, x2 - x1) * max(0, y2 - y1)


@dataclass(slots=True)
class Album:
    """User-created virtual album (one photo can belong to multiple albums)."""

    album_id: int
    name: str
    description: str = ""
    photo_count: int = 0
    created_at: str = ""


@dataclass(slots=True)
class EBirdHotspot:
    """Official eBird Hotspot entry cached locally or returned from eBird API v2."""

    loc_id: str  # e.g. "L2586431"
    loc_name: str
    country_code: str = ""
    subnational1_code: str = ""  # e.g. "CN-11"
    subnational2_code: str = ""  # e.g. prefecture code if provided by eBird
    city_name: str = ""  # Prefecture-level city / district, e.g. "深圳市", "海淀区"
    lat: float | None = None
    lng: float | None = None
    num_species: int = 0
    latest_obs_dt: str = ""
    pinyin_initials: str = ""
    pinyin_full: str = ""
    distance_km: float | None = None  # Populated during GPS nearby search

    @property
    def ebird_url(self) -> str:
        return f"https://ebird.org/hotspot/{self.loc_id}"


@dataclass(slots=True)
class FavoriteLocation:
    """User-configured frequent birding spot with province + prefecture/city & optional eBird link."""

    fav_id: int
    name: str  # User display alias, e.g. "北京·奥森北园"
    province: str = ""  # e.g. "北京", "广东", "云南"
    city: str = ""  # Prefecture-level city / district, e.g. "朝阳区", "深圳市", "德宏傣族景颇族自治州"
    region: str = ""  # Combined display label, e.g. "广东·深圳市"
    ebird_loc_id: str | None = None
    ebird_loc_name: str = ""
    lat: float | None = None
    lng: float | None = None
    notes: str = ""
    sort_order: int = 0
    use_count: int = 0
    created_at: str = ""

    @property
    def ebird_url(self) -> str | None:
        return f"https://ebird.org/hotspot/{self.ebird_loc_id}" if self.ebird_loc_id else None

    @property
    def admin_label(self) -> str:
        if self.province and self.city:
            return f"{self.province}·{self.city}"
        return self.province or self.city or self.region


@dataclass(slots=True)
class ChecklistItem:
    """Single species observation row inside a personal birding checklist."""

    common_name_cn: str
    scientific_name: str = ""
    count_num: int = 1  # 0 when recorded as 'X' / present only
    count_str: str = "1"
    remarks: str = ""


@dataclass(slots=True)
class BirdingChecklist:
    """Personal birding checklist synced/imported from BirdReport.cn, eBird, or CSV/Excel."""

    checklist_id: int
    obs_date: str  # YYYY-MM-DD
    obs_time: str = ""  # HH:MM optional
    source: str = "birdreport"  # 'birdreport' | 'ebird' | 'file' | 'manual'
    external_id: str = ""  # e.g. 'S89703713' or BirdReport ID
    location_name: str = ""
    province: str = ""
    city: str = ""
    ebird_loc_id: str | None = None
    lat: float | None = None
    lng: float | None = None
    species_count: int = 0
    notes: str = ""
    created_at: str = ""
    items: list[ChecklistItem] = field(default_factory=list)

    @property
    def admin_label(self) -> str:
        if self.province and self.city:
            return f"{self.province}·{self.city}"
        return self.province or self.city


@dataclass(slots=True)
class PhotoRecord:
    """Full database representation of an indexed photo."""

    file_path: str
    file_name: str
    file_ext: str
    file_size: int
    file_mtime: float
    is_raw: bool
    folder_path: str = ""
    width: int = 0
    height: int = 0
    file_hash: str | None = None
    thumbnail_path: str | None = None
    exif: ExifMetadata = field(default_factory=ExifMetadata)

    # Organization attributes (date & location)
    taken_date: str | None = None  # YYYY-MM-DD (effective date for timeline albums)
    manual_date: str | None = None  # YYYY-MM-DD user override
    location_name: str = ""  # User-assigned spot name, e.g. "北京·奥森公园"
    location_province: str = ""  # Province/Municipality, e.g. "广东"
    location_city: str = ""  # Prefecture-level city/district, e.g. "深圳市"
    ebird_loc_id: str | None = None  # Linked eBird Hotspot ID, e.g. "L2586431"

    # Aggregated AI / Species fields
    has_bird: bool = False
    bird_count: int = 0
    is_blurry: bool = False
    best_sharpness: float = 0.0
    primary_scientific_name: str = ""
    primary_common_name_cn: str = ""
    primary_common_name_en: str = ""
    primary_order_cn: str = ""
    primary_family_cn: str = ""
    primary_confidence: float = 0.0

    # Manual review & culling fields
    review_status: ReviewStatus = ReviewStatus.UNREVIEWED
    manual_scientific_name: str | None = None
    manual_common_name_cn: str | None = None
    rating: int = 0  # 0..5 stars
    pick_flag: int = 0  # 1 = Pick (留片), 0 = Unflagged, -1 = Rejected (淘汰)
    is_rejected: bool = False
    notes: str = ""

    # Timestamps & DB ID
    photo_id: int | None = None
    scanned_at: str | None = None
    updated_at: str | None = None

    # Child detections, multi-species tags & album memberships (loaded on demand)
    detections: list[BirdDetection] = field(default_factory=list)
    species_list: list[str] = field(default_factory=list)
    album_ids: list[int] = field(default_factory=list)

    @property
    def effective_scientific_name(self) -> str:
        """Return manually assigned/corrected scientific name if set, otherwise primary."""
        return self.manual_scientific_name or self.primary_scientific_name

    @property
    def effective_common_name_cn(self) -> str:
        """Return manually assigned/corrected Chinese name if set, otherwise primary."""
        if self.species_list:
            return self.species_list[0]
        return (
            self.manual_common_name_cn
            or self.primary_common_name_cn
            or self.effective_scientific_name
            or "未知鸟种"
        )

    @property
    def all_species_cn(self) -> list[str]:
        """Return all assigned Chinese bird species names on this photo (1 or multiple)."""
        if self.species_list:
            return list(self.species_list)
        if self.has_assigned_species:
            return [self.effective_common_name_cn]
        return []

    @property
    def display_species_badge(self) -> str:
        """All assigned species joined cleanly (never truncating with '+N')."""
        all_sp = self.all_species_cn
        return " · ".join(all_sp) if all_sp else ""

    @property
    def display_species_full(self) -> str:
        """Full multi-species summary string (e.g. '黑脸琵鹭 / 反嘴鹬')."""
        all_sp = self.all_species_cn
        return " / ".join(all_sp) if all_sp else "未归类"

    @property
    def has_assigned_species(self) -> bool:
        """True if one or more bird species are recorded on this photo."""
        return bool(
            self.species_list
            or (self.manual_common_name_cn and self.manual_common_name_cn.strip())
            or (self.manual_scientific_name and self.manual_scientific_name.strip())
            or (self.primary_common_name_cn and self.primary_common_name_cn.strip())
            or (self.primary_scientific_name and self.primary_scientific_name.strip())
        )

    @property
    def display_location(self) -> str:
        """Human-friendly location label falling back to rounded GPS bucket if unnamed."""
        if self.location_name.strip():
            return self.location_name.strip()
        if self.exif.gps_lat is not None and self.exif.gps_lon is not None:
            return format_gps_bucket(self.exif.gps_lat, self.exif.gps_lon)
        return ""


def format_gps_bucket(lat: float, lon: float) -> str:
    """Format unnamed GPS coordinates into a ~1km neighborhood bucket label."""
    ns = "N" if lat >= 0 else "S"
    ew = "E" if lon >= 0 else "W"
    return f"GPS ({abs(lat):.2f}°{ns}, {abs(lon):.2f}°{ew})"


@dataclass(slots=True)
class FilterQuery:
    """Composable query criteria for gallery browsing, multi-album filtering, and export."""

    keyword: str | None = None  # Free-text search across file name, species, location, notes
    species: str | None = None  # Substring match across CN name, EN name, scientific name, family, order
    exact_species_cn: str | None = None  # Exact match on effective Chinese bird name
    exact_order_cn: str | None = None
    exact_family_cn: str | None = None
    unassigned_species_only: bool = False  # True returns photos with no species assigned yet
    folder_path: str | None = None
    include_subfolders: bool = True
    album_id: int | None = None
    date_prefix: str | None = None  # "2026" or "2026-10" or "2026-10-05"
    undated_only: bool = False
    location_key: str | None = None  # Named spot, "GPS (...)" bucket, or "__unlocated__"
    location_province: str | None = None  # Filter by province, e.g. "广东"
    location_city: str | None = None  # Filter by prefecture/city, e.g. "深圳市"
    has_bird: bool | None = None
    min_confidence: float | None = None
    max_confidence: float | None = None
    min_sharpness: float | None = None
    max_sharpness: float | None = None
    min_rating: int | None = None
    max_rating: int | None = None
    pick_only: bool = False
    review_status: ReviewStatus | None = None
    only_reviewed: bool = False  # True matches both CONFIRMED and CORRECTED
    include_rejected: bool = False
    rejected_only: bool = False
    include_blurry: bool = True
    is_raw: bool | None = None
    date_from: str | None = None  # YYYY-MM-DD
    date_to: str | None = None  # YYYY-MM-DD
    sort_by: str = "taken_at_desc"  # taken_at_desc | taken_at_asc | name_asc | rating_desc | confidence_desc | sharpness_desc | id_asc
    limit: int = 5000
    offset: int = 0


@dataclass(slots=True)
class FieldGuideSpeciesCard:
    """Single species entry in the Bird Field Guide (with Life List lit status)."""

    scientific_name: str
    common_name_cn: str
    common_name_en: str
    order_cn: str
    family_cn: str
    is_lit: bool = False
    photo_count: int = 0
    cover_photo_id: int | None = None
    cover_thumbnail_path: str | None = None
    cover_file_path: str | None = None
    first_seen_date: str | None = None


@dataclass(slots=True)
class ScanSummary:
    """Summary metrics returned after scanning or importing a directory."""

    total_discovered: int = 0
    skipped_existing: int = 0
    processed: int = 0
    with_birds: int = 0
    no_birds: int = 0
    flagged_blurry: int = 0
    failed: int = 0
    errors: list[tuple[str, str]] = field(default_factory=list)
    elapsed_seconds: float = 0.0


@dataclass(slots=True)
class ExportItem:
    """Single planned or executed export operation."""

    photo_id: int
    source_path: Path
    target_path: Path
    species_cn: str
    scientific_name: str
    status: str = "planned"  # planned | exported | skipped_exists | missing_source | error
    error: str | None = None


@dataclass(slots=True)
class ExportReport:
    """Summary of an archive export operation."""

    mode: str
    output_dir: Path
    dry_run: bool
    total_matched: int = 0
    exported: int = 0
    skipped: int = 0
    failed: int = 0
    items: list[ExportItem] = field(default_factory=list)

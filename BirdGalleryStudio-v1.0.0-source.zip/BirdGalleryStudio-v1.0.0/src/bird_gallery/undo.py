"""Bounded 10-step Undo Manager for lossless rollback of photo & album operations."""

from __future__ import annotations

from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Callable, Iterator

from bird_gallery.db import GalleryDatabase

MAX_UNDO_STEPS = 10


@dataclass(slots=True)
class UndoEntry:
    """Single atomic undoable user action."""

    description: str
    photo_ids: list[int]
    before_snapshot: dict[int, dict[str, object]]
    created_album_id: int | None = None


class UndoManager:
    """Maintains up to `max_steps` (default 10) snapshots for one-click / Ctrl+Z rollback."""

    def __init__(self, db: GalleryDatabase, *, max_steps: int = MAX_UNDO_STEPS) -> None:
        self.db = db
        self.max_steps = max(1, int(max_steps))
        self._stack: deque[UndoEntry] = deque(maxlen=self.max_steps)
        self._listeners: list[Callable[[], None]] = []

    def add_listener(self, callback: Callable[[], None]) -> None:
        if callback not in self._listeners:
            self._listeners.append(callback)

    def _notify(self) -> None:
        for cb in list(self._listeners):
            cb()

    @property
    def can_undo(self) -> bool:
        return len(self._stack) > 0

    @property
    def count(self) -> int:
        return len(self._stack)

    def latest_description(self) -> str:
        return self._stack[-1].description if self._stack else ""

    def history_descriptions(self) -> list[str]:
        """Return descriptions from newest (next to undo) to oldest."""
        return [entry.description for entry in reversed(self._stack)]

    def clear(self) -> None:
        if self._stack:
            self._stack.clear()
            self._notify()

    @contextmanager
    def record(self, photo_ids: list[int], description: str) -> Iterator[None]:
        """Capture `photo_ids` state before a block and push an UndoEntry if state changed."""
        clean_ids = [int(pid) for pid in dict.fromkeys(photo_ids) if pid is not None]
        if not clean_ids:
            yield
            return

        before = self.db.capture_photos_snapshot(clean_ids)
        yield
        after = self.db.capture_photos_snapshot(clean_ids)

        if before != after:
            self._stack.append(
                UndoEntry(
                    description=description,
                    photo_ids=clean_ids,
                    before_snapshot=before,
                )
            )
            self._notify()

    def push_album_creation(
        self,
        *,
        created_album_id: int,
        photo_ids: list[int],
        before_snapshot: dict[int, dict[str, object]],
        description: str,
    ) -> None:
        """Record creating a custom album (and optionally adding selected photos to it)."""
        clean_ids = [int(pid) for pid in dict.fromkeys(photo_ids) if pid is not None]
        self._stack.append(
            UndoEntry(
                description=description,
                photo_ids=clean_ids,
                before_snapshot=before_snapshot,
                created_album_id=int(created_album_id),
            )
        )
        self._notify()

    def undo(self) -> UndoEntry | None:
        """Pop and restore the most recent operation. Returns the undone UndoEntry or None."""
        if not self._stack:
            return None
        entry = self._stack.pop()
        self.db.restore_photos_snapshot(
            entry.before_snapshot,
            delete_album_id=entry.created_album_id,
        )
        self._notify()
        return entry
